from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional, Tuple, Union

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader


class Role(str, Enum):
    system = "system"
    user = "user"
    assistant = "assistant"
    function = "function"
    tool = "tool"


@dataclass
class Turn:
    role: Role
    content: str
    name: Optional[str] = None


@dataclass
class ConversationSample:
    turns: List[Turn] = field(default_factory=list)
    system: Optional[str] = None
    tools: Optional[str] = None


def format_conversation(
    conversation: ConversationSample,
    tokenizer: Optional[Any] = None,
    add_generation_prompt: bool = False,
    continue_last_message: bool = False,
) -> str:
    formatted = ""

    if conversation.system:
        formatted += f"<|im_start|>system\n{conversation.system}<|im_end|>\n"

    for turn in conversation.turns:
        if turn.role == Role.system:
            formatted += f"<|im_start|>system\n{turn.content}<|im_end|>\n"
        elif turn.role == Role.user:
            if turn.name:
                formatted += f"<|im_start|>user name={turn.name}\n{turn.content}<|im_end|>\n"
            else:
                formatted += f"<|im_start|>user\n{turn.content}<|im_end|>\n"
        elif turn.role == Role.assistant:
            formatted += f"<|im_start|>assistant\n{turn.content}<|im_end|>\n"
        elif turn.role == Role.function:
            formatted += f"<|im_start|>function\n{turn.content}<|im_end|>\n"
        elif turn.role == Role.tool:
            formatted += f"<|im_start|>tool\n{turn.content}<|im_end|>\n"

    if add_generation_prompt:
        formatted += "<|im_start|>assistant\n"
    elif continue_last_message and conversation.turns:
        last_turn = conversation.turns[-1]
        if last_turn.role == Role.assistant:
            formatted += last_turn.content

    return formatted


def prepare_conversation_dataset(
    conversations: List[Dict[str, Any]],
    tokenizer: Any,
    max_length: int = 2048,
    mask_system: bool = True,
    mask_user: bool = True,
    system_field: str = "system",
    turns_field: str = "turns",
    role_field: str = "role",
    content_field: str = "content",
) -> List[Dict[str, torch.Tensor]]:
    processed = []

    for conv in conversations:
        sample = ConversationSample()
        sample.system = conv.get(system_field)
        for turn_data in conv.get(turns_field, []):
            role_str = turn_data.get(role_field, "user")
            content = turn_data.get(content_field, "")
            try:
                role = Role(role_str)
            except ValueError:
                role = Role.user
            sample.turns.append(Turn(role=role, content=content))

        token_ids = []
        labels = []
        attention_mask = []

        if sample.system:
            system_text = f"<|im_start|>system\n{sample.system}<|im_end|>\n"
            system_ids = tokenizer.encode(system_text, add_special_tokens=False)
            token_ids.extend(system_ids)
            if mask_system:
                labels.extend([-100] * len(system_ids))
            else:
                labels.extend(system_ids)
            attention_mask.extend([1] * len(system_ids))

        for turn in sample.turns:
            if turn.role == Role.user:
                turn_text = f"<|im_start|>user\n{turn.content}<|im_end|>\n"
            elif turn.role == Role.assistant:
                turn_text = f"<|im_start|>assistant\n{turn.content}<|im_end|>\n"
            elif turn.role == Role.system:
                turn_text = f"<|im_start|>system\n{turn.content}<|im_end|>\n"
            elif turn.role == Role.function:
                turn_text = f"<|im_start|>function\n{turn.content}<|im_end|>\n"
            elif turn.role == Role.tool:
                turn_text = f"<|im_start|>tool\n{turn.content}<|im_end|>\n"
            else:
                turn_text = f"<|im_start|>{turn.role.value}\n{turn.content}<|im_end|>\n"

            turn_ids = tokenizer.encode(turn_text, add_special_tokens=False)

            token_ids.extend(turn_ids)
            attention_mask.extend([1] * len(turn_ids))

            if turn.role == Role.assistant:
                labels.extend(turn_ids)
            elif turn.role == Role.assistant and mask_user:
                labels.extend([-100] * len(turn_ids))
            else:
                labels.extend([-100] * len(turn_ids))

        if len(token_ids) > max_length:
            token_ids = token_ids[-max_length:]
            labels = labels[-max_length:]
            attention_mask = attention_mask[-max_length:]

        eos_id = tokenizer.eos_token_id if hasattr(tokenizer, "eos_token_id") and tokenizer.eos_token_id is not None else 0
        token_ids.append(eos_id)
        labels.append(eos_id)
        attention_mask.append(1)

        if len(token_ids) < max_length:
            pad_id = tokenizer.pad_token_id if hasattr(tokenizer, "pad_token_id") and tokenizer.pad_token_id is not None else 0
            pad_len = max_length - len(token_ids)
            token_ids.extend([pad_id] * pad_len)
            labels.extend([-100] * pad_len)
            attention_mask.extend([0] * pad_len)
        else:
            token_ids = token_ids[:max_length]
            labels = labels[:max_length]
            attention_mask = attention_mask[:max_length]

        processed.append({
            "input_ids": torch.tensor(token_ids, dtype=torch.long),
            "labels": torch.tensor(labels, dtype=torch.long),
            "attention_mask": torch.tensor(attention_mask, dtype=torch.long),
        })

    return processed


class ConversationDataset(Dataset):
    def __init__(
        self,
        conversations: List[Dict[str, Any]],
        tokenizer: Any,
        max_length: int = 2048,
        mask_system: bool = True,
        mask_user: bool = True,
        truncation_side: str = "left",
    ):
        self.tokenizer = tokenizer
        self.max_length = max_length
        self.mask_system = mask_system
        self.mask_user = mask_user
        self.truncation_side = truncation_side

        self.examples = prepare_conversation_dataset(
            conversations=conversations,
            tokenizer=tokenizer,
            max_length=max_length,
            mask_system=mask_system,
            mask_user=mask_user,
        )

    def __len__(self) -> int:
        return len(self.examples)

    def __getitem__(self, idx: int) -> Dict[str, torch.Tensor]:
        return self.examples[idx]

    def truncate_conversation(self, token_ids: List[int], labels: List[int], mask: List[int]) -> Tuple[List[int], List[int], List[int]]:
        if len(token_ids) <= self.max_length:
            return token_ids, labels, mask

        if self.truncation_side == "left":
            return (
                token_ids[-self.max_length:],
                labels[-self.max_length:],
                mask[-self.max_length:],
            )
        else:
            return (
                token_ids[:self.max_length],
                labels[:self.max_length],
                mask[:self.max_length],
            )


class ConversationDataCollator:
    def __init__(
        self,
        tokenizer: Any,
        max_length: int = 2048,
        pad_token_id: int = 0,
        ignore_index: int = -100,
    ):
        self.tokenizer = tokenizer
        self.max_length = max_length
        self.pad_token_id = pad_token_id if hasattr(tokenizer, "pad_token_id") else pad_token_id
        self.ignore_index = ignore_index

    def __call__(self, batch: List[Dict[str, torch.Tensor]]) -> Dict[str, torch.Tensor]:
        input_ids = [item["input_ids"] for item in batch]
        labels = [item["labels"] for item in batch]
        attention_masks = [item["attention_mask"] for item in batch]

        max_len = max(ids.size(0) for ids in input_ids)
        max_len = min(max_len, self.max_length)

        padded_input_ids = []
        padded_labels = []
        padded_attention_masks = []

        for i in range(len(input_ids)):
            ids = input_ids[i]
            lbls = labels[i]
            mask = attention_masks[i]

            seq_len = ids.size(0)
            if seq_len > max_len:
                if self.truncation_side == "left":
                    padded_input_ids.append(ids[-max_len:])
                    padded_labels.append(lbls[-max_len:])
                    padded_attention_masks.append(mask[-max_len:])
                else:
                    padded_input_ids.append(ids[:max_len])
                    padded_labels.append(lbls[:max_len])
                    padded_attention_masks.append(mask[:max_len])
            else:
                pad_len = max_len - seq_len
                padded_input_ids.append(
                    F.pad(ids, (0, pad_len), value=self.pad_token_id)
                )
                padded_labels.append(
                    F.pad(lbls, (0, pad_len), value=self.ignore_index)
                )
                padded_attention_masks.append(
                    F.pad(mask, (0, pad_len), value=0)
                )

        return {
            "input_ids": torch.stack(padded_input_ids, dim=0),
            "labels": torch.stack(padded_labels, dim=0),
            "attention_mask": torch.stack(padded_attention_masks, dim=0),
        }


class ConversationTuner:
    def __init__(
        self,
        model: nn.Module,
        tokenizer: Any,
        max_length: int = 2048,
        learning_rate: float = 2e-5,
        weight_decay: float = 0.01,
        num_epochs: int = 3,
        batch_size: int = 4,
        gradient_accumulation_steps: int = 4,
        max_grad_norm: float = 1.0,
        warmup_ratio: float = 0.03,
        device: Optional[torch.device] = None,
        mask_system: bool = True,
        mask_user: bool = True,
    ):
        self.model = model
        self.tokenizer = tokenizer
        self.max_length = max_length
        self.learning_rate = learning_rate
        self.weight_decay = weight_decay
        self.num_epochs = num_epochs
        self.batch_size = batch_size
        self.gradient_accumulation_steps = gradient_accumulation_steps
        self.max_grad_norm = max_grad_norm
        self.warmup_ratio = warmup_ratio
        self.mask_system = mask_system
        self.mask_user = mask_user
        self.device = device or torch.device("cuda" if torch.cuda.is_available() else "cpu")

        self.model.to(self.device)

        no_decay = ["bias", "LayerNorm", "layer_norm", "layernorm", "ln", "norm", "embed"]
        decay_params = []
        no_decay_params = []
        for name, param in self.model.named_parameters():
            if not param.requires_grad:
                continue
            if any(nd in name.lower() for nd in no_decay):
                no_decay_params.append(param)
            else:
                decay_params.append(param)

        param_groups = [
            {"params": decay_params, "weight_decay": weight_decay},
            {"params": no_decay_params, "weight_decay": 0.0},
        ]
        self.optimizer = torch.optim.AdamW(param_groups, lr=learning_rate)

    def _create_scheduler(self, num_training_steps: int) -> torch.optim.lr_scheduler.LambdaLR:
        warmup_steps = int(num_training_steps * self.warmup_ratio)

        def lr_lambda(current_step: int) -> float:
            if current_step < warmup_steps:
                return float(current_step) / float(max(1, warmup_steps))
            progress = float(current_step - warmup_steps) / float(
                max(1, num_training_steps - warmup_steps)
            )
            return 0.5 * (1.0 + torch.cos(torch.tensor(progress * torch.pi)).item())

        return torch.optim.lr_scheduler.LambdaLR(self.optimizer, lr_lambda)

    def train(
        self,
        dataset: ConversationDataset,
        eval_dataset: Optional[ConversationDataset] = None,
        output_dir: str = "./conversation_tuning_output",
    ) -> Dict[str, float]:
        collator = ConversationDataCollator(
            tokenizer=self.tokenizer,
            max_length=self.max_length,
        )

        dataloader = DataLoader(
            dataset,
            batch_size=self.batch_size,
            shuffle=True,
            collate_fn=collator,
        )

        num_training_steps = len(dataloader) * self.num_epochs // self.gradient_accumulation_steps
        scheduler = self._create_scheduler(num_training_steps)

        self.model.train()
        global_step = 0
        total_loss = 0.0
        best_loss = float("inf")
        accum_loss = 0.0
        accum_count = 0

        for epoch in range(self.num_epochs):
            epoch_loss = 0.0
            num_batches = 0

            for batch_idx, batch in enumerate(dataloader):
                batch = {k: v.to(self.device) for k, v in batch.items()}

                outputs = self.model(**batch)
                loss = outputs["loss"] if isinstance(outputs, dict) else outputs.loss
                loss = loss / self.gradient_accumulation_steps
                loss.backward()

                accum_loss += loss.item()
                accum_count += 1
                epoch_loss += loss.item()
                num_batches += 1
                global_step += 1

                if global_step % self.gradient_accumulation_steps == 0:
                    if self.max_grad_norm > 0.0:
                        torch.nn.utils.clip_grad_norm_(self.model.parameters(), self.max_grad_norm)
                    self.optimizer.step()
                    scheduler.step()
                    self.optimizer.zero_grad()

                    if global_step % 100 == 0:
                        total_loss = 0.0

            avg_epoch_loss = epoch_loss / max(1, num_batches)

            if eval_dataset is not None:
                eval_loss = self.evaluate(eval_dataset)
                if eval_loss < best_loss:
                    best_loss = eval_loss
                    self.save_pretrained(output_dir)

        return {"loss": avg_epoch_loss, "best_eval_loss": best_loss}

    def evaluate(self, dataset: ConversationDataset) -> float:
        collator = ConversationDataCollator(
            tokenizer=self.tokenizer,
            max_length=self.max_length,
        )
        dataloader = DataLoader(
            dataset,
            batch_size=self.batch_size,
            shuffle=False,
            collate_fn=collator,
        )

        self.model.eval()
        total_loss = 0.0
        num_batches = 0

        with torch.no_grad():
            for batch in dataloader:
                batch = {k: v.to(self.device) for k, v in batch.items()}
                outputs = self.model(**batch)
                loss = outputs["loss"] if isinstance(outputs, dict) else outputs.loss
                total_loss += loss.item()
                num_batches += 1

        self.model.train()
        return total_loss / max(1, num_batches)

    def chat(
        self,
        messages: List[Dict[str, str]],
        max_new_tokens: int = 512,
        temperature: float = 0.7,
        top_p: float = 0.9,
        top_k: int = 50,
        repetition_penalty: float = 1.1,
        **kwargs,
    ) -> str:
        conversation = ConversationSample()
        for msg in messages:
            role = msg.get("role", "user")
            content = msg.get("content", "")
            try:
                conversation.turns.append(Turn(role=Role(role), content=content))
            except ValueError:
                conversation.turns.append(Turn(role=Role.user, content=content))

        prompt = format_conversation(conversation, add_generation_prompt=True)
        input_ids = self.tokenizer.encode(prompt, return_tensors="pt").to(self.device)

        self.model.eval()
        generated_ids = []
        past_key_values = None
        input_token_len = input_ids.size(1)

        for _ in range(max_new_tokens):
            with torch.no_grad():
                if past_key_values is None:
                    outputs = self.model(input_ids=input_ids, use_cache=True)
                else:
                    outputs = self.model(
                        input_ids=next_token_ids,
                        past_key_values=past_key_values,
                        use_cache=True,
                    )

            logits = outputs["logits"] if isinstance(outputs, dict) else outputs.logits
            next_logits = logits[:, -1, :] / temperature

            if repetition_penalty != 1.0:
                for token_id in set(generated_ids):
                    next_logits[:, token_id] /= repetition_penalty

            if top_k > 0:
                indices_to_remove = next_logits < torch.topk(next_logits, top_k)[0][..., -1, None]
                next_logits[indices_to_remove] = float("-inf")

            if top_p < 1.0:
                sorted_logits, sorted_indices = torch.sort(next_logits, descending=True)
                cumulative_probs = torch.cumsum(F.softmax(sorted_logits, dim=-1), dim=-1)
                sorted_indices_to_remove = cumulative_probs > top_p
                sorted_indices_to_remove[..., 1:] = sorted_indices_to_remove[..., :-1].clone()
                sorted_indices_to_remove[..., 0] = 0
                indices_to_remove = sorted_indices_to_remove.scatter(
                    dim=-1, index=sorted_indices, src=sorted_indices_to_remove
                )
                next_logits[indices_to_remove] = float("-inf")

            probs = F.softmax(next_logits, dim=-1)
            next_token_ids = torch.multinomial(probs, num_samples=1)

            eos_id = self.tokenizer.eos_token_id if hasattr(self.tokenizer, "eos_token_id") and self.tokenizer.eos_token_id is not None else None
            if eos_id is not None and next_token_ids.item() == eos_id:
                break

            generated_ids.append(next_token_ids.item())
            past_key_values = outputs.get("past_key_values") if isinstance(outputs, dict) else getattr(outputs, "past_key_values", None)

        response = self.tokenizer.decode(generated_ids, skip_special_tokens=True)
        return response

    def save_pretrained(self, output_dir: str) -> None:
        import os
        os.makedirs(output_dir, exist_ok=True)
        torch.save(self.model.state_dict(), os.path.join(output_dir, "pytorch_model.bin"))

    def from_pretrained(self, model_path: str) -> None:
        state_dict = torch.load(model_path, map_location=self.device)
        self.model.load_state_dict(state_dict)
