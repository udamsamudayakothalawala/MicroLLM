"""muLLM Data Engineering Module.

Complete data processing pipeline for LLM training data preparation:
crawling, downloading, cleaning, extraction, language detection,
deduplication, quality scoring, toxicity filtering, PII removal,
copyright filtering, and dataset balancing.
"""

from mullm.core.data.annotation import (
    AnnotationSchema,
    AnnotationStore,
    AnnotationValidator,
    DocumentAnnotation,
    SpanAnnotation,
    SpanAnnotator,
    TokenLevelAnnotator,
)
from mullm.core.data.augmentation import (
    AugmentationConfig,
    BackTranslator,
    NoiseInjector,
    Paraphraser,
    SynonymReplacer,
    TextAugmenter,
)
from mullm.core.data.balancing import (
    BalancingConfig,
    CategoryBalancer,
    DatasetBalancer,
    DomainBalancer,
    LengthBalancer,
    LanguageBalancer,
    ReservoirSampler,
    StratifiedSampler,
)
from mullm.core.data.cleaner import (
    CleanConfig,
    EncodingDetector,
    HTMLCleaner,
)
from mullm.core.data.copyright import (
    CopyrightConfig,
    CopyrightDetection,
    CopyrightFilter,
    LicenseDetector,
    SourceTracker,
    WatermarkDetector,
)
from mullm.core.data.crawler import (
    BloomFilter,
    CrawlConfig,
    CrawlResult,
    DomainRateLimiter,
    RobotsChecker,
    WebCrawler,
)
from mullm.core.data.datasets import (
    ArxivLoader,
    BooksLoader,
    CodeDatasetLoader,
    ConversationsLoader,
    CustomDatasetLoader,
    DatasetConfig,
    DatasetFactory,
    DatasetItem,
    MultilingualLoader,
    WikipediaLoader,
)
from mullm.core.data.deduplication import (
    DeduplicationConfig,
    Deduplicator,
    ExactDeduplicator,
    LSHIndex,
    MinHashDeduplicator,
    MinHashSignature,
    SimHash,
    SimHashDeduplicator,
    TextNormalizer,
)
from mullm.core.data.downloader import (
    ChecksumValidator,
    DownloadConfig,
    DownloadManager,
    DownloadRequest,
    DownloadResult,
    FileFormat,
    ProgressInfo,
)
from mullm.core.data.extractor import (
    ExtractedContent,
    ExtractionConfig,
    HTMLTextExtractor,
    MarkdownExtractor,
    NotebookExtractor,
    PDFExtractor,
    TextExtractor,
)
from mullm.core.data.language_detector import (
    HeuristicLanguageDetector,
    LanguageDetectionConfig,
    LanguageDetector,
    LanguageFilterConfig,
    LanguageResult,
)
from mullm.core.data.pipeline import (
    CacheManager,
    DataPipeline,
    PipelineConfig,
    PipelineStage,
    PipelineStats,
    StageResult,
)
from mullm.core.data.privacy import (
    PIIDetection,
    PIIDetector,
    PIIAnonymizer,
    PIIPatterns,
    PrivacyConfig,
    RedactionStrategy,
)
from mullm.core.data.quality import (
    CoherenceScorer,
    CompressionScorer,
    LengthScorer,
    PunctuationScorer,
    QualityConfig,
    QualityScorer,
    QualityScore,
    RepetitionScorer,
    StopWordScorer,
    SymbolScorer,
)
from mullm.core.data.labeling import (
    ActiveLearningLabeler,
    Label,
    LabelConfig,
    LabeledItem,
    LabelManager,
    RuleBasedLabeler,
)
from mullm.core.data.multimodal_builder import (
    ModalityConfig,
    MultimodalDatasetBuilder,
    MultimodalSample,
    Text3dPairBuilder,
    TextAudioPairBuilder,
    TextImagePairBuilder,
    TextVideoPairBuilder,
)
from mullm.core.data.synthetic_generation import (
    PatternExpander,
    PromptBasedGenerator,
    QAGenerator,
    SynthGenConfig,
    SynthSample,
    SyntheticDataPipeline,
    TemplateGenerator,
)
from mullm.core.data.toxicity import (
    HateSpeechDetector,
    NSFWDetector,
    ProfanityFilter,
    ToxicityCategory,
    ToxicityConfig,
    ToxicityFilter,
    ToxicityResult,
    ViolenceDetector,
)

__all__ = [
    # Annotation
    "AnnotationSchema",
    "AnnotationStore",
    "AnnotationValidator",
    "DocumentAnnotation",
    "SpanAnnotation",
    "SpanAnnotator",
    "TokenLevelAnnotator",
    # Augmentation
    "AugmentationConfig",
    "BackTranslator",
    "NoiseInjector",
    "Paraphraser",
    "SynonymReplacer",
    "TextAugmenter",
    # Crawler
    "WebCrawler",
    "CrawlConfig",
    "CrawlResult",
    "BloomFilter",
    "DomainRateLimiter",
    "RobotsChecker",
    # Downloader
    "DownloadManager",
    "DownloadConfig",
    "DownloadRequest",
    "DownloadResult",
    "DownloadResult",
    "FileFormat",
    "ProgressInfo",
    "ChecksumValidator",
    # Cleaner
    "HTMLCleaner",
    "CleanConfig",
    "EncodingDetector",
    # Extractor
    "TextExtractor",
    "ExtractionConfig",
    "ExtractedContent",
    "PDFExtractor",
    "HTMLTextExtractor",
    "MarkdownExtractor",
    "NotebookExtractor",
    # Language Detection
    "LanguageDetector",
    "LanguageDetectionConfig",
    "LanguageFilterConfig",
    "LanguageResult",
    "HeuristicLanguageDetector",
    # Deduplication
    "Deduplicator",
    "DeduplicationConfig",
    "ExactDeduplicator",
    "MinHashDeduplicator",
    "SimHashDeduplicator",
    "MinHashSignature",
    "SimHash",
    "LSHIndex",
    "TextNormalizer",
    # Quality
    "QualityScorer",
    "QualityConfig",
    "QualityScore",
    "LengthScorer",
    "PunctuationScorer",
    "SymbolScorer",
    "StopWordScorer",
    "CompressionScorer",
    "RepetitionScorer",
    "CoherenceScorer",
    # Toxicity
    "ToxicityFilter",
    "ToxicityConfig",
    "ToxicityResult",
    "ToxicityCategory",
    "ProfanityFilter",
    "HateSpeechDetector",
    "NSFWDetector",
    "ViolenceDetector",
    # Privacy
    "PIIAnonymizer",
    "PIIDetector",
    "PIIDetection",
    "PIIPatterns",
    "PrivacyConfig",
    "RedactionStrategy",
    # Copyright
    "CopyrightFilter",
    "CopyrightConfig",
    "CopyrightDetection",
    "LicenseDetector",
    "WatermarkDetector",
    "SourceTracker",
    # Balancing
    "DatasetBalancer",
    "BalancingConfig",
    "CategoryBalancer",
    "DomainBalancer",
    "LanguageBalancer",
    "LengthBalancer",
    "StratifiedSampler",
    "ReservoirSampler",
    # Pipeline
    "DataPipeline",
    "PipelineConfig",
    "PipelineStage",
    "PipelineStats",
    "StageResult",
    "CacheManager",
    # Labeling
    "ActiveLearningLabeler",
    "Label",
    "LabelConfig",
    "LabeledItem",
    "LabelManager",
    "RuleBasedLabeler",
    # Multimodal
    "ModalityConfig",
    "MultimodalDatasetBuilder",
    "MultimodalSample",
    "Text3dPairBuilder",
    "TextAudioPairBuilder",
    "TextImagePairBuilder",
    "TextVideoPairBuilder",
    # Synthetic Generation
    "PatternExpander",
    "PromptBasedGenerator",
    "QAGenerator",
    "SynthGenConfig",
    "SynthSample",
    "SyntheticDataPipeline",
    "TemplateGenerator",
    # Datasets
    "DatasetFactory",
    "DatasetConfig",
    "DatasetItem",
    "WikipediaLoader",
    "BooksLoader",
    "CodeDatasetLoader",
    "ArxivLoader",
    "ConversationsLoader",
    "MultilingualLoader",
    "CustomDatasetLoader",
]

__version__ = "1.0.0"
