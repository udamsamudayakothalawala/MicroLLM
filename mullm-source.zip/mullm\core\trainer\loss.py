from __future__ import annotations

import math
from typing import Any, Dict, List, Optional, Tuple, Union

import torch
import torch.distributed as dist
import torch.nn as nn
import torch.nn.functional as F

from mullm.core.trainer.training_config import LossConfig


class FusedCrossEntropyLoss(nn.Module):
    def __init__(
        self,
        ignore_index: int = -100,
        reduction: str = "mean",
        label_smoothing: float = 0.0,
        inplace: bool = False,
    ) -> None:
        super().__init__()
        self.ignore_index = ignore_index
        self.reduction = reduction
        self.label_smoothing = label_smoothing
        self.inplace = inplace

    def forward(self, logits: torch.Tensor, labels: torch.Tensor) -> torch.Tensor:
        if self.inplace and logits.size(-1) >= 128:
            return self._fused_forward(logits, labels)
        return F.cross_entropy(
            logits.view(-1, logits.size(-1)),
            labels.view(-1),
            ignore_index=self.ignore_index,
            reduction=self.reduction,
            label_smoothing=self.label_smoothing,
        )

    def _fused_forward(self, logits: torch.Tensor, labels: torch.Tensor) -> torch.Tensor:
        vocab_size = logits.size(-1)
        logits_2d = logits.view(-1, vocab_size)
        labels_1d = labels.view(-1)

        if self.label_smoothing > 0.0:
            return F.cross_entropy(logits_2d, labels_1d, ignore_index=self.ignore_index, reduction=self.reduction, label_smoothing=self.label_smoothing)

        max_logits = logits_2d.max(dim=-1, keepdim=True).values
        logits_shifted = logits_2d - max_logits
        exp_logits = logits_shifted.exp()
        sum_exp = exp_logits.sum(dim=-1, keepdim=True)
        log_probs = logits_shifted - sum_exp.log()

        valid_mask = labels_1d != self.ignore_index

        if not valid_mask.any():
            return logits_2d.sum() * 0.0

        valid_log_probs = log_probs[valid_mask]
        valid_labels = labels_1d[valid_mask]
        nll = -valid_log_probs.gather(1, valid_labels.unsqueeze(1)).squeeze(1)

        if self.reduction == "mean":
            return nll.mean()
        elif self.reduction == "sum":
            return nll.sum()
        return nll


class FocalLoss(nn.Module):
    def __init__(
        self,
        gamma: float = 2.0,
        alpha: Optional[float] = None,
        ignore_index: int = -100,
        reduction: str = "mean",
    ) -> None:
        super().__init__()
        self.gamma = gamma
        self.alpha = alpha
        self.ignore_index = ignore_index
        self.reduction = reduction

    def forward(self, logits: torch.Tensor, labels: torch.Tensor) -> torch.Tensor:
        logits_2d = logits.view(-1, logits.size(-1))
        labels_1d = labels.view(-1)

        log_probs = F.log_softmax(logits_2d, dim=-1)
        probs = log_probs.exp()

        valid_mask = labels_1d != self.ignore_index
        if not valid_mask.any():
            return logits_2d.sum() * 0.0

        valid_log_probs = log_probs[valid_mask]
        valid_probs = probs[valid_mask]
        valid_labels = labels_1d[valid_mask]

        nll = -valid_log_probs.gather(1, valid_labels.unsqueeze(1)).squeeze(1)
        pt = valid_probs.gather(1, valid_labels.unsqueeze(1)).squeeze(1)
        modulating_factor = (1 - pt) ** self.gamma

        if self.alpha is not None:
            alpha_t = torch.where(valid_labels > 0, self.alpha, 1.0 - self.alpha)
            loss = alpha_t * modulating_factor * nll
        else:
            loss = modulating_factor * nll

        if self.reduction == "mean":
            return loss.mean()
        elif self.reduction == "sum":
            return loss.sum()
        return loss


class MoEAuxiliaryLoss(nn.Module):
    def __init__(self, aux_loss_coef: float = 0.01, z_loss_coef: float = 0.001) -> None:
        super().__init__()
        self.aux_loss_coef = aux_loss_coef
        self.z_loss_coef = z_loss_coef

    def forward(
        self,
        router_logits: torch.Tensor,
        expert_indices: torch.Tensor,
        num_experts: int,
        top_k: int = 2,
    ) -> torch.Tensor:
        router_probs = F.softmax(router_logits, dim=-1)
        expert_mask = F.one_hot(expert_indices, num_classes=num_experts).float()

        per_expert_fraction = expert_mask.mean(dim=0)
        per_expert_probability = router_probs.mean(dim=0)

        load_balancing_loss = (per_expert_fraction * per_expert_probability).sum() * num_experts

        z_loss = router_logits.logsumexp(dim=-1).square().mean()

        return self.aux_loss_coef * load_balancing_loss + self.z_loss_coef * z_loss


class MoELoadBalancingLoss(nn.Module):
    def __init__(self, coefficient: float = 0.01) -> None:
        super().__init__()
        self.coefficient = coefficient

    def forward(
        self,
        router_logits: torch.Tensor,
        expert_indices: torch.Tensor,
        num_experts: int,
    ) -> torch.Tensor:
        router_probs = F.softmax(router_logits, dim=-1)
        expert_mask = F.one_hot(expert_indices, num_classes=num_experts).float()

        tokens_per_expert = expert_mask.sum(dim=0)
        tokens_per_expert = tokens_per_expert / tokens_per_expert.sum()

        prob_per_expert = router_probs.mean(dim=0)

        loss = (tokens_per_expert * prob_per_expert).sum() * num_experts
        return self.coefficient * loss


class ZLoss(nn.Module):
    def __init__(self, coefficient: float = 0.001) -> None:
        super().__init__()
        self.coefficient = coefficient

    def forward(self, logits: torch.Tensor) -> torch.Tensor:
        return self.coefficient * logits.logsumexp(dim=-1).square().mean()


class KLDivergencePenalty(nn.Module):
    def __init__(self, coefficient: float = 0.0, reduction: str = "batchmean") -> None:
        super().__init__()
        self.coefficient = coefficient
        self.reduction = reduction

    def forward(
        self,
        student_logits: torch.Tensor,
        teacher_logits: torch.Tensor,
        temperature: float = 1.0,
    ) -> torch.Tensor:
        if self.coefficient <= 0.0:
            return student_logits.sum() * 0.0

        student_log_probs = F.log_softmax(student_logits / temperature, dim=-1)
        teacher_probs = F.softmax(teacher_logits / temperature, dim=-1)

        loss = F.kl_div(student_log_probs, teacher_probs, reduction=self.reduction, log_target=False)
        return self.coefficient * temperature * temperature * loss


class AdaptiveLossWeighting(nn.Module):
    def __init__(self, num_losses: int, temperature: float = 1.0) -> None:
        super().__init__()
        self.num_losses = num_losses
        self.temperature = temperature
        self.log_weights = nn.Parameter(torch.zeros(num_losses))

    def forward(self, losses: List[torch.Tensor]) -> torch.Tensor:
        weights = F.softmax(self.log_weights / self.temperature, dim=-1)
        weighted_loss = sum(w * l for w, l in zip(weights, losses))
        return weighted_loss

    def get_weights(self) -> torch.Tensor:
        return F.softmax(self.log_weights / self.temperature, dim=-1)


class AdaptiveLossWeightingEMA(nn.Module):
    def __init__(
        self,
        num_losses: int,
        temperature: float = 1.0,
        ema_decay: float = 0.9,
        learning_rate: float = 0.01,
    ) -> None:
        super().__init__()
        self.num_losses = num_losses
        self.temperature = temperature
        self.ema_decay = ema_decay
        self.learning_rate = learning_rate
        self.log_weights = nn.Parameter(torch.zeros(num_losses))
        self.register_buffer("ema_losses", torch.zeros(num_losses))
        self.register_buffer("step", torch.tensor(0))

    def forward(self, losses: List[torch.Tensor]) -> torch.Tensor:
        self.step += 1
        loss_values = torch.tensor([l.detach() for l in losses], device=losses[0].device)
        self.ema_losses = self.ema_decay * self.ema_losses + (1 - self.ema_decay) * loss_values

        if self.step > 1:
            weights = F.softmax(self.log_weights / self.temperature, dim=-1)
            weighted_losses = weights * self.ema_losses
            grad = weighted_losses.sum()
            self.log_weights = self.log_weights - self.learning_rate * torch.autograd.grad(grad, self.log_weights, retain_graph=True)[0]

        weights = F.softmax(self.log_weights / self.temperature, dim=-1)
        return sum(w * l for w, l in zip(weights, losses))

    def get_weights(self) -> torch.Tensor:
        return F.softmax(self.log_weights / self.temperature, dim=-1)


class CombinedLoss(nn.Module):
    def __init__(self, config: LossConfig) -> None:
        super().__init__()
        self.config = config
        self.main_loss = FusedCrossEntropyLoss(
            ignore_index=-100,
            reduction="mean",
            label_smoothing=config.label_smoothing,
        )
        self.focal_loss = FocalLoss(
            gamma=config.focal_loss_gamma,
            alpha=config.focal_loss_alpha,
            ignore_index=-100,
        )
        self.moe_aux_loss = MoEAuxiliaryLoss(
            aux_loss_coef=config.moe_aux_loss_coef,
            z_loss_coef=config.moe_z_loss_coef,
        )
        self.z_loss = ZLoss(coefficient=config.moe_z_loss_coef)
        self.kl_penalty = KLDivergencePenalty(coefficient=config.kl_penalty_coef)

        if config.adaptive_loss:
            self.adaptive_weighting = AdaptiveLossWeighting(
                num_losses=3,
                temperature=config.adaptive_loss_temperature,
            )
        else:
            self.adaptive_weighting = None

    def forward(
        self,
        logits: torch.Tensor,
        labels: torch.Tensor,
        auxiliary_losses: Optional[List[torch.Tensor]] = None,
        router_logits: Optional[torch.Tensor] = None,
        expert_indices: Optional[torch.Tensor] = None,
        num_experts: int = 0,
        top_k: int = 2,
        student_logits: Optional[torch.Tensor] = None,
        teacher_logits: Optional[torch.Tensor] = None,
        kl_temperature: float = 1.0,
    ) -> Dict[str, torch.Tensor]:
        losses: Dict[str, torch.Tensor] = {}

        losses["ce_loss"] = self.main_loss(logits, labels)

        if self.config.z_loss > 0.0:
            losses["z_loss"] = self.config.z_loss * logits.logsumexp(dim=-1).square().mean()

        if auxiliary_losses:
            for i, aux_loss in enumerate(auxiliary_losses):
                losses[f"aux_loss_{i}"] = aux_loss

        if router_logits is not None and expert_indices is not None and num_experts > 0:
            losses["moe_aux_loss"] = self.moe_aux_loss(router_logits, expert_indices, num_experts, top_k)
            losses["moe_load_balancing"] = MoELoadBalancingLoss(
                coefficient=self.config.moe_aux_loss_coef
            )(router_logits, expert_indices, num_experts)

        if student_logits is not None and teacher_logits is not None:
            losses["kl_loss"] = self.kl_penalty(student_logits, teacher_logits, kl_temperature)

        main_losses = [v for k, v in losses.items() if "aux" not in k and "kl" not in k]

        if self.adaptive_weighting is not None and len(main_losses) > 1:
            losses["loss"] = self.adaptive_weighting(main_losses)
        else:
            losses["loss"] = sum(main_losses)

        if auxiliary_losses:
            losses["loss"] = losses["loss"] + sum(auxiliary_losses)

        return losses


def build_loss(config: LossConfig) -> CombinedLoss:
    return CombinedLoss(config)
