import math
import torch
import torch.nn as nn
import torch.nn.functional as F


class GELU(nn.Module):
    def __init__(self, approximate: str = "tanh"):
        super().__init__()
        self.approximate = approximate

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        if self.approximate == "tanh":
            return 0.5 * x * (1.0 + torch.tanh(
                math.sqrt(2.0 / math.pi) * (x + 0.044715 * torch.pow(x, 3.0))
            ))
        return F.gelu(x)


class SiLU(nn.Module):
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return x * torch.sigmoid(x)


class SwiGLU(nn.Module):
    def __init__(self, hidden_size: int, intermediate_size: int, bias: bool = False):
        super().__init__()
        self.gate_proj = nn.Linear(hidden_size, intermediate_size, bias=bias)
        self.up_proj = nn.Linear(hidden_size, intermediate_size, bias=bias)
        self.down_proj = nn.Linear(intermediate_size, hidden_size, bias=bias)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        gate = self.gate_proj(x)
        up = self.up_proj(x)
        return self.down_proj(F.silu(gate) * up)


ACTIVATION_MAP = {
    "gelu": GELU,
    "gelu_tanh": lambda: GELU(approximate="tanh"),
    "gelu_exact": lambda: GELU(approximate="exact"),
    "silu": SiLU,
    "swiglu": SwiGLU,
    "relu": nn.ReLU,
    "tanh": nn.Tanh,
    "sigmoid": nn.Sigmoid,
}


def get_activation(activation_name: str) -> nn.Module:
    if activation_name.lower() not in ACTIVATION_MAP:
        raise ValueError(
            f"Unknown activation: {activation_name}. "
            f"Available: {list(ACTIVATION_MAP.keys())}"
        )
    factory = ACTIVATION_MAP[activation_name.lower()]
    return factory()
