#Requires -Version 5.1
<#
.SYNOPSIS
    muLLM Benchmark Launcher (PowerShell)

.EXAMPLE
    .\benchmark.ps1 -Concurrent 16 -Duration 60
#>

[CmdletBinding()]
param(
    [string]$ModelPath = $env:MULLM_MODEL_PATH,
    [string]$Host_ = "localhost",
    [int]$Port = 8000,
    [int]$Concurrent = 16,
    [int]$Duration = 60,
    [int]$PromptLength = 128,
    [int]$MaxTokens = 128,
    [string]$OutputDir = ".\benchmarks",
    [string]$ApiKey,
    [int]$Warmup = 10
)

$ErrorActionPreference = "Stop"

Write-Host "============================================" -ForegroundColor Cyan
Write-Host "  muLLM Benchmark" -ForegroundColor Cyan
Write-Host "============================================" -ForegroundColor Cyan
Write-Host "Server:         ${Host_}:${Port}"
Write-Host "Concurrent:     $Concurrent"
Write-Host "Duration:       ${Duration}s"
Write-Host "Prompt length:  $PromptLength tokens"
Write-Host "Max tokens:     $MaxTokens"
Write-Host "============================================" -ForegroundColor Cyan

if (-not (Test-Path $OutputDir)) {
    New-Item -ItemType Directory -Path $OutputDir -Force | Out-Null
}

$timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
$resultsFile = Join-Path $OutputDir "benchmark_${timestamp}.json"

$url = "http://${Host_}:${Port}/v1/completions"
$healthUrl = "http://${Host_}:${Port}/v1/health"

Write-Host "Checking server health..."
try {
    $health = Invoke-RestMethod -Uri $healthUrl -Method Get -ErrorAction Stop
    Write-Host "Server is healthy." -ForegroundColor Green
} catch {
    Write-Error "Server not responding at $healthUrl"
    exit 1
}

Write-Host ""
Write-Host "Starting benchmark with Python backend..."
Write-Host ""

$pyArgs = @(
    "-m", "mullm.cli.main",
    "--help"
)

# Use a Python script for the actual concurrent benchmarking
$benchmarkScript = @"
import sys, json, time, statistics, threading, urllib.request, urllib.error

url = "$url"
concurrent = $Concurrent
duration = $Duration
max_tokens = $MaxTokens
api_key = "$ApiKey"
results_file = r"$resultsFile"
prompt_length = $PromptLength

prompt = ('The quick brown fox jumps over the lazy dog. ' * (prompt_length // 8))[:prompt_length * 4]
payload = json.dumps({"model": "default", "prompt": prompt, "max_tokens": max_tokens, "temperature": 0.0}).encode()
headers = {"Content-Type": "application/json"}
if api_key:
    headers["Authorization"] = f"Bearer {api_key}"

latencies, tokens_generated, errors = [], 0, 0
lock = threading.Lock()
stop = threading.Event()

def run():
    global tokens_generated, errors
    while not stop.is_set():
        start = time.monotonic()
        try:
            req = urllib.request.Request(url, data=payload, headers=headers)
            with urllib.request.urlopen(req, timeout=300) as resp:
                body = json.loads(resp.read())
                elapsed = time.monotonic() - start
                with lock:
                    latencies.append(elapsed)
                    tokens_generated += body.get("usage", {}).get("completion_tokens", max_tokens)
        except:
            with lock: errors += 1
            time.sleep(0.1)

threads = [threading.Thread(target=run, daemon=True) for _ in range(concurrent)]
for t in threads: t.start()
t0 = time.monotonic()
time.sleep(duration)
stop.set()
for t in threads: t.join(timeout=5)
elapsed = time.monotonic() - t0

n = len(latencies)
tps = tokens_generated / elapsed if elapsed else 0
rps = n / elapsed if elapsed else 0
stats = {}
if latencies:
    s = sorted(latencies)
    stats = {
        "mean_ms": round(statistics.mean(s) * 1000, 2),
        "median_ms": round(statistics.median(s) * 1000, 2),
        "p90_ms": round(s[int(n * 0.9)] * 1000, 2),
        "p95_ms": round(s[int(n * 0.95)] * 1000, 2),
        "p99_ms": round(s[int(n * 0.99)] * 1000, 2),
        "min_ms": round(s[0] * 1000, 2),
        "max_ms": round(s[-1] * 1000, 2),
    }

results = {
    "config": {"concurrent": concurrent, "duration": duration, "max_tokens": max_tokens},
    "results": {
        "total_requests": n, "errors": errors,
        "tokens_generated": tokens_generated,
        "tokens_per_second": round(tps, 2),
        "requests_per_second": round(rps, 4),
        "latency": stats,
    }
}
with open(results_file, "w") as f: json.dump(results, f, indent=2)
print(f"Requests: {n}, Errors: {errors}, Throughput: {tps:.1f} tok/s, RPS: {rps:.4f}")
if stats: print(f"Latency: mean={stats['mean_ms']:.1f}ms, p95={stats['p95_ms']:.1f}ms, p99={stats['p99_ms']:.1f}ms")
print(f"Results: {results_file}")
"@

$benchmarkScript | & python
if ($LASTEXITCODE -ne 0) {
    Write-Error "Benchmark failed"
    exit $LASTEXITCODE
}

Write-Host ""
Write-Host "Benchmark complete." -ForegroundColor Green
