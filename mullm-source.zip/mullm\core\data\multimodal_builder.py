"""Multimodal dataset construction for text-image, text-audio, text-video, and text-3d pairs."""

from __future__ import annotations

import json
import logging
import random
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional

logger = logging.getLogger(__name__)


@dataclass
class ModalityConfig:
    modalities: list[str] = field(default_factory=lambda: ["text", "image"])
    min_caption_length: int = 10
    max_caption_length: int = 512
    supported_formats: dict[str, list[str]] = field(default_factory=lambda: {"image": ["jpg", "png", "webp"], "audio": ["wav", "mp3", "flac"], "video": ["mp4", "avi", "mov"], "3d": ["obj", "glb", "gltf"]})


@dataclass
class MultimodalSample:
    id: str
    modalities: dict[str, str]
    text: str = ""
    metadata: dict[str, Any] = field(default_factory=dict)
    label: Optional[str] = None


class TextImagePairBuilder:
    def __init__(self, config: Optional[ModalityConfig] = None) -> None:
        self.config = config or ModalityConfig()

    def build_pairs(self, image_paths: list[str], captions: list[str]) -> list[MultimodalSample]:
        pairs = []
        for img_path, caption in zip(image_paths, captions):
            if len(caption) < self.config.min_caption_length:
                continue
            sample_id = f"ti_{abs(hash(img_path + caption)) % 10**8}"
            pairs.append(MultimodalSample(id=sample_id, modalities={"image": img_path}, text=caption))
        return pairs

    def build_from_directory(self, image_dir: str, caption_file: Optional[str] = None) -> list[MultimodalSample]:
        image_dir_path = Path(image_dir)
        image_files = [str(f) for f in image_dir_path.glob("*") if f.suffix.lower()[1:] in self.config.supported_formats.get("image", [])]
        if caption_file and Path(caption_file).exists():
            captions = Path(caption_file).read_text(encoding="utf-8").splitlines()
        else:
            captions = [f"An image from {Path(p).name}" for p in image_files]
        if len(captions) < len(image_files):
            captions.extend(["A photograph."] * (len(image_files) - len(captions)))
        return self.build_pairs(image_files[:len(captions)], captions[:len(image_files)])


class TextAudioPairBuilder:
    def __init__(self, config: Optional[ModalityConfig] = None) -> None:
        self.config = config or ModalityConfig()

    def build_pairs(self, audio_paths: list[str], transcripts: list[str]) -> list[MultimodalSample]:
        pairs = []
        for audio_path, transcript in zip(audio_paths, transcripts):
            sample_id = f"ta_{abs(hash(audio_path + transcript)) % 10**8}"
            pairs.append(MultimodalSample(id=sample_id, modalities={"audio": audio_path}, text=transcript))
        return pairs


class TextVideoPairBuilder:
    def __init__(self, config: Optional[ModalityConfig] = None) -> None:
        self.config = config or ModalityConfig()

    def build_pairs(self, video_paths: list[str], descriptions: list[str]) -> list[MultimodalSample]:
        pairs = []
        for video_path, desc in zip(video_paths, descriptions):
            sample_id = f"tv_{abs(hash(video_path + desc)) % 10**8}"
            pairs.append(MultimodalSample(id=sample_id, modalities={"video": video_path}, text=desc))
        return pairs


class Text3dPairBuilder:
    def __init__(self, config: Optional[ModalityConfig] = None) -> None:
        self.config = config or ModalityConfig()

    def build_pairs(self, mesh_paths: list[str], descriptions: list[str]) -> list[MultimodalSample]:
        pairs = []
        for mesh_path, desc in zip(mesh_paths, descriptions):
            sample_id = f"t3_{abs(hash(mesh_path + desc)) % 10**8}"
            pairs.append(MultimodalSample(id=sample_id, modalities={"3d": mesh_path}, text=desc))
        return pairs


class MultimodalDatasetBuilder:
    def __init__(self, config: Optional[ModalityConfig] = None) -> None:
        self.config = config or ModalityConfig()
        self.image_builder = TextImagePairBuilder(config)
        self.audio_builder = TextAudioPairBuilder(config)
        self.video_builder = TextVideoPairBuilder(config)
        self.mesh3d_builder = Text3dPairBuilder(config)
        self.samples: list[MultimodalSample] = []

    def add_image_pairs(self, image_paths: list[str], captions: list[str]) -> None:
        self.samples.extend(self.image_builder.build_pairs(image_paths, captions))

    def add_audio_pairs(self, audio_paths: list[str], transcripts: list[str]) -> None:
        self.samples.extend(self.audio_builder.build_pairs(audio_paths, transcripts))

    def add_video_pairs(self, video_paths: list[str], descriptions: list[str]) -> None:
        self.samples.extend(self.video_builder.build_pairs(video_paths, descriptions))

    def add_3d_pairs(self, mesh_paths: list[str], descriptions: list[str]) -> None:
        self.samples.extend(self.mesh3d_builder.build_pairs(mesh_paths, descriptions))

    def add_multi_modal_sample(self, text: str, modality_paths: dict[str, str]) -> MultimodalSample:
        sample_id = f"mm_{abs(hash(text + str(modality_paths))) % 10**8}"
        sample = MultimodalSample(id=sample_id, modalities=modality_paths, text=text)
        self.samples.append(sample)
        return sample

    def filter_by_modality(self, modality: str) -> list[MultimodalSample]:
        return [s for s in self.samples if modality in s.modalities]

    def filter_by_text_length(self, min_len: int = 0, max_len: int = 10**6) -> list[MultimodalSample]:
        return [s for s in self.samples if min_len <= len(s.text) <= max_len]

    def split(self, train_ratio: float = 0.8) -> tuple[list[MultimodalSample], list[MultimodalSample]]:
        shuffled = self.samples[:]
        random.shuffle(shuffled)
        split_idx = int(len(shuffled) * train_ratio)
        return shuffled[:split_idx], shuffled[split_idx:]

    def stats(self) -> dict[str, Any]:
        modality_counts: dict[str, int] = {}
        for s in self.samples:
            for mod in s.modalities:
                modality_counts[mod] = modality_counts.get(mod, 0) + 1
        return {"total_samples": len(self.samples), "modality_distribution": modality_counts, "config": self.config}

    def save(self, output_path: str) -> None:
        data = [{"id": s.id, "modalities": s.modalities, "text": s.text, "label": s.label, "metadata": s.metadata} for s in self.samples]
        Path(output_path).write_text(json.dumps(data, indent=2), encoding="utf-8")

    def load(self, input_path: str) -> None:
        data = json.loads(Path(input_path).read_text(encoding="utf-8"))
        for entry in data:
            self.samples.append(MultimodalSample(id=entry["id"], modalities=entry["modalities"], text=entry.get("text", ""), label=entry.get("label"), metadata=entry.get("metadata", {})))
