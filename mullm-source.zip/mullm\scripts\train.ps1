#Requires -Version 5.1
<#
.SYNOPSIS
    muLLM Training Launcher (PowerShell)

.DESCRIPTION
    Launches muLLM training with configurable parameters.

.PARAMETER Model
    Model name or path (required).

.PARAMETER Dataset
    Dataset name or path (required).

.EXAMPLE
    .\train.ps1 -Model "meta-llama/Llama-2-7b" -Dataset "tatsu-lab/alpaca" -Epochs 3
#>

[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [string]$Model,

    [Parameter(Mandatory = $true)]
    [string]$Dataset,

    [string]$OutputDir = $env:MULLM_OUTPUT_DIR,
    [int]$BatchSize = if ($env:MULLM_BATCH_SIZE) { [int]$env:MULLM_BATCH_SIZE } else { 8 },
    [float]$LearningRate = if ($env:MULLM_LEARNING_RATE) { [float]$env:MULLM_LEARNING_RATE } else { 5e-5 },
    [int]$Epochs = if ($env:MULLM_EPOCHS) { [int]$env:MULLM_EPOCHS } else { 3 },
    [int]$MaxSteps = if ($env:MULLM_MAX_STEPS) { [int]$env:MULLM_MAX_STEPS } else { -1 },
    [int]$WarmupSteps = if ($env:MULLM_WARMUP_STEPS) { [int]$env:MULLM_WARMUP_STEPS } else { 0 },
    [bool]$Bf16 = if ($env:MULLM_BF16) { [bool]::Parse($env:MULLM_BF16) } else { $true },
    [bool]$Fp16 = if ($env:MULLM_FP16) { [bool]::Parse($env:MULLM_FP16) } else { $false },
    [int]$GradientAccumulation = if ($env:MULLM_GRADIENT_ACCUMULATION_STEPS) { [int]$env:MULLM_GRADIENT_ACCUMULATION_STEPS } else { 1 },
    [float]$WeightDecay = if ($env:MULLM_WEIGHT_DECAY) { [float]$env:MULLM_WEIGHT_DECAY } else { 0.01 },
    [float]$MaxGradNorm = if ($env:MULLM_MAX_GRAD_NORM) { [float]$env:MULLM_MAX_GRAD_NORM } else { 1.0 },
    [int]$SaveSteps = if ($env:MULLM_SAVE_STEPS) { [int]$env:MULLM_SAVE_STEPS } else { 500 },
    [int]$EvalSteps = if ($env:MULLM_EVAL_STEPS) { [int]$env:MULLM_EVAL_STEPS } else { 500 },
    [int]$LoggingSteps = if ($env:MULLM_LOGGING_STEPS) { [int]$env:MULLM_LOGGING_STEPS } else { 10 },
    [int]$Seed = if ($env:MULLM_SEED) { [int]$env:MULLM_SEED } else { 42 },
    [int]$MaxSeqLength = if ($env:MULLM_MAX_SEQ_LENGTH) { [int]$env:MULLM_MAX_SEQ_LENGTH } else { 2048 },
    [string]$LogLevel = if ($env:MULLM_LOG_LEVEL) { $env:MULLM_LOG_LEVEL } else { "INFO" },
    [switch]$DeepSpeed,
    [int]$DeepSpeedStage = 2,
    [int]$LoraRank,
    [int]$LoraAlpha = 32,
    [float]$LoraDropout = 0.05,
    [string]$LoraTargetModules
)

$ErrorActionPreference = "Stop"

if (-not $OutputDir) { $OutputDir = ".\output" }

Write-Host "============================================" -ForegroundColor Cyan
Write-Host "  muLLM Training" -ForegroundColor Cyan
Write-Host "============================================" -ForegroundColor Cyan
Write-Host "Model:           $Model"
Write-Host "Dataset:         $Dataset"
Write-Host "Output:          $OutputDir"
Write-Host "Batch size:      $BatchSize"
Write-Host "Learning rate:   $LearningRate"
Write-Host "Epochs:          $Epochs"
Write-Host "Max steps:       $MaxSteps"
Write-Host "BF16:            $Bf16"
Write-Host "FP16:            $Fp16"
Write-Host "Grad accum:      $GradientAccumulation"
Write-Host "Seed:            $Seed"
Write-Host "============================================" -ForegroundColor Cyan

if (-not (Test-Path $OutputDir)) {
    New-Item -ItemType Directory -Path $OutputDir -Force | Out-Null
}

$env:MULLM_MODEL_PATH = $Model
$env:MULLM_DATASET_PATH = $Dataset
$env:MULLM_OUTPUT_DIR = $OutputDir
$env:MULLM_BATCH_SIZE = $BatchSize.ToString()
$env:MULLM_LEARNING_RATE = $LearningRate.ToString()
$env:MULLM_EPOCHS = $Epochs.ToString()
$env:MULLM_MAX_STEPS = $MaxSteps.ToString()
$env:MULLM_WARMUP_STEPS = $WarmupSteps.ToString()
$env:MULLM_BF16 = $Bf16.ToString().ToLower()
$env:MULLM_FP16 = $Fp16.ToString().ToLower()
$env:MULLM_GRADIENT_ACCUMULATION_STEPS = $GradientAccumulation.ToString()
$env:MULLM_WEIGHT_DECAY = $WeightDecay.ToString()
$env:MULLM_MAX_GRAD_NORM = $MaxGradNorm.ToString()
$env:MULLM_SAVE_STEPS = $SaveSteps.ToString()
$env:MULLM_EVAL_STEPS = $EvalSteps.ToString()
$env:MULLM_LOGGING_STEPS = $LoggingSteps.ToString()
$env:MULLM_SEED = $Seed.ToString()
$env:MULLM_MAX_SEQ_LENGTH = $MaxSeqLength.ToString()
$env:MULLM_LOG_LEVEL = $LogLevel

if ($LoraRank -gt 0) {
    $env:MULLM_LORA_RANK = $LoraRank.ToString()
    $env:MULLM_LORA_ALPHA = $LoraAlpha.ToString()
    $env:MULLM_LORA_DROPOUT = $LoraDropout.ToString()
    if ($LoraTargetModules) {
        $env:MULLM_LORA_TARGET_MODULES = $LoraTargetModules
    }
    Write-Host "LoRA rank:       $LoraRank" -ForegroundColor Yellow
}

Write-Host "Starting training..." -ForegroundColor Green

if ($DeepSpeed) {
    $env:MULLM_DEEPSPEED = "true"
    $env:MULLM_DEEPSPEED_STAGE = $DeepSpeedStage.ToString()
    & deepspeed -m mullm.core.trainer.trainer
} else {
    & python -m mullm.core.trainer.trainer
}

if ($LASTEXITCODE -ne 0) {
    Write-Error "Training failed with exit code $LASTEXITCODE"
    exit $LASTEXITCODE
}

Write-Host "Training complete." -ForegroundColor Green
