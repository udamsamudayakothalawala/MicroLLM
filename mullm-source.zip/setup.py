"""Setup script for muLLM Platform."""

import os
import re
from typing import List

from setuptools import find_packages, setup


def get_version() -> str:
    """Read package version from __init__.py without importing."""
    init_path = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        "mullm",
        "__init__.py",
    )
    with open(init_path, encoding="utf-8") as f:
        content = f.read()
    match = re.search(r'__version__\s*=\s*["\']([^"\']+)["\']', content)
    if not match:
        raise RuntimeError("Unable to find version string.")
    return match.group(1)


def get_requirements() -> List[str]:
    """Read requirements from requirements.txt."""
    req_path = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        "requirements.txt",
    )
    with open(req_path, encoding="utf-8") as f:
        return [
            line.strip()
            for line in f
            if line.strip() and not line.startswith("#") and not line.startswith("--")
        ]


def get_long_description() -> str:
    """Read README for long description."""
    readme_path = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        "README.md",
    )
    with open(readme_path, encoding="utf-8") as f:
        return f.read()


setup(
    name="mullm",
    version=get_version(),
    description="Production-grade Large Language Model ecosystem",
    long_description=get_long_description(),
    long_description_content_type="text/markdown",
    author="muLLM Contributors",
    author_email="dev@mullm.ai",
    url="https://github.com/mullm/mullm-platform",
    license="Apache 2.0",
    python_requires=">=3.10",
    packages=find_packages(exclude=["tests", "tests.*"]),
    include_package_data=True,
    install_requires=get_requirements(),
    extras_require={
        "gpu": [
            "flash-attn>=2.5.0",
            "xformers>=0.0.23",
        ],
        "quantization": [
            "bitsandbytes>=0.41.0",
        ],
        "distributed": [
            "deepspeed>=0.13.0",
        ],
        "vectorstore": [
            "faiss-cpu>=1.7.4",
        ],
        "dev": [
            "pytest>=7.4.0",
            "pytest-cov>=4.1.0",
            "pytest-asyncio>=0.23.0",
            "black>=23.11.0",
            "ruff>=0.1.0",
            "mypy>=1.7.0",
            "pre-commit>=3.5.0",
        ],
        "all": [
            "mullm[gpu,quantization,distributed,vectorstore,dev]",
        ],
    },
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Intended Audience :: Science/Research",
        "License :: OSI Approved :: Apache Software License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
        "Topic :: Software Development :: Libraries :: Python Modules",
    ],
    keywords="llm deep-learning transformers machine-learning ai",
    project_urls={
        "Homepage": "https://github.com/mullm/mullm-platform",
        "Repository": "https://github.com/mullm/mullm-platform",
        "Documentation": "https://mullm.ai/docs",
    },
)
