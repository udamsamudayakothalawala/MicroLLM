"""
gguf_export.py - Export PyTorch model to GGUF format for llama.cpp.
Pure Python, no llama.cpp dependency.
"""

import json
import os
import struct
from typing import Optional

import torch
import torch.nn as nn


GGUF_MAGIC = 0x46554747
GGUF_VERSION = 3

GGML_TYPE_F32 = 0
GGML_TYPE_F16 = 1
GGML_TYPE_Q4_0 = 2
GGML_TYPE_Q4_1 = 3
GGML_TYPE_Q5_0 = 6
GGML_TYPE_Q5_1 = 7
GGML_TYPE_Q8_0 = 8


DTYPE_MAP = {
    "f32": GGML_TYPE_F32,
    "f16": GGML_TYPE_F16,
    "q4_0": GGML_TYPE_Q4_0,
    "q4_1": GGML_TYPE_Q4_1,
    "q5_0": GGML_TYPE_Q5_0,
    "q5_1": GGML_TYPE_Q5_1,
    "q8_0": GGML_TYPE_Q8_0,
}


def _quantize_q4_0(tensor: torch.Tensor) -> bytes:
    t = tensor.float().flatten()
    n = len(t)
    if n == 0:
        return b""
    n_blocks = (n + 31) // 32
    padded = n_blocks * 32
    if padded > n:
        t = torch.cat([t, torch.zeros(padded - n)])
    t = t.view(n_blocks, 32)

    mins = t.min(dim=1, keepdim=True).values
    t = t - mins
    maxs = t.max(dim=1, keepdim=True).values
    scale = (maxs / 7.0).clamp(min=1e-10)
    quantized = (t / scale).round().clamp(0, 15).to(torch.uint8)

    # scale/mins: [n_blocks] f32 -> bytes
    scale_bytes = scale.squeeze(-1).numpy().astype("<f4").tobytes()
    min_bytes = mins.squeeze(-1).numpy().astype("<f4").tobytes()

    # pack pairs of nibbles into bytes
    even = quantized[:, 0::2]
    odd = quantized[:, 1::2]
    packed = (even | (odd << 4)).contiguous().view(-1).numpy().tobytes()

    out = bytearray()
    for i in range(n_blocks):
        out += scale_bytes[i * 4:(i + 1) * 4]
        out += min_bytes[i * 4:(i + 1) * 4]
        out += packed[i * 16:(i + 1) * 16]
    return bytes(out)


def _quantize_f16(tensor: torch.Tensor) -> bytes:
    t = tensor.float().flatten().half()
    return t.numpy().tobytes()


def _quantize_f32(tensor: torch.Tensor) -> bytes:
    t = tensor.float().flatten()
    return t.numpy().tobytes()


QUANTIZE_FN = {
    GGML_TYPE_F32: _quantize_f32,
    GGML_TYPE_F16: _quantize_f16,
    GGML_TYPE_Q4_0: _quantize_q4_0,
}


class GGUFExporter:
    def __init__(self):
        self.metadata: dict[str, any] = {}
        self.tensors: list[tuple[str, torch.Tensor]] = []

    def add_metadata(self, key: str, value) -> None:
        self.metadata[key] = value

    def set_architecture(self, arch: str) -> None:
        self.metadata["general.architecture"] = arch

    def add_tensor(self, name: str, tensor: torch.Tensor) -> None:
        self.tensors.append((name, tensor))

    def export(
        self,
        model: nn.Module,
        output_path: str,
        dtype: str = "f16",
        architecture: Optional[str] = None,
    ) -> str:
        os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
        ggml_type = DTYPE_MAP.get(dtype, GGML_TYPE_F16)

        if architecture:
            self.metadata["general.architecture"] = architecture

        for name, param in model.named_parameters():
            self.add_tensor(name, param.data.cpu())

        self.metadata["general.name"] = getattr(model, "name", "mullm")
        self.metadata["general.type"] = "llm"
        self.metadata["general.file_type"] = ggml_type

        with open(output_path, "wb") as f:
            self._write_header(f)
            self._write_kv_data(f)
            self._write_tensors(f, ggml_type)

        return output_path

    def _write_header(self, f) -> None:
        f.write(struct.pack("<I", GGUF_MAGIC))
        f.write(struct.pack("<I", GGUF_VERSION))
        f.write(struct.pack("<Q", len(self.metadata)))
        f.write(struct.pack("<Q", len(self.tensors)))
        n_head = self._get_n_head()
        f.write(struct.pack("<q", n_head))

    def _get_n_head(self) -> int:
        for key in self.metadata:
            if "n_head" in key or "num_attention_heads" in key:
                return self.metadata[key]
        return 0

    def _write_kv_data(self, f) -> None:
        for key, value in self.metadata.items():
            self._write_string(f, key)
            self._write_value(f, value)

    def _write_string(self, f, s: str) -> None:
        encoded = s.encode("utf-8")
        f.write(struct.pack("<Q", len(encoded)))
        f.write(encoded)

    def _write_value(self, f, value) -> None:
        if isinstance(value, bool):
            f.write(struct.pack("<I", 1))
            f.write(struct.pack("<B", int(value)))
        elif isinstance(value, int):
            f.write(struct.pack("<I", 4))
            f.write(struct.pack("<q", value))
        elif isinstance(value, float):
            f.write(struct.pack("<I", 6))
            f.write(struct.pack("<d", value))
        elif isinstance(value, str):
            f.write(struct.pack("<I", 8))
            self._write_string(f, value)
        else:
            f.write(struct.pack("<I", 8))
            self._write_string(f, str(value))

    def _write_tensors(self, f, ggml_type: int) -> None:
        for name, tensor in self.tensors:
            self._write_string(f, name)
            n_dims = len(tensor.shape)
            f.write(struct.pack("<I", n_dims))
            for dim in reversed(tensor.shape):
                f.write(struct.pack("<q", dim))
            f.write(struct.pack("<I", ggml_type))
            f.write(struct.pack("<q", 0))

            quant_fn = QUANTIZE_FN.get(ggml_type, _quantize_f16)
            data = quant_fn(tensor)
            f.write(data)
