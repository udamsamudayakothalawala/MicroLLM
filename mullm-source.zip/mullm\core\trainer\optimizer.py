from __future__ import annotations

import math
from typing import Any, Callable, Dict, Iterable, List, Optional, Tuple, Union

import torch
from torch import Tensor
from torch.optim.optimizer import Optimizer, ParamsT

from mullm.core.trainer.training_config import OptimizerConfig, OptimizerType


class AdamW(Optimizer):
    def __init__(
        self,
        params: ParamsT,
        lr: float = 1e-4,
        betas: Tuple[float, float] = (0.9, 0.999),
        eps: float = 1e-8,
        weight_decay: float = 0.01,
        foreach: bool = True,
        fused: bool = False,
        decoupled_weight_decay: bool = True,
    ) -> None:
        if not 0.0 <= lr:
            raise ValueError(f"Invalid learning rate: {lr}")
        if not 0.0 <= eps:
            raise ValueError(f"Invalid epsilon value: {eps}")
        if not 0.0 <= betas[0] < 1.0:
            raise ValueError(f"Invalid beta parameter at index 0: {betas[0]}")
        if not 0.0 <= betas[1] < 1.0:
            raise ValueError(f"Invalid beta parameter at index 1: {betas[1]}")
        if not 0.0 <= weight_decay:
            raise ValueError(f"Invalid weight_decay value: {weight_decay}")

        defaults = {
            "lr": lr,
            "betas": betas,
            "eps": eps,
            "weight_decay": weight_decay,
            "foreach": foreach,
            "fused": fused,
            "decoupled_weight_decay": decoupled_weight_decay,
        }
        super().__init__(params, defaults)

    def __setstate__(self, state: Dict[str, Any]) -> None:
        super().__setstate__(state)
        for group in self.param_groups:
            group.setdefault("fused", False)
            group.setdefault("foreach", True)
            group.setdefault("decoupled_weight_decay", True)

    @torch.no_grad()
    def step(self, closure: Optional[Callable[[], float]] = None) -> Optional[float]:
        loss = None
        if closure is not None:
            with torch.enable_grad():
                loss = closure()

        for group in self.param_groups:
            params_with_grad: List[Tensor] = []
            grads: List[Tensor] = []
            exp_avgs: List[Tensor] = []
            exp_avg_sqs: List[Tensor] = []
            state_steps: List[int] = []
            beta1, beta2 = group["betas"]

            for p in group["params"]:
                if p.grad is None:
                    continue
                params_with_grad.append(p)
                if p.grad.is_sparse:
                    raise RuntimeError("AdamW does not support sparse gradients")
                grads.append(p.grad)

                state = self.state[p]
                if len(state) == 0:
                    state["step"] = 0
                    state["exp_avg"] = torch.zeros_like(p, memory_format=torch.preserve_format)
                    state["exp_avg_sq"] = torch.zeros_like(p, memory_format=torch.preserve_format)

                exp_avgs.append(state["exp_avg"])
                exp_avg_sqs.append(state["exp_avg_sq"])
                state_steps.append(state["step"])

            if not params_with_grad:
                continue

            self._adamw_update(
                params_with_grad,
                grads,
                exp_avgs,
                exp_avg_sqs,
                state_steps,
                beta1=beta1,
                beta2=beta2,
                lr=group["lr"],
                weight_decay=group["weight_decay"],
                eps=group["eps"],
                foreach=group["foreach"],
                fused=group["fused"],
                decoupled=group["decoupled_weight_decay"],
            )

            for s in state_steps:
                s += 1

        return loss

    def _adamw_update(
        self,
        params: List[Tensor],
        grads: List[Tensor],
        exp_avgs: List[Tensor],
        exp_avg_sqs: List[Tensor],
        state_steps: List[int],
        beta1: float,
        beta2: float,
        lr: float,
        weight_decay: float,
        eps: float,
        foreach: bool,
        fused: bool,
        decoupled: bool,
    ) -> None:
        if fused:
            self._fused_adamw(params, grads, exp_avgs, exp_avg_sqs, state_steps, beta1, beta2, lr, weight_decay, eps, decoupled)
        elif foreach:
            self._foreach_adamw(params, grads, exp_avgs, exp_avg_sqs, state_steps, beta1, beta2, lr, weight_decay, eps, decoupled)
        else:
            self._single_adamw(params, grads, exp_avgs, exp_avg_sqs, state_steps, beta1, beta2, lr, weight_decay, eps, decoupled)

    def _single_adamw(
        self,
        params: List[Tensor],
        grads: List[Tensor],
        exp_avgs: List[Tensor],
        exp_avg_sqs: List[Tensor],
        state_steps: List[int],
        beta1: float,
        beta2: float,
        lr: float,
        weight_decay: float,
        eps: float,
        decoupled: bool,
    ) -> None:
        for i, p in enumerate(params):
            grad = grads[i]
            exp_avg = exp_avgs[i]
            exp_avg_sq = exp_avg_sqs[i]
            step = state_steps[i] + 1

            bias_correction1 = 1 - beta1 ** step
            bias_correction2 = 1 - beta2 ** step

            exp_avg.mul_(beta1).add_(grad, alpha=1 - beta1)
            exp_avg_sq.mul_(beta2).addcmul_(grad, grad, value=1 - beta2)

            denom = (exp_avg_sq.sqrt() / math.sqrt(bias_correction2)).add_(eps)

            step_size = lr / bias_correction1
            p.addcdiv_(exp_avg, denom, value=-step_size)

            if decoupled:
                p.mul_(1 - lr * weight_decay)
            else:
                p.add_(p, alpha=-weight_decay * lr)

    def _foreach_adamw(
        self,
        params: List[Tensor],
        grads: List[Tensor],
        exp_avgs: List[Tensor],
        exp_avg_sqs: List[Tensor],
        state_steps: List[int],
        beta1: float,
        beta2: float,
        lr: float,
        weight_decay: float,
        eps: float,
        decoupled: bool,
    ) -> None:
        steps = [s + 1 for s in state_steps]
        bias_correction1 = [1 - beta1 ** s for s in steps]
        bias_correction2 = [1 - beta2 ** s for s in steps]

        torch._foreach_mul_(exp_avgs, beta1)
        torch._foreach_add_(exp_avgs, grads, alpha=1 - beta1)

        torch._foreach_mul_(exp_avg_sqs, beta2)
        torch._foreach_addcmul_(exp_avg_sqs, grads, grads, value=1 - beta2)

        denom = torch._foreach_sqrt(exp_avg_sqs)
        denom = [
            d / math.sqrt(bc2) if bc2 > 0 else d for d, bc2 in zip(denom, bias_correction2)
        ]
        torch._foreach_add_(denom, eps)

        step_sizes = [lr / bc1 for bc1 in bias_correction1]
        torch._foreach_addcdiv_(params, exp_avgs, denom, value=-1.0)
        for p, ss in zip(params, step_sizes):
            p.addcdiv_(exp_avgs[i], denom[i], value=-ss)

        if decoupled:
            torch._foreach_mul_(params, 1 - lr * weight_decay)
        else:
            torch._foreach_add_(params, params, alpha=-weight_decay * lr)

    def _fused_adamw(
        self,
        params: List[Tensor],
        grads: List[Tensor],
        exp_avgs: List[Tensor],
        exp_avg_sqs: List[Tensor],
        state_steps: List[int],
        beta1: float,
        beta2: float,
        lr: float,
        weight_decay: float,
        eps: float,
        decoupled: bool,
    ) -> None:
        try:
            from torch.optim import _fused_adam
            _fused_adam(params, grads, exp_avgs, exp_avg_sqs, state_steps, beta1, beta2, lr, weight_decay, eps, decoupled)
        except ImportError:
            self._foreach_adamw(params, grads, exp_avgs, exp_avg_sqs, state_steps, beta1, beta2, lr, weight_decay, eps, decoupled)

    @classmethod
    def build_with_groups(
        cls,
        model: torch.nn.Module,
        config: OptimizerConfig,
    ) -> AdamW:
        if config.optimizer_type != OptimizerType.adamw:
            raise ValueError(f"Expected adamw optimizer type, got {config.optimizer_type}")

        adamw_cfg = config.adamw
        no_decay = config.no_decay_params

        decay_params = []
        no_decay_params = []

        for name, param in model.named_parameters():
            if not param.requires_grad:
                continue
            if any(nd in name.lower() for nd in no_decay):
                no_decay_params.append(param)
            else:
                decay_params.append(param)

        param_groups = [
            {"params": decay_params, "weight_decay": adamw_cfg.weight_decay},
            {"params": no_decay_params, "weight_decay": 0.0},
        ]

        return cls(
            param_groups,
            lr=adamw_cfg.lr,
            betas=adamw_cfg.betas,
            eps=adamw_cfg.eps,
            weight_decay=adamw_cfg.weight_decay,
            foreach=adamw_cfg.foreach,
            fused=adamw_cfg.fused,
            decoupled_weight_decay=adamw_cfg.decoupled_weight_decay,
        )


class Lion(Optimizer):
    def __init__(
        self,
        params: ParamsT,
        lr: float = 1e-4,
        betas: Tuple[float, float] = (0.9, 0.99),
        weight_decay: float = 0.0,
        decoupled_weight_decay: bool = True,
    ) -> None:
        if not 0.0 <= lr:
            raise ValueError(f"Invalid learning rate: {lr}")
        if not 0.0 <= betas[0] < 1.0:
            raise ValueError(f"Invalid beta parameter at index 0: {betas[0]}")
        if not 0.0 <= betas[1] < 1.0:
            raise ValueError(f"Invalid beta parameter at index 1: {betas[1]}")
        if not 0.0 <= weight_decay:
            raise ValueError(f"Invalid weight_decay value: {weight_decay}")

        defaults = {
            "lr": lr,
            "betas": betas,
            "weight_decay": weight_decay,
            "decoupled_weight_decay": decoupled_weight_decay,
        }
        super().__init__(params, defaults)

    @torch.no_grad()
    def step(self, closure: Optional[Callable[[], float]] = None) -> Optional[float]:
        loss = None
        if closure is not None:
            with torch.enable_grad():
                loss = closure()

        for group in self.param_groups:
            beta1, beta2 = group["betas"]

            for p in group["params"]:
                if p.grad is None:
                    continue

                grad = p.grad
                state = self.state[p]

                if len(state) == 0:
                    state["exp_avg"] = torch.zeros_like(p, memory_format=torch.preserve_format)
                    state["step"] = 0

                exp_avg = state["exp_avg"]
                state["step"] += 1
                step = state["step"]

                exp_avg.mul_(beta1).add_(grad, alpha=1 - beta1)

                update = exp_avg.sign()
                if group["decoupled_weight_decay"]:
                    p.mul_(1 - group["lr"] * group["weight_decay"])
                    p.add_(update, alpha=-group["lr"])
                else:
                    p.add_(update, alpha=-group["lr"])
                    p.add_(p, alpha=-group["weight_decay"] * group["lr"])

        return loss

    @classmethod
    def build_with_groups(
        cls,
        model: torch.nn.Module,
        config: OptimizerConfig,
    ) -> Lion:
        if config.optimizer_type != OptimizerType.lion:
            raise ValueError(f"Expected lion optimizer type, got {config.optimizer_type}")

        lion_cfg = config.lion
        no_decay = config.no_decay_params

        decay_params = []
        no_decay_params = []

        for name, param in model.named_parameters():
            if not param.requires_grad:
                continue
            if any(nd in name.lower() for nd in no_decay):
                no_decay_params.append(param)
            else:
                decay_params.append(param)

        param_groups = [
            {"params": decay_params, "weight_decay": lion_cfg.weight_decay},
            {"params": no_decay_params, "weight_decay": 0.0},
        ]

        return cls(
            param_groups,
            lr=lion_cfg.lr,
            betas=lion_cfg.betas,
            weight_decay=lion_cfg.weight_decay,
            decoupled_weight_decay=lion_cfg.decoupled_weight_decay,
        )


class Adafactor(Optimizer):
    def __init__(
        self,
        params: ParamsT,
        lr: Optional[float] = None,
        eps: Tuple[float, float] = (1e-30, 1e-3),
        clip_threshold: float = 1.0,
        decay_rate: float = -0.8,
        beta1: Optional[float] = None,
        weight_decay: float = 0.0,
        scale_parameter: bool = True,
        relative_step: bool = True,
        warmup_init: bool = False,
    ) -> None:
        if lr is not None and not 0.0 <= lr:
            raise ValueError(f"Invalid learning rate: {lr}")
        if not 0.0 <= eps[0]:
            raise ValueError(f"Invalid epsilon value 0: {eps[0]}")
        if not 0.0 <= eps[1]:
            raise ValueError(f"Invalid epsilon value 1: {eps[1]}")
        if not 0.0 <= clip_threshold:
            raise ValueError(f"Invalid clip_threshold value: {clip_threshold}")
        if not 0.0 <= weight_decay:
            raise ValueError(f"Invalid weight_decay value: {weight_decay}")

        defaults = {
            "lr": lr,
            "eps": eps,
            "clip_threshold": clip_threshold,
            "decay_rate": decay_rate,
            "beta1": beta1,
            "weight_decay": weight_decay,
            "scale_parameter": scale_parameter,
            "relative_step": relative_step,
            "warmup_init": warmup_init,
        }
        super().__init__(params, defaults)

    def __setstate__(self, state: Dict[str, Any]) -> None:
        super().__setstate__(state)

    @torch.no_grad()
    def step(self, closure: Optional[Callable[[], float]] = None) -> Optional[float]:
        loss = None
        if closure is not None:
            with torch.enable_grad():
                loss = closure()

        for group in self.param_groups:
            for p in group["params"]:
                if p.grad is None:
                    continue

                grad = p.grad
                if grad.is_sparse:
                    raise RuntimeError("Adafactor does not support sparse gradients")

                state = self.state[p]
                grad_shape = grad.shape

                if len(state) == 0:
                    state["step"] = 0
                    if len(grad_shape) >= 2:
                        state["exp_avg_sq_row"] = torch.zeros(grad_shape[:-1], dtype=torch.float32, device=p.device)
                        state["exp_avg_sq_col"] = torch.zeros(grad_shape[:-2] + grad_shape[-1:], dtype=torch.float32, device=p.device)
                    else:
                        state["exp_avg_sq"] = torch.zeros(1, dtype=torch.float32, device=p.device)

                state["step"] += 1
                step = state["step"]

                lr = group["lr"]
                eps = group["eps"]
                clip_threshold = group["clip_threshold"]
                decay_rate = group["decay_rate"]
                beta1 = group["beta1"]
                weight_decay = group["weight_decay"]
                scale_parameter = group["scale_parameter"]
                relative_step = group["relative_step"]
                warmup_init = group["warmup_init"]

                if relative_step:
                    lr = max(min(1e-2, 1.0 / math.sqrt(max(step - 1, 1))), 1e-6)
                    if warmup_init and step < 10000:
                        lr = lr * float(step) / 10000.0

                update = grad.float()
                update_squared = update * update

                if len(grad_shape) >= 2:
                    exp_avg_sq_row = state["exp_avg_sq_row"]
                    exp_avg_sq_col = state["exp_avg_sq_col"]

                    if decay_rate < 0:
                        exp_avg_sq_row.mul_(1.0).add_(update_squared.mean(dim=-1), alpha=1.0)
                        exp_avg_sq_col.mul_(1.0).add_(update_squared.mean(dim=-2), alpha=1.0)
                    else:
                        exp_avg_sq_row.mul_(decay_rate).add_(update_squared.mean(dim=-1), alpha=1 - decay_rate)
                        exp_avg_sq_col.mul_(decay_rate).add_(update_squared.mean(dim=-2), alpha=1 - decay_rate)

                    row_rms = exp_avg_sq_row.rsqrt()
                    col_rms = exp_avg_sq_col.rsqrt()
                    update = update * row_rms.unsqueeze(-1) * col_rms.unsqueeze(-2)

                    rms = torch.sqrt(update_squared.mean())
                    clipping_norm = (row_rms.mean() * col_rms.mean()).rsqrt()
                    update = update * (clipping_norm / (rms + eps[0])).clamp(max=clip_threshold)

                    if scale_parameter:
                        update = update * (row_rms.mean() * col_rms.mean()).rsqrt()
                else:
                    exp_avg_sq = state["exp_avg_sq"]
                    if decay_rate < 0:
                        exp_avg_sq.mul_(1.0).add_(update_squared, alpha=1.0)
                    else:
                        exp_avg_sq.mul_(decay_rate).add_(update_squared, alpha=1 - decay_rate)

                    rms = exp_avg_sq.rsqrt()
                    clipping_norm = rms.rsqrt()
                    update = update * (clipping_norm / (rms + eps[0])).clamp(max=clip_threshold)

                    if scale_parameter:
                        update = update * rms

                if beta1 is not None:
                    if "exp_avg" not in state:
                        state["exp_avg"] = torch.zeros_like(update, memory_format=torch.preserve_format)
                    state["exp_avg"].mul_(beta1).add_(update, alpha=1 - beta1)
                    update = state["exp_avg"]

                if weight_decay > 0.0:
                    p.mul_(1 - lr * weight_decay)

                if lr is not None:
                    update = update * lr

                p.add_(-update)

        return loss

    @classmethod
    def build_with_groups(
        cls,
        model: torch.nn.Module,
        config: OptimizerConfig,
    ) -> Adafactor:
        if config.optimizer_type != OptimizerType.adafactor:
            raise ValueError(f"Expected adafactor optimizer type, got {config.optimizer_type}")

        af_cfg = config.adafactor
        no_decay = config.no_decay_params

        decay_params = []
        no_decay_params = []

        for name, param in model.named_parameters():
            if not param.requires_grad:
                continue
            if any(nd in name.lower() for nd in no_decay):
                no_decay_params.append(param)
            else:
                decay_params.append(param)

        param_groups = [
            {"params": decay_params, "weight_decay": af_cfg.weight_decay},
            {"params": no_decay_params, "weight_decay": 0.0},
        ]

        return cls(
            param_groups,
            lr=af_cfg.lr,
            eps=af_cfg.eps,
            clip_threshold=af_cfg.clip_threshold,
            decay_rate=af_cfg.decay_rate,
            beta1=af_cfg.beta1,
            weight_decay=af_cfg.weight_decay,
            scale_parameter=af_cfg.scale_parameter,
            relative_step=af_cfg.relative_step,
            warmup_init=af_cfg.warmup_init,
        )


def build_optimizer(
    model: torch.nn.Module,
    config: OptimizerConfig,
) -> Optimizer:
    if config.optimizer_type == OptimizerType.adamw:
        return AdamW.build_with_groups(model, config)
    elif config.optimizer_type == OptimizerType.lion:
        return Lion.build_with_groups(model, config)
    elif config.optimizer_type == OptimizerType.adafactor:
        return Adafactor.build_with_groups(model, config)
    else:
        raise ValueError(f"Unknown optimizer type: {config.optimizer_type}")
