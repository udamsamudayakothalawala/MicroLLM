"""Self reflection system for LLM output evaluation and refinement."""

from __future__ import annotations

import json
import math
import random
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Callable, Dict, List, Optional, Set, Tuple


@dataclass
class ReflectionResult:
    original_output: str = ""
    critique: str = ""
    improved_output: str = ""
    confidence: float = 0.0
    uncertainty: float = 0.0
    verification_questions: List[str] = field(default_factory=list)
    verification_answers: List[str] = field(default_factory=list)
    issues_found: List[str] = field(default_factory=list)
    passed_verification: bool = False
    reflection_time: float = 0.0

    def to_dict(self) -> Dict[str, Any]:
        return {
            "original_output": self.original_output,
            "critique": self.critique,
            "improved_output": self.improved_output,
            "confidence": self.confidence,
            "uncertainty": self.uncertainty,
            "verification_questions": self.verification_questions,
            "verification_answers": self.verification_answers,
            "issues_found": self.issues_found,
            "passed_verification": self.passed_verification,
            "reflection_time": self.reflection_time,
        }


class SelfReflectionEngine:
    def __init__(
        self,
        llm_generate: Optional[Callable[[str], str]] = None,
        critique_prompt: str = "",
        improvement_prompt: str = "",
    ) -> None:
        self.llm_generate = llm_generate
        self.critique_prompt = critique_prompt or (
            "You are a critical reviewer. Analyze the following output for:\n"
            "1. Accuracy and factual correctness\n"
            "2. Completeness and thoroughness\n"
            "3. Clarity and coherence\n"
            "4. Logical consistency\n"
            "5. Potential improvements\n\n"
            "Output to critique:\n{output}\n\n"
            "Provide detailed constructive criticism."
        )
        self.improvement_prompt = improvement_prompt or (
            "You are an improvement specialist. Given the original output and "
            "the critique, produce an improved version that addresses all issues.\n\n"
            "Original output:\n{original}\n\n"
            "Critique:\n{critique}\n\n"
            "Improved output:"
        )

    def reflect(self, output: str, context: Optional[str] = None) -> ReflectionResult:
        import time
        start = time.monotonic()

        result = ReflectionResult(original_output=output)

        critique = self._generate_critique(output, context)
        result.critique = critique

        issues = self._extract_issues(critique)
        result.issues_found = issues

        improved = self._generate_improvement(output, critique)
        result.improved_output = improved

        result.confidence = self._estimate_confidence(improved)
        result.uncertainty = 1.0 - result.confidence

        questions = self._generate_verification_questions(improved)
        result.verification_questions = questions

        answers = self._answer_verification_questions(questions, improved)
        result.verification_answers = answers

        result.passed_verification = self._check_verification(answers)
        result.reflection_time = time.monotonic() - start

        return result

    def _generate_critique(self, output: str, context: Optional[str] = None) -> str:
        if self.llm_generate:
            prompt = self.critique_prompt.format(output=output)
            if context:
                prompt += f"\n\nAdditional context:\n{context}"
            return self.llm_generate(prompt)
        return self._default_critique(output)

    def _generate_improvement(self, original: str, critique: str) -> str:
        if self.llm_generate:
            prompt = self.improvement_prompt.format(original=original, critique=critique)
            return self.llm_generate(prompt)
        return original

    def _extract_issues(self, critique: str) -> List[str]:
        issues: List[str] = []
        lines = critique.strip().split('\n')
        for line in lines:
            stripped = line.strip().strip('-*')
            if stripped and len(stripped) > 10 and any(
                kw in stripped.lower()
                for kw in ['issue', 'problem', 'error', 'incorrect', 'missing',
                           'unclear', 'wrong', 'lack', 'should', 'could improve']
            ):
                issues.append(stripped)
        return issues[:10]

    def _default_critique(self, output: str) -> str:
        word_count = len(output.split())
        issues: List[str] = []

        if word_count < 10:
            issues.append("Output is too short, lacks detail")
        if word_count > 1000:
            issues.append("Output is verbose, could be more concise")

        sentences = output.count('.')
        if sentences > 0:
            avg_sentence_length = word_count / sentences
            if avg_sentence_length > 30:
                issues.append("Sentences are too long, reduce complexity")

        if output.count('?') > word_count * 0.1:
            issues.append("Contains many questions, be more definitive")
        if output.count('!') > word_count * 0.05:
            issues.append("Overuse of exclamation marks")

        if issues:
            return "Critique:\n- " + "\n- ".join(issues)
        return "Critique:\n- Output appears reasonable in length and structure."

    def _estimate_confidence(self, output: str) -> float:
        score = 0.5

        if not output:
            return 0.0

        uncertain_phrases = [
            "i think", "i believe", "maybe", "perhaps", "possibly",
            "not sure", "uncertain", "might", "could be", "i'm not",
            "i don't know", "it depends", "arguably", "sort of",
            "kind of", "approximately", "roughly",
        ]
        confident_phrases = [
            "definitely", "certainly", "clearly", "undoubtedly",
            "absolutely", "always", "never", "must be", "is always",
            "proven", "established", "confirmed",
        ]

        text_lower = output.lower()
        uncertain_count = sum(1 for p in uncertain_phrases if p in text_lower)
        confident_count = sum(1 for p in confident_phrases if p in text_lower)

        score -= uncertain_count * 0.05
        score += confident_count * 0.05

        word_count = len(output.split())
        if word_count < 20:
            score -= 0.2
        elif word_count > 200:
            score += 0.1

        if output.endswith('?') or output.endswith('...'):
            score -= 0.1

        return max(0.0, min(1.0, score))

    def _generate_verification_questions(self, output: str) -> List[str]:
        questions: List[str] = []
        sentences = [s.strip() for s in output.split('.') if len(s.strip()) > 20]

        for sentence in sentences[:3]:
            sentence_lower = sentence.lower()
            if ' is ' in sentence_lower:
                parts = sentence.split(' is ', 1)
                if len(parts) == 2:
                    subject = parts[0].strip().split()[-1] if parts[0].strip() else parts[0].strip()
                    questions.append(f"Is it true that {sentence_lower.strip()}?")
            elif any(kw in sentence_lower for kw in ['because', 'since', 'due to', 'therefore']):
                questions.append(f"What evidence supports: '{sentence.strip()}'?")
            else:
                if len(sentence) > 30:
                    questions.append(f"Can you verify: '{sentence.strip()}'?")
                    questions.append(f"What is the source of the claim: '{sentence.strip()}'?")

        if not questions:
            questions.append(f"Does the output correctly address the query?")
            questions.append(f"Are there any factual errors in the output?")

        return questions[:5]

    def _answer_verification_questions(self, questions: List[str], output: str) -> List[str]:
        if self.llm_generate:
            answers: List[str] = []
            for q in questions:
                prompt = (
                    f"Based on this output, answer the verification question.\n\n"
                    f"Output:\n{output}\n\n"
                    f"Question: {q}\n\nAnswer:"
                )
                try:
                    answer = self.llm_generate(prompt)
                    answers.append(answer.strip()[:200])
                except Exception:
                    answers.append("Unable to verify")
            return answers
        return ["Verify based on available knowledge" for _ in questions]

    def _check_verification(self, answers: List[str]) -> bool:
        if not answers:
            return True
        failure_indicators = ["unable", "cannot confirm", "incorrect", "false", "wrong", "error"]
        failures = sum(
            1 for a in answers
            if any(indicator in a.lower() for indicator in failure_indicators)
        )
        return failures < len(answers) * 0.5


class RefinementLoop:
    def __init__(
        self,
        engine: SelfReflectionEngine,
        max_iterations: int = 3,
        improvement_threshold: float = 0.1,
    ) -> None:
        self.engine = engine
        self.max_iterations = max_iterations
        self.improvement_threshold = improvement_threshold

    def refine(self, output: str, context: Optional[str] = None) -> ReflectionResult:
        current = output
        best_result = ReflectionResult(original_output=output, improved_output=output)

        for i in range(self.max_iterations):
            result = self.engine.reflect(current, context)
            result.original_output = output

            if result.confidence > best_result.confidence + self.improvement_threshold:
                best_result = result

            if result.passed_verification and result.confidence > 0.8:
                best_result = result
                break

            current = result.improved_output

        return best_result


class ConfidenceScorer:
    def __init__(
        self,
        llm_generate: Optional[Callable[[str], str]] = None,
    ) -> None:
        self.llm_generate = llm_generate

    def score(self, output: str, criteria: Optional[List[str]] = None) -> Dict[str, float]:
        if criteria is None:
            criteria = ["accuracy", "completeness", "clarity", "relevance"]

        scores: Dict[str, float] = {}
        for criterion in criteria:
            scores[criterion] = self._score_criterion(output, criterion)

        scores["overall"] = sum(scores.values()) / len(scores)
        return scores

    def _score_criterion(self, output: str, criterion: str) -> float:
        if self.llm_generate:
            prompt = (
                f"Score the following output on '{criterion}' from 0.0 to 1.0.\n"
                f"Output: {output}\n\nScore:"
            )
            try:
                response = self.llm_generate(prompt)
                numbers = [float(s) for s in response.split() if s.replace('.', '').isdigit()]
                if numbers:
                    return max(0.0, min(1.0, numbers[0]))
            except Exception:
                pass
        return 0.5


class UncertaintyEstimator:
    def __init__(
        self,
        llm_generate: Optional[Callable[[str], str]] = None,
    ) -> None:
        self.llm_generate = llm_generate

    def estimate(self, output: str, num_samples: int = 3) -> float:
        if not self.llm_generate:
            return self._heuristic_uncertainty(output)

        prompt = (
            f"Given this output, generate {num_samples} alternative responses "
            f"that could also be correct:\n\n{output}\n\nAlternatives:"
        )
        try:
            response = self.llm_generate(prompt)
            alternatives = self._extract_alternatives(response)
            return self._compute_variance(output, alternatives)
        except Exception:
            return self._heuristic_uncertainty(output)

    def _extract_alternatives(self, text: str) -> List[str]:
        lines = text.strip().split('\n')
        alternatives = [l.strip() for l in lines if l.strip() and len(l.strip()) > 20]
        return alternatives[:5]

    def _compute_variance(self, original: str, alternatives: List[str]) -> float:
        if not alternatives:
            return 1.0
        similarity_scores = []
        for alt in alternatives:
            sim = self._text_similarity(original.lower(), alt.lower())
            similarity_scores.append(sim)
        avg_similarity = sum(similarity_scores) / len(similarity_scores)
        return 1.0 - avg_similarity

    def _text_similarity(self, a: str, b: str) -> float:
        words_a = set(a.split())
        words_b = set(b.split())
        if not words_a or not words_b:
            return 0.0
        overlap = words_a & words_b
        union = words_a | words_b
        return len(overlap) / len(union)

    def _heuristic_uncertainty(self, output: str) -> float:
        uncertain_words = {
            "maybe", "perhaps", "possibly", "might", "could", "unclear",
            "uncertain", "not sure", "approximately", "roughly", "around",
            "i think", "i believe", "it seems", "apparently",
        }
        text_lower = output.lower()
        matches = sum(1 for w in uncertain_words if w in text_lower)
        return min(1.0, matches * 0.15)


class VerificationQuestionGenerator:
    def __init__(self, llm_generate: Optional[Callable[[str], str]] = None) -> None:
        self.llm_generate = llm_generate

    def generate(self, output: str, num_questions: int = 3) -> List[str]:
        questions: List[str] = []
        sentences = [s.strip() for s in output.replace('!', '.').replace('?', '.').split('.') if len(s.strip()) > 15]

        for sentence in sentences[:num_questions]:
            if ' because ' in sentence.lower():
                questions.append(f"Is the reasoning in '{sentence[:100]}' valid?")
            elif any(x in sentence.lower() for x in ['is', 'are', 'was', 'were']):
                questions.append(f"Can you confirm: '{sentence[:100]}'?")
            else:
                questions.append(f"What is the basis for: '{sentence[:100]}'?")

        while len(questions) < num_questions:
            questions.append(f"Does the output contain any factual errors?")

        return questions[:num_questions]

    def verify(self, output: str) -> Tuple[bool, List[str]]:
        questions = self.generate(output)
        if self.llm_generate:
            answers: List[str] = []
            for q in questions:
                prompt = f"Output: {output}\n\nQuestion: {q}\n\nAnswer (yes/no/uncertain):"
                try:
                    answers.append(self.llm_generate(prompt).strip()[:100])
                except Exception:
                    answers.append("uncertain")
            failures = sum(1 for a in answers if a.lower().startswith('no'))
            return failures < len(answers) * 0.5, questions
        return True, questions


class SelfConsistency:
    def __init__(
        self,
        llm_generate: Callable[[str], str],
        num_samples: int = 5,
        temperature: float = 0.7,
    ) -> None:
        self.llm_generate = llm_generate
        self.num_samples = num_samples
        self.temperature = temperature

    def generate_samples(self, prompt: str) -> List[str]:
        samples: List[str] = []
        for _ in range(self.num_samples):
            try:
                response = self.llm_generate(prompt)
                samples.append(response)
            except Exception:
                continue
        return samples

    def compute_consistency(self, samples: List[str]) -> Dict[str, Any]:
        if not samples:
            return {"consistency_score": 0.0, "majority_answer": "", "samples": []}

        pairwise_similarities = []
        for i in range(len(samples)):
            for j in range(i + 1, len(samples)):
                sim = self._text_similarity(samples[i], samples[j])
                pairwise_similarities.append(sim)

        consistency = sum(pairwise_similarities) / len(pairwise_similarities) if pairwise_similarities else 0.0

        clusters = self._cluster_samples(samples)
        majority = max(clusters, key=lambda c: len(c)) if clusters else samples

        return {
            "consistency_score": consistency,
            "num_samples": len(samples),
            "num_clusters": len(clusters),
            "majority_answer": majority[0] if majority else "",
            "cluster_sizes": [len(c) for c in clusters],
            "samples": samples,
        }

    def _text_similarity(self, a: str, b: str) -> float:
        words_a = set(a.lower().split())
        words_b = set(b.lower().split())
        if not words_a or not words_b:
            return 0.0
        overlap = words_a & words_b
        union = words_a | words_b
        return len(overlap) / len(union)

    def _cluster_samples(self, samples: List[str]) -> List[List[str]]:
        clusters: List[List[str]] = []
        assigned = [False] * len(samples)

        for i in range(len(samples)):
            if assigned[i]:
                continue
            cluster = [samples[i]]
            assigned[i] = True
            for j in range(i + 1, len(samples)):
                if not assigned[j] and self._text_similarity(samples[i], samples[j]) > 0.5:
                    cluster.append(samples[j])
                    assigned[j] = True
            clusters.append(cluster)

        return clusters
