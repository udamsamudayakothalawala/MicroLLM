import torch  # noqa: F401,E402  (load before PyQt5 to avoid DLL conflicts)

"""muLLM GUI - Train tab: configure and run training with live monitoring."""

import time
from datetime import datetime

from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QPushButton, QLabel,
    QTextEdit, QProgressBar, QGroupBox, QGridLayout, QSplitter,
    QTableWidget, QTableWidgetItem, QHeaderView, QMessageBox,
    QSpinBox, QDoubleSpinBox, QComboBox, QLineEdit, QCheckBox,
    QScrollArea, QFormLayout
)
from PyQt5.QtCore import Qt, QTimer

from .workers import TrainWorker


class TrainTab(QWidget):
    def __init__(self, dataset_tab=None, parent=None):
        super().__init__(parent)
        self.dataset_tab = dataset_tab
        self.trainer = None
        self.start_time = None
        self.build_ui()

    def build_ui(self):
        main = QHBoxLayout(self)
        main.setContentsMargins(12, 12, 12, 12)
        splitter = QSplitter(Qt.Horizontal)

        left = QWidget()
        left_layout = QVBoxLayout(left)
        left_layout.setContentsMargins(0, 0, 0, 0)

        header = QLabel("TRAIN MODEL")
        header.setProperty("class", "heading")
        left_layout.addWidget(header)
        sub = QLabel("Configure the model and start training. Monitor loss in real time.")
        sub.setProperty("class", "subheading")
        left_layout.addWidget(sub)

        config_group = QGroupBox("Model & Training")
        form = QFormLayout(config_group)

        self.size_combo = QComboBox()
        self.size_combo.addItems(["tiny", "small", "base", "medium"])
        self.size_combo.setCurrentText("tiny")
        form.addRow("Model size:", self.size_combo)

        self.epochs_spin = QSpinBox()
        self.epochs_spin.setRange(1, 1000)
        self.epochs_spin.setValue(3)
        form.addRow("Epochs:", self.epochs_spin)

        self.max_steps_spin = QSpinBox()
        self.max_steps_spin.setRange(-1, 1000000)
        self.max_steps_spin.setValue(-1)
        self.max_steps_spin.setSpecialValueText("Auto")
        form.addRow("Max steps:", self.max_steps_spin)

        self.batch_size_spin = QSpinBox()
        self.batch_size_spin.setRange(1, 1024)
        self.batch_size_spin.setValue(8)
        form.addRow("Batch size:", self.batch_size_spin)

        self.lr_spin = QDoubleSpinBox()
        self.lr_spin.setRange(1e-8, 1.0)
        self.lr_spin.setValue(3e-4)
        self.lr_spin.setDecimals(7)
        self.lr_spin.setExpressionsEnabled(True)
        form.addRow("Learning rate:", self.lr_spin)

        self.seq_len_spin = QSpinBox()
        self.seq_len_spin.setRange(16, 32768)
        self.seq_len_spin.setValue(256)
        self.seq_len_spin.setSingleStep(16)
        form.addRow("Max seq len:", self.seq_len_spin)

        self.vocab_spin = QSpinBox()
        self.vocab_spin.setRange(256, 64000)
        self.vocab_spin.setValue(3000)
        self.vocab_spin.setSingleStep(100)
        form.addRow("Vocab size:", self.vocab_spin)

        self.warmup_spin = QSpinBox()
        self.warmup_spin.setRange(0, 100000)
        self.warmup_spin.setValue(100)
        form.addRow("Warmup steps:", self.warmup_spin)

        self.save_steps_spin = QSpinBox()
        self.save_steps_spin.setRange(0, 100000)
        self.save_steps_spin.setValue(500)
        self.save_steps_spin.setSpecialValueText("Off")
        form.addRow("Save every N steps:", self.save_steps_spin)

        self.eval_steps_spin = QSpinBox()
        self.eval_steps_spin.setRange(0, 100000)
        self.eval_steps_spin.setValue(200)
        self.eval_steps_spin.setSpecialValueText("Off")
        form.addRow("Eval every N steps:", self.eval_steps_spin)

        self.device_combo = QComboBox()
        self.device_combo.addItems(["auto", "cuda", "cpu", "mps"])
        form.addRow("Device:", self.device_combo)

        self.bf16_check = QCheckBox("BF16")
        self.bf16_check.setChecked(True)
        form.addRow("", self.bf16_check)

        self.output_dir_edit = QLineEdit("./outputs")
        form.addRow("Output dir:", self.output_dir_edit)

        left_layout.addWidget(config_group)

        controls = QHBoxLayout()
        self.start_btn = QPushButton("▶ Start Training")
        self.start_btn.setProperty("class", "btn-success")
        self.start_btn.clicked.connect(self.start_training)
        self.stop_btn = QPushButton("■ Stop")
        self.stop_btn.setProperty("class", "btn-danger")
        self.stop_btn.setEnabled(False)
        self.stop_btn.clicked.connect(self.stop_training)
        controls.addWidget(self.start_btn)
        controls.addWidget(self.stop_btn)
        controls.addStretch()
        left_layout.addLayout(controls)

        status_group = QGroupBox("Status")
        sg = QGridLayout(status_group)
        self.status_label = QLabel("Ready")
        sg.addWidget(QLabel("Status:"), 0, 0)
        sg.addWidget(self.status_label, 0, 1)
        self.current_loss = QLabel("—")
        self.current_loss.setProperty("class", "metric-value")
        sg.addWidget(QLabel("Loss:"), 1, 0)
        sg.addWidget(self.current_loss, 1, 1)
        self.current_ppl = QLabel("—")
        sg.addWidget(QLabel("Perplexity:"), 2, 0)
        sg.addWidget(self.current_ppl, 2, 1)
        self.level_label = QLabel("—")
        sg.addWidget(QLabel("Training level:"), 3, 0)
        sg.addWidget(self.level_label, 3, 1)
        self.current_step = QLabel("0")
        sg.addWidget(QLabel("Step:"), 4, 0)
        sg.addWidget(self.current_step, 4, 1)
        self.elapsed_label = QLabel("00:00:00")
        sg.addWidget(QLabel("Elapsed:"), 5, 0)
        sg.addWidget(self.elapsed_label, 5, 1)
        left_layout.addWidget(status_group)

        self.progress_bar = QProgressBar()
        self.progress_bar.setValue(0)
        left_layout.addWidget(self.progress_bar)

        self.log_output = QTextEdit()
        self.log_output.setReadOnly(True)
        self.log_output.setPlaceholderText("Training logs will appear here...")
        left_layout.addWidget(QLabel("LOG"))
        left_layout.addWidget(self.log_output)

        right = QWidget()
        right_layout = QVBoxLayout(right)
        right_layout.setContentsMargins(0, 0, 0, 0)

        metrics_header = QLabel("METRICS HISTORY")
        metrics_header.setProperty("class", "heading")
        right_layout.addWidget(metrics_header)

        self.metrics_table = QTableWidget()
        self.metrics_table.setColumnCount(6)
        self.metrics_table.setHorizontalHeaderLabels(["Step", "Loss", "Perplexity", "Level", "LR", "Eval Loss"])
        self.metrics_table.horizontalHeader().setStretchLastSection(True)
        right_layout.addWidget(self.metrics_table)

        splitter.addWidget(left)
        splitter.addWidget(right)
        splitter.setStretchFactor(0, 3)
        splitter.setStretchFactor(1, 2)
        main.addWidget(splitter)

        self._timer = QTimer()
        self._timer.setInterval(1000)
        self._timer.timeout.connect(self._update_elapsed)

    def _level_for_loss(self, loss):
        if loss is None:
            return "Starting..."
        if loss < 2.5:
            return "Level 4 - Converged"
        if loss < 3.2:
            return "Level 3 - Learning well"
        if loss < 4.0:
            return "Level 2 - Learning"
        if loss < 5.5:
            return "Level 1 - Training"
        return "Level 0 - Initializing"

    def start_training(self):
        if not self.dataset_tab:
            QMessageBox.warning(self, "No Data", "Dataset tab not connected.")
            return
        texts = self.dataset_tab.get_training_data()
        if not texts:
            reply = QMessageBox.question(
                self, "No Dataset",
                "No dataset loaded. Use built-in sample data?",
                QMessageBox.Yes | QMessageBox.No
            )
            if reply != QMessageBox.Yes:
                return
            texts = ["Artificial intelligence is the simulation of human intelligence.\n"] * 50

        max_steps = self.max_steps_spin.value()
        save_steps = self.save_steps_spin.value()
        eval_steps = self.eval_steps_spin.value()

        config = {
            "output_dir": self.output_dir_edit.text() or "./outputs",
            "size": self.size_combo.currentText(),
            "num_epochs": self.epochs_spin.value(),
            "batch_size": self.batch_size_spin.value(),
            "learning_rate": self.lr_spin.value(),
            "max_seq_length": self.seq_len_spin.value(),
            "vocab_size": self.vocab_spin.value(),
            "warmup_steps": self.warmup_spin.value(),
            "max_steps": max_steps if max_steps > 0 else -1,
            "save_steps": save_steps if save_steps > 0 else 0,
            "eval_steps": eval_steps if eval_steps > 0 else 0,
            "device": self.device_combo.currentText(),
            "bf16": self.bf16_check.isChecked(),
        }

        self.start_btn.setEnabled(False)
        self.stop_btn.setEnabled(True)
        self.log_output.clear()
        self.metrics_table.setRowCount(0)
        self.progress_bar.setValue(0)
        self.start_time = time.time()
        self.elapsed_label.setText("00:00:00")
        self._timer.start()

        self.trainer = TrainWorker(config=config, train_dataset=texts)
        self.trainer.log_signal.connect(self._on_log)
        self.trainer.metrics_signal.connect(self._on_metrics)
        self.trainer.progress_signal.connect(
            lambda step, total: self.progress_bar.setValue(
                int(min(100, step / max(total, 1) * 100))))
        self.trainer.status_signal.connect(self.status_label.setText)
        self.trainer.finished_signal.connect(self._on_finished)
        self.trainer.error_signal.connect(self._on_error)
        self.trainer.start()

    def stop_training(self):
        if self.trainer:
            self.trainer.stop()
            self._on_log("Stopping training...")

    def _on_log(self, msg):
        ts = datetime.now().strftime("%H:%M:%S")
        self.log_output.append(f"[{ts}] {msg}")
        scroll = self.log_output.verticalScrollBar()
        scroll.setValue(scroll.maximum())

    def _on_metrics(self, metrics):
        step = metrics.get("step", 0)
        loss = metrics.get("loss")
        lr = metrics.get("lr")
        eval_loss = metrics.get("eval_loss")

        if loss is not None:
            self.current_loss.setText(f"{loss:.4f}")
            import math
            ppl = math.exp(min(loss, 20))
            self.current_ppl.setText(f"{ppl:.2f}")
            self.level_label.setText(self._level_for_loss(loss))

        self.current_step.setText(str(step))

        row = self.metrics_table.rowCount()
        self.metrics_table.insertRow(row)
        self.metrics_table.setItem(row, 0, QTableWidgetItem(str(step)))
        self.metrics_table.setItem(row, 1, QTableWidgetItem(f"{loss:.4f}" if loss else "—"))
        self.metrics_table.setItem(row, 2, QTableWidgetItem(self._ppl_str(loss)))
        self.metrics_table.setItem(row, 3, QTableWidgetItem(
            self._level_for_loss(loss).split(" - ")[0] if loss else "—"))
        self.metrics_table.setItem(row, 4, QTableWidgetItem(f"{lr:.2e}" if lr else "—"))
        self.metrics_table.setItem(row, 5, QTableWidgetItem(f"{eval_loss:.4f}" if eval_loss else "—"))
        self.metrics_table.scrollToBottom()

    def _ppl_str(self, loss):
        if loss is None:
            return "—"
        import math
        return f"{math.exp(min(loss, 20)):.2f}"

    def _on_finished(self, result):
        self.start_btn.setEnabled(True)
        self.stop_btn.setEnabled(False)
        self._timer.stop()
        self.status_label.setText("Completed")
        self._on_log(f"Training finished: {result}")
        self.progress_bar.setValue(100)

    def _on_error(self, err):
        self.start_btn.setEnabled(True)
        self.stop_btn.setEnabled(False)
        self._timer.stop()
        self.status_label.setText("Error")
        self._on_log(f"ERROR: {err}")

    def _update_elapsed(self):
        if self.start_time:
            elapsed = int(time.time() - self.start_time)
            h, rem = divmod(elapsed, 3600)
            m, s = divmod(rem, 60)
            self.elapsed_label.setText(f"{h:02d}:{m:02d}:{s:02d}")