import math
from typing import Any, Dict, List, Optional, Tuple

import torch
import torch.nn as nn
import torch.nn.functional as F


class ProjectionConfig:
    def __init__(
        self,
        projection_type: str = "mlp",
        vision_hidden_size: int = 768,
        text_hidden_size: int = 768,
        audio_hidden_size: int = 512,
        video_hidden_size: int = 512,
        projection_hidden_size: int = 1024,
        output_hidden_size: int = 768,
        num_query_tokens: int = 32,
        num_heads: int = 8,
        num_layers: int = 6,
        use_norm: bool = True,
        dropout: float = 0.1,
        temperature: float = 0.07,
    ):
        self.projection_type = projection_type
        self.vision_hidden_size = vision_hidden_size
        self.text_hidden_size = text_hidden_size
        self.audio_hidden_size = audio_hidden_size
        self.video_hidden_size = video_hidden_size
        self.projection_hidden_size = projection_hidden_size
        self.output_hidden_size = output_hidden_size
        self.num_query_tokens = num_query_tokens
        self.num_heads = num_heads
        self.num_layers = num_layers
        self.use_norm = use_norm
        self.dropout = dropout
        self.temperature = temperature


class LinearProjector(nn.Module):
    def __init__(self, in_features: int, out_features: int, use_norm: bool = True, dropout: float = 0.0):
        super().__init__()
        self.linear = nn.Linear(in_features, out_features)
        self.use_norm = use_norm
        if use_norm:
            self.norm = nn.LayerNorm(out_features, eps=1e-6)
        self.dropout = nn.Dropout(dropout)
        self.gate = nn.Parameter(torch.ones(1))

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = self.linear(x)
        if self.use_norm:
            x = self.norm(x)
        x = self.dropout(x)
        x = x * torch.sigmoid(self.gate)
        return x


class MLPProjector(nn.Module):
    def __init__(self, in_features: int, hidden_features: int, out_features: int, use_norm: bool = True, dropout: float = 0.0):
        super().__init__()
        self.fc1 = nn.Linear(in_features, hidden_features)
        self.act = nn.GELU()
        self.fc2 = nn.Linear(hidden_features, out_features)
        self.use_norm = use_norm
        if use_norm:
            self.norm = nn.LayerNorm(out_features, eps=1e-6)
        self.dropout = nn.Dropout(dropout)
        self.gate = nn.Parameter(torch.ones(1))
        self.skip = nn.Linear(in_features, out_features) if in_features != out_features else nn.Identity()

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        identity = self.skip(x)
        x = self.fc1(x)
        x = self.act(x)
        x = self.dropout(x)
        x = self.fc2(x)
        x = x + identity
        if self.use_norm:
            x = self.norm(x)
        x = x * torch.sigmoid(self.gate)
        return x


class QFormerTransformerBlock(nn.Module):
    def __init__(self, dim: int, num_heads: int, dropout: float = 0.1):
        super().__init__()
        self.self_attn = nn.MultiheadAttention(dim, num_heads, dropout=dropout, batch_first=True)
        self.cross_attn = nn.MultiheadAttention(dim, num_heads, dropout=dropout, batch_first=True)
        self.norm1 = nn.LayerNorm(dim)
        self.norm2 = nn.LayerNorm(dim)
        self.norm3 = nn.LayerNorm(dim)
        self.ffn = nn.Sequential(
            nn.Linear(dim, dim * 4),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(dim * 4, dim),
            nn.Dropout(dropout),
        )

    def forward(self, queries: torch.Tensor, keys: torch.Tensor, values: torch.Tensor, key_padding_mask: Optional[torch.Tensor] = None) -> torch.Tensor:
        q = self.norm1(queries)
        q = self.self_attn(q, q, q, need_weights=False)[0]
        queries = queries + q

        q = self.norm2(queries)
        q = self.cross_attn(q, keys, values, key_padding_mask=key_padding_mask, need_weights=False)[0]
        queries = queries + q

        q = self.norm3(queries)
        q = self.ffn(q)
        queries = queries + q
        return queries


class QFormerProjector(nn.Module):
    def __init__(
        self,
        in_features: int,
        out_features: int,
        num_query_tokens: int = 32,
        num_heads: int = 8,
        num_layers: int = 6,
        dropout: float = 0.1,
    ):
        super().__init__()
        self.in_features = in_features
        self.out_features = out_features
        self.num_query_tokens = num_query_tokens

        self.query_tokens = nn.Parameter(torch.zeros(1, num_query_tokens, out_features))
        self.input_proj = nn.Linear(in_features, out_features) if in_features != out_features else nn.Identity()

        self.blocks = nn.ModuleList([
            QFormerTransformerBlock(out_features, num_heads, dropout)
            for _ in range(num_layers)
        ])

        self.output_norm = nn.LayerNorm(out_features)
        self.output_proj = nn.Linear(out_features, out_features)
        self.gate = nn.Parameter(torch.ones(1))

        nn.init.normal_(self.query_tokens, std=0.02)

    def forward(self, x: torch.Tensor, key_padding_mask: Optional[torch.Tensor] = None) -> torch.Tensor:
        B = x.shape[0]
        x_proj = self.input_proj(x)
        queries = self.query_tokens.expand(B, -1, -1)

        for block in self.blocks:
            queries = block(queries, x_proj, x_proj, key_padding_mask)

        queries = self.output_norm(queries)
        output = self.output_proj(queries)
        output = output * torch.sigmoid(self.gate)
        return output


class CrossModalAttention(nn.Module):
    def __init__(self, query_dim: int, key_dim: int, hidden_dim: int = 512, num_heads: int = 8, dropout: float = 0.1):
        super().__init__()
        self.num_heads = num_heads
        self.hidden_dim = hidden_dim
        head_dim = hidden_dim // num_heads
        self.scale = head_dim ** -0.5

        self.q_proj = nn.Linear(query_dim, hidden_dim)
        self.k_proj = nn.Linear(key_dim, hidden_dim)
        self.v_proj = nn.Linear(key_dim, hidden_dim)
        self.out_proj = nn.Linear(hidden_dim, hidden_dim)

        self.dropout = nn.Dropout(dropout)
        self.norm = nn.LayerNorm(hidden_dim)

    def forward(self, query: torch.Tensor, key: torch.Tensor, value: torch.Tensor, mask: Optional[torch.Tensor] = None) -> torch.Tensor:
        B, Nq, _ = query.shape
        Nkv = key.shape[1]

        q = self.q_proj(query).reshape(B, Nq, self.num_heads, self.hidden_dim // self.num_heads).permute(0, 2, 1, 3)
        k = self.k_proj(key).reshape(B, Nkv, self.num_heads, self.hidden_dim // self.num_heads).permute(0, 2, 1, 3)
        v = self.v_proj(value).reshape(B, Nkv, self.num_heads, self.hidden_dim // self.num_heads).permute(0, 2, 1, 3)

        attn = (q @ k.transpose(-2, -1)) * self.scale
        if mask is not None:
            attn = attn.masked_fill(mask.unsqueeze(1).unsqueeze(2) == 0, float("-inf"))
        attn = attn.softmax(dim=-1)
        attn = self.dropout(attn)

        out = (attn @ v).transpose(1, 2).reshape(B, Nq, self.hidden_dim)
        out = self.out_proj(out)
        out = self.norm(out)
        return out


class FeatureAlignmentLoss(nn.Module):
    def __init__(self, temperature: float = 0.07, use_contrastive: bool = True, use_mse: bool = True):
        super().__init__()
        self.temperature = temperature
        self.use_contrastive = use_contrastive
        self.use_mse = use_mse
        self.logit_scale = nn.Parameter(torch.ones([]) * math.log(1 / temperature))

    def contrastive_loss(self, x: torch.Tensor, y: torch.Tensor) -> torch.Tensor:
        x = F.normalize(x, dim=-1)
        y = F.normalize(y, dim=-1)
        logit_scale = self.logit_scale.exp()
        logits = logit_scale * x @ y.t()
        labels = torch.arange(x.shape[0], device=x.device)
        loss_x = F.cross_entropy(logits, labels)
        loss_y = F.cross_entropy(logits.t(), labels)
        return (loss_x + loss_y) / 2

    def mse_loss(self, x: torch.Tensor, y: torch.Tensor) -> torch.Tensor:
        x = F.normalize(x, dim=-1)
        y = F.normalize(y, dim=-1)
        return F.mse_loss(x, y)

    def forward(self, x: torch.Tensor, y: torch.Tensor) -> Dict[str, torch.Tensor]:
        losses = {}
        if self.use_contrastive:
            losses["contrastive"] = self.contrastive_loss(x, y)
        if self.use_mse:
            losses["mse"] = self.mse_loss(x, y)
        total = sum(losses.values()) if losses else torch.tensor(0.0, device=x.device)
        losses["total"] = total
        return losses


class ProjectedFeatureNormalizer(nn.Module):
    def __init__(self, feature_dim: int, use_l2: bool = True, use_layer_norm: bool = False, use_batch_norm: bool = False, eps: float = 1e-6):
        super().__init__()
        self.use_l2 = use_l2
        self.use_layer_norm = use_layer_norm
        self.use_batch_norm = use_batch_norm

        if use_layer_norm:
            self.layer_norm = nn.LayerNorm(feature_dim, eps=eps)
        if use_batch_norm:
            self.batch_norm = nn.BatchNorm1d(feature_dim, eps=eps)

        self.scale = nn.Parameter(torch.ones(1))
        self.bias = nn.Parameter(torch.zeros(1))

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        if self.use_l2:
            x = F.normalize(x, dim=-1)
        if self.use_layer_norm:
            x = self.layer_norm(x)
        if self.use_batch_norm:
            if x.ndim == 3:
                B, N, D = x.shape
                x = self.batch_norm(x.reshape(-1, D)).reshape(B, N, D)
            else:
                x = self.batch_norm(x)
        x = x * self.scale + self.bias
        return x


class MultimodalProjector(nn.Module):
    def __init__(self, config: ProjectionConfig):
        super().__init__()
        self.config = config
        self.projection_type = config.projection_type

        if config.projection_type == "linear":
            projector_cls = LinearProjector
            projector_kwargs = {"use_norm": config.use_norm, "dropout": config.dropout}
        elif config.projection_type == "mlp":
            projector_cls = MLPProjector
            projector_kwargs = {"hidden_features": config.projection_hidden_size, "use_norm": config.use_norm, "dropout": config.dropout}
        elif config.projection_type == "qformer":
            projector_cls = QFormerProjector
            projector_kwargs = {"num_query_tokens": config.num_query_tokens, "num_heads": config.num_heads, "num_layers": config.num_layers, "dropout": config.dropout}
        else:
            raise ValueError(f"Unsupported projection type: {config.projection_type}")

        self.vision_projector = projector_cls(config.vision_hidden_size, config.output_hidden_size, **projector_kwargs)
        self.text_projector = projector_cls(config.text_hidden_size, config.output_hidden_size, **projector_kwargs)
        self.audio_projector = projector_cls(config.audio_hidden_size, config.output_hidden_size, **projector_kwargs)
        self.video_projector = projector_cls(config.video_hidden_size, config.output_hidden_size, **projector_kwargs)

        self.cross_attention = CrossModalAttention(config.output_hidden_size, config.output_hidden_size, hidden_dim=config.projection_hidden_size, num_heads=config.num_heads, dropout=config.dropout)

        self.alignment_loss = FeatureAlignmentLoss(temperature=config.temperature)
        self.normalizer = ProjectedFeatureNormalizer(config.output_hidden_size, use_l2=True)

    def forward_vision(self, x: torch.Tensor) -> torch.Tensor:
        return self.vision_projector(x)

    def forward_text(self, x: torch.Tensor) -> torch.Tensor:
        return self.text_projector(x)

    def forward_audio(self, x: torch.Tensor) -> torch.Tensor:
        return self.audio_projector(x)

    def forward_video(self, x: torch.Tensor) -> torch.Tensor:
        return self.video_projector(x)

    def fuse_modalities(self, vision_feat: torch.Tensor, text_feat: torch.Tensor, audio_feat: Optional[torch.Tensor] = None, video_feat: Optional[torch.Tensor] = None) -> torch.Tensor:
        modalities = [vision_feat, text_feat]
        if audio_feat is not None:
            modalities.append(audio_feat)
        if video_feat is not None:
            modalities.append(video_feat)
        if len(modalities) == 2:
            cross = self.cross_attention(vision_feat, text_feat, text_feat)
            cross = cross + vision_feat
            return cross
        fused = torch.cat(modalities, dim=-2)
        return fused

    def compute_alignment(self, vision_feat: torch.Tensor, text_feat: torch.Tensor) -> Dict[str, torch.Tensor]:
        vision_norm = self.normalizer(vision_feat)
        text_norm = self.normalizer(text_feat)
        if vision_norm.ndim > 2:
            vision_norm = vision_norm.mean(dim=1)
        if text_norm.ndim > 2:
            text_norm = text_norm.mean(dim=1)
        return self.alignment_loss(vision_norm, text_norm)

    def normalize(self, x: torch.Tensor) -> torch.Tensor:
        return self.normalizer(x)
