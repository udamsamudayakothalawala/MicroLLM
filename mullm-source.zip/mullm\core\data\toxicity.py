"""Toxicity filtering with classifier, hate speech detection, and profanity filtering."""

from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field
from enum import Enum
from typing import Optional

logger = logging.getLogger(__name__)


class ToxicityCategory(Enum):
    TOXIC = "toxic"
    HATE_SPEECH = "hate_speech"
    PROFANITY = "profanity"
    NSFW = "nsfw"
    VIOLENCE = "violence"
    SELF_HARM = "self_harm"
    HARASSMENT = "harassment"
    DISCRIMINATION = "discrimination"


@dataclass
class ToxicityConfig:
    """Configuration for toxicity filtering."""

    toxicity_threshold: float = 0.7
    hate_speech_threshold: float = 0.7
    profanity_threshold: float = 0.5
    nsfw_threshold: float = 0.7
    use_classifier: bool = True
    use_regex_filter: bool = True
    use_word_list: bool = True
    categories_to_check: tuple[ToxicityCategory, ...] = tuple(ToxicityCategory)
    block_on_any: bool = True
    max_severity: float = 0.8
    filter_obfuscated: bool = True


@dataclass
class ToxicityResult:
    """Result of toxicity analysis."""

    is_toxic: bool
    overall_score: float
    category_scores: dict[str, float]
    detected_categories: list[str]
    matched_patterns: list[str]
    confidence: float
    details: dict[str, float] = field(default_factory=dict)


class ProfanityFilter:
    """Regex and list-based profanity filter."""

    COMMON_PATTERNS: tuple[str, ...] = (
        r"\bf+u+c+k+\w*\b",
        r"\bs+h+i+t+\w*\b",
        r"\ba+s+s+h+o+l+e+\w*\b",
        r"\bb+i+t+c+h+\w*\b",
        r"\bd+a+m+n+\w*\b",
        r"\bc+r+a+p+\w*\b",
        r"\bd+i+c+k+\w*\b",
        r"\bp+u+s+s+y+\w*\b",
        r"\br+e+t+a+r+d+\w*\b",
        r"\bf+a+g+\w*\b",
        r"\bn+i+g+\w*\b",
        r"\bc+u+n+t+\w*\b",
    )

    OBFUSCATION_MAP: dict[str, str] = {
        "0": "o", "1": "i", "3": "e", "4": "a", "5": "s",
        "7": "t", "8": "b", "@": "a", "$": "s", "!": "i",
        "+": "t", "€": "e", "ï": "i", "¡": "i",
    }

    def __init__(self) -> None:
        self._compiled_patterns = [
            re.compile(p, re.IGNORECASE) for p in self.COMMON_PATTERNS
        ]
        self._custom_words: set[str] = set()
        self._custom_patterns: list[re.Pattern] = []

    def add_custom_words(self, words: list[str]) -> None:
        for word in words:
            self._custom_words.add(word.lower())

    def add_custom_patterns(self, patterns: list[str]) -> None:
        for pattern in patterns:
            self._custom_patterns.append(re.compile(pattern, re.IGNORECASE))

    def _deobfuscate(self, text: str) -> str:
        result = []
        for char in text:
            result.append(self.OBFUSCATION_MAP.get(char, char))
        return "".join(result)

    def check(self, text: str, check_obfuscated: bool = True) -> tuple[float, list[str]]:
        matches: list[str] = []

        for pattern in self._compiled_patterns:
            found = pattern.findall(text)
            matches.extend(found)

        for pattern in self._custom_patterns:
            found = pattern.findall(text)
            matches.extend(found)

        words = re.findall(r"\b\w+\b", text.lower())
        for word in words:
            if word in self._custom_words:
                matches.append(word)

        if check_obfuscated:
            deobfuscated = self._deobfuscate(text)
            for pattern in self._compiled_patterns:
                found = pattern.findall(deobfuscated)
                matches.extend(found)

        if not matches:
            return 0.0, []

        score = min(1.0, len(matches) / 3.0)
        return score, list(set(matches))


class HateSpeechDetector:
    """Detects hate speech patterns."""

    HATE_PATTERNS: tuple[re.Pattern, ...] = (
        re.compile(r"\b(exterminate|annihilate|eliminate)\s+(all\s+)?\w+", re.I),
        re.compile(r"\b(kill|murder|slaughter)\s+(all\s+)?(the\s+)?\w+", re.I),
        re.compile(r"\b(go\s+back\s+to)\s+\w+", re.I),
        re.compile(r"\b(sub)?human\b", re.I),
        re.compile(r"\b(white|black|jewish|muslim|gay|lesbian|trans)\s+(supremacy|power|genocide)", re.I),
        re.compile(r"\b(don'?t\s+belong|doesn'?t\s+belong|not\s+welcome)\b", re.I),
    )

    def check(self, text: str) -> tuple[float, list[str]]:
        matches: list[str] = []
        for pattern in self.HATE_PATTERNS:
            found = pattern.findall(text)
            if found:
                matches.append(pattern.pattern)

        score = min(1.0, len(matches) / 2.0)
        return score, matches


class NSFWDetector:
    """Detects NSFW content patterns."""

    NSFW_PATTERNS: tuple[re.Pattern, ...] = (
        re.compile(r"\b(pornograph|sexually\s+explicit|nsfw|xxx|x-rated)\b", re.I),
        re.compile(r"\b(nude|naked|topless|bottomless)\s+(photo|image|pic|picture|video)", re.I),
        re.compile(r"\b(adult\s+content|mature\s+content)\b", re.I),
    )

    def check(self, text: str) -> tuple[float, list[str]]:
        matches: list[str] = []
        for pattern in self.NSFW_PATTERNS:
            found = pattern.findall(text)
            if found:
                matches.append(pattern.pattern)

        score = min(1.0, len(matches) / 2.0)
        return score, matches


class ViolenceDetector:
    """Detects violent content patterns."""

    VIOLENCE_PATTERNS: tuple[re.Pattern, ...] = (
        re.compile(r"\b(assault|attack|bomb|shoot|stab|strangle)\w*\b", re.I),
        re.compile(r"\b(gun|weapon|knife|bomb|explosive)\s+(attack|violence|threat)", re.I),
        re.compile(r"\b(school|mass)\s+(shooting|attack|bombing)\b", re.I),
    )

    def check(self, text: str) -> tuple[float, list[str]]:
        matches: list[str] = []
        for pattern in self.VIOLENCE_PATTERNS:
            found = pattern.findall(text)
            if found:
                matches.extend(found)

        score = min(1.0, len(matches) / 4.0)
        return score, list(set(matches))


class TransformerClassifier:
    """Wrapper for transformer-based toxicity classifier."""

    def __init__(self) -> None:
        self._pipeline = None
        self._available = False
        self._load_model()

    def _load_model(self) -> None:
        try:
            from transformers import pipeline as hf_pipeline

            self._pipeline = hf_pipeline(
                "text-classification",
                model="unitary/toxic-bert",
                top_k=None,
                truncation=True,
            )
            self._available = True
            logger.info("Toxic-BERT model loaded successfully")
        except Exception as e:
            logger.warning("Transformer classifier not available: %s", e)
            self._available = False

    def classify(self, text: str) -> dict[str, float]:
        if not self._available or self._pipeline is None:
            return {}

        try:
            truncated = text[:512]
            results = self._pipeline(truncated)
            if results and isinstance(results[0], list):
                return {r["label"]: r["score"] for r in results[0]}
            elif results:
                return {results[0]["label"]: results[0]["score"]}
        except Exception as e:
            logger.warning("Classification failed: %s", e)

        return {}


class ToxicityFilter:
    """Unified toxicity detection and filtering."""

    def __init__(self, config: Optional[ToxicityConfig] = None) -> None:
        self.config = config or ToxicityConfig()
        self._profanity = ProfanityFilter()
        self._hate = HateSpeechDetector()
        self._nsfw = NSFWDetector()
        self._violence = ViolenceDetector()
        self._classifier: Optional[TransformerClassifier] = None
        if self.config.use_classifier:
            self._classifier = TransformerClassifier()

    def analyze(self, text: str) -> ToxicityResult:
        category_scores: dict[str, float] = {}
        detected: list[str] = []
        all_matches: list[str] = []

        profanity_score, profanity_matches = self._profanity.check(
            text, self.config.filter_obfuscated
        )
        if profanity_score > 0:
            category_scores["profanity"] = profanity_score
            all_matches.extend(profanity_matches)
            if profanity_score >= self.config.profanity_threshold:
                detected.append("profanity")

        hate_score, hate_matches = self._hate.check(text)
        if hate_score > 0:
            category_scores["hate_speech"] = hate_score
            all_matches.extend(hate_matches)
            if hate_score >= self.config.hate_speech_threshold:
                detected.append("hate_speech")

        nsfw_score, nsfw_matches = self._nsfw.check(text)
        if nsfw_score > 0:
            category_scores["nsfw"] = nsfw_score
            all_matches.extend(nsfw_matches)
            if nsfw_score >= self.config.nsfw_threshold:
                detected.append("nsfw")

        violence_score, violence_matches = self._violence.check(text)
        if violence_score > 0:
            category_scores["violence"] = violence_score
            all_matches.extend(violence_matches)
            if violence_score >= self.config.toxicity_threshold:
                detected.append("violence")

        classifier_scores: dict[str, float] = {}
        if self._classifier and self._classifier._available:
            classifier_scores = self._classifier.classify(text)
            for label, score in classifier_scores.items():
                label_lower = label.lower()
                if label_lower not in category_scores:
                    category_scores[label_lower] = score
                else:
                    category_scores[label_lower] = max(
                        category_scores[label_lower], score
                    )
                if score >= self.config.toxicity_threshold:
                    if label_lower not in detected:
                        detected.append(label_lower)

        if category_scores:
            if self.config.block_on_any:
                overall = max(category_scores.values())
            else:
                overall = sum(category_scores.values()) / len(category_scores)
        else:
            overall = 0.0

        is_toxic = False
        if self.config.block_on_any:
            is_toxic = overall >= self.config.toxicity_threshold
        else:
            is_toxic = overall >= self.config.toxicity_threshold

        confidence = max(classifier_scores.values()) if classifier_scores else 0.8

        return ToxicityResult(
            is_toxic=is_toxic,
            overall_score=overall,
            category_scores=category_scores,
            detected_categories=detected,
            matched_patterns=list(set(all_matches)),
            confidence=confidence,
            details=classifier_scores,
        )

    def filter_texts(
        self, texts: list[str], threshold: Optional[float] = None
    ) -> list[tuple[str, ToxicityResult]]:
        thresh = threshold or self.config.toxicity_threshold
        clean: list[tuple[str, ToxicityResult]] = []
        for text in texts:
            result = self.analyze(text)
            if not result.is_toxic or result.overall_score < thresh:
                clean.append((text, result))
        return clean

    def is_toxic(self, text: str) -> bool:
        result = self.analyze(text)
        return result.is_toxic

    def add_profanity_words(self, words: list[str]) -> None:
        self._profanity.add_custom_words(words)

    def add_profanity_patterns(self, patterns: list[str]) -> None:
        self._profanity.add_custom_patterns(patterns)
