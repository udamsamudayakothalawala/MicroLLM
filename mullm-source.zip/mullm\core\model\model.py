import math
from typing import Optional, Tuple, List, Dict, Any, Union

import torch
import torch.nn as nn
import torch.nn.functional as F

from .transformer import TransformerDecoder, TransformerDecoderLayer
from .config import GPTConfig, LlamaConfig, MistralConfig, DeepSeekConfig
from .attention import KVCache
from .normalization import RMSNorm


class BaseCausalLM(nn.Module):
    def __init__(self, config: Any):
        super().__init__()
        self.config = config

    def forward(
        self,
        input_ids: torch.Tensor,
        attention_mask: Optional[torch.Tensor] = None,
        labels: Optional[torch.Tensor] = None,
        past_key_values: Optional[KVCache] = None,
        position_ids: Optional[torch.Tensor] = None,
        use_cache: Optional[bool] = None,
        output_hidden_states: Optional[bool] = None,
        output_attentions: Optional[bool] = None,
    ) -> Dict[str, Any]:
        raise NotImplementedError

    def compute_loss(self, logits: torch.Tensor, labels: torch.Tensor) -> torch.Tensor:
        shift_logits = logits[..., :-1, :].contiguous()
        shift_labels = labels[..., 1:].contiguous()
        loss = F.cross_entropy(
            shift_logits.view(-1, shift_logits.size(-1)),
            shift_labels.view(-1),
            ignore_index=-100,
        )
        return loss

    @torch.no_grad()
    def generate(
        self,
        input_ids: torch.Tensor,
        max_new_tokens: int = 100,
        temperature: float = 1.0,
        top_k: Optional[int] = None,
        top_p: Optional[float] = None,
        repetition_penalty: float = 1.0,
        do_sample: bool = True,
        pad_token_id: Optional[int] = None,
        eos_token_id: Optional[int] = None,
        use_cache: bool = True,
        **kwargs,
    ) -> torch.Tensor:
        self.eval()
        pad_token_id = pad_token_id if pad_token_id is not None else getattr(self.config, 'pad_token_id', 0)
        eos_token_id = eos_token_id if eos_token_id is not None else getattr(self.config, 'eos_token_id', 0)

        if input_ids.dim() == 1:
            input_ids = input_ids.unsqueeze(0)

        batch_size, seq_len = input_ids.shape
        past_key_values = KVCache(max_batch_size=batch_size, max_seq_len=seq_len + max_new_tokens) if use_cache else None
        generated = input_ids.clone()
        unfinished_sequences = torch.ones(batch_size, dtype=torch.long, device=input_ids.device)

        for _ in range(max_new_tokens):
            if use_cache and past_key_values is not None and generated.shape[1] > 1:
                current_input = generated[:, -1:]
            else:
                current_input = generated

            outputs = self.forward(
                input_ids=current_input,
                past_key_values=past_key_values,
                use_cache=use_cache,
                **kwargs,
            )
            logits = outputs["logits"]
            next_token_logits = logits[:, -1, :] / temperature

            if repetition_penalty != 1.0:
                for i in range(batch_size):
                    for token_id in set(generated[i].tolist()):
                        if next_token_logits[i, token_id] < 0:
                            next_token_logits[i, token_id] *= repetition_penalty
                        else:
                            next_token_logits[i, token_id] /= repetition_penalty

            if top_k is not None:
                top_k_values, _ = torch.topk(next_token_logits, min(top_k, next_token_logits.size(-1)))
                threshold = top_k_values[:, -1].unsqueeze(-1)
                next_token_logits[next_token_logits < threshold] = float("-inf")

            if top_p is not None:
                sorted_logits, sorted_indices = torch.sort(next_token_logits, descending=True, dim=-1)
                cumulative_probs = torch.cumsum(F.softmax(sorted_logits, dim=-1), dim=-1)
                sorted_indices_to_remove = cumulative_probs > top_p
                sorted_indices_to_remove[:, 1:] = sorted_indices_to_remove[:, :-1].clone()
                sorted_indices_to_remove[:, 0] = False
                for i in range(batch_size):
                    indices_to_remove = sorted_indices[i][sorted_indices_to_remove[i]]
                    next_token_logits[i, indices_to_remove] = float("-inf")

            if do_sample:
                probs = F.softmax(next_token_logits, dim=-1)
                next_tokens = torch.multinomial(probs, num_samples=1)
            else:
                next_tokens = torch.argmax(next_token_logits, dim=-1, keepdim=True)

            next_tokens = next_tokens * unfinished_sequences.unsqueeze(-1)
            generated = torch.cat([generated, next_tokens], dim=-1)

            unfinished_sequences = unfinished_sequences * (next_tokens.squeeze(-1) != eos_token_id).long()
            if unfinished_sequences.max() == 0:
                break

            if use_cache:
                past_key_values = outputs["past_key_values"]

        return generated


class GPTModel(BaseCausalLM):
    def __init__(self, config: GPTConfig):
        super().__init__(config)
        self.config = config
        self.transformer = TransformerDecoder(
            vocab_size=config.vocab_size,
            hidden_size=config.hidden_size,
            num_hidden_layers=config.num_hidden_layers,
            num_attention_heads=config.num_attention_heads,
            num_kv_heads=config.num_kv_heads,
            intermediate_size=config.intermediate_size,
            max_position_embeddings=config.max_position_embeddings,
            attention_type=config.attention_type or "multi_head",
            activation=config.activation_function or "gelu",
            layer_norm_eps=config.layer_norm_eps,
            dropout=config.dropout,
            attention_dropout=config.attention_dropout,
            use_bias=config.use_bias,
            use_cache=config.use_cache,
            tie_word_embeddings=config.tie_word_embeddings,
            sliding_window=config.sliding_window,
            rope_theta=config.rope_theta,
            rope_scaling=config.rope_scaling,
            num_experts=config.num_experts,
            num_experts_per_tok=config.num_experts_per_tok,
            expert_intermediate_size=config.expert_intermediate_size,
            output_hidden_states=config.output_hidden_states,
            output_attentions=config.output_attentions,
            ffn_type="standard",
            use_rotary=False,
        )
        self._init_weights()

    def _init_weights(self):
        for module in self.modules():
            if isinstance(module, nn.Linear):
                module.weight.data.normal_(mean=0.0, std=self.config.initializer_range)
                if module.bias is not None:
                    module.bias.data.zero_()
            elif isinstance(module, nn.Embedding):
                module.weight.data.normal_(mean=0.0, std=self.config.initializer_range)

    def forward(
        self,
        input_ids: torch.Tensor,
        attention_mask: Optional[torch.Tensor] = None,
        labels: Optional[torch.Tensor] = None,
        past_key_values: Optional[KVCache] = None,
        position_ids: Optional[torch.Tensor] = None,
        use_cache: Optional[bool] = None,
        output_hidden_states: Optional[bool] = None,
        output_attentions: Optional[bool] = None,
    ) -> Dict[str, Any]:
        outputs = self.transformer(
            input_ids=input_ids,
            attention_mask=attention_mask,
            past_key_values=past_key_values,
            position_ids=position_ids,
            use_cache=use_cache,
            output_hidden_states=output_hidden_states,
            output_attentions=output_attentions,
        )

        logits = outputs["logits"]
        loss = None
        if labels is not None:
            loss = self.compute_loss(logits, labels)

        return {
            "logits": logits,
            "loss": loss,
            "hidden_states": outputs["hidden_states"],
            "attentions": outputs["attentions"],
            "past_key_values": outputs["past_key_values"],
            "aux_loss": outputs["aux_loss"],
        }


class LlamaModel(BaseCausalLM):
    def __init__(self, config: LlamaConfig):
        super().__init__(config)
        self.config = config
        self.transformer = TransformerDecoder(
            vocab_size=config.vocab_size,
            hidden_size=config.hidden_size,
            num_hidden_layers=config.num_hidden_layers,
            num_attention_heads=config.num_attention_heads,
            num_kv_heads=config.num_kv_heads,
            intermediate_size=config.intermediate_size,
            max_position_embeddings=config.max_position_embeddings,
            attention_type=config.attention_type or "grouped_query",
            activation=config.activation_function or "silu",
            layer_norm_eps=config.layer_norm_eps,
            dropout=config.dropout,
            attention_dropout=config.attention_dropout,
            use_bias=config.use_bias,
            use_cache=config.use_cache,
            tie_word_embeddings=config.tie_word_embeddings,
            sliding_window=config.sliding_window,
            rope_theta=config.rope_theta,
            rope_scaling=config.rope_scaling,
            num_experts=config.num_experts,
            num_experts_per_tok=config.num_experts_per_tok,
            expert_intermediate_size=config.expert_intermediate_size,
            output_hidden_states=config.output_hidden_states,
            output_attentions=config.output_attentions,
            ffn_type="gated",
            use_rotary=True,
        )
        self._init_weights()

    def _init_weights(self):
        for module in self.modules():
            if isinstance(module, nn.Linear):
                module.weight.data.normal_(mean=0.0, std=self.config.initializer_range)
                if module.bias is not None:
                    module.bias.data.zero_()
            elif isinstance(module, nn.Embedding):
                module.weight.data.normal_(mean=0.0, std=self.config.initializer_range)

    def forward(
        self,
        input_ids: torch.Tensor,
        attention_mask: Optional[torch.Tensor] = None,
        labels: Optional[torch.Tensor] = None,
        past_key_values: Optional[KVCache] = None,
        position_ids: Optional[torch.Tensor] = None,
        use_cache: Optional[bool] = None,
        output_hidden_states: Optional[bool] = None,
        output_attentions: Optional[bool] = None,
    ) -> Dict[str, Any]:
        outputs = self.transformer(
            input_ids=input_ids,
            attention_mask=attention_mask,
            past_key_values=past_key_values,
            position_ids=position_ids,
            use_cache=use_cache,
            output_hidden_states=output_hidden_states,
            output_attentions=output_attentions,
        )

        logits = outputs["logits"]
        loss = None
        if labels is not None:
            loss = self.compute_loss(logits, labels)

        return {
            "logits": logits,
            "loss": loss,
            "hidden_states": outputs["hidden_states"],
            "attentions": outputs["attentions"],
            "past_key_values": outputs["past_key_values"],
            "aux_loss": outputs["aux_loss"],
        }


class MistralModel(BaseCausalLM):
    def __init__(self, config: MistralConfig):
        super().__init__(config)
        self.config = config
        self.transformer = TransformerDecoder(
            vocab_size=config.vocab_size,
            hidden_size=config.hidden_size,
            num_hidden_layers=config.num_hidden_layers,
            num_attention_heads=config.num_attention_heads,
            num_kv_heads=config.num_kv_heads,
            intermediate_size=config.intermediate_size,
            max_position_embeddings=config.max_position_embeddings,
            attention_type="sliding_window",
            activation=config.activation_function or "silu",
            layer_norm_eps=config.layer_norm_eps,
            dropout=config.dropout,
            attention_dropout=config.attention_dropout,
            use_bias=config.use_bias,
            use_cache=config.use_cache,
            tie_word_embeddings=config.tie_word_embeddings,
            sliding_window=config.sliding_window,
            rope_theta=config.rope_theta,
            rope_scaling=config.rope_scaling,
            num_experts=config.num_experts,
            num_experts_per_tok=config.num_experts_per_tok,
            expert_intermediate_size=config.expert_intermediate_size,
            output_hidden_states=config.output_hidden_states,
            output_attentions=config.output_attentions,
            ffn_type="gated",
            use_rotary=True,
        )
        self._init_weights()

    def _init_weights(self):
        for module in self.modules():
            if isinstance(module, nn.Linear):
                module.weight.data.normal_(mean=0.0, std=self.config.initializer_range)
                if module.bias is not None:
                    module.bias.data.zero_()
            elif isinstance(module, nn.Embedding):
                module.weight.data.normal_(mean=0.0, std=self.config.initializer_range)

    def forward(
        self,
        input_ids: torch.Tensor,
        attention_mask: Optional[torch.Tensor] = None,
        labels: Optional[torch.Tensor] = None,
        past_key_values: Optional[KVCache] = None,
        position_ids: Optional[torch.Tensor] = None,
        use_cache: Optional[bool] = None,
        output_hidden_states: Optional[bool] = None,
        output_attentions: Optional[bool] = None,
    ) -> Dict[str, Any]:
        outputs = self.transformer(
            input_ids=input_ids,
            attention_mask=attention_mask,
            past_key_values=past_key_values,
            position_ids=position_ids,
            use_cache=use_cache,
            output_hidden_states=output_hidden_states,
            output_attentions=output_attentions,
        )

        logits = outputs["logits"]
        loss = None
        if labels is not None:
            loss = self.compute_loss(logits, labels)

        return {
            "logits": logits,
            "loss": loss,
            "hidden_states": outputs["hidden_states"],
            "attentions": outputs["attentions"],
            "past_key_values": outputs["past_key_values"],
            "aux_loss": outputs["aux_loss"],
        }


class DeepSeekModel(BaseCausalLM):
    def __init__(self, config: DeepSeekConfig):
        super().__init__(config)
        self.config = config
        self.transformer = TransformerDecoder(
            vocab_size=config.vocab_size,
            hidden_size=config.hidden_size,
            num_hidden_layers=config.num_hidden_layers,
            num_attention_heads=config.num_attention_heads,
            num_kv_heads=config.num_kv_heads,
            intermediate_size=config.intermediate_size,
            max_position_embeddings=config.max_position_embeddings,
            attention_type=config.attention_type or "grouped_query",
            activation=config.activation_function or "silu",
            layer_norm_eps=config.layer_norm_eps,
            dropout=config.dropout,
            attention_dropout=config.attention_dropout,
            use_bias=config.use_bias,
            use_cache=config.use_cache,
            tie_word_embeddings=config.tie_word_embeddings,
            sliding_window=config.sliding_window,
            rope_theta=config.rope_theta,
            rope_scaling=config.rope_scaling,
            num_experts=config.num_experts,
            num_experts_per_tok=config.num_experts_per_tok,
            expert_intermediate_size=config.expert_intermediate_size,
            output_hidden_states=config.output_hidden_states,
            output_attentions=config.output_attentions,
            ffn_type="gated",
            use_rotary=True,
        )
        self._init_weights()

    def _init_weights(self):
        for module in self.modules():
            if isinstance(module, nn.Linear):
                module.weight.data.normal_(mean=0.0, std=self.config.initializer_range)
                if module.bias is not None:
                    module.bias.data.zero_()
            elif isinstance(module, nn.Embedding):
                module.weight.data.normal_(mean=0.0, std=self.config.initializer_range)

    def forward(
        self,
        input_ids: torch.Tensor,
        attention_mask: Optional[torch.Tensor] = None,
        labels: Optional[torch.Tensor] = None,
        past_key_values: Optional[KVCache] = None,
        position_ids: Optional[torch.Tensor] = None,
        use_cache: Optional[bool] = None,
        output_hidden_states: Optional[bool] = None,
        output_attentions: Optional[bool] = None,
    ) -> Dict[str, Any]:
        outputs = self.transformer(
            input_ids=input_ids,
            attention_mask=attention_mask,
            past_key_values=past_key_values,
            position_ids=position_ids,
            use_cache=use_cache,
            output_hidden_states=output_hidden_states,
            output_attentions=output_attentions,
        )

        logits = outputs["logits"]
        loss = None
        if labels is not None:
            loss = self.compute_loss(logits, labels)

        aux_loss = outputs.get("aux_loss", torch.tensor(0.0, device=logits.device))

        return {
            "logits": logits,
            "loss": loss,
            "hidden_states": outputs["hidden_states"],
            "attentions": outputs["attentions"],
            "past_key_values": outputs["past_key_values"],
            "aux_loss": aux_loss,
        }
