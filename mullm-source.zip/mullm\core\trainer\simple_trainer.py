"""
simple_trainer.py - Lightweight trainer for small models from scratch.
No HuggingFace Trainer, no Accelerate. Just PyTorch.
"""

import json
import math
import os
import time
from dataclasses import dataclass, field
from typing import Optional

import torch
import torch.nn as nn
from torch.utils.data import DataLoader


@dataclass
class SimpleConfig:
    output_dir: str = "./outputs"
    num_epochs: int = 3
    batch_size: int = 8
    learning_rate: float = 3e-4
    weight_decay: float = 0.01
    warmup_steps: int = 100
    max_grad_norm: float = 1.0
    bf16: bool = True
    fp16: bool = False
    seed: int = 42
    log_steps: int = 10
    save_steps: int = 500
    eval_steps: int = 500
    max_steps: int = -1
    gradient_accumulation_steps: int = 1
    device: str = "auto"


def set_seed(seed: int) -> None:
    import random

    random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def get_device(device_str: str = "auto") -> torch.device:
    if device_str == "auto":
        if torch.cuda.is_available():
            return torch.device("cuda")
        elif hasattr(torch.backends, "mps") and torch.backends.mps.is_available():
            return torch.device("mps")
        return torch.device("cpu")
    return torch.device(device_str)


class CosineWarmupScheduler:
    def __init__(self, optimizer, warmup_steps: int, total_steps: int, min_lr: float = 0.0):
        self.optimizer = optimizer
        self.warmup_steps = warmup_steps
        self.total_steps = total_steps
        self.min_lr = min_lr
        self.base_lrs = [group["lr"] for group in optimizer.param_groups]
        self.step_count = 0

    def step(self) -> None:
        self.step_count += 1
        lr_scale = min(1.0, self.step_count / max(1, self.warmup_steps))
        cosine_decay = 0.5 * (1.0 + math.cos(math.pi * self.step_count / max(1, self.total_steps)))
        for group, base_lr in zip(self.optimizer.param_groups, self.base_lrs):
            group["lr"] = max(self.min_lr, base_lr * lr_scale * cosine_decay)


class SimpleTrainer:
    def __init__(
        self,
        model: nn.Module,
        config: Optional[SimpleConfig] = None,
        train_dataset=None,
        eval_dataset=None,
    ):
        self.config = config or SimpleConfig()
        self.device = get_device(self.config.device)
        self.model = model.to(self.device)
        self.train_dataset = train_dataset
        self.eval_dataset = eval_dataset
        self._stop = False
        self.history: list[dict] = []
        self.on_log = None
        self.on_metrics = None

        self.scaler = None
        if self.config.fp16 and self.device.type == "cuda":
            self.scaler = torch.amp.GradScaler("cuda")

    def _log(self, msg: str) -> None:
        print(msg)
        if self.on_log is not None:
            self.on_log(msg)

    def _compute_metrics(self, eval_loss: float, step: int) -> dict:
        perplexity = math.exp(min(eval_loss, 20))
        return {"eval_loss": eval_loss, "perplexity": perplexity, "step": step}

    def train(self) -> dict:
        set_seed(self.config.seed)
        os.makedirs(self.config.output_dir, exist_ok=True)

        train_loader = DataLoader(
            self.train_dataset,
            batch_size=self.config.batch_size,
            shuffle=True,
            num_workers=0,
            pin_memory=self.device.type == "cuda",
        )

        total_steps = self.config.max_steps if self.config.max_steps > 0 else (
            len(train_loader) * self.config.num_epochs // self.config.gradient_accumulation_steps
        )

        optimizer = torch.optim.AdamW(
            self.model.parameters(),
            lr=self.config.learning_rate,
            weight_decay=self.config.weight_decay,
            betas=(0.9, 0.999),
            eps=1e-8,
        )
        scheduler = CosineWarmupScheduler(optimizer, self.config.warmup_steps, total_steps)

        self.model.train()
        step = 0
        epoch = 0
        running_loss = 0.0
        best_loss = float("inf")
        start_time = time.time()

        self._log(f"Training: {self.model.count_parameters()} params, {total_steps} steps, device={self.device}")

        while step < total_steps:
            epoch += 1
            for batch in train_loader:
                if self._stop:
                    break

                input_ids = batch["input_ids"].to(self.device)
                labels = batch["labels"].to(self.device)
                attention_mask = batch.get("attention_mask")
                if attention_mask is not None:
                    attention_mask = attention_mask.to(self.device)

                if self.config.fp16 and self.scaler is not None:
                    with torch.amp.autocast("cuda"):
                        outputs = self.model(input_ids=input_ids, labels=labels)
                        loss = outputs["loss"] / self.config.gradient_accumulation_steps
                    self.scaler.scale(loss).backward()
                else:
                    outputs = self.model(input_ids=input_ids, labels=labels)
                    loss = outputs["loss"] / self.config.gradient_accumulation_steps
                    loss.backward()

                running_loss += loss.item() * self.config.gradient_accumulation_steps

                if (step + 1) % self.config.gradient_accumulation_steps == 0:
                    if self.scaler is not None:
                        self.scaler.unscale_(optimizer)
                        torch.nn.utils.clip_grad_norm_(self.model.parameters(), self.config.max_grad_norm)
                        self.scaler.step(optimizer)
                        self.scaler.update()
                    else:
                        torch.nn.utils.clip_grad_norm_(self.model.parameters(), self.config.max_grad_norm)
                        optimizer.step()

                    scheduler.step()
                    optimizer.zero_grad()

                step += 1

                if step % self.config.log_steps == 0:
                    avg_loss = running_loss / self.config.log_steps
                    elapsed = time.time() - start_time
                    lr = optimizer.param_groups[0]["lr"]
                    metrics = {
                        "step": step,
                        "loss": round(avg_loss, 4),
                        "lr": lr,
                        "elapsed": round(elapsed, 1),
                    }
                    self._log(f"  step={step}/{total_steps}  loss={avg_loss:.4f}  lr={lr:.2e}  time={elapsed:.0f}s")
                    self.history.append(metrics)
                    if self.on_metrics is not None:
                        self.on_metrics(metrics)
                    running_loss = 0.0

                    if avg_loss < best_loss:
                        best_loss = avg_loss

                if self.config.save_steps > 0 and step % self.config.save_steps == 0:
                    self._save_checkpoint(step)

                if self.config.eval_steps > 0 and step % self.config.eval_steps == 0 and self.eval_dataset is not None:
                    eval_loss = self._evaluate()
                    eval_metrics = self._compute_metrics(eval_loss, step)
                    self._log(f"  eval  loss={eval_loss:.4f}  perplexity={eval_metrics['perplexity']:.2f}")
                    self.history.append(eval_metrics)
                    if self.on_metrics is not None:
                        self.on_metrics(eval_metrics)

                if self.config.max_steps > 0 and step >= self.config.max_steps:
                    break

            if self._stop:
                break

        self._save_checkpoint(step, final=True)
        elapsed = time.time() - start_time
        result = {
            "status": "completed" if not self._stop else "stopped",
            "best_loss": best_loss,
            "total_steps": step,
            "total_time": round(elapsed, 1),
            "epochs": epoch,
        }
        self._log(f"Training finished: {result}")
        return result

    def _evaluate(self) -> float:
        if self.eval_dataset is None:
            return float("inf")
        eval_loader = DataLoader(self.eval_dataset, batch_size=self.config.batch_size, shuffle=False)
        self.model.eval()
        total_loss = 0.0
        total_batches = 0
        with torch.no_grad():
            for batch in eval_loader:
                input_ids = batch["input_ids"].to(self.device)
                labels = batch["labels"].to(self.device)
                outputs = self.model(input_ids=input_ids, labels=labels)
                total_loss += outputs["loss"].item()
                total_batches += 1
        self.model.train()
        return total_loss / max(total_batches, 1)

    def _save_checkpoint(self, step: int, final: bool = False) -> None:
        tag = "final" if final else f"step-{step}"
        ckpt_dir = os.path.join(self.config.output_dir, f"checkpoint-{tag}")
        os.makedirs(ckpt_dir, exist_ok=True)
        torch.save(self.model.state_dict(), os.path.join(ckpt_dir, "model.pt"))
        meta = {"step": step, "history": self.history}
        if hasattr(self.model, "config"):
            cfg = self.model.config
            if hasattr(cfg, "__dataclass_fields__"):
                import dataclasses

                meta["model_config"] = dataclasses.asdict(cfg)
            else:
                meta["model_config"] = dict(cfg)
        with open(os.path.join(ckpt_dir, "config.json"), "w") as f:
            json.dump(meta, f, indent=2, default=str)
        self._log(f"  saved checkpoint: {ckpt_dir}")

    def stop(self) -> None:
        self._stop = True
