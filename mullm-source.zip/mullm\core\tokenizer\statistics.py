import math
from collections import Counter, defaultdict
from typing import Dict, List, Optional, Sequence, Tuple

from .base import BaseTokenizer


class TokenStatistics:
    def __init__(self, tokenizer: BaseTokenizer) -> None:
        self._tokenizer = tokenizer

    def token_frequencies(
        self, texts: Sequence[str]
    ) -> Counter[int]:
        freq: Counter[int] = Counter()
        for text in texts:
            ids = self._tokenizer.encode(text, add_special_tokens=False)
            freq.update(ids)
        return freq

    def token_frequency_distribution(
        self, texts: Sequence[str]
    ) -> Dict[str, int]:
        freq = self.token_frequencies(texts)
        dist: Dict[str, int] = {}
        for tid, count in freq.most_common():
            token = self._tokenizer.convert_ids_to_tokens(tid)
            dist[str(token)] = count
        return dist

    def sequence_length_statistics(
        self, texts: Sequence[str]
    ) -> Dict[str, float]:
        lengths: List[int] = []
        for text in texts:
            ids = self._tokenizer.encode(text, add_special_tokens=False)
            lengths.append(len(ids))

        if not lengths:
            return {
                "min": 0.0,
                "max": 0.0,
                "mean": 0.0,
                "median": 0.0,
                "std": 0.0,
                "p25": 0.0,
                "p75": 0.0,
                "p90": 0.0,
                "p95": 0.0,
                "p99": 0.0,
            }

        sorted_lengths = sorted(lengths)
        n = len(sorted_lengths)

        mean = sum(sorted_lengths) / n
        variance = sum((x - mean) ** 2 for x in sorted_lengths) / n

        def percentile(p: float) -> float:
            idx = int(p * n)
            if idx >= n:
                idx = n - 1
            return float(sorted_lengths[idx])

        return {
            "min": float(sorted_lengths[0]),
            "max": float(sorted_lengths[-1]),
            "mean": mean,
            "median": float(sorted_lengths[n // 2]),
            "std": math.sqrt(variance),
            "p25": percentile(0.25),
            "p75": percentile(0.75),
            "p90": percentile(0.90),
            "p95": percentile(0.95),
            "p99": percentile(0.99),
            "total_sequences": float(n),
        }

    def vocabulary_coverage(
        self, texts: Sequence[str]
    ) -> Dict[str, float]:
        vocab = set(
            range(self._tokenizer.vocab_size)
        )
        freq = self.token_frequencies(texts)

        seen_tokens = set(freq.keys())
        unseen = vocab - seen_tokens

        total_ids = sum(freq.values())
        if total_ids == 0:
            return {
                "vocab_size": float(self._tokenizer.vocab_size),
                "tokens_seen": 0.0,
                "tokens_unseen": float(self._tokenizer.vocab_size),
                "coverage_ratio": 0.0,
                "total_token_count": 0.0,
            }

        coverage_ratio = len(seen_tokens) / len(vocab) if vocab else 0.0

        return {
            "vocab_size": float(self._tokenizer.vocab_size),
            "tokens_seen": float(len(seen_tokens)),
            "tokens_unseen": float(len(unseen)),
            "coverage_ratio": coverage_ratio,
            "total_token_count": float(total_ids),
        }

    def oov_rate(
        self, texts: Sequence[str]
    ) -> float:
        unk_id = self._tokenizer.unk_token_id()
        if unk_id is None:
            return 0.0

        total_tokens = 0
        total_oov = 0
        for text in texts:
            ids = self._tokenizer.encode(text, add_special_tokens=False)
            total_tokens += len(ids)
            total_oov += sum(1 for i in ids if i == unk_id)

        if total_tokens == 0:
            return 0.0

        return total_oov / total_tokens

    def compression_ratio(
        self, text: str, char_encoding: str = "utf-8"
    ) -> float:
        byte_length = len(text.encode(char_encoding))
        ids = self._tokenizer.encode(text, add_special_tokens=False)

        if self._tokenizer.vocab_size <= 256:
            token_bits = math.ceil(math.log2(self._tokenizer.vocab_size))
        else:
            token_bits = math.ceil(math.log2(self._tokenizer.vocab_size))

        if token_bits == 0:
            return 1.0

        token_bit_length = len(ids) * token_bits
        byte_bit_length = byte_length * 8

        if token_bit_length == 0:
            return 1.0

        return byte_bit_length / token_bit_length

    def entropy(
        self, texts: Sequence[str]
    ) -> float:
        freq = self.token_frequencies(texts)
        total = sum(freq.values())
        if total == 0:
            return 0.0

        ent = 0.0
        for count in freq.values():
            prob = count / total
            ent -= prob * math.log2(prob)

        return ent

    def per_token_entropy(
        self, texts: Sequence[str]
    ) -> float:
        freq = self.token_frequencies(texts)
        total = sum(freq.values())
        if total == 0:
            return 0.0

        ent = 0.0
        for count in freq.values():
            prob = count / total
            ent -= prob * math.log2(prob)

        return ent / total

    def token_length_statistics(
        self, texts: Sequence[str]
    ) -> Dict[str, float]:
        token_lengths: Dict[int, List[int]] = defaultdict(list)
        for text in texts:
            ids = self._tokenizer.encode(text, add_special_tokens=False)
            for tid in ids:
                token = self._tokenizer.convert_ids_to_tokens(tid)
                token_lengths[tid].append(len(str(token)))

        stats: Dict[str, float] = {
            "min_token_length": float("inf"),
            "max_token_length": 0.0,
            "avg_token_length": 0.0,
        }

        total_chars = 0
        total_tokens = 0
        for tid, lengths in token_lengths.items():
            avg_len = sum(lengths) / len(lengths)
            stats["min_token_length"] = min(
                stats["min_token_length"], avg_len
            )
            stats["max_token_length"] = max(
                stats["max_token_length"], avg_len
            )
            total_chars += sum(lengths)
            total_tokens += len(lengths)

        if total_tokens > 0:
            stats["avg_token_length"] = total_chars / total_tokens
        if stats["min_token_length"] == float("inf"):
            stats["min_token_length"] = 0.0

        return stats

    def rare_token_analysis(
        self, texts: Sequence[str], threshold: int = 5
    ) -> Dict[str, object]:
        freq = self.token_frequencies(texts)

        rare_tokens: List[Tuple[str, int]] = []
        common_tokens: List[Tuple[str, int]] = []

        for tid, count in freq.items():
            token = self._tokenizer.convert_ids_to_tokens(tid)
            entry = (str(token), count)
            if count < threshold:
                rare_tokens.append(entry)
            else:
                common_tokens.append(entry)

        rare_tokens.sort(key=lambda x: x[1])
        common_tokens.sort(key=lambda x: x[1], reverse=True)

        total = sum(freq.values())

        return {
            "rare_token_count": len(rare_tokens),
            "common_token_count": len(common_tokens),
            "rare_token_frequency": sum(c for _, c in rare_tokens),
            "common_token_frequency": sum(c for _, c in common_tokens),
            "rare_token_ratio": len(rare_tokens) / len(freq) if freq else 0.0,
            "rare_frequency_ratio": (
                sum(c for _, c in rare_tokens) / total if total > 0 else 0.0
            ),
            "rare_tokens": rare_tokens[:50],
            "most_common_tokens": common_tokens[:50],
        }

    def zipf_analysis(
        self, texts: Sequence[str]
    ) -> Dict[str, float]:
        freq = self.token_frequencies(texts)
        sorted_counts = [c for _, c in freq.most_common()]

        if len(sorted_counts) < 2:
            return {"rank_correlation": 0.0, "slope": 0.0}

        import math

        ranks = list(range(1, len(sorted_counts) + 1))
        log_ranks = [math.log(r) for r in ranks]
        log_freqs = [math.log(c) if c > 0 else 0 for c in sorted_counts]

        n = len(log_ranks)
        sum_x = sum(log_ranks)
        sum_y = sum(log_freqs)
        sum_xy = sum(x * y for x, y in zip(log_ranks, log_freqs))
        sum_x2 = sum(x * x for x in log_ranks)

        denominator = n * sum_x2 - sum_x * sum_x
        if denominator == 0:
            return {"rank_correlation": 0.0, "slope": 0.0}

        slope = (n * sum_xy - sum_x * sum_y) / denominator
        intercept = (sum_y - slope * sum_x) / n

        ss_res = sum(
            (y - (slope * x + intercept)) ** 2
            for x, y in zip(log_ranks, log_freqs)
        )
        ss_tot = sum((y - sum_y / n) ** 2 for y in log_freqs)

        r_squared = 1 - (ss_res / ss_tot) if ss_tot > 0 else 0.0

        return {
            "slope": slope,
            "intercept": intercept,
            "r_squared": r_squared,
            "rank_correlation": math.sqrt(r_squared) if r_squared >= 0 else 0.0,
        }

    def full_report(
        self, texts: Sequence[str]
    ) -> Dict[str, object]:
        return {
            "sequence_lengths": self.sequence_length_statistics(texts),
            "vocabulary_coverage": self.vocabulary_coverage(texts),
            "oov_rate": self.oov_rate(texts),
            "entropy": self.entropy(texts),
            "per_token_entropy": self.per_token_entropy(texts),
            "compression_ratio": (
                sum(
                    self.compression_ratio(t) for t in texts
                )
                / len(texts)
                if texts
                else 0.0
            ),
            "token_lengths": self.token_length_statistics(texts),
            "rare_tokens": self.rare_token_analysis(texts),
            "zipf": self.zipf_analysis(texts),
        }
