import torch  # noqa: F401,E402  (load before PyQt5 to avoid DLL conflicts)

"""muLLM GUI - Export tab: export trained checkpoint to GGUF."""

import os

from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QPushButton, QLabel,
    QLineEdit, QComboBox, QGroupBox, QGridLayout, QTextEdit,
    QFileDialog, QMessageBox, QProgressBar
)

from .eval_tab import load_checkpoint


class ExportTab(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.build_ui()

    def build_ui(self):
        main = QVBoxLayout(self)
        main.setContentsMargins(12, 12, 12, 12)

        header = QLabel("EXPORT TO GGUF")
        header.setProperty("class", "heading")
        main.addWidget(header)
        sub = QLabel("Export a trained checkpoint to GGUF format for llama.cpp.")
        sub.setProperty("class", "subheading")
        main.addWidget(sub)

        group = QGroupBox("Export")
        grid = QGridLayout(group)

        self.checkpoint_edit = QLineEdit()
        self.checkpoint_edit.setPlaceholderText("Path to output dir or model.pt")
        self.browse_btn = QPushButton("Browse")
        self.browse_btn.setProperty("class", "btn-secondary")
        self.browse_btn.clicked.connect(self.browse)
        grid.addWidget(QLabel("Checkpoint:"), 0, 0)
        grid.addWidget(self.checkpoint_edit, 0, 1, 1, 2)
        grid.addWidget(self.browse_btn, 0, 3)

        self.quant_combo = QComboBox()
        self.quant_combo.addItems(["f16", "f32", "q4_0"])
        grid.addWidget(QLabel("Quantization:"), 1, 0)
        grid.addWidget(self.quant_combo, 1, 1)

        self.arch_combo = QComboBox()
        self.arch_combo.addItems(["llama", "gpt2", "mistral"])
        grid.addWidget(QLabel("Architecture:"), 2, 0)
        grid.addWidget(self.arch_combo, 2, 1)

        self.output_edit = QLineEdit("./outputs/model.gguf")
        grid.addWidget(QLabel("Output file:"), 3, 0)
        grid.addWidget(self.output_edit, 3, 1, 1, 2)
        self.out_browse = QPushButton("Browse")
        self.out_browse.setProperty("class", "btn-secondary")
        self.out_browse.clicked.connect(self.browse_out)
        grid.addWidget(self.out_browse, 3, 3)

        main.addWidget(group)

        row = QHBoxLayout()
        self.export_btn = QPushButton("🚀 Export GGUF")
        self.export_btn.setProperty("class", "btn-success")
        self.export_btn.clicked.connect(self.start_export)
        row.addWidget(self.export_btn)
        row.addStretch()
        main.addLayout(row)

        self.progress = QProgressBar()
        self.progress.setValue(0)
        main.addWidget(self.progress)

        self.log = QTextEdit()
        self.log.setReadOnly(True)
        self.log.setPlaceholderText("Export logs...")
        main.addWidget(QLabel("EXPORT LOG"))
        main.addWidget(self.log)

    def browse(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "Select Checkpoint", "", "Model checkpoints (*.pt);;All Files (*.*)"
        )
        if path:
            self.checkpoint_edit.setText(path)

    def browse_out(self):
        path, _ = QFileDialog.getSaveFileName(
            self, "Save GGUF", "./outputs/model.gguf", "GGUF (*.gguf)"
        )
        if path:
            self.output_edit.setText(path)

    def start_export(self):
        ckpt = self.checkpoint_edit.text().strip()
        out = self.output_edit.text().strip()
        if not ckpt or not out:
            QMessageBox.warning(self, "Missing", "Select a checkpoint and output file.")
            return
        try:
            state = load_checkpoint(ckpt, "small")
            model = state["model"]
            self.log.append(f"Model loaded: {model.count_parameters():,} params")

            from mullm.core.export.gguf_export import GGUFExporter
            self.log.append(f"Exporting to {self.quant_combo.currentText()} GGUF...")
            exporter = GGUFExporter()
            new_out = exporter.export(
                model, out,
                dtype=self.quant_combo.currentText(),
                architecture=self.arch_combo.currentText(),
            )
            self.progress.setValue(100)
            self.log.append(f"✅ GGUF exported to: {new_out}")
            self.log.append(f"   Size: {os.path.getsize(new_out):,} bytes")
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Export failed:\n{e}")
            self.log.append(f"ERROR: {e}")