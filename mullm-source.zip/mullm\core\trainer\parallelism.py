from __future__ import annotations

import math
from typing import Any, Callable, Dict, List, Optional, Tuple, Union

import torch
import torch.distributed as dist
import torch.nn as nn
import torch.nn.functional as F

from mullm.core.trainer.training_config import ParallelismConfig, TensorParallelConfig


def _ensure_divisible(value: int, divisor: int) -> int:
    return (value + divisor - 1) // divisor * divisor


class _ReduceForward(torch.autograd.Function):
    @staticmethod
    def forward(ctx: Any, input_: torch.Tensor, group: dist.ProcessGroup) -> torch.Tensor:
        ctx.group = group
        return input_

    @staticmethod
    def backward(ctx: Any, grad_output: torch.Tensor) -> Tuple[torch.Tensor, None]:
        dist.all_reduce(grad_output, group=ctx.group)
        return grad_output, None


class _ReduceScatterForward(torch.autograd.Function):
    @staticmethod
    def forward(ctx: Any, input_: torch.Tensor, group: dist.ProcessGroup) -> torch.Tensor:
        ctx.group = group
        world_size = dist.get_world_size(group)
        out = torch.empty_like(input_)
        dist.reduce_scatter_tensor(out, input_, group=group)
        return out

    @staticmethod
    def backward(ctx: Any, grad_output: torch.Tensor) -> Tuple[torch.Tensor, None]:
        dist.all_gather_into_tensor(grad_output, grad_output, group=ctx.group)
        return grad_output, None


class _AllGatherForward(torch.autograd.Function):
    @staticmethod
    def forward(ctx: Any, input_: torch.Tensor, group: dist.ProcessGroup) -> torch.Tensor:
        ctx.group = group
        world_size = dist.get_world_size(group)
        out = torch.empty(world_size * input_.size(0), *input_.shape[1:], dtype=input_.dtype, device=input_.device)
        dist.all_gather_into_tensor(out, input_, group=group)
        return out

    @staticmethod
    def backward(ctx: Any, grad_output: torch.Tensor) -> Tuple[torch.Tensor, None]:
        world_size = dist.get_world_size(ctx.group)
        chunk_size = grad_output.size(0) // world_size
        grad_input = grad_output[dist.get_rank(ctx.group) * chunk_size : (dist.get_rank(ctx.group) + 1) * chunk_size]
        dist.reduce_scatter_tensor(grad_output, grad_output, group=ctx.group)
        return grad_input, None


class ColumnParallelLinear(nn.Module):
    def __init__(
        self,
        in_features: int,
        out_features: int,
        bias: bool = True,
        gather_output: bool = True,
        world_size: int = 1,
        rank: int = 0,
        group: Optional[dist.ProcessGroup] = None,
        dtype: torch.dtype = torch.float32,
    ) -> None:
        super().__init__()
        self.in_features = in_features
        self.out_features = out_features
        self.gather_output = gather_output
        self.world_size = world_size
        self.rank = rank
        self.group = group

        local_out = out_features // world_size
        assert local_out * world_size == out_features, "out_features must be divisible by world_size"

        self.weight = nn.Parameter(torch.empty(local_out, in_features, dtype=dtype))
        if bias:
            self.bias = nn.Parameter(torch.empty(local_out, dtype=dtype))
        else:
            self.register_parameter("bias", None)

        self.reset_parameters()

    def reset_parameters(self) -> None:
        k = 1.0 / math.sqrt(self.in_features)
        nn.init.uniform_(self.weight, -k, k)
        if self.bias is not None:
            nn.init.zeros_(self.bias)

    def forward(self, input_: torch.Tensor) -> torch.Tensor:
        output = F.linear(input_, self.weight, self.bias)

        if self.gather_output and self.world_size > 1:
            if self.group is not None:
                output = _AllGatherForward.apply(output, self.group)
            else:
                outputs = [torch.zeros_like(output) for _ in range(self.world_size)]
                dist.all_gather(outputs, output)
                output = torch.cat(outputs, dim=-1)

        return output


class RowParallelLinear(nn.Module):
    def __init__(
        self,
        in_features: int,
        out_features: int,
        bias: bool = True,
        world_size: int = 1,
        rank: int = 0,
        group: Optional[dist.ProcessGroup] = None,
        dtype: torch.dtype = torch.float32,
    ) -> None:
        super().__init__()
        self.in_features = in_features
        self.out_features = out_features
        self.world_size = world_size
        self.rank = rank
        self.group = group

        local_in = in_features // world_size
        assert local_in * world_size == in_features, "in_features must be divisible by world_size"

        self.weight = nn.Parameter(torch.empty(out_features, local_in, dtype=dtype))
        if bias:
            self.bias = nn.Parameter(torch.empty(out_features, dtype=dtype))
        else:
            self.register_parameter("bias", None)

        self.reset_parameters()

    def reset_parameters(self) -> None:
        k = 1.0 / math.sqrt(self.in_features // self.world_size)
        nn.init.uniform_(self.weight, -k, k)
        if self.bias is not None:
            nn.init.zeros_(self.bias)

    def forward(self, input_: torch.Tensor) -> torch.Tensor:
        output = F.linear(input_, self.weight)

        if self.world_size > 1:
            if self.group is not None:
                output = _ReduceForward.apply(output, self.group)
            else:
                dist.all_reduce(output)

        if self.bias is not None:
            output = output + self.bias

        return output


class VocabParallelEmbedding(nn.Module):
    def __init__(
        self,
        num_embeddings: int,
        embedding_dim: int,
        world_size: int = 1,
        rank: int = 0,
        padding_idx: Optional[int] = None,
        group: Optional[dist.ProcessGroup] = None,
        dtype: torch.dtype = torch.float32,
    ) -> None:
        super().__init__()
        self.num_embeddings = num_embeddings
        self.embedding_dim = embedding_dim
        self.world_size = world_size
        self.rank = rank
        self.padding_idx = padding_idx
        self.group = group

        local_vocab = num_embeddings // world_size
        assert local_vocab * world_size == num_embeddings, "num_embeddings must be divisible by world_size"
        self.vocab_start_index = rank * local_vocab
        self.vocab_end_index = (rank + 1) * local_vocab

        self.weight = nn.Parameter(torch.empty(local_vocab, embedding_dim, dtype=dtype))
        self.reset_parameters()

    def reset_parameters(self) -> None:
        nn.init.normal_(self.weight, mean=0.0, std=1.0 / math.sqrt(self.embedding_dim))
        if self.padding_idx is not None and 0 <= self.padding_idx < self.num_embeddings:
            local_idx = self.padding_idx - self.vocab_start_index
            if 0 <= local_idx < self.weight.size(0):
                with torch.no_grad():
                    self.weight[local_idx].zero_()

    def forward(self, input_: torch.Tensor) -> torch.Tensor:
        mask = (input_ < self.vocab_start_index) | (input_ >= self.vocab_end_index)
        adjusted_input = input_ - self.vocab_start_index
        adjusted_input = adjusted_input.masked_fill(mask, 0)
        output = F.embedding(adjusted_input, self.weight, self.padding_idx)
        output = output.masked_fill(mask.unsqueeze(-1), 0.0)

        if self.world_size > 1:
            if self.group is not None:
                output = _ReduceForward.apply(output, self.group)
            else:
                dist.all_reduce(output)

        return output


class PipelineParallelModule(nn.Module):
    def __init__(
        self,
        layers: nn.ModuleList,
        num_micro_batches: int = 1,
        num_stages: int = 1,
        stage_id: int = 0,
        group: Optional[dist.ProcessGroup] = None,
        dtype: torch.dtype = torch.float32,
    ) -> None:
        super().__init__()
        self.layers = layers
        self.num_micro_batches = num_micro_batches
        self.num_stages = num_stages
        self.stage_id = stage_id
        self.group = group
        self.dtype = dtype

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        micro_batches = x.chunk(self.num_micro_batches, dim=0)
        outputs: List[torch.Tensor] = []

        for micro_batch in micro_batches:
            h = micro_batch
            for layer in self.layers:
                h = layer(h)
            outputs.append(h)

        output = torch.cat(outputs, dim=0)

        if self.num_stages > 1 and self.group is not None:
            if self.stage_id < self.num_stages - 1:
                dist.send(output, dst=(self.stage_id + 1) % dist.get_world_size(self.group), group=self.group)
                output = torch.zeros_like(output)

            if self.stage_id > 0:
                src_rank = (self.stage_id - 1) % dist.get_world_size(self.group)
                output = torch.empty_like(output)
                dist.recv(output, src=src_rank, group=self.group)

        return output


class SequenceParallelAttention(nn.Module):
    def __init__(
        self,
        hidden_size: int,
        num_heads: int,
        world_size: int = 1,
        rank: int = 0,
        group: Optional[dist.ProcessGroup] = None,
        dropout: float = 0.0,
        dtype: torch.dtype = torch.float32,
    ) -> None:
        super().__init__()
        self.hidden_size = hidden_size
        self.num_heads = num_heads
        self.head_dim = hidden_size // num_heads
        self.world_size = world_size
        self.rank = rank
        self.group = group

        self.qkv = nn.Linear(hidden_size, 3 * hidden_size, dtype=dtype)
        self.proj = nn.Linear(hidden_size, hidden_size, dtype=dtype)
        self.dropout = nn.Dropout(dropout)

    def _ring_attention(
        self,
        q: torch.Tensor,
        k: torch.Tensor,
        v: torch.Tensor,
        attention_mask: Optional[torch.Tensor] = None,
    ) -> torch.Tensor:
        if self.world_size <= 1:
            scores = torch.matmul(q, k.transpose(-2, -1)) / math.sqrt(self.head_dim)
            if attention_mask is not None:
                scores = scores + attention_mask
            attn = F.softmax(scores, dim=-1, dtype=torch.float32).to(q.dtype)
            attn = self.dropout(attn)
            return torch.matmul(attn, v)

        local_seq_len = q.size(-2)
        global_out = torch.zeros_like(q)

        for i in range(self.world_size):
            scores = torch.matmul(q, k.transpose(-2, -1)) / math.sqrt(self.head_dim)
            if attention_mask is not None:
                mask_slice = attention_mask[..., :, i * local_seq_len : (i + 1) * local_seq_len]
                if mask_slice.size(-1) == scores.size(-1):
                    scores = scores + mask_slice
            attn = F.softmax(scores, dim=-1, dtype=torch.float32).to(q.dtype)
            attn = self.dropout(attn)
            out_slice = torch.matmul(attn, v)
            global_out = global_out + out_slice

            if i < self.world_size - 1:
                send_rank = (self.rank + 1) % self.world_size
                recv_rank = (self.rank - 1) % self.world_size
                recv_k = torch.empty_like(k)
                recv_v = torch.empty_like(v)
                send_req_k = dist.isend(k, send_rank, group=self.group)
                send_req_v = dist.isend(v, send_rank, group=self.group)
                dist.recv(recv_k, recv_rank, group=self.group)
                dist.recv(recv_v, recv_rank, group=self.group)
                send_req_k.wait()
                send_req_v.wait()
                k, v = recv_k, recv_v

        return global_out

    def forward(
        self,
        hidden_states: torch.Tensor,
        attention_mask: Optional[torch.Tensor] = None,
    ) -> torch.Tensor:
        bsz, seq_len, _ = hidden_states.shape
        qkv = self.qkv(hidden_states)
        q, k, v = qkv.chunk(3, dim=-1)

        q = q.view(bsz, seq_len, self.num_heads, self.head_dim).transpose(1, 2)
        k = k.view(bsz, seq_len, self.num_heads, self.head_dim).transpose(1, 2)
        v = v.view(bsz, seq_len, self.num_heads, self.head_dim).transpose(1, 2)

        attn_output = self._ring_attention(q, k, v, attention_mask)
        attn_output = attn_output.transpose(1, 2).contiguous().view(bsz, seq_len, self.hidden_size)
        output = self.proj(attn_output)
        return output


class ContextParallelEmbedding(nn.Module):
    def __init__(
        self,
        num_embeddings: int,
        embedding_dim: int,
        world_size: int = 1,
        rank: int = 0,
        group: Optional[dist.ProcessGroup] = None,
        dtype: torch.dtype = torch.float32,
    ) -> None:
        super().__init__()
        self.num_embeddings = num_embeddings
        self.embedding_dim = embedding_dim
        self.world_size = world_size
        self.rank = rank
        self.group = group
        self.weight = nn.Parameter(torch.empty(num_embeddings, embedding_dim, dtype=dtype))
        self.reset_parameters()

    def reset_parameters(self) -> None:
        nn.init.normal_(self.weight, mean=0.0, std=1.0 / math.sqrt(self.embedding_dim))

    def forward(self, input_: torch.Tensor) -> torch.Tensor:
        return F.embedding(input_, self.weight)


class ContextParallelCrossEntropy(nn.Module):
    def __init__(
        self,
        world_size: int = 1,
        rank: int = 0,
        group: Optional[dist.ProcessGroup] = None,
        ignore_index: int = -100,
    ) -> None:
        super().__init__()
        self.world_size = world_size
        self.rank = rank
        self.group = group
        self.ignore_index = ignore_index

    def forward(self, logits: torch.Tensor, labels: torch.Tensor) -> torch.Tensor:
        if self.world_size <= 1:
            return F.cross_entropy(logits.view(-1, logits.size(-1)), labels.view(-1), ignore_index=self.ignore_index)

        vocab_size = logits.size(-1)
        local_vocab = vocab_size // self.world_size
        start_idx = self.rank * local_vocab
        end_idx = (self.rank + 1) * local_vocab

        logits_local = logits[..., start_idx:end_idx].contiguous()
        max_logits = logits.max(dim=-1, keepdim=True).values
        dist.all_reduce(max_logits, op=dist.ReduceOp.MAX, group=self.group)
        logits_shifted = logits - max_logits
        logits_local_shifted = logits_shifted[..., start_idx:end_idx].contiguous()
        exp_local = logits_local_shifted.exp()
        sum_exp_local = exp_local.sum(dim=-1, keepdim=True)
        sum_exp = sum_exp_local.clone()
        dist.all_reduce(sum_exp, op=dist.ReduceOp.SUM, group=self.group)
        log_probs_local = logits_local_shifted - sum_exp.log()

        nll_loss = F.nll_loss(
            log_probs_local.view(-1, local_vocab),
            labels.view(-1),
            ignore_index=self.ignore_index,
            reduction="none",
        )

        valid_mask = labels.view(-1) != self.ignore_index
        if valid_mask.any():
            return nll_loss.sum() / valid_mask.sum()
        return nll_loss.sum()


def _build_tensor_parallel_module(
    module: nn.Module,
    config: TensorParallelConfig,
    group: Optional[dist.ProcessGroup],
) -> nn.Module:
    if not config.enabled or config.world_size <= 1:
        return module

    if isinstance(module, nn.Linear):
        in_features = module.in_features
        out_features = module.out_features
        has_bias = module.bias is not None
        dtype = module.weight.dtype

        if config.mode.value == "column_wise":
            return ColumnParallelLinear(
                in_features,
                out_features,
                bias=has_bias,
                gather_output=config.gather_output,
                world_size=config.world_size,
                rank=dist.get_rank(group) if group is not None else 0,
                group=group,
                dtype=dtype,
            )
        else:
            return RowParallelLinear(
                in_features,
                out_features,
                bias=has_bias,
                world_size=config.world_size,
                rank=dist.get_rank(group) if group is not None else 0,
                group=group,
                dtype=dtype,
            )

    if isinstance(module, nn.Embedding):
        return VocabParallelEmbedding(
            module.num_embeddings,
            module.embedding_dim,
            world_size=config.world_size,
            rank=dist.get_rank(group) if group is not None else 0,
            padding_idx=module.padding_idx,
            group=group,
            dtype=module.weight.dtype,
        )

    return module


def apply_tensor_parallel(
    model: nn.Module,
    config: TensorParallelConfig,
    group: Optional[dist.ProcessGroup] = None,
) -> nn.Module:
    if not config.enabled or config.world_size <= 1:
        return model

    for name, child in model.named_children():
        new_child = _build_tensor_parallel_module(child, config, group)
        if new_child is not child:
            setattr(model, name, new_child)
        else:
            apply_tensor_parallel(child, config, group)

    return model


def apply_pipeline_parallel(
    model: nn.Module,
    num_stages: int,
    stage_id: int,
    group: Optional[dist.ProcessGroup] = None,
) -> nn.Module:
    if num_stages <= 1:
        return model

    children = list(model.named_children())
    total_layers = len(children)
    layers_per_stage = _ensure_divisible(total_layers, num_stages) // num_stages
    start = stage_id * layers_per_stage
    end = min(start + layers_per_stage, total_layers)

    named_layers = list(model.named_children())
    for name, child in named_layers:
        if name not in [n for n, _ in children[start:end]]:
            setattr(model, name, nn.Identity())

    return model


def sequence_parallel_available() -> bool:
    try:
        import torch.distributed.nn  # noqa: F401

        return True
    except ImportError:
        return False


def context_parallel_available() -> bool:
    return dist.is_available() and dist.is_initialized()


class ParallelismManager:
    def __init__(self, config: ParallelismConfig) -> None:
        self.config = config
        self._groups: Dict[str, dist.ProcessGroup] = {}

    def initialize_groups(self, backend: str = "nccl") -> None:
        if not dist.is_initialized():
            return

        world_size = dist.get_world_size()
        rank = dist.get_rank()

        tp = self.config.tensor_parallel
        pp = self.config.pipeline_parallel
        sp = self.config.sequence_parallel
        cp = self.config.context_parallel

        if tp.enabled and tp.world_size > 1:
            tp_size = tp.world_size
            num_tp_groups = world_size // tp_size
            for i in range(num_tp_groups):
                ranks = list(range(i * tp_size, (i + 1) * tp_size))
                group = dist.new_group(ranks=ranks, backend=backend)
                self._groups[f"tp_{i}"] = group
                if rank in ranks:
                    self._groups["tp"] = group

        if pp.enabled and pp.num_stages > 1:
            pp_size = pp.num_stages
            num_pp_groups = world_size // pp_size
            for i in range(num_pp_groups):
                ranks = list(range(i * pp_size, (i + 1) * pp_size))
                group = dist.new_group(ranks=ranks, backend=backend)
                self._groups[f"pp_{i}"] = group
                if rank in ranks:
                    self._groups["pp"] = group

        if sp.enabled:
            for i in range(world_size):
                group = dist.new_group(ranks=[i], backend=backend)
                self._groups[f"sp_{i}"] = group
                if rank == i:
                    self._groups["sp"] = group

        if cp.enabled and cp.world_size > 1:
            cp_size = cp.world_size
            num_cp_groups = world_size // cp_size
            for i in range(num_cp_groups):
                ranks = list(range(i * cp_size, (i + 1) * cp_size))
                group = dist.new_group(ranks=ranks, backend=backend)
                self._groups[f"cp_{i}"] = group
                if rank in ranks:
                    self._groups["cp"] = group

        dp_size = world_size
        if tp.enabled and tp.world_size > 1:
            dp_size = dp_size // tp.world_size
        if pp.enabled and pp.num_stages > 1:
            dp_size = dp_size // pp.num_stages

        if dp_size > 1:
            dp_ranks = [r for r in range(world_size)]
            if tp.enabled and tp.world_size > 1:
                tp_group_idx = rank // tp.world_size
                dp_ranks = [r for r in range(world_size) if r // tp.world_size == tp_group_idx]
            group = dist.new_group(ranks=dp_ranks, backend=backend)
            self._groups["dp"] = group

    def get_group(self, name: str) -> Optional[dist.ProcessGroup]:
        return self._groups.get(name)

    def get_tp_group(self) -> Optional[dist.ProcessGroup]:
        return self._groups.get("tp")

    def get_pp_group(self) -> Optional[dist.ProcessGroup]:
        return self._groups.get("pp")

    def get_sp_group(self) -> Optional[dist.ProcessGroup]:
        return self._groups.get("sp")

    def get_cp_group(self) -> Optional[dist.ProcessGroup]:
        return self._groups.get("cp")

    def get_dp_group(self) -> Optional[dist.ProcessGroup]:
        return self._groups.get("dp")

    def get_tp_world_size(self) -> int:
        return self.config.tensor_parallel.world_size if self.config.tensor_parallel.enabled else 1

    def get_pp_world_size(self) -> int:
        return self.config.pipeline_parallel.num_stages if self.config.pipeline_parallel.enabled else 1

    def get_dp_world_size(self) -> int:
        tp = self.get_tp_world_size()
        pp = self.get_pp_world_size()
        if dist.is_initialized():
            return dist.get_world_size() // (tp * pp)
        return 1

    def apply_all(self, model: nn.Module) -> nn.Module:
        model = apply_tensor_parallel(model, self.config.tensor_parallel, self.get_tp_group())

        if self.config.pipeline_parallel.enabled:
            model = apply_pipeline_parallel(
                model,
                self.config.pipeline_parallel.num_stages,
                dist.get_rank() if dist.is_initialized() else 0,
                self.get_pp_group(),
            )

        return model
