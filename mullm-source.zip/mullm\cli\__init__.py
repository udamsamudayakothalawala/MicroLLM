"""muLLM CLI - Command-line interface for the muLLM platform."""

from mullm.cli.main import main

__all__ = ["main"]
