"""Complete data processing pipeline with configurable stages, parallel processing, and caching."""

from __future__ import annotations

import asyncio
import hashlib
import json
import logging
import time
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any, Callable, Optional, Protocol

logger = logging.getLogger(__name__)


class PipelineStage(Enum):
    CRAWL = "crawl"
    DOWNLOAD = "download"
    CLEAN = "clean"
    EXTRACT = "extract"
    DETECT_LANGUAGE = "detect_language"
    DEDUPLICATE = "deduplicate"
    SCORE_QUALITY = "score_quality"
    FILTER_TOXICITY = "filter_toxicity"
    REMOVE_PII = "remove_pii"
    FILTER_COPYRIGHT = "filter_copyright"
    BALANCE = "balance"


class TransformFn(Protocol):
    def __call__(self, data: Any) -> Any: ...


class AsyncTransformFn(Protocol):
    async def __call__(self, data: Any) -> Any: ...


@dataclass
class StageResult:
    """Result of a pipeline stage."""

    stage: str
    input_count: int
    output_count: int
    elapsed: float
    skipped: bool = False
    error: Optional[str] = None
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class PipelineConfig:
    """Configuration for data pipeline."""

    stages: list[str] = field(default_factory=lambda: [s.value for s in PipelineStage])
    parallel_stages: bool = False
    max_workers: int = 4
    cache_dir: str = ".pipeline_cache"
    enable_cache: bool = True
    cache_ttl: int = 3600
    progress_callback: Optional[Callable[[str, int, int], None]] = None
    error_handling: str = "skip"
    batch_size: int = 1000
    log_level: str = "INFO"


@dataclass
class PipelineStats:
    """Statistics for a complete pipeline run."""

    total_input: int
    total_output: int
    stages: list[StageResult]
    total_elapsed: float
    errors: list[str]
    cache_hits: int = 0
    cache_misses: int = 0


class CacheManager:
    """Manages intermediate pipeline results."""

    def __init__(self, cache_dir: str, ttl: int = 3600) -> None:
        self._cache_dir = Path(cache_dir)
        self._ttl = ttl
        self._memory_cache: dict[str, Any] = {}
        self._hits = 0
        self._misses = 0

    def _ensure_dir(self) -> None:
        self._cache_dir.mkdir(parents=True, exist_ok=True)

    def _key(self, stage: str, data_hash: str) -> str:
        return f"{stage}_{data_hash}"

    def _hash_data(self, data: Any) -> str:
        if isinstance(data, str):
            content = data
        elif isinstance(data, bytes):
            content = data.decode("utf-8", errors="replace")
        else:
            content = json.dumps(data, default=str, sort_keys=True)
        return hashlib.md5(content.encode("utf-8")).hexdigest()

    def get(self, stage: str, data: Any) -> Optional[Any]:
        key = self._key(stage, self._hash_data(data))
        if key in self._memory_cache:
            self._hits += 1
            return self._memory_cache[key]

        self._ensure_dir()
        cache_path = self._cache_dir / f"{key}.json"
        if cache_path.exists():
            try:
                import os
                mtime = cache_path.stat().st_mtime
                if time.time() - mtime < self._ttl:
                    with open(cache_path, "r", encoding="utf-8") as f:
                        result = json.load(f)
                    self._memory_cache[key] = result
                    self._hits += 1
                    return result
                else:
                    cache_path.unlink(missing_ok=True)
            except Exception:
                cache_path.unlink(missing_ok=True)

        self._misses += 1
        return None

    def set(self, stage: str, data: Any, result: Any) -> None:
        key = self._key(stage, self._hash_data(data))
        self._memory_cache[key] = result

        self._ensure_dir()
        cache_path = self._cache_dir / f"{key}.json"
        try:
            with open(cache_path, "w", encoding="utf-8") as f:
                json.dump(result, f, default=str)
        except Exception as e:
            logger.warning("Failed to write cache: %s", e)

    @property
    def stats(self) -> dict[str, int]:
        return {"hits": self._hits, "misses": self._misses}

    def clear(self) -> None:
        self._memory_cache.clear()
        if self._cache_dir.exists():
            import shutil
            shutil.rmtree(self._cache_dir, ignore_errors=True)


class DataPipeline:
    """Complete data processing pipeline."""

    def __init__(self, config: Optional[PipelineConfig] = None) -> None:
        self.config = config or PipelineConfig()
        self._stages: dict[str, Callable[[Any], Any]] = {}
        self._async_stages: dict[str, Callable[[Any], Any]] = {}
        self._cache = CacheManager(
            self.config.cache_dir, self.config.cache_ttl
        ) if self.config.enable_cache else None
        self._pre_hooks: dict[str, list[Callable]] = {}
        self._post_hooks: dict[str, list[Callable]] = {}
        self._register_default_stages()

    def _register_default_stages(self) -> None:
        self._stages[PipelineStage.CLEAN.value] = self._default_clean
        self._stages[PipelineStage.EXTRACT.value] = self._default_extract
        self._stages[PipelineStage.DEDUPLICATE.value] = self._default_deduplicate
        self._stages[PipelineStage.SCORE_QUALITY.value] = self._default_quality
        self._stages[PipelineStage.FILTER_TOXICITY.value] = self._default_toxicity
        self._stages[PipelineStage.REMOVE_PII.value] = self._default_pii
        self._stages[PipelineStage.FILTER_COPYRIGHT.value] = self._default_copyright
        self._stages[PipelineStage.BALANCE.value] = self._default_balance

    def _default_clean(self, data: Any) -> Any:
        from mullm.core.data.cleaner import HTMLCleaner
        cleaner = HTMLCleaner()
        if isinstance(data, list):
            return [cleaner.clean(item) if isinstance(item, str) else item for item in data]
        elif isinstance(data, str):
            return cleaner.clean(data)
        return data

    def _default_extract(self, data: Any) -> Any:
        if isinstance(data, list):
            from mullm.core.data.extractor import TextExtractor
            extractor = TextExtractor()
            return [extractor.extract_by_type(item, "txt").text if isinstance(item, str) else item for item in data]
        return data

    def _default_deduplicate(self, data: Any) -> Any:
        from mullm.core.data.deduplication import Deduplicator
        dedup = Deduplicator()
        if isinstance(data, list):
            texts = [str(item) for item in data]
            return dedup.deduplicate(texts, method="exact")
        return data

    def _default_quality(self, data: Any) -> Any:
        from mullm.core.data.quality import QualityScorer
        scorer = QualityScorer()
        if isinstance(data, list):
            results = []
            for item in data:
                text = str(item) if not isinstance(item, dict) else item.get("text", str(item))
                score = scorer.score(text)
                if score.passes_threshold:
                    results.append(item)
            return results
        return data

    def _default_toxicity(self, data: Any) -> Any:
        from mullm.core.data.toxicity import ToxicityFilter
        filt = ToxicityFilter()
        if isinstance(data, list):
            results = []
            for item in data:
                text = str(item) if not isinstance(item, dict) else item.get("text", str(item))
                if not filt.is_toxic(text):
                    results.append(item)
            return results
        return data

    def _default_pii(self, data: Any) -> Any:
        from mullm.core.data.privacy import PIIAnonymizer
        anonymizer = PIIAnonymizer()
        if isinstance(data, list):
            results = []
            for item in data:
                if isinstance(item, dict) and "text" in item:
                    item["text"], _ = anonymizer.redact(item["text"])
                    results.append(item)
                elif isinstance(item, str):
                    redacted, _ = anonymizer.redact(item)
                    results.append(redacted)
                else:
                    results.append(item)
            return results
        return data

    def _default_copyright(self, data: Any) -> Any:
        from mullm.core.data.copyright import CopyrightFilter
        filt = CopyrightFilter()
        if isinstance(data, list):
            results = []
            for item in data:
                text = str(item) if not isinstance(item, dict) else item.get("text", str(item))
                if filt.is_allowed(text):
                    results.append(item)
            return results
        return data

    def _default_balance(self, data: Any) -> Any:
        if isinstance(data, list) and data and isinstance(data[0], dict):
            from mullm.core.data.balancing import DatasetBalancer
            balancer = DatasetBalancer()
            return balancer.balance(data, by="category")
        return data

    def register_stage(self, name: str, fn: Callable[[Any], Any]) -> None:
        self._stages[name] = fn

    def register_async_stage(self, name: str, fn: Callable[[Any], Any]) -> None:
        self._async_stages[name] = fn

    def add_pre_hook(self, stage: str, hook: Callable) -> None:
        if stage not in self._pre_hooks:
            self._pre_hooks[stage] = []
        self._pre_hooks[stage].append(hook)

    def add_post_hook(self, stage: str, hook: Callable) -> None:
        if stage not in self._post_hooks:
            self._post_hooks[stage] = []
        self._post_hooks[stage].append(hook)

    def _run_hooks(self, hooks: dict[str, list[Callable]], stage: str, data: Any) -> Any:
        for hook in hooks.get(stage, []):
            data = hook(data)
        return data

    def run(self, data: Any, stages: Optional[list[str]] = None) -> tuple[Any, PipelineStats]:
        stages_to_run = stages or self.config.stages
        stats = PipelineStats(
            total_input=self._count_items(data),
            total_output=0,
            stages=[],
            total_elapsed=0,
            errors=[],
        )
        total_start = time.monotonic()

        current_data = data
        for stage_name in stages_to_run:
            if stage_name not in self._stages and stage_name not in self._async_stages:
                logger.warning("Stage '%s' not registered, skipping", stage_name)
                continue

            if self.config.progress_callback:
                self.config.progress_callback(
                    stage_name,
                    len(stats.stages),
                    len(stages_to_run),
                )

            stage_start = time.monotonic()
            input_count = self._count_items(current_data)

            try:
                if self._cache:
                    cached = self._cache.get(stage_name, current_data)
                    if cached is not None:
                        current_data = cached
                        stats.cache_hits += 1
                        elapsed = time.monotonic() - stage_start
                        stats.stages.append(StageResult(
                            stage=stage_name,
                            input_count=input_count,
                            output_count=self._count_items(current_data),
                            elapsed=elapsed,
                            metadata={"cache_hit": True},
                        ))
                        continue
                    stats.cache_misses += 1

                current_data = self._run_hooks(self._pre_hooks, stage_name, current_data)

                if stage_name in self._async_stages:
                    loop = asyncio.new_event_loop()
                    try:
                        current_data = loop.run_until_complete(
                            self._async_stages[stage_name](current_data)
                        )
                    finally:
                        loop.close()
                elif stage_name in self._stages:
                    current_data = self._stages[stage_name](current_data)

                current_data = self._run_hooks(self._post_hooks, stage_name, current_data)

                if self._cache:
                    self._cache.set(stage_name, current_data, current_data)

                elapsed = time.monotonic() - stage_start
                output_count = self._count_items(current_data)
                stats.stages.append(StageResult(
                    stage=stage_name,
                    input_count=input_count,
                    output_count=output_count,
                    elapsed=elapsed,
                ))
                logger.info(
                    "Stage %s: %d → %d items (%.2fs)",
                    stage_name, input_count, output_count, elapsed,
                )

            except Exception as e:
                elapsed = time.monotonic() - stage_start
                error_msg = f"Stage '{stage_name}' failed: {e}"
                stats.errors.append(error_msg)
                stats.stages.append(StageResult(
                    stage=stage_name,
                    input_count=input_count,
                    output_count=self._count_items(current_data),
                    elapsed=elapsed,
                    error=str(e),
                ))
                logger.error(error_msg)

                if self.config.error_handling == "stop":
                    break

        stats.total_output = self._count_items(current_data)
        stats.total_elapsed = time.monotonic() - total_start
        return current_data, stats

    async def run_async(
        self, data: Any, stages: Optional[list[str]] = None
    ) -> tuple[Any, PipelineStats]:
        stages_to_run = stages or self.config.stages
        stats = PipelineStats(
            total_input=self._count_items(data),
            total_output=0,
            stages=[],
            total_elapsed=0,
            errors=[],
        )
        total_start = time.monotonic()

        current_data = data
        for stage_name in stages_to_run:
            if stage_name not in self._stages and stage_name not in self._async_stages:
                logger.warning("Stage '%s' not registered, skipping", stage_name)
                continue

            stage_start = time.monotonic()
            input_count = self._count_items(current_data)

            try:
                if self._cache:
                    cached = self._cache.get(stage_name, current_data)
                    if cached is not None:
                        current_data = cached
                        stats.cache_hits += 1
                        elapsed = time.monotonic() - stage_start
                        stats.stages.append(StageResult(
                            stage=stage_name,
                            input_count=input_count,
                            output_count=self._count_items(current_data),
                            elapsed=elapsed,
                        ))
                        continue
                    stats.cache_misses += 1

                current_data = self._run_hooks(self._pre_hooks, stage_name, current_data)

                if stage_name in self._async_stages:
                    current_data = await self._async_stages[stage_name](current_data)
                elif stage_name in self._stages:
                    loop = asyncio.get_event_loop()
                    current_data = await loop.run_in_executor(
                        None, self._stages[stage_name], current_data
                    )

                current_data = self._run_hooks(self._post_hooks, stage_name, current_data)

                if self._cache:
                    self._cache.set(stage_name, current_data, current_data)

                elapsed = time.monotonic() - stage_start
                output_count = self._count_items(current_data)
                stats.stages.append(StageResult(
                    stage=stage_name,
                    input_count=input_count,
                    output_count=output_count,
                    elapsed=elapsed,
                ))

            except Exception as e:
                elapsed = time.monotonic() - stage_start
                error_msg = f"Stage '{stage_name}' failed: {e}"
                stats.errors.append(error_msg)
                stats.stages.append(StageResult(
                    stage=stage_name,
                    input_count=input_count,
                    output_count=self._count_items(current_data),
                    elapsed=elapsed,
                    error=str(e),
                ))
                if self.config.error_handling == "stop":
                    break

        stats.total_output = self._count_items(current_data)
        stats.total_elapsed = time.monotonic() - total_start
        return current_data, stats

    def _count_items(self, data: Any) -> int:
        if isinstance(data, list):
            return len(data)
        return 1

    def run_batch(
        self, batches: list[Any], stages: Optional[list[str]] = None
    ) -> tuple[list[Any], list[PipelineStats]]:
        results: list[Any] = []
        all_stats: list[PipelineStats] = []
        for batch in batches:
            result, stats = self.run(batch, stages)
            results.append(result)
            all_stats.append(stats)
        return results, all_stats

    def clear_cache(self) -> None:
        if self._cache:
            self._cache.clear()

    def get_cache_stats(self) -> dict[str, int]:
        if self._cache:
            return self._cache.stats
        return {"hits": 0, "misses": 0}
