#!/usr/bin/env bash
# muLLM Benchmark Launcher
# Runs performance benchmarks: throughput, latency, and memory profiling.

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"

MODEL_PATH="${MULLM_MODEL_PATH:-}"
HOST="${MULLM_SERVE_HOST:-localhost}"
PORT="${MULLM_SERVE_PORT:-8000}"
CONCURRENT="${MULLM_BENCHMARK_CONCURRENT:-16}"
DURATION="${MULLM_BENCHMARK_DURATION:-60}"
PROMPT_LENGTH="${MULLM_BENCHMARK_PROMPT_LENGTH:-128}"
MAX_TOKENS="${MULLM_BENCHMARK_MAX_TOKENS:-128}"
OUTPUT_DIR="${MULLM_BENCHMARK_OUTPUT_DIR:-./benchmarks}"
API_KEY="${MULLM_BENCHMARK_API_KEY:-}"
WARMUP_REQUESTS="${MULLM_BENCHMARK_WARMUP:-10}"

while [[ $# -gt 0 ]]; do
    case $1 in
        --model-path) MODEL_PATH="$2"; shift 2 ;;
        --host) HOST="$2"; shift 2 ;;
        --port) PORT="$2"; shift 2 ;;
        --concurrent) CONCURRENT="$2"; shift 2 ;;
        --duration) DURATION="$2"; shift 2 ;;
        --prompt-length) PROMPT_LENGTH="$2"; shift 2 ;;
        --max-tokens) MAX_TOKENS="$2"; shift 2 ;;
        --output-dir) OUTPUT_DIR="$2"; shift 2 ;;
        --api-key) API_KEY="$2"; shift 2 ;;
        --warmup) WARMUP_REQUESTS="$2"; shift 2 ;;
        -h|--help)
            echo "Usage: $0 [options]"
            echo ""
            echo "Options:"
            echo "  --model-path <path>       Model name/path"
            echo "  --host <host>             API server host (default: localhost)"
            echo "  --port <port>             API server port (default: 8000)"
            echo "  --concurrent <n>          Concurrent requests (default: 16)"
            echo "  --duration <sec>          Benchmark duration in seconds (default: 60)"
            echo "  --prompt-length <tokens>  Input prompt length (default: 128)"
            echo "  --max-tokens <tokens>     Max output tokens (default: 128)"
            echo "  --output-dir <dir>        Results directory (default: ./benchmarks)"
            echo "  --warmup <n>              Warmup requests (default: 10)"
            echo "  --api-key <key>           API key for authentication"
            exit 0
            ;;
        *) echo "Unknown option: $1"; exit 1 ;;
    esac
done

echo "============================================"
echo "  muLLM Benchmark"
echo "============================================"
echo "Server:         $HOST:$PORT"
echo "Concurrent:     $CONCURRENT"
echo "Duration:       ${DURATION}s"
echo "Prompt length:  $PROMPT_LENGTH tokens"
echo "Max tokens:     $MAX_TOKENS"
echo "Warmup:         $WARMUP_REQUESTS requests"
echo "============================================"

mkdir -p "$OUTPUT_DIR"
TIMESTAMP=$(date +%Y%m%d_%H%M%S)
RESULTS_FILE="$OUTPUT_DIR/benchmark_${TIMESTAMP}.json"

URL="http://${HOST}:${PORT}/v1/completions"
HEALTH_URL="http://${HOST}:${PORT}/v1/health"

echo "Checking server health..."
if ! curl -sf "$HEALTH_URL" > /dev/null 2>&1; then
    echo "Error: Server not responding at $HEALTH_URL" >&2
    echo "Start the server with: mullm serve --model-path <model>" >&2
    exit 1
fi
echo "Server is healthy."

echo ""
echo "Generating prompt of ~${PROMPT_LENGTH} tokens..."
PROMPT=$(python3 -c "print('The quick brown fox jumps over the lazy dog. ' * ($PROMPT_LENGTH // 8))")

AUTH_HEADER=""
if [[ -n "$API_KEY" ]]; then
    AUTH_HEADER="-H \"Authorization: Bearer $API_KEY\""
fi

echo "Warming up with $WARMUP_REQUESTS requests..."
for i in $(seq 1 "$WARMUP_REQUESTS"); do
    curl -sf "$URL" \
        -H "Content-Type: application/json" \
        ${AUTH_HEADER:+-H "Authorization: Bearer $API_KEY"} \
        -d "{\"model\": \"default\", \"prompt\": \"$PROMPT\", \"max_tokens\": $MAX_TOKENS, \"temperature\": 0.0}" \
        > /dev/null 2>&1 &
done
wait

echo "Running benchmark..."
python3 - "$URL" "$PROMPT" "$CONCURRENT" "$DURATION" "$MAX_TOKENS" "$API_KEY" "$RESULTS_FILE" << 'PYEOF'
import sys
import json
import time
import statistics
import threading
import urllib.request
import urllib.error

url = sys.argv[1]
prompt = sys.argv[2]
concurrent = int(sys.argv[3])
duration = int(sys.argv[4])
max_tokens = int(sys.argv[5])
api_key = sys.argv[6]
results_file = sys.argv[7]

model_name = "default"
payload = json.dumps({
    "model": model_name,
    "prompt": prompt,
    "max_tokens": max_tokens,
    "temperature": 0.0,
}).encode("utf-8")

headers = {"Content-Type": "application/json"}
if api_key:
    headers["Authorization"] = f"Bearer {api_key}"

latencies = []
tokens_generated = 0
errors = 0
lock = threading.Lock()
stop_event = threading.Event()

def make_request():
    global tokens_generated, errors
    while not stop_event.is_set():
        start = time.monotonic()
        try:
            req = urllib.request.Request(url, data=payload, headers=headers)
            with urllib.request.urlopen(req, timeout=300) as resp:
                body = json.loads(resp.read())
                elapsed = time.monotonic() - start
                with lock:
                    latencies.append(elapsed)
                    generated = body.get("usage", {}).get("completion_tokens", max_tokens)
                    tokens_generated += generated
        except Exception:
            with lock:
                errors += 1
            time.sleep(0.1)

threads = []
for _ in range(concurrent):
    t = threading.Thread(target=make_request, daemon=True)
    t.start()
    threads.append(t)

start_time = time.monotonic()
time.sleep(duration)
stop_event.set()
for t in threads:
    t.join(timeout=5)
elapsed = time.monotonic() - start_time

total_requests = len(latencies)
throughput = tokens_generated / elapsed if elapsed > 0 else 0
requests_per_sec = total_requests / elapsed if elapsed > 0 else 0

stats = {}
if latencies:
    stats = {
        "mean_ms": round(statistics.mean(latencies) * 1000, 2),
        "median_ms": round(statistics.median(latencies) * 1000, 2),
        "p90_ms": round(sorted(latencies)[int(len(latencies) * 0.9)] * 1000, 2) if len(latencies) > 1 else 0,
        "p95_ms": round(sorted(latencies)[int(len(latencies) * 0.95)] * 1000, 2) if len(latencies) > 1 else 0,
        "p99_ms": round(sorted(latencies)[int(len(latencies) * 0.99)] * 1000, 2) if len(latencies) > 1 else 0,
        "min_ms": round(min(latencies) * 1000, 2),
        "max_ms": round(max(latencies) * 1000, 2),
        "stddev_ms": round(statistics.stdev(latencies) * 1000, 2) if len(latencies) > 1 else 0,
    }

results = {
    "model": model_name,
    "timestamp": time.strftime("%Y-%m-%dT%H:%M:%S"),
    "config": {
        "concurrent_requests": concurrent,
        "duration_seconds": duration,
        "prompt_length_tokens": len(prompt.split()),
        "max_tokens": max_tokens,
    },
    "results": {
        "total_requests": total_requests,
        "errors": errors,
        "total_tokens_generated": tokens_generated,
        "tokens_per_second": round(throughput, 2),
        "requests_per_second": round(requests_per_sec, 4),
        "total_duration_seconds": round(elapsed, 2),
        "latency": stats,
    },
}

with open(results_file, "w") as f:
    json.dump(results, f, indent=2)

print(f"\nResults:")
print(f"  Total requests:      {total_requests}")
print(f"  Errors:              {errors}")
print(f"  Tokens generated:    {tokens_generated}")
print(f"  Throughput:          {throughput:.2f} tokens/s")
print(f"  Requests/sec:        {requests_per_sec:.4f}")
if stats:
    print(f"  Mean latency:        {stats['mean_ms']:.2f} ms")
    print(f"  Median latency:      {stats['median_ms']:.2f} ms")
    print(f"  P90 latency:         {stats['p90_ms']:.2f} ms")
    print(f"  P95 latency:         {stats['p95_ms']:.2f} ms")
    print(f"  P99 latency:         {stats['p99_ms']:.2f} ms")
print(f"\nResults saved to: {results_file}")
PYEOF

echo ""
echo "Benchmark complete."
