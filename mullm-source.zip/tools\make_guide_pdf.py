"""Generate the muLLM full user guide as a PDF."""

from fpdf import FPDF


class GuidePDF(FPDF):
    def __init__(self):
        super().__init__("P", "mm", "A4")
        self.set_auto_page_break(auto=True, margin=18)
        self.add_page()

    def header(self):
        if self.page_no() > 1:
            self.set_font("Helvetica", "B", 9)
            self.set_text_color(120, 120, 140)
            self.cell(0, 8, "muLLM - User Guide", align="L")
            self.cell(0, 8, f"Page {self.page_no()}", align="R", new_x="LMARGIN", new_y="NEXT")
            self.ln(2)

    def footer(self):
        self.set_y(-15)
        self.set_font("Helvetica", "I", 8)
        self.set_text_color(150, 150, 160)
        self.cell(0, 10, "muLLM - Train a small LLM from scratch with as little as 1M tokens", align="C")

    def _width(self):
        return self.w - self.l_margin - self.r_margin

    def h1(self, text):
        self.ln(2)
        self.set_x(self.l_margin)
        self.set_font("Helvetica", "B", 18)
        self.set_text_color(99, 102, 241)
        self.cell(self._width(), 10, text, new_x="LMARGIN", new_y="NEXT")
        self.ln(1)

    def h2(self, text):
        self.ln(2)
        self.set_x(self.l_margin)
        self.set_font("Helvetica", "B", 13)
        self.set_text_color(30, 40, 60)
        self.cell(self._width(), 8, text, new_x="LMARGIN", new_y="NEXT")
        self.ln(1)

    def h3(self, text):
        self.ln(1)
        self.set_x(self.l_margin)
        self.set_font("Helvetica", "B", 11)
        self.set_text_color(60, 60, 80)
        self.cell(self._width(), 7, text, new_x="LMARGIN", new_y="NEXT")
        self.ln(1)

    def p(self, text):
        self.set_x(self.l_margin)
        self.set_font("Helvetica", "", 10)
        self.set_text_color(40, 40, 50)
        self.multi_cell(self._width(), 5.5, text)
        self.ln(1)

    def bullet(self, text):
        self.set_x(self.l_margin)
        self.set_font("Helvetica", "", 10)
        self.set_text_color(40, 40, 50)
        self.multi_cell(self._width(), 5.5, "  -  " + text)
        self.ln(0.5)

    def code(self, text):
        self.set_x(self.l_margin)
        self.set_font("Courier", "", 8.5)
        self.set_text_color(20, 20, 20)
        self.set_fill_color(240, 242, 247)
        self.multi_cell(self._width(), 4.5, text, fill=True)
        self.set_text_color(40, 40, 50)

    def note(self, text):
        self.set_x(self.l_margin)
        self.set_font("Helvetica", "I", 9.5)
        self.set_text_color(180, 90, 30)
        self.multi_cell(self._width(), 5, "NOTE: " + text)


pdf = GuidePDF()

pdf.h1("muLLM - Full User Guide")
pdf.p("muLLM is a minimal, self-contained toolkit to train a small transformer LLM from raw text "
       "- no HuggingFace, no pretrained checkpoints required. It is designed to work with small datasets "
       "(~1M tokens or less) on a single machine, using only 4 runtime dependencies (torch, numpy, tqdm, pyyaml).")
pdf.note("This codebase is UNTESTED in production. Validate thoroughly before any production use.")

pdf.h2("1. What is included")
pdf.bullet("TinyTransformer - Llama-style decoder-only transformer (RMSNorm, RoPE, SwiGLU) with 4 presets: "
           "tiny (~4M params), small (~30M), base (~180M), medium (~700M).")
pdf.bullet("SimpleTokenizer - byte-level BPE tokenizer trained on your own data; no HuggingFace tokenizer needed.")
pdf.bullet("SimpleTrainer - lightweight training loop with warmup/cosine LR, mixed precision, gradient clipping.")
pdf.bullet("TextDataset - loads .txt, .json, .jsonl, .csv files for training.")
pdf.bullet("GGUFExporter - exports trained models to GGUF format (f32/f16/q4_0) for llama.cpp.")
pdf.bullet("SimpleEvaluator - loss, perplexity, and accuracy metrics.")
pdf.bullet("PyQt5 GUI - 4-tab desktop app: Feed Data, Train, Test Model, Export GGUF.")
pdf.bullet("CLI - train / export / chat / gui commands.")

pdf.h2("2. Installation")
pdf.h3("2.1 From source (development)")
pdf.code("python -m venv venv\nvenv\\Scripts\\activate\npip install -e .                                # core (CLI)\npip install -r requirements-gui.txt        # PyQt5 for the GUI")
pdf.h3("2.2 From the wheel")
pdf.code("pip install dist\\mullm-0.1.0-py3-none-any.whl\npip install PyQt5   # for the GUI")
pdf.h3("2.3 Installer (provided files)")
pdf.bullet("install.bat  -  double-click to create a venv, install, and add Start-Menu shortcuts.")
pdf.bullet("installer/mullm.iss  -  Inno Setup script; compile with ISCC.exe to produce dist/mullm-setup.exe.")
pdf.note("Python 3.10+ is required. Torch (~200 MB with CUDA-capable builds larger) is downloaded automatically by pip.")

pdf.h2("3. Command Line Interface")
pdf.h3("3.1 Train a model from scratch")
pdf.code("mullm train --dataset data.txt --size small --epochs 3 --output-dir ./outputs")
pdf.bullet("Supported inputs: .txt, .json, .jsonl, .csv.")
pdf.bullet("--size: tiny | small | base | medium")
pdf.bullet("Key flags: --vocab-size (default 32000), --max-seq-length (512), --batch-size (8), "
           "--learning-rate (3e-4), --epochs (3), --max-steps (-1 auto), --warmup-steps (100), "
           "--save-steps (500), --eval-steps (0 off), --device (auto/cuda/cpu/mps), --bf16 (on by default), --seed (42)")
pdf.p("Outputs: a BPE tokenizer (outputs/tokenizer.json), checkpoints (outputs/checkpoint-final/model.pt + config.json), "
       "and a live training log with loss, perplexity, learning rate.")

pdf.h3("3.2 Export to GGUF")
pdf.code("mullm export --checkpoint outputs            # finds checkpoint-final\nmullm export --checkpoint outputs\\checkpoint-final\\model.pt\nmullm export --checkpoint outputs --gguf-type q4_0 --output-dir model.gguf")
pdf.bullet("--gguf-type: f32 | f16 | q4_0")
pdf.bullet("--architecture: llama (default) | gpt2 | mistral")
pdf.bullet("The model configuration is saved with the checkpoint, so export/chat rebuild it exactly.")

pdf.h3("3.3 Chat with your trained model")
pdf.code("mullm chat --checkpoint outputs --tokenizer outputs\\tokenizer.json\nmullm chat --checkpoint outputs\\checkpoint-final\\model.pt --tokenizer outputs\\tokenizer.json --max-tokens 256")

pdf.h3("3.4 Launch the GUI")
pdf.code("mullm gui")

pdf.h2("4. Desktop GUI (Recommended for beginners)")
pdf.p("The GUI is a 4-tab wizard-style workflow:")
pdf.h3("Tab 1 - Feed Data")
pdf.bullet("Import .txt / .json / .jsonl / .csv or load the built-in sample dataset.")
pdf.bullet("Preview rows, sample count, character count, and an approximate token count.")
pdf.h3("Tab 2 - Train")
pdf.bullet("Choose model size preset, epochs, batch size, learning rate, max sequence length, vocab size, device, BF16.")
pdf.bullet("Live monitoring: loss, perplexity, training LEVEL (Level 0 Initializing -> Level 4 Converged), step, elapsed time.")
pdf.bullet("Metrics history table, progress bar, and scrollable log. Stop button halts training and saves a final checkpoint.")
pdf.h3("Tab 3 - Test Model")
pdf.bullet("Load a checkpoint (auto-finds checkpoint-final).")
pdf.bullet("Run evaluation: loss, perplexity, accuracy on a held-out sample.")
pdf.bullet("Generation test: type a prompt and see the model's completion before you commit to exporting.")
pdf.bullet("A 'Ready' indicator confirms the model passed testing before exporting.")
pdf.h3("Tab 4 - Export GGUF")
pdf.bullet("Select the checkpoint, quantization (f16/f32/q4_0), architecture, and output file.")
pdf.bullet("Exports GGUF and reports the resulting file size.")

pdf.h2("5. Model Size Guide")
pdf.code("Preset   Params(approx)   Layers   Heads   d_model\n----     ------------      ------   -----   -------\ntiny     ~4M               4        4       256\nsmall    ~30M              6        8       512\nbase     ~180M             12       12      768\nmedium   ~700M             24       16      1024")
pdf.p("For 1M tokens: start with tiny or small. They train on a single consumer GPU (or CPU) in minutes to hours.")

pdf.h2("6. Project Structure")
pdf.code("mullm-0.1.0/\n|-- gui/                     # PyQt5 desktop app (dataset/train/eval/export tabs, workers, theme)\n|-- installer/\n|   |-- mullm.iss        # Inno Setup installer script\n|-- mullm/\n|   |-- __main__.py         # python -m mullm entry\n|   |-- cli/main.py         # mullm CLI (train/export/chat/gui)\n|   `-- core/\n|       |-- model/tiny_transformer.py   # TinyTransformer + presets\n|       |-- tokenizer/simple_tokenizer.py\n|       |-- trainer/simple_trainer.py   # SimpleTrainer + live callbacks\n|       |-- data/text_dataset.py\n|       |-- export/gguf_export.py\n|       |-- evaluation/simple_eval.py\n|       `-- (config, checkpoint, fine_tune, multimodal, reasoning, alignment, quantization, utils)\n|-- dist/                    # built wheel + sdist + installer output\n|-- tests/test_core.py       # 6 core tests\n|-- requirements.txt         # torch, numpy, tqdm, pyyaml\n|-- requirements-gui.txt     # PyQt5\n|-- pyproject.toml / setup.py\n`-- install.bat              # one-click venv installer")

pdf.h2("7. Testing")
pdf.code("pip install pytest\npython -m pytest tests\\test_core.py -v")
pdf.p("Verifies: transformer forward pass + loss, causal masking, tokenizer round-trip, dataset shapes, "
       "end-to-end training checkpoint save, and GGUF q4_0 export.")

pdf.h2("8. End-to-End Example")
pdf.h3("8.1 Prepare data (data.txt)")
pdf.code("The quick brown fox jumps over the lazy dog.\nLanguage models predict the next token.\nSmall models train fast on tiny data.\n")
pdf.h3("8.2 Train a tiny model")
pdf.code("mullm train --dataset data.txt --size tiny --epochs 5 --max-seq-length 64 --max-steps 100 --save-steps 25")
pdf.h3("8.3 Test it in the GUI or chat")
pdf.code("mullm chat --checkpoint outputs --tokenizer outputs\\tokenizer.json\n# or: mullm gui -> Test Model tab")
pdf.h3("8.4 Export to GGUF for llama.cpp")
pdf.code("mullm export --checkpoint outputs --gguf-type q4_0 --output-dir mymodel-q4.gguf")

pdf.h2("9. Troubleshooting")
pdf.h3("torch / PyQt5 DLL error on Windows")
pdf.p("If the GUI fails with 'WinError 1114 ... c10.dll', torch must load BEFORE PyQt5. All GUI modules already "
       "import torch first, so use the gui entry points (mullm gui, python -m gui.main). Avoid importing "
       "PyQt5 modules before torch in any custom scripts.")
pdf.h3("Slow q4_0 export on huge models")
pdf.p("The quantizer is vectorized and fast for the preset sizes (a few MB per second). For very large models "
       "prefer f16/f32 or use q4_0 on medium.")
pdf.h3("Training loss not decreasing")
pdf.bullet("Increase epochs or reduce max-steps early stop.")
pdf.bullet("Lower learning rate if loss oscillates; raise if it plateaus at high values.")
pdf.bullet("Add more data: tiny models need diversity even at 1M tokens.")
pdf.h3("Checkpoint not found during export")
pdf.p("Pass either the output directory (auto-finds checkpoint-final) or the full path to model.pt.")

pdf.h2("10. License")
pdf.p("Apache 2.0. Built by Udam.")

pdf.output("muLLM-User-Guide.pdf")
print("PDF written: muLLM-User-Guide.pdf")