from __future__ import annotations

import math
import warnings
from typing import List, Optional, Union

import torch
from torch.optim import Optimizer
from torch.optim.lr_scheduler import LRScheduler

from mullm.core.trainer.training_config import SchedulerConfig, SchedulerType


class WarmupLinear(LRScheduler):
    def __init__(
        self,
        optimizer: Optimizer,
        warmup_steps: int,
        num_training_steps: int,
        last_epoch: int = -1,
        verbose: bool = False,
    ) -> None:
        self.warmup_steps = warmup_steps
        self.num_training_steps = num_training_steps
        super().__init__(optimizer, last_epoch, verbose)

    def get_lr(self) -> List[float]:
        if self.last_epoch < self.warmup_steps:
            scale = float(self.last_epoch + 1) / float(max(1, self.warmup_steps))
        else:
            progress = float(self.last_epoch - self.warmup_steps) / float(
                max(1, self.num_training_steps - self.warmup_steps)
            )
            scale = max(0.0, 1.0 - progress)
        return [base_lr * scale for base_lr in self.base_lrs]

    def _compute_values(self) -> List[float]:
        return self.get_lr()


class WarmupCosine(LRScheduler):
    def __init__(
        self,
        optimizer: Optimizer,
        warmup_steps: int,
        num_training_steps: int,
        num_cycles: float = 0.5,
        last_epoch: int = -1,
        verbose: bool = False,
    ) -> None:
        self.warmup_steps = warmup_steps
        self.num_training_steps = num_training_steps
        self.num_cycles = num_cycles
        super().__init__(optimizer, last_epoch, verbose)

    def get_lr(self) -> List[float]:
        if self.last_epoch < self.warmup_steps:
            scale = float(self.last_epoch + 1) / float(max(1, self.warmup_steps))
        else:
            progress = float(self.last_epoch - self.warmup_steps) / float(
                max(1, self.num_training_steps - self.warmup_steps)
            )
            scale = max(0.0, math.cos(math.pi * self.num_cycles * progress * 2.0))
        return [base_lr * scale for base_lr in self.base_lrs]

    def _compute_values(self) -> List[float]:
        return self.get_lr()


class WarmupConstant(LRScheduler):
    def __init__(
        self,
        optimizer: Optimizer,
        warmup_steps: int,
        last_epoch: int = -1,
        verbose: bool = False,
    ) -> None:
        self.warmup_steps = warmup_steps
        super().__init__(optimizer, last_epoch, verbose)

    def get_lr(self) -> List[float]:
        if self.last_epoch < self.warmup_steps:
            scale = float(self.last_epoch + 1) / float(max(1, self.warmup_steps))
        else:
            scale = 1.0
        return [base_lr * scale for base_lr in self.base_lrs]

    def _compute_values(self) -> List[float]:
        return self.get_lr()


class CosineWithMinLR(LRScheduler):
    def __init__(
        self,
        optimizer: Optimizer,
        num_training_steps: int,
        min_lr_ratio: float = 0.0,
        num_cycles: float = 0.5,
        warmup_steps: int = 0,
        last_epoch: int = -1,
        verbose: bool = False,
    ) -> None:
        self.num_training_steps = num_training_steps
        self.min_lr_ratio = min_lr_ratio
        self.num_cycles = num_cycles
        self.warmup_steps = warmup_steps
        super().__init__(optimizer, last_epoch, verbose)

    def get_lr(self) -> List[float]:
        if self.last_epoch < self.warmup_steps:
            scale = float(self.last_epoch + 1) / float(max(1, self.warmup_steps))
            return [base_lr * scale for base_lr in self.base_lrs]

        progress = float(self.last_epoch - self.warmup_steps) / float(
            max(1, self.num_training_steps - self.warmup_steps)
        )
        cosine_decay = 0.5 * (1.0 + math.cos(math.pi * progress * 2.0 * self.num_cycles))
        scale = self.min_lr_ratio + (1.0 - self.min_lr_ratio) * cosine_decay
        return [base_lr * scale for base_lr in self.base_lrs]

    def _compute_values(self) -> List[float]:
        return self.get_lr()


class PolynomialDecay(LRScheduler):
    def __init__(
        self,
        optimizer: Optimizer,
        num_training_steps: int,
        lr_end: float = 0.0,
        power: float = 1.0,
        warmup_steps: int = 0,
        last_epoch: int = -1,
        verbose: bool = False,
    ) -> None:
        self.num_training_steps = num_training_steps
        self.lr_end = lr_end
        self.power = power
        self.warmup_steps = warmup_steps
        super().__init__(optimizer, last_epoch, verbose)

    def get_lr(self) -> List[float]:
        if self.last_epoch < self.warmup_steps:
            scale = float(self.last_epoch + 1) / float(max(1, self.warmup_steps))
            return [base_lr * scale for base_lr in self.base_lrs]

        progress = float(self.last_epoch - self.warmup_steps) / float(
            max(1, self.num_training_steps - self.warmup_steps)
        )
        progress = min(1.0, max(0.0, progress))
        scale = (1.0 - progress) ** self.power
        return [
            self.lr_end + (base_lr - self.lr_end) * scale for base_lr in self.base_lrs
        ]

    def _compute_values(self) -> List[float]:
        return self.get_lr()


def build_scheduler(
    optimizer: Optimizer,
    config: SchedulerConfig,
) -> LRScheduler:
    warmup_steps = config.warmup_steps
    if warmup_steps == 0 and config.warmup_ratio > 0.0:
        warmup_steps = int(config.num_training_steps * config.warmup_ratio)

    if config.scheduler_type == SchedulerType.warmup_linear:
        return WarmupLinear(optimizer, warmup_steps, config.num_training_steps)
    elif config.scheduler_type == SchedulerType.warmup_cosine:
        return WarmupCosine(
            optimizer, warmup_steps, config.num_training_steps, config.num_cycles
        )
    elif config.scheduler_type == SchedulerType.warmup_constant:
        return WarmupConstant(optimizer, warmup_steps)
    elif config.scheduler_type == SchedulerType.cosine_with_min_lr:
        return CosineWithMinLR(
            optimizer,
            config.num_training_steps,
            min_lr_ratio=config.min_lr_ratio,
            num_cycles=config.num_cycles,
            warmup_steps=warmup_steps,
        )
    elif config.scheduler_type == SchedulerType.polynomial_decay:
        return PolynomialDecay(
            optimizer,
            config.num_training_steps,
            lr_end=config.lr_end,
            power=config.polynomial_power,
            warmup_steps=warmup_steps,
        )
    else:
        raise ValueError(f"Unknown scheduler type: {config.scheduler_type}")
