"""JSON output mode for structured LLM output generation."""

from __future__ import annotations

import json
import math
import re
from collections import Counter
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Set, Tuple, Type, Union


class JSONValidationError(Exception):
    def __init__(self, message: str, path: Optional[str] = None) -> None:
        self.path = path
        super().__init__(f"[{path}] {message}" if path else message)


@dataclass
class ValidationResult:
    valid: bool
    errors: List[str] = field(default_factory=list)
    data: Optional[Any] = None

    def to_dict(self) -> Dict[str, Any]:
        return {"valid": self.valid, "errors": self.errors, "data": self.data}


class JSONValidator:
    def __init__(self, schema: Dict[str, Any]) -> None:
        self.schema = schema

    def validate(self, data: Any) -> ValidationResult:
        errors: List[str] = []
        try:
            self._validate_value(data, self.schema, "$")
        except JSONValidationError as e:
            errors.append(str(e))
        except Exception as e:
            errors.append(f"Unexpected error: {e}")
        return ValidationResult(valid=len(errors) == 0, errors=errors, data=data)

    def validate_string(self, json_str: str) -> ValidationResult:
        try:
            data = json.loads(json_str)
        except json.JSONDecodeError as e:
            return ValidationResult(valid=False, errors=[f"Invalid JSON: {e}"])
        return self.validate(data)

    def _validate_value(self, value: Any, schema: Dict[str, Any], path: str) -> None:
        schema_type = schema.get("type")

        if schema_type == "null" and value is not None:
            raise JSONValidationError(f"Expected null, got {type(value).__name__}", path)

        if "const" in schema and value != schema["const"]:
            raise JSONValidationError(
                f"Expected const {schema['const']!r}, got {value!r}", path
            )

        if "enum" in schema and value not in schema["enum"]:
            raise JSONValidationError(
                f"Value {value!r} not in enum {schema['enum']}", path
            )

        if value is None:
            if schema_type not in ("null", None):
                raise JSONValidationError(
                    f"Expected {schema_type}, got null", path
                )
            return

        if schema_type == "object":
            self._validate_object(value, schema, path)
        elif schema_type == "array":
            self._validate_array(value, schema, path)
        elif schema_type == "string":
            if not isinstance(value, str):
                raise JSONValidationError(
                    f"Expected string, got {type(value).__name__}", path
                )
            if "minLength" in schema and len(value) < schema["minLength"]:
                raise JSONValidationError(
                    f"String length {len(value)} < minLength {schema['minLength']}", path
                )
            if "maxLength" in schema and len(value) > schema["maxLength"]:
                raise JSONValidationError(
                    f"String length {len(value)} > maxLength {schema['maxLength']}", path
                )
            if "pattern" in schema and not re.match(schema["pattern"], value):
                raise JSONValidationError(
                    f"String '{value}' does not match pattern '{schema['pattern']}'", path
                )
        elif schema_type == "integer":
            if isinstance(value, bool) or not isinstance(value, int):
                raise JSONValidationError(
                    f"Expected integer, got {type(value).__name__}", path
                )
            if "minimum" in schema and value < schema["minimum"]:
                raise JSONValidationError(
                    f"Value {value} < minimum {schema['minimum']}", path
                )
            if "maximum" in schema and value > schema["maximum"]:
                raise JSONValidationError(
                    f"Value {value} > maximum {schema['maximum']}", path
                )
        elif schema_type == "number":
            if isinstance(value, bool) or not isinstance(value, (int, float)):
                raise JSONValidationError(
                    f"Expected number, got {type(value).__name__}", path
                )
            if "minimum" in schema and value < schema["minimum"]:
                raise JSONValidationError(
                    f"Value {value} < minimum {schema['minimum']}", path
                )
            if "maximum" in schema and value > schema["maximum"]:
                raise JSONValidationError(
                    f"Value {value} > maximum {schema['maximum']}", path
                )
        elif schema_type == "boolean":
            if not isinstance(value, bool):
                raise JSONValidationError(
                    f"Expected boolean, got {type(value).__name__}", path
                )
        elif schema_type == "array":
            self._validate_array(value, schema, path)
        else:
            if "properties" in schema:
                self._validate_object(value, schema, path)
            elif "items" in schema:
                self._validate_array(value, schema, path)

    def _validate_object(self, value: Any, schema: Dict[str, Any], path: str) -> None:
        if not isinstance(value, dict):
            raise JSONValidationError(
                f"Expected object, got {type(value).__name__}", path
            )

        required = schema.get("required", [])
        for prop in required:
            if prop not in value:
                raise JSONValidationError(f"Missing required property '{prop}'", path)

        properties = schema.get("properties", {})
        additional_props = schema.get("additionalProperties", True)
        for key, val in value.items():
            prop_path = f"{path}.{key}"
            if key in properties:
                self._validate_value(val, properties[key], prop_path)
            elif not additional_props:
                raise JSONValidationError(
                    f"Unexpected property '{key}'", path
                )

        if "minProperties" in schema and len(value) < schema["minProperties"]:
            raise JSONValidationError(
                f"Object has {len(value)} properties < min {schema['minProperties']}", path
            )
        if "maxProperties" in schema and len(value) > schema["maxProperties"]:
            raise JSONValidationError(
                f"Object has {len(value)} properties > max {schema['maxProperties']}", path
            )

    def _validate_array(self, value: Any, schema: Dict[str, Any], path: str) -> None:
        if not isinstance(value, list):
            raise JSONValidationError(
                f"Expected array, got {type(value).__name__}", path
            )

        if "minItems" in schema and len(value) < schema["minItems"]:
            raise JSONValidationError(
                f"Array has {len(value)} items < minItems {schema['minItems']}", path
            )
        if "maxItems" in schema and len(value) > schema["maxItems"]:
            raise JSONValidationError(
                f"Array has {len(value)} items > maxItems {schema['maxItems']}", path
            )

        items_schema = schema.get("items")
        if items_schema:
            if isinstance(items_schema, dict):
                for i, item in enumerate(value):
                    self._validate_value(item, items_schema, f"{path}[{i}]")
            elif isinstance(items_schema, list):
                for i, (item, item_schema) in enumerate(zip(value, items_schema)):
                    self._validate_value(item, item_schema, f"{path}[{i}]")
                if len(value) > len(items_schema):
                    for i in range(len(items_schema), len(value)):
                        extra_schema = items_schema[-1] if items_schema else {}
                        self._validate_value(value[i], extra_schema, f"{path}[{i}]")

        if "uniqueItems" in schema and schema["uniqueItems"]:
            seen = [json.dumps(v, sort_keys=True) for v in value]
            if len(seen) != len(set(seen)):
                raise JSONValidationError("Array items are not unique", path)

    @staticmethod
    def is_json_compatible(value: Any) -> bool:
        if value is None or isinstance(value, (bool, int, float, str)):
            return True
        if isinstance(value, (list, tuple)):
            return all(JSONValidator.is_json_compatible(v) for v in value)
        if isinstance(value, dict):
            return all(
                isinstance(k, str) and JSONValidator.is_json_compatible(v)
                for k, v in value.items()
            )
        return False


class JSONParser:
    JSON_BLOCK_RE = re.compile(
        r'```(?:json)?\s*\n?(.*?)```', re.DOTALL
    )
    JSON_OBJECT_RE = re.compile(
        r'\{(?:[^{}]|(?:\{[^{}]*\}))*\}', re.DOTALL
    )
    JSON_ARRAY_RE = re.compile(
        r'\[(?:[^\[\]]|(?:\[[^\[\]]*\]))*\]', re.DOTALL
    )

    def __init__(self, strict: bool = False) -> None:
        self.strict = strict

    def extract(self, text: str) -> Optional[Any]:
        blocks = self.JSON_BLOCK_RE.findall(text)
        for block in blocks:
            try:
                return json.loads(block.strip())
            except json.JSONDecodeError:
                continue

        for pattern in (self.JSON_OBJECT_RE, self.JSON_ARRAY_RE):
            for match in pattern.finditer(text):
                try:
                    return json.loads(match.group())
                except json.JSONDecodeError:
                    continue

        stripped = text.strip()
        try:
            return json.loads(stripped)
        except json.JSONDecodeError:
            pass

        return None

    def extract_all(self, text: str) -> List[Any]:
        results: List[Any] = []
        seen: Set[str] = set()

        blocks = self.JSON_BLOCK_RE.findall(text)
        for block in blocks:
            try:
                parsed = json.loads(block.strip())
                key = json.dumps(parsed, sort_keys=True)
                if key not in seen:
                    seen.add(key)
                    results.append(parsed)
            except json.JSONDecodeError:
                pass

        for pattern in (self.JSON_OBJECT_RE, self.JSON_ARRAY_RE):
            for match in pattern.finditer(text):
                try:
                    parsed = json.loads(match.group())
                    key = json.dumps(parsed, sort_keys=True)
                    if key not in seen:
                        seen.add(key)
                        results.append(parsed)
                except json.JSONDecodeError:
                    pass

        return results

    def extract_schema_aware(
        self, text: str, schema: Dict[str, Any]
    ) -> Optional[Any]:
        data = self.extract(text)
        if data is None:
            return None
        validator = JSONValidator(schema)
        result = validator.validate(data)
        if result.valid:
            return data
        return None

    def safe_extract(self, text: str, schema: Optional[Dict[str, Any]] = None) -> Tuple[Optional[Any], List[str]]:
        errors: List[str] = []
        data = self.extract(text)
        if data is None:
            errors.append("No JSON content found in text")
            return None, errors
        if schema:
            validator = JSONValidator(schema)
            validation = validator.validate(data)
            if not validation.valid:
                errors.extend(validation.errors)
                return None, errors
        return data, errors


class SchemaGenerator:
    def __init__(self, infer_required: bool = True, sample_count: int = 5) -> None:
        self.infer_required = infer_required
        self.sample_count = sample_count

    def from_examples(self, examples: List[Any]) -> Dict[str, Any]:
        if not examples:
            return {}
        return self._infer_schema(examples[0], examples)

    def _infer_schema(self, example: Any, all_examples: List[Any]) -> Dict[str, Any]:
        if example is None:
            return {"type": "null"}
        if isinstance(example, bool):
            return {"type": "boolean"}
        if isinstance(example, int):
            return {"type": "integer"}
        if isinstance(example, float):
            return {"type": "number"}
        if isinstance(example, str):
            schema: Dict[str, Any] = {"type": "string"}
            lengths = [len(e) for e in all_examples if isinstance(e, str)]
            if lengths:
                schema["minLength"] = min(lengths)
                schema["maxLength"] = max(lengths)
            return schema
        if isinstance(example, list):
            items_schemas = []
            for e in all_examples:
                if isinstance(e, list) and e:
                    items_schemas.append(self._infer_schema(e[0], [item for ex in all_examples if isinstance(ex, list) for item in ex]))
            merged = self._merge_schemas(items_schemas) if items_schemas else {}
            return {"type": "array", "items": merged, "minItems": min((len(e) for e in all_examples if isinstance(e, list)), default=0)}
        if isinstance(example, dict):
            all_keys: Set[str] = set()
            for e in all_examples:
                if isinstance(e, dict):
                    all_keys.update(e.keys())
            properties: Dict[str, Any] = {}
            for key in sorted(all_keys):
                values = [e[key] for e in all_examples if isinstance(e, dict) and key in e]
                if values:
                    properties[key] = self._infer_schema(values[0], values)
            schema: Dict[str, Any] = {"type": "object", "properties": properties}
            if self.infer_required:
                required = []
                for key in all_keys:
                    if all(key in e for e in all_examples if isinstance(e, dict)):
                        required.append(key)
                if required:
                    schema["required"] = required
            return schema
        return {"type": "string"}

    def _merge_schemas(self, schemas: List[Dict[str, Any]]) -> Dict[str, Any]:
        if not schemas:
            return {}
        if len(schemas) == 1:
            return schemas[0]
        type_set: Set[str] = set()
        for s in schemas:
            t = s.get("type")
            if isinstance(t, str):
                type_set.add(t)
        if len(type_set) == 1:
            merged = dict(schemas[0])
            for s in schemas[1:]:
                for key in s:
                    if key not in merged:
                        merged[key] = s[key]
                    elif key in ("minLength", "minItems", "minimum"):
                        merged[key] = min(merged[key], s[key])
                    elif key in ("maxLength", "maxItems", "maximum"):
                        merged[key] = max(merged[key], s[key])
            return merged
        return {"anyOf": schemas}

    def from_type(
        self,
        type_hint: Type[Any],
        description: Optional[str] = None,
    ) -> Dict[str, Any]:
        import typing
        origin = getattr(type_hint, "__origin__", None)
        args = getattr(type_hint, "__args__", ())

        if origin is list:
            item_schema = self.from_type(args[0]) if args else {"type": "string"}
            return {"type": "array", "items": item_schema}
        if origin is dict:
            return {"type": "object"}
        if origin is Union or origin is Optional:
            non_none = [a for a in args if a is not type(None)]
            if len(non_none) == 1:
                return self.from_type(non_none[0])
            return {"anyOf": [self.from_type(a) for a in non_none]} if non_none else {}
        if type_hint is str:
            return {"type": "string", "description": description or ""}
        if type_hint is int:
            return {"type": "integer", "description": description or ""}
        if type_hint is float:
            return {"type": "number", "description": description or ""}
        if type_hint is bool:
            return {"type": "boolean", "description": description or ""}
        if type_hint is bytes:
            return {"type": "string", "contentEncoding": "base64"}
        if type_hint is Any:
            return {}
        try:
            if hasattr(type_hint, "__annotations__"):
                properties: Dict[str, Any] = {}
                required: List[str] = []
                for field_name, field_type in type_hint.__annotations__.items():
                    properties[field_name] = self.from_type(field_type, field_name)
                    required.append(field_name)
                return {"type": "object", "properties": properties, "required": required}
        except Exception:
            pass
        return {"type": "string"}


class JSONRepairer:
    COMMON_ERRORS = [
        (r"'([^']*?)'", r'"\1"'),
        (r",\s*([}\]])", r"\1"),
        (r"(?<=[{,])\s*,", ""),
        (r"(?<!\\)'", '"'),
    ]

    TRAILING_COMMA_RE = re.compile(r",\s*([}\]])")
    SINGLE_QUOTE_RE = re.compile(r"(?<!\\)'")
    COMMA_BEFORE_CLOSE_RE = re.compile(r",\s*[}\]]")
    MISSING_QUOTE_KEY_RE = re.compile(r"([\{,]\s*)([a-zA-Z_][a-zA-Z0-9_]*)\s*:")

    def repair(self, text: str) -> str:
        text = text.strip()
        if not text:
            return text

        repaired = text
        repaired = self.TRAILING_COMMA_RE.sub(r"\1", repaired)
        repaired = self.COMMA_BEFORE_CLOSE_RE.sub("", repaired)
        repaired = self.MISSING_QUOTE_KEY_RE.sub(r'\1"\2":', repaired)

        repaired = repaired.replace("'", '"')

        repaired = repaired.replace("True", "true").replace("False", "false").replace("None", "null")

        repaired = re.sub(r",\s*}", "}", repaired)
        repaired = re.sub(r",\s*]", "]", repaired)

        repaired = re.sub(r'(?<!")\b(true|false|null)\b(?!")', lambda m: m.group(1), repaired)

        try:
            json.loads(repaired)
            return repaired
        except json.JSONDecodeError:
            pass

        repaired = self._fix_unquoted_strings(repaired)

        try:
            json.loads(repaired)
            return repaired
        except json.JSONDecodeError:
            pass

        repaired = self._fix_newlines_in_strings(repaired)
        return repaired

    def repair_and_parse(self, text: str) -> Optional[Any]:
        repaired = self.repair(text)
        try:
            return json.loads(repaired)
        except json.JSONDecodeError:
            return None

    def _fix_unquoted_strings(self, text: str) -> str:
        return re.sub(
            r':\s*([a-zA-Z_][a-zA-Z0-9_.]*)\s*([,\}\]])',
            r': "\1"\2',
            text,
        )

    def _fix_newlines_in_strings(self, text: str) -> str:
        result = []
        in_string = False
        escaped = False
        for ch in text:
            if ch == '"' and not escaped:
                in_string = not in_string
            if in_string and ch == '\n':
                result.append('\\n')
            else:
                result.append(ch)
            if ch == '\\' and not escaped:
                escaped = True
            else:
                escaped = False
        return ''.join(result)


class ConstrainedGenerator:
    def __init__(
        self,
        schema: Dict[str, Any],
        tokenizer: Optional[Any] = None,
    ) -> None:
        self.schema = schema
        self.tokenizer = tokenizer
        self._allowed_token_ids: Optional[Set[int]] = None

    def get_allowed_token_ids(self) -> Set[int]:
        if self._allowed_token_ids is not None:
            return self._allowed_token_ids
        if self.tokenizer is None:
            return set()
        structural_tokens = self._get_structural_tokens()
        self._allowed_token_ids = structural_tokens
        return self._allowed_token_ids

    def _get_structural_tokens(self) -> Set[int]:
        tokens: Set[int] = set()
        if self.tokenizer is None:
            return tokens
        structural_chars = set('{}[]:,\"truefalsnul0123456789.-eE ')
        for char in structural_chars:
            ids = self.tokenizer.encode(char, add_special_tokens=False)
            tokens.update(ids)
        whitespace_id = self.tokenizer.encode(" ", add_special_tokens=False)
        tokens.update(whitespace_id)
        return tokens

    def get_prefix_allowed_tokens_fn(self):
        def prefix_allowed_tokens_fn(batch_id: int, input_ids: List[int]) -> List[int]:
            allowed = self.get_allowed_token_ids()
            return list(allowed) if allowed else []
        return prefix_allowed_tokens_fn

    def create_grammar(self) -> str:
        return json.dumps(self.schema, indent=2)


@dataclass
class StructuredOutputWrapper:
    schema: Dict[str, Any]
    parser: JSONParser = field(default_factory=lambda: JSONParser(strict=True))
    validator: Optional[JSONValidator] = None
    repairer: JSONRepairer = field(default_factory=JSONRepairer)
    max_repair_attempts: int = 3

    def __post_init__(self) -> None:
        if self.validator is None:
            self.validator = JSONValidator(self.schema)

    def wrap_prompt(self, prompt: str) -> str:
        schema_str = json.dumps(self.schema, indent=2)
        return (
            f"{prompt}\n\n"
            f"Respond with valid JSON matching this schema:\n"
            f"```json\n{schema_str}\n```\n"
            f"Output ONLY valid JSON, no other text."
        )

    def parse_output(self, text: str) -> Tuple[Optional[Any], List[str]]:
        data, errors = self.parser.safe_extract(text, self.schema)
        if data is not None:
            return data, errors

        current = text
        for attempt in range(self.max_repair_attempts):
            repaired = self.repairer.repair(current)
            if repaired == current:
                break
            data, errors = self.parser.safe_extract(repaired, self.schema)
            if data is not None:
                return data, errors
            current = repaired

        return None, errors or ["Failed to parse output after repair"]

    def validate_output(self, data: Any) -> ValidationResult:
        if self.validator:
            return self.validator.validate(data)
        return ValidationResult(valid=True, data=data)
