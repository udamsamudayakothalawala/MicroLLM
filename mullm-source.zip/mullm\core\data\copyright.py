"""Copyright detection, watermark detection, and licensed content filtering."""

from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field
from typing import Optional

logger = logging.getLogger(__name__)


@dataclass
class CopyrightConfig:
    """Configuration for copyright filtering."""

    detect_copyright_notices: bool = True
    detect_watermarks: bool = True
    detect_license_headers: bool = True
    block_copyrighted: bool = False
    allowed_licenses: tuple[str, ...] = (
        "MIT", "Apache-2.0", "BSD-2-Clause", "BSD-3-Clause",
        "CC0-1.0", "CC-BY-4.0", "CC-BY-SA-4.0", "ISC",
        "GPL-2.0", "GPL-3.0", "LGPL-2.1", "LGPL-3.0",
        "MPL-2.0", "Unlicense",
    )
    min_copyright_confidence: float = 0.7
    track_source: bool = True
    custom_blacklisted_phrases: tuple[str, ...] = ()
    dmca_compliance: bool = True


@dataclass
class CopyrightDetection:
    """A detected copyright notice."""

    notice_type: str
    value: str
    start: int
    end: int
    copyright_holder: Optional[str] = None
    year: Optional[str] = None
    license_type: Optional[str] = None
    confidence: float = 0.0
    is_allowed: bool = True


@dataclass
class CopyrightResult:
    """Result of copyright analysis."""

    has_copyright: bool
    detections: list[CopyrightDetection]
    detected_licenses: list[str]
    blocked: bool
    source_info: dict[str, str] = field(default_factory=dict)


class CopyrightDetector:
    """Detects copyright notices in text."""

    COPYRIGHT_PATTERNS: tuple[re.Pattern, ...] = (
        re.compile(
            r"(?:copyright|©|\(c\))\s*(?:\d{4}(?:\s*[-–]\s*\d{4})?)?\s*(?:by\s+)?(.+?)(?:\.|$)",
            re.IGNORECASE | re.MULTILINE,
        ),
        re.compile(
            r"all\s+rights\s+reserved",
            re.IGNORECASE,
        ),
        re.compile(
            r"(?:copyright|©)\s*(?:\d{4})?",
            re.IGNORECASE,
        ),
    )

    YEAR_PATTERN = re.compile(r"\b(19|20)\d{2}\b")

    def detect(self, text: str) -> list[CopyrightDetection]:
        detections: list[CopyrightDetection] = []

        for pattern in self.COPYRIGHT_PATTERNS:
            for match in pattern.finditer(text):
                groups = match.groups()
                holder = groups[0].strip() if groups else ""

                year_match = self.YEAR_PATTERN.search(match.group())
                year = year_match.group() if year_match else None

                holder = re.sub(r"\s+", " ", holder).strip(".,;:")

                detections.append(CopyrightDetection(
                    notice_type="copyright",
                    value=match.group().strip(),
                    start=match.start(),
                    end=match.end(),
                    copyright_holder=holder if holder else None,
                    year=year,
                    confidence=0.85,
                ))

        return detections


class WatermarkDetector:
    """Detects watermarks and hidden copyright markers."""

    INVISIBLE_PATTERN = re.compile(r"[\u200b-\u200f\u2028-\u202f\u2060-\u2069\ufeff]+")

    TEXT_WATERMARK_PATTERNS: tuple[re.Pattern, ...] = (
        re.compile(r"\bwatermark\b", re.IGNORECASE),
        re.compile(r"\bdo\s+not\s+copy\b", re.IGNORECASE),
        re.compile(r"\bfor\s+(?:internal|authorized)\s+(?:use|personnel)\s+only\b", re.IGNORECASE),
        re.compile(r"\b(?:confidential|proprietary|trade\s+secret)\b", re.IGNORECASE),
        re.compile(r"\blicensed\s+(?:to|for)\s+(?:use\s+by)?\s*(.+?)(?:\.|;|$)", re.IGNORECASE),
    )

    def detect(self, text: str) -> list[CopyrightDetection]:
        detections: list[CopyrightDetection] = []

        invisible = self.INVISIBLE_PATTERN.findall(text)
        if invisible and len(invisible) > 5:
            detections.append(CopyrightDetection(
                notice_type="invisible_watermark",
                value=f"Found {len(invisible)} invisible characters",
                start=0,
                end=0,
                confidence=0.7,
            ))

        for pattern in self.TEXT_WATERMARK_PATTERNS:
            for match in pattern.finditer(text):
                detections.append(CopyrightDetection(
                    notice_type="text_watermark",
                    value=match.group().strip(),
                    start=match.start(),
                    end=match.end(),
                    confidence=0.8,
                ))

        return detections


class LicenseDetector:
    """Detects software licenses and open-source licenses."""

    LICENSE_PATTERNS: dict[str, re.Pattern] = {
        "MIT": re.compile(r"\bMIT\s+License\b", re.IGNORECASE),
        "Apache-2.0": re.compile(r"\bApache(?:\s+License)?(?:\s*,?\s*(?:Version\s*)?2\.0)?\b", re.IGNORECASE),
        "BSD-2-Clause": re.compile(r"\bBSD[-\s]2[-\s]Clause\b", re.IGNORECASE),
        "BSD-3-Clause": re.compile(r"\bBSD[-\s]3[-\s]Clause\b", re.IGNORECASE),
        "GPL-2.0": re.compile(r"\bGPL(?:\s*[-v]?\s*2(?:\.0)?)?\b", re.IGNORECASE),
        "GPL-3.0": re.compile(r"\bGPL(?:\s*[-v]?\s*3(?:\.0)?)?\b", re.IGNORECASE),
        "LGPL-2.1": re.compile(r"\bLGPL(?:\s*[-v]?\s*2\.1)?\b", re.IGNORECASE),
        "LGPL-3.0": re.compile(r"\bLGPL(?:\s*[-v]?\s*3(?:\.0)?)?\b", re.IGNORECASE),
        "MPL-2.0": re.compile(r"\bMPL(?:\s*[-v]?\s*2\.0)?\b", re.IGNORECASE),
        "CC-BY-4.0": re.compile(r"\bCC[-\s]BY(?:[-\s]4\.0)?\b", re.IGNORECASE),
        "CC-BY-SA-4.0": re.compile(r"\bCC[-\s]BY[-\s]SA(?:[-\s]4\.0)?\b", re.IGNORECASE),
        "CC0-1.0": re.compile(r"\bCC0(?:[-\s]1\.0)?\b", re.IGNORECASE),
        "Unlicense": re.compile(r"\bUnlicense\b", re.IGNORECASE),
        "ISC": re.compile(r"\bISC\s+License\b", re.IGNORECASE),
    }

    LICENSE_HEADER_PATTERNS: tuple[re.Pattern, ...] = (
        re.compile(r"Permission\s+is\s+hereby\s+granted.*?to\s+use.*?(?:without\s+restriction|subject\s+to)", re.DOTALL | re.IGNORECASE),
        re.compile(r"Licensed\s+under\s+the\s+(.+?)\s+(?:License|version)", re.IGNORECASE),
    )

    def detect(self, text: str) -> tuple[list[str], list[CopyrightDetection]]:
        detected_licenses: list[str] = []
        detections: list[CopyrightDetection] = []

        for license_name, pattern in self.LICENSE_PATTERNS.items():
            for match in pattern.finditer(text):
                if license_name not in detected_licenses:
                    detected_licenses.append(license_name)
                detections.append(CopyrightDetection(
                    notice_type="license",
                    value=match.group().strip(),
                    start=match.start(),
                    end=match.end(),
                    license_type=license_name,
                    confidence=0.9,
                ))

        for pattern in self.LICENSE_HEADER_PATTERNS:
            for match in pattern.finditer(text):
                full = match.group().strip()
                if "GPL" in full:
                    lic = "GPL"
                elif "Apache" in full:
                    lic = "Apache-2.0"
                elif "MIT" in full:
                    lic = "MIT"
                elif "BSD" in full:
                    lic = "BSD"
                else:
                    lic = "Unknown"

                detections.append(CopyrightDetection(
                    notice_type="license_header",
                    value=full[:200],
                    start=match.start(),
                    end=min(match.end(), match.start() + 200),
                    license_type=lic,
                    confidence=0.8,
                ))

        return detected_licenses, detections


class SourceTracker:
    """Tracks content source for attribution."""

    def __init__(self) -> None:
        self._sources: dict[str, dict[str, str]] = {}

    def register(self, content_id: str, source_url: str = "", author: str = "", license_type: str = "") -> None:
        self._sources[content_id] = {
            "url": source_url,
            "author": author,
            "license": license_type,
        }

    def get_source(self, content_id: str) -> dict[str, str]:
        return self._sources.get(content_id, {})

    def get_all_sources(self) -> dict[str, dict[str, str]]:
        return dict(self._sources)

    def has_source(self, content_id: str) -> bool:
        return content_id in self._sources


class CopyrightFilter:
    """Unified copyright detection and filtering."""

    def __init__(self, config: Optional[CopyrightConfig] = None) -> None:
        self.config = config or CopyrightConfig()
        self._copyright_detector = CopyrightDetector()
        self._watermark_detector = WatermarkDetector()
        self._license_detector = LicenseDetector()
        self._source_tracker = SourceTracker()

    def analyze(self, text: str, content_id: Optional[str] = None) -> CopyrightResult:
        all_detections: list[CopyrightDetection] = []
        detected_licenses: list[str] = []

        if self.config.detect_copyright_notices:
            copyright_detections = self._copyright_detector.detect(text)
            all_detections.extend(copyright_detections)

        if self.config.detect_watermarks:
            watermark_detections = self._watermark_detector.detect(text)
            all_detections.extend(watermark_detections)

        if self.config.detect_license_headers:
            licenses, license_detections = self._license_detector.detect(text)
            detected_licenses.extend(licenses)
            all_detections.extend(license_detections)

        for phrase in self.config.custom_blacklisted_phrases:
            for match in re.finditer(re.escape(phrase), text, re.IGNORECASE):
                all_detections.append(CopyrightDetection(
                    notice_type="blacklisted_phrase",
                    value=match.group(),
                    start=match.start(),
                    end=match.end(),
                    confidence=0.95,
                    is_allowed=False,
                ))

        if self.config.track_source and content_id:
            source = self._source_tracker.get_source(content_id)
            source_info = {
                "has_copyright": str(any(
                    d.notice_type == "copyright" for d in all_detections
                )),
                "licenses": ",".join(detected_licenses) if detected_licenses else "none",
            }
            source_info.update(source)
        else:
            source_info = {}

        has_copyright = len(all_detections) > 0
        blocked = False
        if self.config.block_copyrighted and has_copyright:
            non_allowed = [
                d for d in all_detections
                if d.notice_type in ("copyright", "text_watermark", "invisible_watermark", "blacklisted_phrase")
            ]
            blocked = len(non_allowed) > 0

        if self.config.dmca_compliance:
            for d in all_detections:
                if d.notice_type == "copyright" and not d.is_allowed:
                    blocked = True
                    break

        return CopyrightResult(
            has_copyright=has_copyright,
            detections=all_detections,
            detected_licenses=detected_licenses,
            blocked=blocked,
            source_info=source_info,
        )

    def filter_texts(self, texts: list[str]) -> list[tuple[str, CopyrightResult]]:
        allowed: list[tuple[str, CopyrightResult]] = []
        for text in texts:
            result = self.analyze(text)
            if not result.blocked:
                allowed.append((text, result))
        return allowed

    def is_allowed(self, text: str) -> bool:
        result = self.analyze(text)
        return not result.blocked

    def register_source(self, content_id: str, source_url: str = "", author: str = "", license_type: str = "") -> None:
        self._source_tracker.register(content_id, source_url, author, license_type)

    def get_source_info(self, content_id: str) -> dict[str, str]:
        return self._source_tracker.get_source(content_id)
