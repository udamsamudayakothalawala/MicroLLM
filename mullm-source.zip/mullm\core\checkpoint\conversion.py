from __future__ import annotations

import copy
import json
import logging
import os
import shutil
import struct
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple, Union

import torch
import torch.nn as nn

logger = logging.getLogger(__name__)


class ConversionFormat(Enum):
    PYTORCH = "pytorch"
    SAFETENSORS = "safetensors"
    ONNX = "onnx"
    GGUF = "gguf"
    TENSORRT = "tensorrt"
    HUGGINGFACE = "huggingface"


class QuantizationMethod(Enum):
    NONE = "none"
    GPTQ = "gptq"
    AWQ = "awq"
    SMOOTH_QUANT = "smooth_quant"
    DYNAMIC = "dynamic"


@dataclass
class QuantizationConfig:
    method: QuantizationMethod = QuantizationMethod.NONE
    bits: int = 16
    group_size: int = 128
    symmetric: bool = True
    clamp_threshold: float = 0.0
    calibration_samples: int = 128

    def validate(self) -> None:
        if self.method != QuantizationMethod.NONE and self.bits not in (2, 3, 4, 8):
            raise ValueError(f"Unsupported quantization bits: {self.bits}")
        if self.bits < 2 or self.bits > 16:
            raise ValueError(f"Bits must be between 2 and 16, got {self.bits}")
        if self.group_size < 1:
            raise ValueError(f"group_size must be >= 1, got {self.group_size}")


@dataclass
class ConversionConfig:
    source_format: ConversionFormat = ConversionFormat.PYTORCH
    target_format: ConversionFormat = ConversionFormat.SAFETENSORS
    quantization: QuantizationConfig = field(default_factory=QuantizationConfig)
    max_shard_size_bytes: int = 5 * 1024 * 1024 * 1024
    dtype: Optional[torch.dtype] = None
    preserve_metadata: bool = True
    validate_output: bool = True
    hf_model_type: str = "AutoModelForCausalLM"
    hf_revision: Optional[str] = None
    onnx_opset_version: int = 14
    onnx_dynamic_axes: Optional[Dict[str, Dict[int, str]]] = None
    tensorrt_max_batch_size: int = 1
    tensorrt_max_workspace_size: int = 1 << 30
    tensorrt_fp16: bool = True


@dataclass
class ConversionResult:
    success: bool
    output_path: Path
    format: ConversionFormat
    size_bytes: int = 0
    shard_count: int = 0
    warnings: List[str] = field(default_factory=list)
    errors: List[str] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)


class CheckpointConverter:
    def __init__(self, config: Optional[ConversionConfig] = None) -> None:
        self.config = config or ConversionConfig()

    def convert(
        self,
        source_path: Union[str, Path],
        output_path: Union[str, Path],
        model: Optional[nn.Module] = None,
    ) -> ConversionResult:
        source_path = Path(source_path)
        output_path = Path(output_path)
        output_path.mkdir(parents=True, exist_ok=True)
        converter_map = {
            (ConversionFormat.PYTORCH, ConversionFormat.SAFETENSORS): self._pytorch_to_safetensors,
            (ConversionFormat.PYTORCH, ConversionFormat.ONNX): self._pytorch_to_onnx,
            (ConversionFormat.PYTORCH, ConversionFormat.GGUF): self._pytorch_to_gguf,
            (ConversionFormat.PYTORCH, ConversionFormat.TENSORRT): self._pytorch_to_tensorrt,
            (ConversionFormat.PYTORCH, ConversionFormat.HUGGINGFACE): self._pytorch_to_huggingface,
            (ConversionFormat.SAFETENSORS, ConversionFormat.PYTORCH): self._safetensors_to_pytorch,
            (ConversionFormat.HUGGINGFACE, ConversionFormat.PYTORCH): self._huggingface_to_pytorch,
            (ConversionFormat.PYTORCH, ConversionFormat.PYTORCH): self._pytorch_to_pytorch,
        }
        key = (self.config.source_format, self.config.target_format)
        if key not in converter_map:
            return ConversionResult(
                success=False,
                output_path=output_path,
                format=self.config.target_format,
                errors=[f"Unsupported conversion: {key[0].value} -> {key[1].value}"],
            )
        try:
            result = converter_map[key](source_path, output_path, model)
            if self.config.validate_output:
                self._validate_output(result)
            return result
        except Exception as e:
            logger.error("Conversion failed: %s", e)
            return ConversionResult(
                success=False,
                output_path=output_path,
                format=self.config.target_format,
                errors=[str(e)],
            )

    def _pytorch_to_safetensors(
        self,
        source_path: Path,
        output_path: Path,
        model: Optional[nn.Module],
    ) -> ConversionResult:
        state_dict = self._load_state_dict(source_path)
        if model is not None:
            state_dict = self._apply_quantization(state_dict)
        if self.config.dtype is not None:
            state_dict = {k: v.to(self.config.dtype) for k, v in state_dict.items()}
        try:
            from safetensors.torch import save_file
        except ImportError:
            logger.warning("safetensors not available, falling back to manual safetensors writing")
            self._write_safetensors_manual(state_dict, output_path / "model.safetensors")
            return ConversionResult(
                success=True,
                output_path=output_path / "model.safetensors",
                format=ConversionFormat.SAFETENSORS,
                size_bytes=(output_path / "model.safetensors").stat().st_size,
            )
        total_size = sum(p.numel() * p.element_size() for p in state_dict.values())
        if total_size > self.config.max_shard_size_bytes:
            return self._sharded_safetensors(state_dict, output_path)
        target_file = output_path / "model.safetensors"
        metadata = {k: {"dtype": str(v.dtype), "shape": list(v.shape)} for k, v in state_dict.items()}
        save_file(state_dict, str(target_file), metadata=metadata)
        return ConversionResult(
            success=True,
            output_path=target_file,
            format=ConversionFormat.SAFETENSORS,
            size_bytes=target_file.stat().st_size,
            metadata=metadata,
        )

    def _write_safetensors_manual(
        self,
        state_dict: Dict[str, torch.Tensor],
        output_path: Path,
    ) -> None:
        tensors_data: Dict[str, Tuple[torch.Tensor, int, int]] = {}
        offset = 0
        for name, tensor in state_dict.items():
            tensor_bytes = tensor.numel() * tensor.element_size()
            tensors_data[name] = (tensor, offset, tensor_bytes)
            offset += tensor_bytes
        header: Dict[str, Any] = {}
        for name, (tensor, start, size) in tensors_data.items():
            dtype_map = {
                torch.float32: 0,
                torch.float16: 1,
                torch.bfloat16: 3,
                torch.int32: 6,
                torch.int64: 7,
                torch.int8: 5,
                torch.uint8: 8,
                torch.bool: 9,
            }
            dtype_id = dtype_map.get(tensor.dtype, 0)
            header[name] = {
                "dtype": dtype_id,
                "shape": list(tensor.shape),
                "data_offsets": [start, start + size],
            }
        header_json = json.dumps(header).encode("utf-8")
        header_len = len(header_json)
        with open(output_path, "wb") as f:
            f.write(struct.pack("<Q", header_len))
            f.write(header_json)
            for name, (tensor, _, _) in tensors_data.items():
                f.write(tensor.numpy().tobytes())

    def _sharded_safetensors(
        self,
        state_dict: Dict[str, torch.Tensor],
        output_path: Path,
    ) -> ConversionResult:
        try:
            from safetensors.torch import save_file
        except ImportError:
            items = list(state_dict.items())
            shard_size = max(1, (len(items) + 1) // 2)
            shard_files = []
            for i in range(0, len(items), shard_size):
                shard_items = items[i:i + shard_size]
                shard_dict = dict(shard_items)
                shard_idx = i // shard_size
                shard_path = output_path / f"model-{shard_idx:05d}-of-00002.safetensors"
                self._write_safetensors_manual(shard_dict, shard_path)
                shard_files.append(shard_path.name)
            shard_count = len(shard_files)
            return ConversionResult(
                success=True,
                output_path=output_path,
                format=ConversionFormat.SAFETENSORS,
                size_bytes=sum(f.stat().st_size for f in [output_path / s for s in shard_files]),
                shard_count=shard_count,
            )
        items = list(state_dict.items())
        shard_size = max(1, (len(items) + 1) // 2)
        shard_files: List[str] = []
        for i in range(0, len(items), shard_size):
            shard_items = items[i:i + shard_size]
            shard_dict = dict(shard_items)
            shard_idx = i // shard_size
            shard_path = output_path / f"model-{shard_idx:05d}-of-00002.safetensors"
            save_file(shard_dict, str(shard_path))
            shard_files.append(shard_path.name)
        metadata = {
            "shard_files": shard_files,
            "total_shards": len(shard_files),
            "total_params": len(state_dict),
        }
        with open(output_path / "metadata.json", "w") as f:
            json.dump(metadata, f, indent=2)
        shard_count = len(shard_files)
        total_size = sum((output_path / s).stat().st_size for s in shard_files)
        return ConversionResult(
            success=True,
            output_path=output_path,
            format=ConversionFormat.SAFETENSORS,
            size_bytes=total_size,
            shard_count=shard_count,
            metadata=metadata,
        )

    def _pytorch_to_onnx(
        self,
        source_path: Path,
        output_path: Path,
        model: Optional[nn.Module],
    ) -> ConversionResult:
        if model is None:
            raise ValueError("Model must be provided for ONNX conversion")
        state_dict = self._load_state_dict(source_path)
        model.load_state_dict(state_dict, strict=False)
        model.eval()
        dummy_input = torch.randn(1, 512, dtype=torch.long)
        onnx_path = output_path / "model.onnx"
        try:
            torch.onnx.export(
                model,
                dummy_input,
                str(onnx_path),
                opset_version=self.config.onnx_opset_version,
                input_names=["input_ids"],
                output_names=["logits"],
                dynamic_axes=self.config.onnx_dynamic_axes or {
                    "input_ids": {0: "batch_size", 1: "sequence_length"},
                    "logits": {0: "batch_size", 1: "sequence_length"},
                },
            )
        except Exception as e:
            logger.error("ONNX export failed: %s", e)
            raise
        size_bytes = onnx_path.stat().st_size
        return ConversionResult(
            success=True,
            output_path=onnx_path,
            format=ConversionFormat.ONNX,
            size_bytes=size_bytes,
        )

    def _pytorch_to_gguf(
        self,
        source_path: Path,
        output_path: Path,
        model: Optional[nn.Module],
    ) -> ConversionResult:
        state_dict = self._load_state_dict(source_path)
        gguf_path = output_path / "model.gguf"
        metadata = {
            "format": "gguf",
            "quantization": self.config.quantization.method.value,
            "bits": self.config.quantization.bits,
            "num_tensors": len(state_dict),
            "tensor_names": list(state_dict.keys()),
        }
        for name, tensor in state_dict.items():
            metadata[f"tensor_{name}_dtype"] = str(tensor.dtype)
            metadata[f"tensor_{name}_shape"] = list(tensor.shape)
        with open(gguf_path, "wb") as f:
            magic = b"GGUF"
            f.write(magic)
            version = 3
            f.write(struct.pack("<I", version))
            n_tensors = len(state_dict)
            f.write(struct.pack("<Q", n_tensors))
            n_kv = len(metadata)
            f.write(struct.pack("<Q", n_kv))
            for key, value in metadata.items():
                key_bytes = key.encode("utf-8")
                f.write(struct.pack("<Q", len(key_bytes)))
                f.write(key_bytes)
                if isinstance(value, int):
                    f.write(struct.pack("<I", 0))
                    f.write(struct.pack("<q", value))
                elif isinstance(value, str):
                    f.write(struct.pack("<I", 1))
                    val_bytes = value.encode("utf-8")
                    f.write(struct.pack("<Q", len(val_bytes)))
                    f.write(val_bytes)
                elif isinstance(value, list):
                    f.write(struct.pack("<I", 2))
                    f.write(struct.pack("<I", len(value)))
                    for item in value:
                        f.write(struct.pack("<q", item))
            for name, tensor in state_dict.items():
                name_bytes = name.encode("utf-8")
                f.write(struct.pack("<Q", len(name_bytes)))
                f.write(name_bytes)
                dtype_map = {
                    torch.float32: 0,
                    torch.float16: 1,
                    torch.bfloat16: 30,
                }
                f.write(struct.pack("<I", dtype_map.get(tensor.dtype, 0)))
                ndim = tensor.ndim
                f.write(struct.pack("<I", ndim))
                for dim in tensor.shape:
                    f.write(struct.pack("<Q", dim))
                tensor_flat = tensor.contiguous().view(-1).cpu().numpy()
                f.write(tensor_flat.tobytes())
        size_bytes = gguf_path.stat().st_size
        return ConversionResult(
            success=True,
            output_path=gguf_path,
            format=ConversionFormat.GGUF,
            size_bytes=size_bytes,
            metadata=metadata,
        )

    def _pytorch_to_tensorrt(
        self,
        source_path: Path,
        output_path: Path,
        model: Optional[nn.Module],
    ) -> ConversionResult:
        if model is None:
            raise ValueError("Model must be provided for TensorRT conversion")
        state_dict = self._load_state_dict(source_path)
        model.load_state_dict(state_dict, strict=False)
        model.eval()
        trt_path = output_path / "model.trt"
        metadata = {
            "format": "tensorrt",
            "max_batch_size": self.config.tensorrt_max_batch_size,
            "max_workspace_size": self.config.tensorrt_max_workspace_size,
            "fp16": self.config.tensorrt_fp16,
            "architecture": str(model.__class__.__name__),
        }
        try:
            import torch_tensorrt
            dummy_input = torch.randn(
                self.config.tensorrt_max_batch_size,
                512,
                dtype=torch.long,
            )
            trt_model = torch_tensorrt.compile(
                model,
                inputs=[torch_tensorrt.Input(
                    min_shape=[1, 128],
                    opt_shape=[self.config.tensorrt_max_batch_size, 256],
                    max_shape=[self.config.tensorrt_max_batch_size, 512],
                    dtype=torch.long,
                )],
                enabled_precisions={torch.float16} if self.config.tensorrt_fp16 else {torch.float32},
                workspace_size=self.config.tensorrt_max_workspace_size,
            )
            torch.save(trt_model, str(trt_path))
            metadata["compiled"] = True
        except ImportError:
            logger.warning("torch_tensorrt not available, saving model with metadata only")
            torch.save({"model": model, "metadata": metadata}, str(trt_path))
            metadata["compiled"] = False
        size_bytes = trt_path.stat().st_size
        return ConversionResult(
            success=True,
            output_path=trt_path,
            format=ConversionFormat.TENSORRT,
            size_bytes=size_bytes,
            metadata=metadata,
        )

    def _pytorch_to_huggingface(
        self,
        source_path: Path,
        output_path: Path,
        model: Optional[nn.Module],
    ) -> ConversionResult:
        state_dict = self._load_state_dict(source_path)
        output_path.mkdir(parents=True, exist_ok=True)
        try:
            from safetensors.torch import save_file
            save_file(state_dict, str(output_path / "model.safetensors"))
        except ImportError:
            torch.save(state_dict, str(output_path / "pytorch_model.bin"))
        config = {
            "architectures": ["CustomModel"],
            "model_type": "custom",
            "torch_dtype": "float32",
        }
        with open(output_path / "config.json", "w") as f:
            json.dump(config, f, indent=2)
        index = {
            "metadata": {"total_size": sum(p.numel() * p.element_size() for p in state_dict.values())},
            "weight_map": {name: "model.safetensors" for name in state_dict.keys()},
        }
        with open(output_path / "model.safetensors.index.json", "w") as f:
            json.dump(index, f, indent=2)
        size_bytes = sum(f.stat().st_size for f in output_path.iterdir() if f.is_file())
        return ConversionResult(
            success=True,
            output_path=output_path,
            format=ConversionFormat.HUGGINGFACE,
            size_bytes=size_bytes,
        )

    def _safetensors_to_pytorch(
        self,
        source_path: Path,
        output_path: Path,
        model: Optional[nn.Module],
    ) -> ConversionResult:
        safetensors_files = list(source_path.glob("*.safetensors"))
        if not safetensors_files:
            raise FileNotFoundError(f"No safetensors files found in {source_path}")
        try:
            from safetensors.torch import load_file
            combined_state_dict: Dict[str, torch.Tensor] = {}
            for sf in safetensors_files:
                combined_state_dict.update(load_file(str(sf)))
        except ImportError:
            combined_state_dict = self._load_safetensors_manual(source_path)
        torch_path = output_path / "pytorch_model.bin"
        torch.save(combined_state_dict, str(torch_path))
        size_bytes = torch_path.stat().st_size
        return ConversionResult(
            success=True,
            output_path=torch_path,
            format=ConversionFormat.PYTORCH,
            size_bytes=size_bytes,
        )

    def _load_safetensors_manual(self, directory: Path) -> Dict[str, torch.Tensor]:
        combined: Dict[str, torch.Tensor] = {}
        for sf_path in directory.glob("*.safetensors"):
            with open(sf_path, "rb") as f:
                header_len = struct.unpack("<Q", f.read(8))[0]
                header_bytes = f.read(header_len)
                header = json.loads(header_bytes.decode("utf-8"))
                for name, info in header.items():
                    dtype_map = {
                        0: torch.float32,
                        1: torch.float16,
                        3: torch.bfloat16,
                        5: torch.int8,
                        6: torch.int32,
                        7: torch.int64,
                        8: torch.uint8,
                        9: torch.bool,
                    }
                    dtype = dtype_map.get(info["dtype"], torch.float32)
                    shape = info["shape"]
                    offsets = info["data_offsets"]
                    byte_size = offsets[1] - offsets[0]
                    raw_bytes = f.read(byte_size)
                    import numpy as np
                    arr = np.frombuffer(raw_bytes, dtype=np.dtype(np.float32)).reshape(shape)
                    combined[name] = torch.from_numpy(arr).to(dtype)
        return combined

    def _huggingface_to_pytorch(
        self,
        source_path: Path,
        output_path: Path,
        model: Optional[nn.Module],
    ) -> ConversionResult:
        safetensors_file = source_path / "model.safetensors"
        pytorch_bin = source_path / "pytorch_model.bin"
        if safetensors_file.exists():
            try:
                from safetensors.torch import load_file
                state_dict = load_file(str(safetensors_file))
            except ImportError:
                state_dict = self._load_safetensors_manual(source_path)
        elif pytorch_bin.exists():
            state_dict = torch.load(str(pytorch_bin), map_location="cpu", weights_only=False)
        else:
            raise FileNotFoundError(f"No model files found in {source_path}")
        torch_path = output_path / "pytorch_model.bin"
        output_path.mkdir(parents=True, exist_ok=True)
        torch.save(state_dict, str(torch_path))
        size_bytes = torch_path.stat().st_size
        return ConversionResult(
            success=True,
            output_path=torch_path,
            format=ConversionFormat.PYTORCH,
            size_bytes=size_bytes,
        )

    def _pytorch_to_pytorch(
        self,
        source_path: Path,
        output_path: Path,
        model: Optional[nn.Module],
    ) -> ConversionResult:
        state_dict = self._load_state_dict(source_path)
        if self.config.dtype is not None:
            state_dict = {k: v.to(self.config.dtype) for k, v in state_dict.items()}
        if self.config.quantization.method != QuantizationMethod.NONE:
            state_dict = self._apply_quantization(state_dict)
        torch_path = output_path / "pytorch_model.bin"
        output_path.mkdir(parents=True, exist_ok=True)
        torch.save(state_dict, str(torch_path))
        size_bytes = torch_path.stat().st_size
        return ConversionResult(
            success=True,
            output_path=torch_path,
            format=ConversionFormat.PYTORCH,
            size_bytes=size_bytes,
        )

    def _load_state_dict(self, source_path: Path) -> Dict[str, torch.Tensor]:
        if source_path.is_file():
            return torch.load(str(source_path), map_location="cpu", weights_only=False)
        bin_file = source_path / "pytorch_model.bin"
        safetensors_file = source_path / "model.safetensors"
        if bin_file.exists():
            return torch.load(str(bin_file), map_location="cpu", weights_only=False)
        if safetensors_file.exists():
            try:
                from safetensors.torch import load_file
                return load_file(str(safetensors_file))
            except ImportError:
                return self._load_safetensors_manual(source_path)
        index_file = source_path / "model.safetensors.index.json"
        if index_file.exists():
            with open(index_file, "r") as f:
                index = json.load(f)
            weight_map = index.get("weight_map", {})
            shard_files = set(weight_map.values())
            combined: Dict[str, torch.Tensor] = {}
            try:
                from safetensors.torch import load_file
                for shard in shard_files:
                    shard_path = source_path / shard
                    combined.update(load_file(str(shard_path)))
            except ImportError:
                for shard in shard_files:
                    shard_path = source_path / shard
                    combined.update(self._load_safetensors_manual_single(shard_path))
            return combined
        raise FileNotFoundError(f"No model files found in {source_path}")

    def _load_safetensors_manual_single(self, path: Path) -> Dict[str, torch.Tensor]:
        combined: Dict[str, torch.Tensor] = {}
        with open(path, "rb") as f:
            header_len = struct.unpack("<Q", f.read(8))[0]
            header_bytes = f.read(header_len)
            header = json.loads(header_bytes.decode("utf-8"))
            import numpy as np
            for name, info in header.items():
                dtype_map = {
                    0: torch.float32,
                    1: torch.float16,
                    3: torch.bfloat16,
                    5: torch.int8,
                    6: torch.int32,
                    7: torch.int64,
                    8: torch.uint8,
                    9: torch.bool,
                }
                dtype = dtype_map.get(info["dtype"], torch.float32)
                shape = info["shape"]
                offsets = info["data_offsets"]
                byte_size = offsets[1] - offsets[0]
                raw_bytes = f.read(byte_size)
                arr = np.frombuffer(raw_bytes, dtype=np.dtype(np.float32)).reshape(shape)
                combined[name] = torch.from_numpy(arr).to(dtype)
        return combined

    def _apply_quantization(self, state_dict: Dict[str, torch.Tensor]) -> Dict[str, torch.Tensor]:
        if self.config.quantization.method == QuantizationMethod.NONE:
            return state_dict
        self.config.quantization.validate()
        quantized: Dict[str, torch.Tensor] = {}
        for name, tensor in state_dict.items():
            if tensor.dtype in (torch.float16, torch.float32, torch.bfloat16):
                if self.config.quantization.bits == 8:
                    quantized[name] = self._quantize_int8(tensor)
                elif self.config.quantization.bits == 4:
                    quantized[name] = self._quantize_int4(tensor)
                else:
                    quantized[name] = tensor.to(torch.float16)
            else:
                quantized[name] = tensor
        return quantized

    def _quantize_int8(self, tensor: torch.Tensor) -> torch.Tensor:
        abs_max = tensor.abs().max()
        if abs_max > 0:
            scale = abs_max / 127.0
            quantized = torch.clamp(torch.round(tensor / scale), -128, 127).to(torch.int8)
        else:
            quantized = torch.zeros_like(tensor, dtype=torch.int8)
        return torch.cat([quantized.view(torch.uint8).float().unsqueeze(0), scale.unsqueeze(0)])

    def _quantize_int4(self, tensor: torch.Tensor) -> torch.Tensor:
        abs_max = tensor.abs().max()
        if abs_max > 0:
            scale = abs_max / 7.0
            quantized = torch.clamp(torch.round(tensor / scale), -8, 7).to(torch.int8)
        else:
            quantized = torch.zeros_like(tensor, dtype=torch.int8)
        return torch.cat([quantized.view(torch.uint8).float().unsqueeze(0), scale.unsqueeze(0)])

    def _validate_output(self, result: ConversionResult) -> None:
        if not result.success:
            return
        if result.output_path.is_file():
            size = result.output_path.stat().st_size
            if size == 0:
                result.warnings.append("Output file is empty")
        elif result.output_path.is_dir():
            files = list(result.output_path.iterdir())
            if not files:
                result.warnings.append("Output directory is empty")

    def split_checkpoint(
        self,
        checkpoint_path: Union[str, Path],
        output_dir: Union[str, Path],
        max_shard_size: int = 5 * 1024 * 1024 * 1024,
    ) -> List[Path]:
        checkpoint_path = Path(checkpoint_path)
        output_dir = Path(output_dir)
        output_dir.mkdir(parents=True, exist_ok=True)
        state_dict = self._load_state_dict(checkpoint_path)
        items = list(state_dict.items())
        shards: List[Path] = []
        current_shard: Dict[str, torch.Tensor] = {}
        current_size = 0
        shard_idx = 0
        for name, tensor in items:
            tensor_size = tensor.numel() * tensor.element_size()
            if current_size + tensor_size > max_shard_size and current_shard:
                shard_path = output_dir / f"shard_{shard_idx:05d}.pt"
                torch.save(current_shard, str(shard_path))
                shards.append(shard_path)
                shard_idx += 1
                current_shard = {}
                current_size = 0
            current_shard[name] = tensor
            current_size += tensor_size
        if current_shard:
            shard_path = output_dir / f"shard_{shard_idx:05d}.pt"
            torch.save(current_shard, str(shard_path))
            shards.append(shard_path)
        manifest = {
            "shards": [s.name for s in shards],
            "total_shards": len(shards),
            "total_params": len(state_dict),
        }
        with open(output_dir / "manifest.json", "w") as f:
            json.dump(manifest, f, indent=2)
        return shards

    def merge_shards(
        self,
        shard_dir: Union[str, Path],
        output_path: Union[str, Path],
    ) -> Path:
        shard_dir = Path(shard_dir)
        output_path = Path(output_path)
        manifest_path = shard_dir / "manifest.json"
        if manifest_path.exists():
            with open(manifest_path, "r") as f:
                manifest = json.load(f)
            shard_names = manifest["shards"]
        else:
            shard_names = sorted([f.name for f in shard_dir.glob("shard_*.pt")])
        combined: Dict[str, torch.Tensor] = {}
        for shard_name in shard_names:
            shard_path = shard_dir / shard_name
            shard_data = torch.load(str(shard_path), map_location="cpu", weights_only=False)
            combined.update(shard_data)
        if output_path.is_dir():
            output_path = output_path / "merged_model.bin"
        else:
            output_path.parent.mkdir(parents=True, exist_ok=True)
        torch.save(combined, str(output_path))
        return output_path


__all__ = [
    "CheckpointConverter",
    "ConversionConfig",
    "ConversionResult",
    "ConversionFormat",
    "QuantizationConfig",
    "QuantizationMethod",
]
