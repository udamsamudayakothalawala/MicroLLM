import math
from abc import ABC, abstractmethod
from typing import List, Optional, Tuple

import torch
import torch.nn as nn
import torch.nn.functional as F
from torchvision import transforms
from torchvision.transforms import functional as TF


class ImageEncoder(ABC):
    @abstractmethod
    def encode(self, images: torch.Tensor) -> torch.Tensor:
        pass

    @abstractmethod
    def get_hidden_dim(self) -> int:
        pass


class LayerNorm2d(nn.Module):
    def __init__(self, num_channels: int, eps: float = 1e-6):
        super().__init__()
        self.weight = nn.Parameter(torch.ones(num_channels))
        self.bias = nn.Parameter(torch.zeros(num_channels))
        self.eps = eps

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        u = x.mean(1, keepdim=True)
        s = (x - u).pow(2).mean(1, keepdim=True)
        x = (x - u) / torch.sqrt(s + self.eps)
        x = self.weight[:, None, None] * x + self.bias[:, None, None]
        return x


class Attention(nn.Module):
    def __init__(self, dim: int, num_heads: int = 8, qkv_bias: bool = False, attn_drop: float = 0.0, proj_drop: float = 0.0):
        super().__init__()
        self.num_heads = num_heads
        head_dim = dim // num_heads
        self.scale = head_dim ** -0.5

        self.qkv = nn.Linear(dim, dim * 3, bias=qkv_bias)
        self.attn_drop = nn.Dropout(attn_drop)
        self.proj = nn.Linear(dim, dim)
        self.proj_drop = nn.Dropout(proj_drop)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        B, N, C = x.shape
        qkv = self.qkv(x).reshape(B, N, 3, self.num_heads, C // self.num_heads).permute(2, 0, 3, 1, 4)
        q, k, v = qkv[0], qkv[1], qkv[2]

        attn = (q @ k.transpose(-2, -1)) * self.scale
        attn = attn.softmax(dim=-1)
        attn = self.attn_drop(attn)

        x = (attn @ v).transpose(1, 2).reshape(B, N, C)
        x = self.proj(x)
        x = self.proj_drop(x)
        return x


class MLP(nn.Module):
    def __init__(self, in_features: int, hidden_features: Optional[int] = None, out_features: Optional[int] = None, drop: float = 0.0):
        super().__init__()
        out_features = out_features or in_features
        hidden_features = hidden_features or in_features * 4
        self.fc1 = nn.Linear(in_features, hidden_features)
        self.act = nn.GELU()
        self.fc2 = nn.Linear(hidden_features, out_features)
        self.drop = nn.Dropout(drop)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = self.fc1(x)
        x = self.act(x)
        x = self.drop(x)
        x = self.fc2(x)
        x = self.drop(x)
        return x


class TransformerBlock(nn.Module):
    def __init__(self, dim: int, num_heads: int, mlp_ratio: float = 4.0, qkv_bias: bool = False, drop: float = 0.0, attn_drop: float = 0.0):
        super().__init__()
        self.norm1 = nn.LayerNorm(dim, eps=1e-6)
        self.attn = Attention(dim, num_heads=num_heads, qkv_bias=qkv_bias, attn_drop=attn_drop, proj_drop=drop)
        self.norm2 = nn.LayerNorm(dim, eps=1e-6)
        mlp_hidden_dim = int(dim * mlp_ratio)
        self.mlp = MLP(in_features=dim, hidden_features=mlp_hidden_dim, drop=drop)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = x + self.attn(self.norm1(x))
        x = x + self.mlp(self.norm2(x))
        return x


class PatchEmbed(nn.Module):
    def __init__(self, img_size: int = 224, patch_size: int = 16, in_chans: int = 3, embed_dim: int = 768):
        super().__init__()
        self.img_size = img_size
        self.patch_size = patch_size
        self.num_patches = (img_size // patch_size) ** 2
        self.proj = nn.Conv2d(in_chans, embed_dim, kernel_size=patch_size, stride=patch_size)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = self.proj(x)
        x = x.flatten(2).transpose(1, 2)
        return x


class SinusoidalPositionEmbedding(nn.Module):
    def __init__(self, embed_dim: int, num_patches: int):
        super().__init__()
        position = torch.arange(num_patches).unsqueeze(1)
        div_term = torch.exp(torch.arange(0, embed_dim, 2) * (-math.log(10000.0) / embed_dim))
        pe = torch.zeros(num_patches, embed_dim)
        pe[:, 0::2] = torch.sin(position * div_term)
        pe[:, 1::2] = torch.cos(position * div_term)
        self.register_buffer("pe", pe)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return x + self.pe.unsqueeze(0)


class VisionTransformer(nn.Module, ImageEncoder):
    def __init__(
        self,
        img_size: int = 224,
        patch_size: int = 16,
        in_chans: int = 3,
        embed_dim: int = 768,
        depth: int = 12,
        num_heads: int = 12,
        mlp_ratio: float = 4.0,
        qkv_bias: bool = True,
        drop_rate: float = 0.0,
        attn_drop_rate: float = 0.0,
        use_sinusoidal_pos: bool = False,
        pre_normalize: bool = True,
    ):
        super().__init__()
        self.embed_dim = embed_dim
        self.patch_embed = PatchEmbed(img_size=img_size, patch_size=patch_size, in_chans=in_chans, embed_dim=embed_dim)
        num_patches = self.patch_embed.num_patches

        self.cls_token = nn.Parameter(torch.zeros(1, 1, embed_dim))
        if use_sinusoidal_pos:
            self.pos_embed = SinusoidalPositionEmbedding(embed_dim, num_patches + 1)
            self._learned_pos = False
        else:
            self.pos_embed = nn.Parameter(torch.zeros(1, num_patches + 1, embed_dim))
            self._learned_pos = True
            nn.init.trunc_normal_(self.pos_embed, std=0.02)

        self.pre_norm = nn.LayerNorm(embed_dim, eps=1e-6) if pre_normalize else nn.Identity()

        self.blocks = nn.ModuleList([
            TransformerBlock(embed_dim, num_heads, mlp_ratio, qkv_bias, drop_rate, attn_drop_rate)
            for _ in range(depth)
        ])

        self.post_norm = nn.LayerNorm(embed_dim, eps=1e-6)

        self.head = nn.Identity()

        nn.init.normal_(self.cls_token, std=0.02)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        B = x.shape[0]
        x = self.patch_embed(x)
        x = self.pre_norm(x)

        cls_token = self.cls_token.expand(B, -1, -1)
        x = torch.cat((cls_token, x), dim=1)

        if self._learned_pos:
            x = x + self.pos_embed
        else:
            x = self.pos_embed(x)

        for blk in self.blocks:
            x = blk(x)

        x = self.post_norm(x)
        return x

    def encode(self, images: torch.Tensor) -> torch.Tensor:
        return self.forward(images)

    def get_hidden_dim(self) -> int:
        return self.embed_dim


class MultiResolutionSupport(nn.Module):
    def __init__(self, base_encoder: VisionTransformer, supported_sizes: List[int] = None):
        super().__init__()
        self.base_encoder = base_encoder
        self.supported_sizes = supported_sizes or [224, 336, 448, 560]

    def forward(self, x: torch.Tensor) -> List[torch.Tensor]:
        B, C, H, W = x.shape
        features = []
        for size in self.supported_sizes:
            resized = F.interpolate(x, size=(size, size), mode="bilinear", align_corners=False)
            feats = self.base_encoder(resized)
            features.append(feats)
        return features

    def encode(self, images: torch.Tensor) -> torch.Tensor:
        return self.forward(images)

    def get_hidden_dim(self) -> int:
        return self.base_encoder.get_hidden_dim()


class ImageProcessor:
    def __init__(
        self,
        image_size: int = 224,
        mean: Tuple[float, float, float] = (0.485, 0.456, 0.406),
        std: Tuple[float, float, float] = (0.229, 0.224, 0.225),
        augment: bool = False,
    ):
        self.image_size = image_size
        self.mean = mean
        self.std = std
        self.augment = augment

        self.base_transform = transforms.Compose([
            transforms.Resize((image_size, image_size)),
            transforms.ToTensor(),
            transforms.Normalize(mean=mean, std=std),
        ])

        if augment:
            self.aug_transform = transforms.Compose([
                transforms.Resize((int(image_size * 1.1), int(image_size * 1.1))),
                transforms.RandomResizedCrop(image_size, scale=(0.8, 1.0)),
                transforms.RandomHorizontalFlip(),
                transforms.ColorJitter(brightness=0.2, contrast=0.2, saturation=0.1, hue=0.1),
                transforms.ToTensor(),
                transforms.Normalize(mean=mean, std=std),
            ])
        else:
            self.aug_transform = self.base_transform

    def __call__(self, images, augment: Optional[bool] = None) -> torch.Tensor:
        use_aug = augment if augment is not None else self.augment
        transform = self.aug_transform if use_aug else self.base_transform
        if isinstance(images, torch.Tensor):
            if images.ndim == 3:
                images = images.unsqueeze(0)
            if use_aug and self.augment:
                results = []
                for i in range(images.shape[0]):
                    pil = transforms.ToPILImage()(images[i])
                    results.append(transform(pil))
                return torch.stack(results, dim=0)
            if images.shape[-2:] != (self.image_size, self.image_size):
                images = F.interpolate(images, size=(self.image_size, self.image_size), mode="bilinear", align_corners=False)
            return images
        if not isinstance(images, list):
            images = [images]
        results = []
        for img in images:
            if isinstance(img, torch.Tensor):
                if img.ndim == 3:
                    img = img.unsqueeze(0)
                img = F.interpolate(img, size=(self.image_size, self.image_size), mode="bilinear", align_corners=False)
                results.append(img.squeeze(0))
            else:
                results.append(transform(img))
        return torch.stack(results, dim=0)

    def resize(self, images: torch.Tensor, size: Tuple[int, int]) -> torch.Tensor:
        return F.interpolate(images, size=size, mode="bilinear", align_corners=False)

    def normalize(self, images: torch.Tensor) -> torch.Tensor:
        mean = torch.tensor(self.mean, device=images.device).view(1, 3, 1, 1)
        std = torch.tensor(self.std, device=images.device).view(1, 3, 1, 1)
        return (images / 255.0 - mean) / std if images.dtype == torch.uint8 else images


class ImageFeatureProjector(nn.Module):
    def __init__(self, vision_hidden_size: int, llm_hidden_size: int, use_norm: bool = True):
        super().__init__()
        self.proj = nn.Linear(vision_hidden_size, llm_hidden_size)
        self.use_norm = use_norm
        if use_norm:
            self.norm = nn.LayerNorm(llm_hidden_size, eps=1e-6)
        self.gate = nn.Parameter(torch.ones(1))

    def forward(self, image_features: torch.Tensor) -> torch.Tensor:
        projected = self.proj(image_features)
        if self.use_norm:
            projected = self.norm(projected)
        projected = projected * torch.sigmoid(self.gate)
        return projected
