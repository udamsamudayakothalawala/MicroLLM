import math
from typing import Any, Dict, List, Optional, Tuple

import torch
import torch.nn as nn
import torch.nn.functional as F
from torchvision import models, transforms


class ConvBNReLU(nn.Sequential):
    def __init__(self, in_planes: int, out_planes: int, kernel_size: int = 3, stride: int = 1, padding: Optional[int] = None):
        if padding is None:
            padding = kernel_size // 2
        super().__init__(
            nn.Conv2d(in_planes, out_planes, kernel_size=kernel_size, stride=stride, padding=padding, bias=False),
            nn.BatchNorm2d(out_planes),
            nn.ReLU(inplace=True),
        )


class BidirectionalLSTM(nn.Module):
    def __init__(self, input_size: int, hidden_size: int, num_layers: int = 2):
        super().__init__()
        self.lstm = nn.LSTM(input_size, hidden_size, num_layers, batch_first=True, bidirectional=True)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        output, _ = self.lstm(x)
        return output


class CRNNFeatureExtractor(nn.Module):
    def __init__(self, in_channels: int = 3, hidden_size: int = 256):
        super().__init__()
        self.conv1 = ConvBNReLU(in_channels, 64, 3, 1)
        self.pool1 = nn.MaxPool2d(2, 2)
        self.conv2 = ConvBNReLU(64, 128, 3, 1)
        self.pool2 = nn.MaxPool2d(2, 2)
        self.conv3 = nn.Sequential(
            ConvBNReLU(128, 256, 3, 1),
            ConvBNReLU(256, 256, 3, 1),
        )
        self.pool3 = nn.MaxPool2d(2, (2, 1), (0, 0))
        self.conv4 = nn.Sequential(
            ConvBNReLU(256, 512, 3, 1),
            ConvBNReLU(512, 512, 3, 1),
        )
        self.pool4 = nn.MaxPool2d(2, (2, 1), (0, 0))
        self.conv5 = nn.Sequential(
            ConvBNReLU(512, 512, 3, 1),
            ConvBNReLU(512, 512, 3, 1),
        )
        self._to_sequence = nn.Sequential(
            nn.AdaptiveAvgPool2d((1, None)),
            nn.Flatten(2),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = self.conv1(x)
        x = self.pool1(x)
        x = self.conv2(x)
        x = self.pool2(x)
        x = self.conv3(x)
        x = self.pool3(x)
        x = self.conv4(x)
        x = self.pool4(x)
        x = self.conv5(x)
        x = self._to_sequence(x)
        x = x.permute(0, 2, 1)
        return x


class CharacterRecognizer(nn.Module):
    def __init__(self, num_classes: int = 1000, hidden_size: int = 256, lstm_layers: int = 2):
        super().__init__()
        self.feature_extractor = CRNNFeatureExtractor(3, hidden_size)
        self.sequence_model = BidirectionalLSTM(hidden_size * 2, hidden_size, lstm_layers)
        self.classifier = nn.Linear(hidden_size * 2, num_classes)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        features = self.feature_extractor(x)
        seq_features = self.sequence_model(features)
        logits = self.classifier(seq_features)
        return logits

    def recognize(self, x: torch.Tensor) -> torch.Tensor:
        logits = self.forward(x)
        return logits.argmax(dim=-1)


class CRAFTBlock(nn.Module):
    def __init__(self, in_channels: int, out_channels: int):
        super().__init__()
        self.conv1 = ConvBNReLU(in_channels, out_channels, 3, 1)
        self.conv2 = ConvBNReLU(out_channels, out_channels, 3, 1)
        self.conv3 = ConvBNReLU(out_channels, out_channels, 3, 1)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = self.conv1(x)
        x = self.conv2(x)
        x = self.conv3(x)
        return x


class TextDetector(nn.Module):
    def __init__(self, pretrained: bool = True):
        super().__init__()
        backbone = models.vgg16_bn(weights="DEFAULT" if pretrained else None)
        features = list(backbone.features)

        self.stage1 = nn.Sequential(*features[:6])
        self.stage2 = nn.Sequential(*features[6:13])
        self.stage3 = nn.Sequential(*features[13:20])
        self.stage4 = nn.Sequential(*features[20:27])
        self.stage5 = nn.Sequential(*features[27:34])

        self.up_conv4 = nn.ConvTranspose2d(512, 256, 2, 2)
        self.up_conv3 = nn.ConvTranspose2d(256, 128, 2, 2)
        self.up_conv2 = nn.ConvTranspose2d(128, 64, 2, 2)

        self.craft_block4 = CRAFTBlock(512 + 256, 256)
        self.craft_block3 = CRAFTBlock(256 + 128, 128)
        self.craft_block2 = CRAFTBlock(128 + 64, 64)

        self.score = nn.Conv2d(64, 1, 1)
        self.affinity = nn.Conv2d(64, 2, 1)

    def forward(self, x: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        s1 = self.stage1(x)
        s2 = self.stage2(s1)
        s3 = self.stage3(s2)
        s4 = self.stage4(s3)
        s5 = self.stage5(s4)

        u4 = self.up_conv4(s5)
        u4 = torch.cat([u4, s4], dim=1)
        u4 = self.craft_block4(u4)

        u3 = self.up_conv3(u4)
        u3 = torch.cat([u3, s3], dim=1)
        u3 = self.craft_block3(u3)

        u2 = self.up_conv2(u3)
        u2 = torch.cat([u2, s2], dim=1)
        u2 = self.craft_block2(u2)

        score = self.score(u2)
        affinity = self.affinity(u2)

        score = torch.sigmoid(score)
        affinity = torch.sigmoid(affinity)
        return score, affinity

    def detect(self, x: torch.Tensor, threshold: float = 0.5) -> List[torch.Tensor]:
        score, affinity = self.forward(x)
        masks = (score > threshold).float()
        boxes = []
        for i in range(masks.shape[0]):
            mask = masks[i, 0]
            box = self._mask_to_boxes(mask)
            boxes.append(box)
        return boxes

    def _mask_to_boxes(self, mask: torch.Tensor) -> torch.Tensor:
        indices = torch.nonzero(mask > 0)
        if indices.shape[0] == 0:
            return torch.zeros((0, 4), device=mask.device)
        y_min = indices[:, 0].min().float()
        y_max = indices[:, 0].max().float()
        x_min = indices[:, 1].min().float()
        x_max = indices[:, 1].max().float()
        return torch.tensor([[x_min, y_min, x_max, y_max]], device=mask.device)


class LineDetector(nn.Module):
    def __init__(self, min_line_height: int = 10, line_gap_threshold: int = 5):
        super().__init__()
        self.min_line_height = min_line_height
        self.line_gap_threshold = line_gap_threshold
        self.text_detector = TextDetector()

    def forward(self, x: torch.Tensor) -> List[torch.Tensor]:
        boxes = self.text_detector.detect(x)
        lines = []
        for batch_boxes in boxes:
            if batch_boxes.shape[0] == 0:
                lines.append(torch.zeros((0, 4), device=x.device))
                continue
            sorted_boxes = batch_boxes[batch_boxes[:, 1].argsort()]
            merged = self._merge_lines(sorted_boxes)
            lines.append(merged)
        return lines

    def _merge_lines(self, boxes: torch.Tensor) -> torch.Tensor:
        if boxes.shape[0] <= 1:
            return boxes
        merged = [boxes[0]]
        for i in range(1, boxes.shape[0]):
            prev = merged[-1]
            curr = boxes[i]
            if abs(curr[1].item() - prev[3].item()) < self.line_gap_threshold:
                merged[-1] = torch.tensor([
                    min(prev[0], curr[0]),
                    min(prev[1], curr[1]),
                    max(prev[2], curr[2]),
                    max(prev[3], curr[3]),
                ], device=boxes.device)
            else:
                merged.append(curr)
        return torch.stack(merged)


class DocumentLayoutAnalyzer(nn.Module):
    def __init__(self, num_layout_classes: int = 10, backbone: str = "resnet50"):
        super().__init__()
        self.num_layout_classes = num_layout_classes
        resnet = models.resnet50(weights="DEFAULT")
        self.backbone = nn.Sequential(*list(resnet.children())[:-2])

        self.fpn = nn.ModuleList([
            nn.Conv2d(2048, 256, 1),
            nn.Conv2d(1024, 256, 1),
            nn.Conv2d(512, 256, 1),
            nn.Conv2d(256, 256, 1),
        ])

        self.seg_head = nn.Sequential(
            nn.Conv2d(256, 128, 3, padding=1),
            nn.BatchNorm2d(128),
            nn.ReLU(inplace=True),
            nn.Conv2d(128, num_layout_classes, 1),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        features = []
        h = x
        for name, module in self.backbone.named_children():
            h = module(h)
            if isinstance(module, nn.Sequential) and len(list(module.children())) == 3:
                features.append(h)

        fpn_features = []
        for i, (feat, conv) in enumerate(zip(reversed(features[-4:]), self.fpn)):
            f = conv(feat)
            fpn_features.append(f)

        target_size = fpn_features[-1].shape[-2:]
        upsampled = []
        for f in fpn_features[:-1]:
            u = F.interpolate(f, size=target_size, mode="bilinear", align_corners=False)
            upsampled.append(u)
        upsampled.append(fpn_features[-1])

        fused = sum(upsampled)
        out = self.seg_head(fused)
        return out

    def analyze(self, x: torch.Tensor) -> Dict[str, torch.Tensor]:
        layout_logits = self.forward(x)
        layout_probs = F.softmax(layout_logits, dim=1)
        layout_labels = layout_probs.argmax(dim=1)
        return {"logits": layout_logits, "probs": layout_probs, "labels": layout_labels}


class TableExtractor(nn.Module):
    def __init__(self, hidden_dim: int = 256, num_heads: int = 8):
        super().__init__()
        self.backbone = models.resnet18(weights="DEFAULT")
        self.backbone = nn.Sequential(*list(self.backbone.children())[:-2])

        self.reduce_dim = nn.Conv2d(512, hidden_dim, 1)

        encoder_layer = nn.TransformerEncoderLayer(d_model=hidden_dim, nhead=num_heads, dim_feedforward=hidden_dim * 4, batch_first=True)
        self.transformer = nn.TransformerEncoder(encoder_layer, num_layers=6)

        self.cell_classifier = nn.Linear(hidden_dim, 2)
        self.row_classifier = nn.Linear(hidden_dim, 2)
        self.col_classifier = nn.Linear(hidden_dim, 2)

    def forward(self, x: torch.Tensor) -> Dict[str, torch.Tensor]:
        features = self.backbone(x)
        features = self.reduce_dim(features)
        B, C, H, W = features.shape
        seq = features.flatten(2).transpose(1, 2)
        seq = self.transformer(seq)

        cell_logits = self.cell_classifier(seq)
        row_logits = self.row_classifier(seq)
        col_logits = self.col_classifier(seq)

        cell_probs = torch.sigmoid(cell_logits)
        row_probs = torch.sigmoid(row_logits)
        col_probs = torch.sigmoid(col_logits)

        return {
            "cell_probs": cell_probs,
            "row_probs": row_probs,
            "col_probs": col_probs,
            "sequence": seq,
            "spatial": (H, W),
        }

    def extract_table(self, x: torch.Tensor, threshold: float = 0.5) -> List[Dict[str, Any]]:
        outputs = self.forward(x)
        B = x.shape[0]
        results = []
        for b in range(B):
            rows = torch.where(outputs["row_probs"][b, :, 1] > threshold)[0].tolist()
            cols = torch.where(outputs["col_probs"][b, :, 1] > threshold)[0].tolist()
            cells = torch.where(outputs["cell_probs"][b, :, 1] > threshold)[0].tolist()
            results.append({
                "rows": rows,
                "cols": cols,
                "cells": cells,
            })
        return results


class OCRProcessor:
    def __init__(
        self,
        num_chars: int = 1000,
        hidden_size: int = 256,
        device: str = "cpu",
    ):
        self.device = torch.device(device)
        self.text_detector = TextDetector().to(self.device)
        self.char_recognizer = CharacterRecognizer(num_classes=num_chars, hidden_size=hidden_size).to(self.device)
        self.layout_analyzer = DocumentLayoutAnalyzer(num_layout_classes=10).to(self.device)
        self.table_extractor = TableExtractor(hidden_dim=hidden_size).to(self.device)
        self.line_detector = LineDetector().to(self.device)
        self.transform = transforms.Compose([
            transforms.ToTensor(),
            transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),
        ])

    def _prepare_input(self, images) -> torch.Tensor:
        if isinstance(images, torch.Tensor):
            if images.ndim == 3:
                images = images.unsqueeze(0)
            if images.shape[1] != 3:
                raise ValueError(f"Expected 3 channels, got {images.shape[1]}")
            if images.max() <= 1.0 and images.min() >= 0:
                images = (images * 255).byte()
            return images.to(self.device)
        if not isinstance(images, list):
            images = [images]
        tensors = []
        for img in images:
            tensors.append(self.transform(img))
        return torch.stack(tensors).to(self.device)

    def extract_text(self, images, detection_threshold: float = 0.5) -> List[str]:
        x = self._prepare_input(images)
        lines = self.line_detector(x)
        texts = []
        for b in range(x.shape[0]):
            line_texts = []
            batch_lines = lines[b]
            for line_box in batch_lines:
                x1, y1, x2, y2 = line_box.round().int().tolist()
                if x2 - x1 < 5 or y2 - y1 < 5:
                    continue
                cropped = x[b:b+1, :, max(0, y1):min(y2, x.shape[2]), max(0, x1):min(x2, x.shape[3])]
                if cropped.shape[2] < 5 or cropped.shape[3] < 5:
                    continue
                cropped_resized = F.interpolate(cropped, size=(32, 128), mode="bilinear", align_corners=False)
                char_logits = self.char_recognizer(cropped_resized)
                char_ids = char_logits.argmax(dim=-1)
                line_texts.append(char_ids)
            texts.append(line_texts)
        return texts

    def analyze_layout(self, images) -> List[Dict[str, torch.Tensor]]:
        x = self._prepare_input(images)
        output = self.layout_analyzer.analyze(x)
        results = []
        for b in range(x.shape[0]):
            results.append({
                "logits": output["logits"][b],
                "probs": output["probs"][b],
                "labels": output["labels"][b],
            })
        return results

    def extract_tables(self, images, threshold: float = 0.5) -> List[Dict[str, Any]]:
        x = self._prepare_input(images)
        return self.table_extractor.extract_table(x, threshold)

    def process_document(self, images) -> Dict[str, Any]:
        x = self._prepare_input(images)
        text_lines = self.extract_text(x)
        layout = self.analyze_layout(x)
        tables = self.extract_tables(x)
        return {
            "text": text_lines,
            "layout": layout,
            "tables": tables,
        }
