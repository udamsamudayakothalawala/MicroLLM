import json
import os
import struct
from typing import Any, Dict, List, Optional, Tuple, Union

import torch
import torch.nn as nn


GGUF_MAGIC = 0x46554747
GGUF_VERSION = 3


GGML_TYPE_MAP = {
    "F32": 0,
    "F16": 1,
    "Q4_0": 2,
    "Q4_1": 3,
    "Q5_0": 6,
    "Q5_1": 7,
    "Q8_0": 8,
    "Q8_1": 9,
    "Q2_K": 10,
    "Q3_K_S": 11,
    "Q3_K_M": 12,
    "Q3_K_L": 13,
    "Q4_K_S": 14,
    "Q4_K_M": 15,
    "Q5_K_S": 16,
    "Q5_K_M": 17,
    "Q6_K": 18,
}


class GGUFExporter:
    """Export quantized models to GGUF format for GGML/GGUF inference engines."""

    def __init__(self):
        self.metadata: Dict[str, Any] = {}
        self.tensors: List[Dict[str, Any]] = []
        self.tensor_data: List[bytes] = []

    def add_metadata(self, key: str, value: Any):
        self.metadata[key] = value

    def set_architecture(self, arch: str):
        self.metadata["general.architecture"] = arch

    def set_tokenizer(self, vocab: Dict[str, int], bos_token: int, eos_token: int, unk_token: int = 0):
        self.metadata["tokenizer.ggml.model"] = "llama"
        self.metadata["tokenizer.ggml.bos_token_id"] = bos_token
        self.metadata["tokenizer.ggml.eos_token_id"] = eos_token
        self.metadata["tokenizer.ggml.unk_token_id"] = unk_token

        tokens = [""] * (max(vocab.values()) + 1) if vocab else []
        for token, idx in vocab.items():
            if idx < len(tokens):
                tokens[idx] = token
        self.metadata["tokenizer.ggml.tokens"] = tokens
        self.metadata["tokenizer.ggml.scores"] = [0.0] * len(tokens)

    def _write_header(self, f):
        f.write(struct.pack("<I", GGUF_MAGIC))
        f.write(struct.pack("<I", GGUF_VERSION))
        f.write(struct.pack("<Q", len(self.tensors)))
        n_kv = len(self.metadata)
        f.write(struct.pack("<Q", n_kv))

    def _write_metadata_value(self, f, key: str, value: Any):
        f.write(struct.pack("<Q", len(key.encode("utf-8"))))
        f.write(key.encode("utf-8"))

        if isinstance(value, bool):
            f.write(struct.pack("<I", 1))
            f.write(struct.pack("<B", 1 if value else 0))
        elif isinstance(value, int):
            if value < 0:
                f.write(struct.pack("<I", 3))
                f.write(struct.pack("<q", value))
            else:
                f.write(struct.pack("<I", 2))
                f.write(struct.pack("<Q", value))
        elif isinstance(value, float):
            f.write(struct.pack("<I", 4))
            f.write(struct.pack("<f", value))
        elif isinstance(value, str):
            encoded = value.encode("utf-8")
            f.write(struct.pack("<I", 6))
            f.write(struct.pack("<Q", len(encoded)))
            f.write(encoded)
        elif isinstance(value, list):
            if len(value) > 0:
                first = value[0]
                if isinstance(first, str):
                    f.write(struct.pack("<I", 7))
                    f.write(struct.pack("<Q", len(value)))
                    for s in value:
                        encoded = s.encode("utf-8")
                        f.write(struct.pack("<Q", len(encoded)))
                        f.write(encoded)
                elif isinstance(first, int):
                    f.write(struct.pack("<I", 8))
                    f.write(struct.pack("<Q", len(value)))
                    for i in value:
                        f.write(struct.pack("<q", i))
                elif isinstance(first, float):
                    f.write(struct.pack("<I", 9))
                    f.write(struct.pack("<Q", len(value)))
                    for fl in value:
                        f.write(struct.pack("<f", fl))
                elif isinstance(first, bool):
                    f.write(struct.pack("<I", 10))
                    f.write(struct.pack("<Q", len(value)))
                    for b in value:
                        f.write(struct.pack("<B", 1 if b else 0))

    def _write_tensor_info(self, f, name: str, shape: List[int], ggml_type: int, offset: int):
        f.write(struct.pack("<Q", len(name.encode("utf-8"))))
        f.write(name.encode("utf-8"))
        f.write(struct.pack("<I", len(shape)))
        for s in reversed(shape):
            f.write(struct.pack("<Q", s))
        f.write(struct.pack("<I", ggml_type))
        f.write(struct.pack("<Q", offset))

    def write_tensor_metadata(
        self,
        f,
        tensor_name: str,
        shape: List[int],
        quantized_type: str,
        offset: int,
    ):
        ggml_type = GGML_TYPE_MAP.get(quantized_type, 0)
        self._write_tensor_info(f, tensor_name, shape, ggml_type, offset)

    def write_tensor_data(self, f, data: torch.Tensor):
        if data.dtype == torch.float32:
            f.write(data.cpu().numpy().tobytes())
        elif data.dtype == torch.float16:
            f.write(data.cpu().half().numpy().tobytes())
        else:
            f.write(data.cpu().float().numpy().tobytes())

    def export(
        self,
        model: nn.Module,
        output_path: str,
        model_arch: str = "llama",
        config: Optional[Dict[str, Any]] = None,
    ):
        """Export model to GGUF format."""
        self.set_architecture(model_arch)

        if config:
            arch = model_arch
            self.metadata[f"{arch}.block_count"] = config.get("num_layers", 32)
            self.metadata[f"{arch}.embedding_length"] = config.get("hidden_size", 4096)
            self.metadata[f"{arch}.feed_forward_length"] = config.get("intermediate_size", 11008)
            self.metadata[f"{arch}.attention.head_count"] = config.get("num_heads", 32)
            self.metadata[f"{arch}.attention.head_count_kv"] = config.get("num_kv_heads", 32)
            self.metadata[f"{arch}.context_length"] = config.get("max_seq_len", 2048)
            self.metadata[f"{arch}.vocab_size"] = config.get("vocab_size", 32000)

        self.metadata["general.name"] = config.get("name", "mullm_model") if config else "mullm_model"
        self.metadata["general.type"] = "model"
        self.metadata["general.quantization_version"] = GGUF_VERSION

        tensor_entries = []
        for name, param in model.named_parameters():
            tensor_entries.append({
                "name": name,
                "tensor": param.data,
                "type": "F16",
            })
        for name, buf in model.named_buffers():
            if buf.numel() > 0:
                tensor_entries.append({
                    "name": name,
                    "tensor": buf.data,
                    "type": "F16",
                })

        os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
        with open(output_path, "wb") as f:
            self._write_header(f)
            for k, v in self.metadata.items():
                self._write_metadata_value(f, k, v)

            data_offset = 0
            aligned_data_offset = 0
            for entry in tensor_entries:
                shape = list(entry["tensor"].shape)
                data_offset = aligned_data_offset
                self._write_tensor_info(f, entry["name"], shape, GGML_TYPE_MAP[entry["type"]], data_offset)
                element_size = 2 if entry["tensor"].dtype == torch.float16 else 4
                tensor_size = entry["tensor"].numel() * element_size
                aligned_data_offset = (data_offset + tensor_size + 31) & ~31

            for entry in tensor_entries:
                tensor_bytes = entry["tensor"].cpu().float().half().numpy().tobytes()
                current_pos = f.tell()
                padding = (32 - (current_pos % 32)) % 32
                f.write(b"\x00" * padding)
                f.write(tensor_bytes)

        return output_path


class ONNXExporter:
    """Export models to ONNX format."""

    def __init__(self, opset_version: int = 17):
        self.opset_version = opset_version

    def export(
        self,
        model: nn.Module,
        output_path: str,
        input_sample: Optional[torch.Tensor] = None,
        dynamic_axes: Optional[Dict[str, Dict[int, str]]] = None,
        input_names: Optional[List[str]] = None,
        output_names: Optional[List[str]] = None,
        opset_version: Optional[int] = None,
    ):
        """Export model to ONNX format.

        Args:
            model: The model to export.
            output_path: Path to save the ONNX file.
            input_sample: Sample input for tracing.
            dynamic_axes: Dynamic axis specifications.
            input_names: Names for input tensors.
            output_names: Names for output tensors.
            opset_version: ONNX opset version override.
        """
        import onnx

        if opset_version is None:
            opset_version = self.opset_version

        model.eval()
        if input_sample is None:
            input_sample = torch.randn(1, 1, dtype=torch.long)

        if input_names is None:
            input_names = ["input_ids"]
        if output_names is None:
            output_names = ["logits"]

        if dynamic_axes is None:
            dynamic_axes = {
                "input_ids": {0: "batch_size", 1: "sequence_length"},
                "logits": {0: "batch_size", 1: "sequence_length"},
            }

        os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)

        torch.onnx.export(
            model,
            input_sample,
            output_path,
            opset_version=opset_version,
            do_constant_folding=True,
            input_names=input_names,
            output_names=output_names,
            dynamic_axes=dynamic_axes,
        )

        onnx_model = onnx.load(output_path)
        onnx.checker.check_model(onnx_model)
        onnx.save(onnx_model, output_path)

        return output_path

    def export_with_quantization(
        self,
        model: nn.Module,
        output_path: str,
        quantize_mode: str = "int8",
        input_sample: Optional[torch.Tensor] = None,
    ) -> str:
        """Export with ONNX-compatible quantization."""
        import onnx

        model.eval()
        if input_sample is None:
            input_sample = torch.randn(1, 1, dtype=torch.long)

        os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)

        temp_path = output_path + ".tmp"
        torch.onnx.export(
            model,
            input_sample,
            temp_path,
            opset_version=self.opset_version,
            do_constant_folding=True,
            input_names=["input_ids"],
            output_names=["logits"],
            dynamic_axes={
                "input_ids": {0: "batch_size", 1: "sequence_length"},
                "logits": {0: "batch_size", 1: "sequence_length"},
            },
        )

        onnx_model = onnx.load(temp_path)

        if quantize_mode in ("int8", "int4"):
            from onnxruntime.quantization import QuantType, quantize_dynamic
            quant_type = QuantType.QInt8 if quantize_mode == "int8" else QuantType.QInt8
            quantize_dynamic(
                model_input=temp_path,
                model_output=output_path,
                weight_type=quant_type,
            )
        else:
            onnx.save(onnx_model, output_path)

        if os.path.exists(temp_path):
            os.remove(temp_path)

        return output_path


class TensorRTExporter:
    """Export models to TensorRT optimized engines."""

    def __init__(
       self,
        max_batch_size: int = 1,
        fp16: bool = True,
        int8: bool = False,
        int4: bool = False,
        max_workspace_size: int = 1 << 30,
    ):
        self.max_batch_size = max_batch_size
        self.fp16 = fp16
        self.int8 = int8
        self.int4 = int4
        self.max_workspace_size = max_workspace_size

    def build_engine(
        self,
        onnx_path: str,
        engine_path: str,
        min_shape: Optional[Tuple[int, ...]] = None,
        opt_shape: Optional[Tuple[int, ...]] = None,
        max_shape: Optional[Tuple[int, ...]] = None,
    ):
        """Build a TensorRT engine from an ONNX model.

        Args:
            onnx_path: Path to ONNX model.
            engine_path: Path to save the TensorRT engine.
            min_shape: Minimum input shapes.
            opt_shape: Optimal input shapes.
            max_shape: Maximum input shapes.
        """
        try:
            import tensorrt as trt
        except ImportError:
            raise ImportError("tensorrt is required for TensorRT export. Install with: pip install tensorrt")

        logger = trt.Logger(trt.Logger.WARNING)
        builder = trt.Builder(logger)
        network = builder.create_network(1 << int(trt.NetworkDefinitionCreationFlag.EXPLICIT_BATCH))
        parser = trt.OnnxParser(network, logger)

        with open(onnx_path, "rb") as f:
            if not parser.parse(f.read()):
                for i in range(parser.num_errors):
                    print(f"ONNX Parse Error: {parser.get_error(i)}")
                raise RuntimeError("Failed to parse ONNX model")

        config = builder.create_builder_config()
        config.set_memory_pool_limit(trt.MemoryPoolType.WORKSPACE, self.max_workspace_size)

        if self.fp16 and builder.platform_has_fast_fp16:
            config.set_flag(trt.BuilderFlag.FP16)

        if self.int8 and builder.platform_has_fast_int8:
            config.set_flag(trt.BuilderFlag.INT8)

        if self.int4:
            config.set_flag(trt.BuilderFlag.INT8)

        profile = builder.create_optimization_profile()

        input_tensor = network.get_input(0)
        input_shape = input_tensor.shape

        if min_shape is None:
            min_shape = (1,) + tuple(s if isinstance(s, int) and s > 0 else 1 for s in input_shape[1:])
        if opt_shape is None:
            opt_shape = (min(self.max_batch_size, 4),) + tuple(s if isinstance(s, int) and s > 0 else 128 for s in input_shape[1:])
        if max_shape is None:
            max_shape = (self.max_batch_size,) + tuple(s if isinstance(s, int) and s > 0 else 2048 for s in input_shape[1:])

        profile.set_shape(input_tensor.name, min_shape, opt_shape, max_shape)
        config.add_optimization_profile(profile)

        os.makedirs(os.path.dirname(engine_path) or ".", exist_ok=True)

        serialized_engine = builder.build_serialized_network(network, config)
        if serialized_engine is None:
            raise RuntimeError("Failed to build TensorRT engine")

        with open(engine_path, "wb") as f:
            f.write(serialized_engine)

        return engine_path

    def export(
        self,
        model: nn.Module,
        engine_path: str,
        input_sample: Optional[torch.Tensor] = None,
    ) -> str:
        """Full export pipeline: model -> ONNX -> TensorRT."""
        model.eval()
        if input_sample is None:
            input_sample = torch.randn(1, 1, dtype=torch.long)

        temp_onnx = engine_path + ".onnx"
        onnx_exporter = ONNXExporter()
        onnx_exporter.export(model, temp_onnx, input_sample=input_sample)

        self.build_engine(temp_onnx, engine_path)

        if os.path.exists(temp_onnx):
            os.remove(temp_onnx)

        return engine_path


class SafeTensorsExporter:
    """Export tensors in SafeTensors format - a safe, zero-copy serialization format."""

    SAFE_TENSORS_MAGIC = b"safetensors"

    def __init__(self):
        self.tensors: Dict[str, torch.Tensor] = {}
        self.metadata: Dict[str, str] = {}

    def add_tensor(self, name: str, tensor: torch.Tensor):
        """Add a tensor to be exported."""
        self.tensors[name] = tensor.contiguous()

    def add_metadata(self, key: str, value: str):
        """Add metadata entry."""
        self.metadata[key] = value

    def _dtype_to_string(self, dtype: torch.dtype) -> str:
        dtype_map = {
            torch.float32: "F32",
            torch.float16: "F16",
            torch.bfloat16: "BF16",
            torch.int32: "I32",
            torch.int16: "I16",
            torch.int8: "INT8",
            torch.uint8: "UINT8",
            torch.int64: "I64",
            torch.bool: "BOOL",
        }
        return dtype_map.get(dtype, "F32")

    def _string_to_dtype(self, s: str) -> torch.dtype:
        dtype_map = {
            "F32": torch.float32,
            "F16": torch.float16,
            "BF16": torch.bfloat16,
            "I32": torch.int32,
            "I16": torch.int16,
            "INT8": torch.int8,
            "UINT8": torch.uint8,
            "I64": torch.int64,
            "BOOL": torch.bool,
        }
        return dtype_map.get(s, torch.float32)

    def _dtype_nbytes(self, dtype: torch.dtype) -> int:
        nbytes_map = {
            torch.float32: 4,
            torch.float16: 2,
            torch.bfloat16: 2,
            torch.int32: 4,
            torch.int16: 2,
            torch.int8: 1,
            torch.uint8: 1,
            torch.int64: 8,
            torch.bool: 1,
        }
        return nbytes_map.get(dtype, 4)

    def export(self, output_path: str) -> str:
        """Export all tensors to SafeTensors format.

        Format layout:
        [header_json][tensor_data_1][tensor_data_2]...

        Header contains metadata about each tensor (dtype, shape, offset, data_start).
        """
        import json

        offset = 0
        header_dict = {}

        header_dict["__metadata__"] = dict(self.metadata)

        tensor_names = sorted(self.tensors.keys())
        data_offsets = {}

        for name in tensor_names:
            tensor = self.tensors[name]
            dtype_str = self._dtype_to_string(tensor.dtype)
            shape = list(tensor.shape)
            nbytes = tensor.numel() * self._dtype_nbytes(tensor.dtype)

            data_offsets[name] = {"dtype": dtype_str, "shape": shape, "data_offsets": [offset, offset + nbytes]}
            offset += nbytes

        header_dict.update(data_offsets)
        header_json = json.dumps(header_dict).encode("utf-8")

        header_len = len(header_json)
        total_size = 8 + header_len + offset

        os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)

        with open(output_path, "wb") as f:
            f.write(struct.pack("<Q", header_len))
            f.write(header_json)

            for name in tensor_names:
                tensor = self.tensors[name]
                raw_bytes = tensor.numpy().tobytes()
                f.write(raw_bytes)

        return output_path

    def export_model(self, model: nn.Module, output_path: str) -> str:
        """Export all model parameters and buffers to SafeTensors."""
        for name, param in model.named_parameters():
            self.add_tensor(f"parameters.{name}", param.data)

        for name, buf in model.named_buffers():
            if buf.numel() > 0:
                self.add_tensor(f"buffers.{name}", buf.data)

        config = {}
        for name, param in model.named_parameters():
            config[name] = {
                "shape": list(param.shape),
                "dtype": self._dtype_to_string(param.dtype),
            }
        self.add_metadata("model_config", json.dumps(config))

        return self.export(output_path)

    @staticmethod
    def load(file_path: str) -> Tuple[Dict[str, torch.Tensor], Dict[str, str]]:
        """Load and verify a SafeTensors file.

        Returns:
            (tensor_dict, metadata)
        """
        import json

        with open(file_path, "rb") as f:
            header_len = struct.unpack("<Q", f.read(8))[0]
            header_json = f.read(header_len)
            header = json.loads(header_json)

            metadata = header.pop("__metadata__", {})

            tensors = {}
            for name, info in header.items():
                dtype_str = info["dtype"]
                shape = info["shape"]
                data_offsets = info["data_offsets"]
                start, end = data_offsets

                f.seek(8 + header_len + start)
                raw_data = f.read(end - start)

                if len(raw_data) != end - start:
                    raise ValueError(f"Tensor '{name}': expected {end - start} bytes, got {len(raw_data)} bytes")

                dtype_map = {
                    "F32": torch.float32,
                    "F16": torch.float16,
                    "BF16": torch.bfloat16,
                    "I32": torch.int32,
                    "I16": torch.int16,
                    "INT8": torch.int8,
                    "UINT8": torch.uint8,
                    "I64": torch.int64,
                    "BOOL": torch.bool,
                }

                dtype = dtype_map.get(dtype_str, torch.float32)

                if dtype == torch.bfloat16:
                    arr = np.frombuffer(raw_data, dtype=np.uint16)
                    tensor = torch.from_numpy(arr).view(torch.bfloat16)
                else:
                    import numpy as np
                    np_dtype_map = {
                        "F32": np.float32,
                        "F16": np.float16,
                        "I32": np.int32,
                        "I16": np.int16,
                        "INT8": np.int8,
                        "UINT8": np.uint8,
                        "I64": np.int64,
                        "BOOL": np.bool_,
                    }
                    arr = np.frombuffer(raw_data, dtype=np_dtype_map.get(dtype_str, np.float32))
                    tensor = torch.from_numpy(arr)

                tensor = tensor.reshape(shape)
                tensors[name] = tensor

        return tensors, metadata
