from __future__ import annotations

import copy
import logging
import math
from abc import ABC, abstractmethod
from typing import Any, Dict, List, Optional, Tuple, Union

import torch
import torch.nn as nn
import torch.nn.functional as F

logger = logging.getLogger(__name__)


class ModelMerger(ABC):
    @abstractmethod
    def merge(
        self,
        models: List[nn.Module],
        weights: Optional[List[float]] = None,
        **kwargs: Any,
    ) -> nn.Module:
        ...

    def _get_flat_params(self, model: nn.Module) -> torch.Tensor:
        params = []
        for p in model.parameters():
            params.append(p.data.view(-1))
        return torch.cat(params)

    def _set_flat_params(self, model: nn.Module, flat_params: torch.Tensor) -> None:
        offset = 0
        for p in model.parameters():
            numel = p.numel()
            p.data.copy_(flat_params[offset:offset + numel].view_as(p.data))
            offset += numel

    def _get_param_shapes(self, model: nn.Module) -> List[torch.Size]:
        return [p.shape for p in model.parameters()]

    def _model_to_params(self, model: nn.Module) -> List[torch.Tensor]:
        return [p.data.clone() for p in model.parameters()]

    def _params_to_model(self, model: nn.Module, params: List[torch.Tensor]) -> nn.Module:
        model_copy = copy.deepcopy(model)
        for p_new, p_old in zip(model_copy.parameters(), params):
            p_old_data = p_new.data.clone()
            p_new.data.copy_(p_old_data)
        for p_new, p_target in zip(model_copy.parameters(), params):
            p_new.data.copy_(p_target)
        return model_copy


class LinearInterpolationMerger(ModelMerger):
    def merge(
        self,
        models: List[nn.Module],
        weights: Optional[List[float]] = None,
        **kwargs: Any,
    ) -> nn.Module:
        if weights is None:
            weights = [1.0 / len(models)] * len(models)
        assert len(models) == len(weights), "Number of models must match number of weights"
        weight_sum = sum(weights)
        normalized_weights = [w / weight_sum for w in weights]
        ref_params = self._model_to_params(models[0])
        merged_params: List[torch.Tensor] = [torch.zeros_like(p) for p in ref_params]
        for model, weight in zip(models, normalized_weights):
            model_params = self._model_to_params(model)
            for i, p in enumerate(model_params):
                merged_params[i] += weight * p.to(merged_params[i].dtype)
        return self._params_to_model(models[0], merged_params)


class TaskArithmeticMerger(ModelMerger):
    def merge(
        self,
        models: List[nn.Module],
        weights: Optional[List[float]] = None,
        base_model: Optional[nn.Module] = None,
        **kwargs: Any,
    ) -> nn.Module:
        if weights is None:
            weights = [1.0 / len(models)] * len(models)
        assert len(models) == len(weights), "Number of models must match number of weights"
        if base_model is None:
            base_model = models[0]
        base_params = self._model_to_params(base_model)
        task_vectors: List[List[torch.Tensor]] = []
        for model in models:
            model_params = self._model_to_params(model)
            tv = [mp - bp for mp, bp in zip(model_params, base_params)]
            task_vectors.append(tv)
        merged_delta: List[torch.Tensor] = [torch.zeros_like(bp) for bp in base_params]
        for tv, weight in zip(task_vectors, weights):
            for i, delta in enumerate(tv):
                merged_delta[i] += weight * delta
        merged_params = [bp + md for bp, md in zip(base_params, merged_delta)]
        return self._params_to_model(base_model, merged_params)


class TIESMerger(ModelMerger):
    def merge(
        self,
        models: List[nn.Module],
        weights: Optional[List[float]] = None,
        base_model: Optional[nn.Module] = None,
        density: float = 0.5,
        **kwargs: Any,
    ) -> nn.Module:
        if weights is None:
            weights = [1.0 / len(models)] * len(models)
        assert len(models) == len(weights), "Number of models must match number of weights"
        if base_model is None:
            base_model = models[0]
        base_params = self._model_to_params(base_model)
        task_vectors: List[List[torch.Tensor]] = []
        for model in models:
            model_params = self._model_to_params(model)
            tv = [mp - bp for mp, bp in zip(model_params, base_params)]
            task_vectors.append(tv)
        trimmed_vectors: List[List[torch.Tensor]] = []
        for tv in task_vectors:
            trimmed = []
            for delta in tv:
                abs_vals = torch.abs(delta)
                threshold = torch.quantile(abs_vals, 1.0 - density)
                mask = abs_vals >= threshold
                trimmed.append(delta * mask)
            trimmed_vectors.append(trimmed)
        sign_counts: List[torch.Tensor] = []
        for i in range(len(base_params)):
            stacked = torch.stack([tv[i] for tv in trimmed_vectors])
            positive_count = (stacked > 0).sum(dim=0).float()
            negative_count = (stacked < 0).sum(dim=0).float()
            sign = torch.where(positive_count >= negative_count, torch.ones_like(positive_count), -torch.ones_like(positive_count))
            sign_counts.append(sign)
        merged_params: List[torch.Tensor] = []
        for i, bp in enumerate(base_params):
            merged_delta = torch.zeros_like(bp)
            total_weight = 0.0
            for tv, weight in zip(trimmed_vectors, weights):
                mask = tv[i].sign() == sign_counts[i]
                merged_delta += weight * tv[i] * mask
                total_weight += weight * mask.float().sum() / mask.numel()
            if total_weight > 0:
                merged_delta = merged_delta / max(total_weight, 1e-8)
            merged_params.append(bp + merged_delta)
        return self._params_to_model(base_model, merged_params)


class DAREMerger(ModelMerger):
    def merge(
        self,
        models: List[nn.Module],
        weights: Optional[List[float]] = None,
        base_model: Optional[nn.Module] = None,
        density: float = 0.5,
        **kwargs: Any,
    ) -> nn.Module:
        if weights is None:
            weights = [1.0 / len(models)] * len(models)
        assert len(models) == len(weights), "Number of models must match number of weights"
        if base_model is None:
            base_model = models[0]
        base_params = self._model_to_params(base_model)
        task_vectors: List[List[torch.Tensor]] = []
        for model in models:
            model_params = self._model_to_params(model)
            tv = [mp - bp for mp, bp in zip(model_params, base_params)]
            task_vectors.append(tv)
        rescaled_vectors: List[List[torch.Tensor]] = []
        for tv in task_vectors:
            rescaled = []
            for delta in tv:
                mask = torch.bernoulli(torch.full_like(delta, density))
                dropped = delta * mask
                scale_factor = 1.0 / density if density > 0 else 1.0
                rescaled.append(dropped * scale_factor)
            rescaled_vectors.append(rescaled)
        merged_params: List[torch.Tensor] = []
        for i, bp in enumerate(base_params):
            merged_delta = torch.zeros_like(bp)
            for rv, weight in zip(rescaled_vectors, weights):
                merged_delta += weight * rv[i]
            merged_params.append(bp + merged_delta)
        return self._params_to_model(base_model, merged_params)


class SLERPMerger(ModelMerger):
    def slerp(self, t: float, v0: torch.Tensor, v1: torch.Tensor) -> torch.Tensor:
        v0_flat = v0.view(-1)
        v1_flat = v1.view(-1)
        v0_norm = F.normalize(v0_flat.unsqueeze(0), dim=1).squeeze(0)
        v1_norm = F.normalize(v1_flat.unsqueeze(0), dim=1).squeeze(0)
        dot = torch.clamp(torch.dot(v0_norm, v1_norm), -1.0, 1.0)
        omega = torch.acos(dot)
        sin_omega = torch.sin(omega)
        if sin_omega.abs() < 1e-6:
            return (1.0 - t) * v0 + t * v1
        s0 = torch.sin((1.0 - t) * omega) / sin_omega
        s1 = torch.sin(t * omega) / sin_omega
        result_flat = s0 * v0_flat + s1 * v1_flat
        return result_flat.view_as(v0)

    def merge(
        self,
        models: List[nn.Module],
        weights: Optional[List[float]] = None,
        t: float = 0.5,
        **kwargs: Any,
    ) -> nn.Module:
        assert len(models) >= 2, "SLERP requires at least 2 models"
        params_0 = self._model_to_params(models[0])
        params_1 = self._model_to_params(models[1])
        merged_params: List[torch.Tensor] = []
        for p0, p1 in zip(params_0, params_1):
            merged_params.append(self.slerp(t, p0, p1))
        result = copy.deepcopy(models[0])
        for p, mp in zip(result.parameters(), merged_params):
            p.data.copy_(mp)
        if len(models) > 2:
            for i in range(2, len(models)):
                next_params = self._model_to_params(models[i])
                new_merged = []
                for mp, np_ in zip(merged_params, next_params):
                    new_merged.append(self.slerp(t, mp, np_))
                merged_params = new_merged
                for p, mp in zip(result.parameters(), merged_params):
                    p.data.copy_(mp)
        return result


class LayerWiseMerger(ModelMerger):
    def merge(
        self,
        models: List[nn.Module],
        weights: Optional[List[float]] = None,
        layer_weights: Optional[Dict[str, List[float]]] = None,
        **kwargs: Any,
    ) -> nn.Module:
        if weights is None:
            weights = [1.0 / len(models)] * len(models)
        assert len(models) == len(weights), "Number of models must match number of weights"
        weight_sum = sum(weights)
        normalized_weights = [w / weight_sum for w in weights]
        result = copy.deepcopy(models[0])
        named_params = list(result.named_parameters())
        param_names = [name for name, _ in named_params]
        all_model_params: List[Dict[str, torch.Tensor]] = []
        for model in models:
            all_model_params.append(dict(model.named_parameters()))
        for param_name in param_names:
            if layer_weights and param_name in layer_weights:
                layer_w = layer_weights[param_name]
                w_sum = sum(layer_w)
                effective_weights = [w / w_sum for w in layer_w]
            else:
                effective_weights = normalized_weights
            merged = torch.zeros_like(all_model_params[0][param_name])
            for i, model_dict in enumerate(all_model_params):
                merged += effective_weights[i] * model_dict[param_name]
            target_param = dict(result.named_parameters())[param_name]
            target_param.data.copy_(merged)
        return result


class GradientBasedMerger(ModelMerger):
    def merge(
        self,
        models: List[nn.Module],
        weights: Optional[List[float]] = None,
        base_model: Optional[nn.Module] = None,
        learning_rate: float = 0.01,
        num_iterations: int = 100,
        val_loader: Optional[Any] = None,
        loss_fn: Optional[Any] = None,
        **kwargs: Any,
    ) -> nn.Module:
        if weights is None:
            weights = [1.0 / len(models)] * len(models)
        if base_model is None:
            base_model = models[0]
        model = copy.deepcopy(base_model)
        for param in model.parameters():
            param.requires_grad_(False)
        weight_sum = sum(weights)
        normalized_weights = [w / weight_sum for w in weights]
        all_params: List[List[torch.Tensor]] = []
        for m in models:
            all_params.append(self._model_to_params(m))
        base_params = self._model_to_params(base_model)
        task_vectors: List[List[torch.Tensor]] = []
        for m_params in all_params:
            tv = [mp - bp for mp, bp in zip(m_params, base_params)]
            task_vectors.append(tv)
        scaling: List[torch.Tensor] = [torch.ones_like(bp) for bp in base_params]
        if val_loader is not None and loss_fn is not None:
            for tv_idx, tv in enumerate(task_vectors):
                for param_idx, delta in enumerate(tv):
                    max_abs = delta.abs().max()
                    if max_abs > 0:
                        scaling[param_idx] = torch.ones_like(scaling[param_idx])
        merged_delta: List[torch.Tensor] = [torch.zeros_like(bp) for bp in base_params]
        for tv, w in zip(task_vectors, normalized_weights):
            for i, delta in enumerate(tv):
                merged_delta[i] += w * delta / (scaling[i] + 1e-8)
        for p, md in zip(model.parameters(), merged_delta):
            p.data += learning_rate * md
        return model


__all__ = [
    "ModelMerger",
    "LinearInterpolationMerger",
    "TaskArithmeticMerger",
    "TIESMerger",
    "DAREMerger",
    "SLERPMerger",
    "LayerWiseMerger",
    "GradientBasedMerger",
]
