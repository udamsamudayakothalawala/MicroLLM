"""Tests for muLLM core pipeline (TinyTransformer, SimpleTokenizer, SimpleTrainer, GGUF export)."""

import os
import torch

from mullm.core.model.tiny_transformer import TinyTransformer, TinyConfig, TINY_CONFIGS
from mullm.core.tokenizer.simple_tokenizer import SimpleTokenizer
from mullm.core.data.text_dataset import TextDataset, load_text_file
from mullm.core.trainer.simple_trainer import SimpleTrainer, SimpleConfig, set_seed


def build_tiny(tmp_path):
    texts = load_text_file(os.path.join(os.path.dirname(__file__), "..", "..", "README.md"))
    tok = SimpleTokenizer(vocab_size=2000)
    tok.train(texts[:200] if len(texts) > 200 else texts)
    cfg = TINY_CONFIGS["tiny"]
    cfg.vocab_size = min(2000, len(tok.vocab))
    cfg.max_seq_len = 64
    model = TinyTransformer(cfg)
    return model, tok, texts


def test_tiny_transformer_dims():
    cfg = TinyConfig(vocab_size=100, max_seq_len=8, n_layers=1, n_heads=2, d_model=32, d_ff=64)
    model = TinyTransformer(cfg)
    ids = torch.randint(0, 100, (2, 8))
    out = model(input_ids=ids)
    assert out["logits"].shape == (2, 8, 100)
    out2 = model(input_ids=ids, labels=ids)
    assert out2["loss"] is not None
    assert out2["loss"].item() > 0


def test_tiny_transformer_masks(tmp_path):
    cfg = TinyConfig(vocab_size=100, max_seq_len=8, n_layers=1, n_heads=2, d_model=32, d_ff=64)
    model = TinyTransformer(cfg)
    ids = torch.randint(0, 100, (1, 4))
    logits = model(input_ids=ids)["logits"]
    assert logits.shape == (1, 4, 100)


def test_simple_tokenizer_roundtrip(tmp_path):
    tok = SimpleTokenizer(vocab_size=300)
    corpus = ["hello world this is a test", "the quick brown fox jumps", "neural networks learn"]
    tok.train(corpus)
    ids = tok.encode("hello world this is a test")
    assert len(ids) > 0
    path = tmp_path / "tokenizer.json"
    tok.save(str(path))
    loaded = SimpleTokenizer.load(str(path))
    assert loaded.encode("hello world") == tok.encode("hello world")


def test_text_dataset():
    tok = SimpleTokenizer(vocab_size=300)
    tok.train(["hello world", "test sentence here"])
    ds = TextDataset(["hello world"], tokenizer=tok, max_len=16)
    item = ds[0]
    assert item["input_ids"].shape == (16,)
    assert item["labels"].shape == (16,)
    assert item["attention_mask"].shape == (16,)


def test_simple_trainer_smoke(tmp_path):
    set_seed(42)
    tok = SimpleTokenizer(vocab_size=400)
    corpus = ["aaa bbb ccc ddd", "hello world test", "one two three"]
    tok.train(corpus)
    cfg = TinyConfig(vocab_size=min(400, len(tok.vocab)), max_seq_len=16, n_layers=1, n_heads=2, d_model=32, d_ff=64)
    model = TinyTransformer(cfg)
    ds = TextDataset(corpus, tokenizer=tok, max_len=16)
    tcfg = SimpleConfig(
        num_epochs=1,
        batch_size=2,
        max_steps=5,
        save_steps=0,
        eval_steps=0,
        log_steps=1,
        bf16=False,
        output_dir=str(tmp_path),
    )
    trainer = SimpleTrainer(model=model, config=tcfg, train_dataset=ds)
    result = trainer.train()
    assert result["status"] == "completed"
    assert os.path.exists(tmp_path / "checkpoint-final" / "model.pt")
    assert os.path.exists(tmp_path / "checkpoint-final" / "config.json")


def test_gguf_export(tmp_path):
    cfg = TinyConfig(vocab_size=100, max_seq_len=8, n_layers=1, n_heads=2, d_model=32, d_ff=64)
    model = TinyTransformer(cfg)
    from mullm.core.export.gguf_export import GGUFExporter

    out = str(tmp_path / "model.gguf")
    GGUFExporter().export(model, out, dtype="q4_0", architecture="llama")
    assert os.path.exists(out)
    assert os.path.getsize(out) > 0