import json
import os
import re
from collections import Counter, defaultdict
from typing import Dict, Iterator, List, Optional, Sequence, Set, Tuple

from .base import BaseTokenizer, SpecialTokens


def _score_pair(
    pair: Tuple[str, str],
    pair_counts: Counter[Tuple[str, str]],
    token_counts: Counter[str],
) -> float:
    a, b = pair
    total_pair = pair_counts[pair]
    total_a = token_counts.get(a, 1)
    total_b = token_counts.get(b, 1)
    if total_a == 0 or total_b == 0:
        return 0.0
    return total_pair / (total_a * total_b)


class WordPieceTokenizer(BaseTokenizer):
    def __init__(
        self,
        vocab: Optional[Dict[str, int]] = None,
        special_tokens: Optional[SpecialTokens] = None,
        unk_token: str = "[UNK]",
        max_input_chars_per_word: int = 100,
    ) -> None:
        super().__init__(special_tokens)
        self._vocab: Dict[str, int] = {}
        self._decoder: Dict[int, str] = {}
        self._max_input_chars_per_word = max_input_chars_per_word
        self._initial_alphabet: Set[str] = set()

        if vocab is not None:
            self._vocab = dict(vocab)
            self._decoder = {v: k for k, v in self._vocab.items()}

        if self._special_tokens.unk_token is None:
            self._special_tokens.unk_token = unk_token

        for st in self._special_tokens.all_special_tokens:
            if st not in self._vocab:
                idx = len(self._vocab) + len(self._added_tokens)
                self._added_tokens[st] = idx
                self._added_tokens_decoder[idx] = st

    @property
    def vocab_size(self) -> int:
        return len(self._vocab) + len(self._added_tokens)

    def _token_to_id(self, token: str) -> int:
        if token in self._added_tokens:
            return self._added_tokens[token]
        if token in self._vocab:
            return self._vocab[token]
        unk = self._special_tokens.unk_token
        if unk is not None and unk in self._vocab:
            return self._vocab[unk]
        if unk is not None and unk in self._added_tokens:
            return self._added_tokens[unk]
        return -1

    def _id_to_token(self, idx: int) -> str:
        if idx in self._added_tokens_decoder:
            return self._added_tokens_decoder[idx]
        return self._decoder.get(idx, self._special_tokens.unk_token or "[UNK]")

    def _get_vocab(self) -> Dict[str, int]:
        full = dict(self._vocab)
        full.update(self._added_tokens)
        return full

    def _set_vocab(self, vocab: Dict[str, int]) -> None:
        added = {k: v for k, v in vocab.items() if k in self._added_tokens or k in self._special_tokens.all_special_tokens}
        base = {k: v for k, v in vocab.items() if k not in added}
        self._vocab = base
        self._decoder = {v: k for k, v in self._vocab.items()}
        self._added_tokens = added
        self._added_tokens_decoder = {v: k for k, v in added.items()}

    def encode(self, text: str, add_special_tokens: bool = True) -> List[int]:
        tokens: List[int] = []
        if add_special_tokens:
            cls_id = self._token_to_id(self._special_tokens.cls_token) if self._special_tokens.cls_token else None
            sep_id = self._token_to_id(self._special_tokens.sep_token) if self._special_tokens.sep_token else None
            if cls_id is not None and cls_id >= 0:
                tokens.append(cls_id)

        for word in re.findall(r"\S+|\s+", text):
            word_tokens = self._tokenize_word(word.strip())
            for wt in word_tokens:
                tid = self._token_to_id(wt)
                if tid >= 0:
                    tokens.append(tid)
                else:
                    unk = self._special_tokens.unk_token
                    if unk is not None:
                        uid = self._token_to_id(unk)
                        if uid >= 0:
                            tokens.append(uid)

        if add_special_tokens:
            sep_id = self._token_to_id(self._special_tokens.sep_token) if self._special_tokens.sep_token else None
            if sep_id is not None and sep_id >= 0:
                tokens.append(sep_id)

        return tokens

    def _tokenize_word(self, word: str) -> List[str]:
        if not word:
            return []
        if len(word) > self._max_input_chars_per_word:
            return [word]

        is_bad = False
        start = 0
        tokens: List[str] = []
        while start < len(word):
            end = len(word)
            cur_str = None
            while end > start:
                sub_str = word[start:end]
                if start > 0:
                    sub_str = "##" + sub_str
                if sub_str in self._vocab or sub_str in self._added_tokens:
                    cur_str = sub_str
                    break
                end -= 1
            if cur_str is None:
                is_bad = True
                break
            tokens.append(cur_str)
            start = end

        if is_bad:
            unk = self._special_tokens.unk_token
            return [unk] if unk is not None else ["[UNK]"]

        return tokens

    def decode(self, ids: Sequence[int], skip_special_tokens: bool = True) -> str:
        special_ids = set(self.all_special_ids()) if skip_special_tokens else set()
        pieces: List[str] = []
        for idx in ids:
            if idx in special_ids:
                continue
            token = self._id_to_token(idx)
            if token.startswith("##"):
                if pieces:
                    pieces[-1] += token[2:]
                else:
                    pieces.append(token[2:])
            else:
                pieces.append(token)
        return " ".join(pieces).replace("  ", " ").strip()

    def _build_word_frequencies(self, texts: Iterator[str]) -> Counter[str]:
        freq: Counter[str] = Counter()
        for text in texts:
            for word in re.findall(r"\S+|\s+", text):
                cleaned = word.strip()
                if cleaned:
                    freq[cleaned] += 1
        return freq

    def train_from_iterator(
        self,
        texts: Iterator[str],
        vocab_size: int,
        show_progress: bool = True,
    ) -> None:
        self._vocab = {}
        self._decoder = {}
        self._added_tokens = {}
        self._added_tokens_decoder = {}

        word_freqs = self._build_word_frequencies(texts)

        char_set: Set[str] = set()
        for word in word_freqs:
            for ch in word:
                char_set.add(ch)

        sorted_chars = sorted(char_set)
        self._vocab = {ch: i for i, ch in enumerate(sorted_chars)}
        self._decoder = {v: k for k, v in self._vocab.items()}

        if self._special_tokens.unk_token is not None and self._special_tokens.unk_token not in self._vocab:
            idx = len(self._vocab)
            self._vocab[self._special_tokens.unk_token] = idx
            self._decoder[idx] = self._special_tokens.unk_token

        initial_vocab_size = len(self._vocab)
        num_merges = vocab_size - initial_vocab_size
        if num_merges <= 0:
            return

        splits: Dict[str, List[str]] = {}
        for word in word_freqs:
            splits[word] = list(word)

        if show_progress:
            try:
                from tqdm import tqdm

                iterator = tqdm(range(num_merges), desc="Training WordPiece merges")
            except ImportError:
                iterator = range(num_merges)
        else:
            iterator = range(num_merges)

        for _ in iterator:
            pair_counts: Counter[Tuple[str, str]] = Counter()
            token_counts: Counter[str] = Counter()

            for word, split in splits.items():
                freq = word_freqs[word]
                for i in range(len(split) - 1):
                    a = split[i]
                    b = split[i + 1]
                    pair_counts[(a, b)] += freq
                    token_counts[a] += freq
                if split:
                    token_counts[split[-1]] += freq

            if not pair_counts:
                break

            best_pair = max(
                pair_counts,
                key=lambda p: _score_pair(p, pair_counts, token_counts),
            )
            a, b = best_pair
            merged_token = a + b

            if a.startswith("##"):
                merged_token = a + b
            else:
                merged_token = a + b

            continuation = "##" + b
            merged_cont = "##" + merged_token

            self._vocab[merged_token] = len(self._vocab)
            self._decoder[self._vocab[merged_token]] = merged_token

            if len(self._vocab) >= vocab_size:
                break

            new_splits: Dict[str, List[str]] = {}
            for word, split in splits.items():
                new_split: List[str] = []
                i = 0
                while i < len(split):
                    if i < len(split) - 1 and split[i] == a and split[i + 1] == b:
                        new_split.append(merged_token)
                        i += 2
                    else:
                        new_split.append(split[i])
                        i += 1
                new_splits[word] = new_split
            splits = new_splits

    def save(self, path: str) -> None:
        os.makedirs(os.path.dirname(path) if os.path.dirname(path) else ".", exist_ok=True)
        data = {
            "vocab": self._vocab,
            "special_tokens": self._special_tokens.to_dict(),
            "added_tokens": self._added_tokens,
            "max_input_chars_per_word": self._max_input_chars_per_word,
        }
        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)

    @classmethod
    def load(cls, path: str) -> "WordPieceTokenizer":
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        special_tokens = SpecialTokens.from_dict(data.get("special_tokens", {}))
        return cls(
            vocab=data.get("vocab"),
            special_tokens=special_tokens,
            max_input_chars_per_word=data.get("max_input_chars_per_word", 100),
        )

    @classmethod
    def from_pretrained(
        cls, vocab_path: str, special_tokens: Optional[SpecialTokens] = None
    ) -> "WordPieceTokenizer":
        vocab: Dict[str, int] = {}
        with open(vocab_path, "r", encoding="utf-8") as f:
            vocab_data = json.load(f)
            if isinstance(vocab_data, list):
                vocab = {t: i for i, t in enumerate(vocab_data)}
            elif isinstance(vocab_data, dict):
                vocab = vocab_data
        return cls(vocab=vocab, special_tokens=special_tokens)
