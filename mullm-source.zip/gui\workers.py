"""muLLM GUI - Background workers (training, evaluation)."""

import torch  # noqa: F401,E402  (must load before PyQt5 to avoid DLL conflicts on Windows)

import math
import os
import traceback

from PyQt5.QtCore import QThread, pyqtSignal

from mullm.core.data.text_dataset import TextDataset, load_text_file
from mullm.core.model.tiny_transformer import TinyTransformer, TINY_CONFIGS
from mullm.core.tokenizer.simple_tokenizer import SimpleTokenizer
from mullm.core.trainer.simple_trainer import SimpleTrainer, SimpleConfig, set_seed


class TrainWorker(QThread):
    log_signal = pyqtSignal(str)
    progress_signal = pyqtSignal(int, int)
    metrics_signal = pyqtSignal(dict)
    status_signal = pyqtSignal(str)
    finished_signal = pyqtSignal(dict)
    error_signal = pyqtSignal(str)

    def __init__(self, config, train_dataset=None, parent=None):
        super().__init__(parent)
        self.config = config
        self.train_dataset = train_dataset
        self._stop = False
        self.total_steps = 0

    def run(self):
        try:
            if self._stop:
                return
            self.log_signal.emit("Training BPE tokenizer on your data...")
            tokenizer = SimpleTokenizer(vocab_size=self.config.get("vocab_size", 3000))
            tokenizer.train(self.train_dataset)
            os.makedirs(self.config["output_dir"], exist_ok=True)
            tok_path = os.path.join(self.config["output_dir"], "tokenizer.json")
            tokenizer.save(tok_path)
            self.log_signal.emit(f"Tokenizer saved: {tok_path} (vocab={len(tokenizer.vocab)})")

            self.log_signal.emit(f"Building {self.config.get('size', 'tiny')} transformer...")
            model_cfg = TINY_CONFIGS.get(self.config.get("size", "tiny"), TINY_CONFIGS["tiny"])
            model_cfg.vocab_size = min(self.config.get("vocab_size", 3000), len(tokenizer.vocab))
            model_cfg.max_seq_len = self.config.get("max_seq_length", 256)
            model = TinyTransformer(model_cfg)
            self.log_signal.emit(f"Model params: {model.count_parameters():,}")

            max_len = self.config.get("max_seq_length", 256)
            train_ds = TextDataset(self.train_dataset, tokenizer=tokenizer, max_len=max_len)
            eval_ds = train_ds if self.config.get("eval_steps", 0) > 0 else None

            tcfg = SimpleConfig(
                output_dir=self.config["output_dir"],
                num_epochs=self.config.get("num_epochs", 3),
                batch_size=self.config.get("batch_size", 8),
                learning_rate=self.config.get("learning_rate", 3e-4),
                warmup_steps=self.config.get("warmup_steps", 100),
                max_steps=self.config.get("max_steps", -1),
                save_steps=self.config.get("save_steps", 500),
                eval_steps=self.config.get("eval_steps", 0),
                log_steps=5,
                bf16=self.config.get("bf16", True),
                seed=42,
                device=self.config.get("device", "auto"),
                gradient_accumulation_steps=1,
            )

            total_loader = math.ceil(len(self.train_dataset) / tcfg.batch_size)
            self.total_steps = tcfg.max_steps if tcfg.max_steps > 0 else (
                total_loader * tcfg.num_epochs // tcfg.gradient_accumulation_steps
            )

            set_seed(42)
            trainer = SimpleTrainer(model=model, config=tcfg, train_dataset=train_ds, eval_dataset=eval_ds)
            trainer.on_log = lambda msg: self.log_signal.emit(msg)
            trainer.on_metrics = lambda m: self._emit_metrics(m)
            self._trainer = trainer

            self.status_signal.emit("Training started...")
            result = trainer.train()
            self.finished_signal.emit(result)

        except Exception as e:
            self.error_signal.emit(f"{type(e).__name__}: {e}\n{traceback.format_exc()}")

    def _emit_metrics(self, metrics):
        self.metrics_signal.emit(metrics)
        step = metrics.get("step", 0)
        self.progress_signal.emit(step, max(self.total_steps, 1))

    def stop(self):
        self._stop = True
        trainer = getattr(self, "_trainer", None)
        if trainer is not None:
            trainer.stop()


class EvalWorker(QThread):
    result_signal = pyqtSignal(dict)
    status_signal = pyqtSignal(str)
    error_signal = pyqtSignal(str)

    def __init__(self, state, parent=None):
        super().__init__(parent)
        self.state = state

    def run(self):
        try:
            import torch
            from torch.utils.data import Dataset

            from mullm.core.evaluation.simple_eval import evaluate

            model = self.state["model"]
            tok = self.state["tokenizer"]

            class SampleDataset(Dataset):
                def __len__(self):
                    return len(ids)

                def __getitem__(self, i):
                    t = torch.tensor(ids[i])
                    return {"input_ids": t, "labels": t, "attention_mask": torch.ones_like(t)}

            texts = [
                "The quick brown fox jumps over the lazy dog.",
                "Artificial intelligence is the simulation of human intelligence in machines.",
                "Language models predict the next token in a sequence.",
                "Neural networks adjust weights through backpropagation.",
            ]
            ids = [tok.encode(t, add_special_tokens=False)[: model.config.max_seq_len] for t in texts]
            max_len = max(len(x) for x in ids)
            ids = [x + [0] * (max_len - len(x)) for x in ids]

            self.status_signal.emit("evaluating loss / perplexity / accuracy...")
            metrics = evaluate(model, SampleDataset(), batch_size=2)
            metrics["perplexity"] = round(metrics["perplexity"], 2)
            self.result_signal.emit(metrics)
        except Exception as e:
            self.error_signal.emit(f"{type(e).__name__}: {e}\n{traceback.format_exc()}")