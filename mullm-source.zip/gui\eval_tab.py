"""muLLM GUI - Eval tab: test the trained model before exporting to GGUF."""

import torch  # noqa: F401,E402  (must load before PyQt5 to avoid DLL conflicts on Windows)

import math
import os

from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QPushButton, QLabel,
    QTextEdit, QGroupBox, QGridLayout, QFileDialog, QMessageBox,
    QLineEdit, QSpinBox, QComboBox
)
from PyQt5.QtCore import Qt

from .workers import EvalWorker


class EvalTab(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.worker = None
        self.state = None
        self.build_ui()

    def build_ui(self):
        main = QVBoxLayout(self)
        main.setContentsMargins(12, 12, 12, 12)

        header = QLabel("TEST MODEL")
        header.setProperty("class", "heading")
        main.addWidget(header)
        sub = QLabel("Evaluate a trained checkpoint (loss, perplexity, accuracy) and test generation before export.")
        sub.setProperty("class", "subheading")
        main.addWidget(sub)

        load_group = QGroupBox("Model Checkpoint")
        lg = QGridLayout(load_group)
        self.checkpoint_edit = QLineEdit()
        self.checkpoint_edit.setPlaceholderText("Path to output dir or model.pt")
        self.browse_btn = QPushButton("Browse")
        self.browse_btn.setProperty("class", "btn-secondary")
        self.browse_btn.clicked.connect(self.browse_checkpoint)
        lg.addWidget(self.checkpoint_edit, 0, 0, 1, 3)
        lg.addWidget(self.browse_btn, 0, 3)

        self.size_combo = QComboBox()
        self.size_combo.addItems(["tiny", "small", "base", "medium"])
        lg.addWidget(QLabel("Size:"), 1, 0)
        lg.addWidget(self.size_combo, 1, 1)

        self.max_tokens_spin = QSpinBox()
        self.max_tokens_spin.setRange(8, 4096)
        self.max_tokens_spin.setValue(64)
        lg.addWidget(QLabel("Gen tokens:"), 1, 2)
        lg.addWidget(self.max_tokens_spin, 1, 3)

        self.load_btn = QPushButton("Load Model")
        self.load_btn.setProperty("class", "btn-success")
        self.load_btn.clicked.connect(self.load_model)
        lg.addWidget(self.load_btn, 2, 0, 1, 4)
        main.addWidget(load_group)

        metrics_group = QGroupBox("Metrics")
        mg = QGridLayout(metrics_group)
        self.loss_label = QLabel("—")
        self.loss_label.setProperty("class", "metric-value")
        mg.addWidget(QLabel("Loss:"), 0, 0)
        mg.addWidget(self.loss_label, 0, 1)
        self.ppl_label = QLabel("—")
        mg.addWidget(QLabel("Perplexity:"), 1, 0)
        mg.addWidget(self.ppl_label, 1, 1)
        self.acc_label = QLabel("—")
        mg.addWidget(QLabel("Accuracy:"), 2, 0)
        mg.addWidget(self.acc_label, 2, 1)
        self.eval_btn = QPushButton("▶ Run Evaluation")
        self.eval_btn.setEnabled(False)
        self.eval_btn.setProperty("class", "btn-secondary")
        self.eval_btn.clicked.connect(self.run_eval)
        mg.addWidget(self.eval_btn, 0, 2, 3, 1)
        main.addWidget(metrics_group)

        gen_group = QGroupBox("Generation Test")
        gg = QGridLayout(gen_group)
        self.prompt_edit = QLineEdit("The quick brown fox")
        gg.addWidget(self.prompt_edit, 0, 0, 1, 2)
        self.generate_btn = QPushButton("▶ Generate")
        self.generate_btn.setEnabled(False)
        self.generate_btn.setProperty("class", "btn-secondary")
        self.generate_btn.clicked.connect(self.generate)
        gg.addWidget(self.generate_btn, 0, 2)
        main.addWidget(gen_group)

        self.output = QTextEdit()
        self.output.setReadOnly(True)
        self.output.setPlaceholderText("Evaluation and generation output...")
        main.addWidget(QLabel("OUTPUT"))
        main.addWidget(self.output)

        self.export_btn = QPushButton("✅ Ready - Go to Export & GGUF tab")
        self.export_btn.setProperty("class", "btn-success")
        self.export_btn.setEnabled(False)
        main.addWidget(self.export_btn)

    def browse_checkpoint(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "Select Checkpoint", "", "Model checkpoints (*.pt);;All Files (*.*)"
        )
        if path:
            self.checkpoint_edit.setText(path)

    def load_model(self):
        ckpt = self.checkpoint_edit.text().strip()
        if not ckpt:
            QMessageBox.warning(self, "Missing", "Select a checkpoint first.")
            return
        try:
            state = load_checkpoint(ckpt, self.size_combo.currentText())
            self.state = state
            self.eval_btn.setEnabled(True)
            self.generate_btn.setEnabled(True)
            self.export_btn.setEnabled(True)
            self.output.append(
                f"Model loaded: {state['model'].count_parameters():,} params "
                f"| vocab={state['tokenizer'].vocab_size()} | seq_len={state['config'].max_seq_len}"
            )
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to load model:\n{e}")

    def run_eval(self):
        if not self.state:
            return
        self.eval_btn.setEnabled(False)
        self.output.append("Running evaluation (loss / perplexity / accuracy)...")
        self.worker = EvalWorker(state=self.state)
        self.worker.result_signal.connect(self._on_eval_result)
        self.worker.error_signal.connect(self._on_error)
        self.worker.status_signal.connect(lambda s: self.output.append(f"  {s}"))
        self.worker.start()

    def generate(self):
        if not self.state:
            return
        prompt = self.prompt_edit.text().strip()
        if not prompt:
            self.output.append("  (empty prompt)")
            return
        model = self.state["model"]
        tok = self.state["tokenizer"]
        import torch

        ids = tok.encode(prompt, add_special_tokens=False)
        max_len = model.config.max_seq_len
        ids = ids[: max_len]
        input_ids = torch.tensor([ids], dtype=torch.long)
        max_gen = min(self.max_tokens_spin.value(), max_len - input_ids.shape[1])
        with torch.no_grad():
            for _ in range(max(1, max_gen)):
                outputs = model(input_ids=input_ids)
                next_id = outputs["logits"][0, -1].argmax().item()
                if next_id in (tok.eos_token_id, 0):
                    break
                input_ids = torch.cat([input_ids, torch.tensor([[next_id]], dtype=torch.long)], dim=1)
        tokens = input_ids[0].tolist()[len(ids):]
        resp = tok.decode(tokens)
        self.output.append(f"Prompt: {prompt}")
        self.output.append(f"Model:  {resp}\n")

    def _on_eval_result(self, metrics):
        self.eval_btn.setEnabled(True)
        self.loss_label.setText(f"{metrics['loss']:.4f}")
        self.ppl_label.setText(f"{metrics['perplexity']:.2f}")
        self.acc_label.setText(f"{metrics['accuracy']*100:.2f}%")
        self.output.append(
            f"Evaluation complete: loss={metrics['loss']:.4f} "
            f"ppl={metrics['perplexity']:.2f} acc={metrics['accuracy']*100:.2f}%\n"
        )

    def _on_error(self, err):
        self.eval_btn.setEnabled(True)
        self.output.append(f"ERROR: {err}")


def load_checkpoint(ckpt, size):
    import json
    import torch

    from mullm.core.model.tiny_transformer import TinyTransformer, TinyConfig, TINY_CONFIGS
    from mullm.core.tokenizer.simple_tokenizer import SimpleTokenizer

    if ckpt.endswith(".pt"):
        state_dict_path = ckpt
        cfg_path = ckpt.replace("model.pt", "config.json")
    elif os.path.isdir(ckpt):
        cands = [os.path.join(ckpt, "model.pt"), os.path.join(ckpt, "checkpoint-final", "model.pt")]
        state_dict_path = None
        cfg_path = None
        for c in cands:
            if os.path.exists(c):
                state_dict_path = c
                alt = c.replace("model.pt", "config.json")
                if os.path.exists(alt):
                    cfg_path = alt
                break
        if not state_dict_path:
            raise FileNotFoundError(f"No model.pt found under {ckpt}")
    else:
        state_dict_path = ckpt
        cfg_path = ckpt.replace("model.pt", "config.json")

    model_cfg = TINY_CONFIGS.get(size, TINY_CONFIGS["small"])
    if cfg_path and os.path.exists(cfg_path):
        with open(cfg_path) as f:
            meta = json.load(f)
        saved = meta.get("model_config")
        if saved:
            allowed = set(TinyConfig.__dataclass_fields__)
            model_cfg = TinyConfig(**{k: v for k, v in saved.items() if k in allowed})

    model = TinyTransformer(model_cfg)
    model.load_state_dict(torch.load(state_dict_path, map_location="cpu"), strict=False)
    model.eval()

    tok_path = None
    if cfg_path:
        tok_path = os.path.join(os.path.dirname(state_dict_path), "..", "tokenizer.json")
    if not tok_path or not os.path.exists(tok_path):
        out_dir = ckpt if os.path.isdir(ckpt) else os.path.dirname(ckpt)
        tok_path = os.path.join(out_dir, "tokenizer.json")
        dirpath = os.path.dirname(state_dict_path)
        parent = os.path.dirname(dirpath)
        if os.path.exists(os.path.join(parent, "tokenizer.json")):
            tok_path = os.path.join(parent, "tokenizer.json")
    if not os.path.exists(tok_path):
        tok = SimpleTokenizer(vocab_size=model_cfg.vocab_size)
        tok._build_vocab()
    else:
        tok = SimpleTokenizer.load(tok_path)

    return {"model": model, "tokenizer": tok, "config": model_cfg, "dir": os.path.dirname(state_dict_path)}