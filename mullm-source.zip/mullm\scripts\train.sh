#!/usr/bin/env bash
# muLLM Training Launcher
# Usage: ./train.sh --model <model_path> --dataset <dataset_path> [options]

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"

MODEL="${MULLM_MODEL_PATH:-}"
DATASET="${MULLM_DATASET_PATH:-}"
OUTPUT_DIR="${MULLM_OUTPUT_DIR:-./output}"
BATCH_SIZE="${MULLM_BATCH_SIZE:-8}"
LEARNING_RATE="${MULLM_LEARNING_RATE:-5e-5}"
EPOCHS="${MULLM_EPOCHS:-3}"
MAX_STEPS="${MULLM_MAX_STEPS:--1}"
WARMUP_STEPS="${MULLM_WARMUP_STEPS:-0}"
BF16="${MULLM_BF16:-true}"
FP16="${MULLM_FP16:-false}"
GRADIENT_ACCUMULATION="${MULLM_GRADIENT_ACCUMULATION_STEPS:-1}"
WEIGHT_DECAY="${MULLM_WEIGHT_DECAY:-0.01}"
MAX_GRAD_NORM="${MULLM_MAX_GRAD_NORM:-1.0}"
SAVE_STEPS="${MULLM_SAVE_STEPS:-500}"
EVAL_STEPS="${MULLM_EVAL_STEPS:-500}"
LOGGING_STEPS="${MULLM_LOGGING_STEPS:-10}"
SEED="${MULLM_SEED:-42}"
MAX_SEQ_LENGTH="${MULLM_MAX_SEQ_LENGTH:-2048}"
LOG_LEVEL="${MULLM_LOG_LEVEL:-INFO}"

DEEPSPEED="${MULLM_DEEPSPEED:-false}"
DEEPSPEED_STAGE="${MULLM_DEEPSPEED_STAGE:-2}"
LORA_RANK="${MULLM_LORA_RANK:-}"
LORA_ALPHA="${MULLM_LORA_ALPHA:-32}"
LORA_DROPOUT="${MULLM_LORA_DROPOUT:-0.05}"
LORA_TARGET_MODULES="${MULLM_LORA_TARGET_MODULES:-}"

while [[ $# -gt 0 ]]; do
    case $1 in
        --model) MODEL="$2"; shift 2 ;;
        --dataset) DATASET="$2"; shift 2 ;;
        --output-dir) OUTPUT_DIR="$2"; shift 2 ;;
        --batch-size) BATCH_SIZE="$2"; shift 2 ;;
        --learning-rate) LEARNING_RATE="$2"; shift 2 ;;
        --epochs) EPOCHS="$2"; shift 2 ;;
        --max-steps) MAX_STEPS="$2"; shift 2 ;;
        --warmup-steps) WARMUP_STEPS="$2"; shift 2 ;;
        --bf16) BF16="$2"; shift 2 ;;
        --fp16) FP16="$2"; shift 2 ;;
        --gradient-accumulation) GRADIENT_ACCUMULATION="$2"; shift 2 ;;
        --weight-decay) WEIGHT_DECAY="$2"; shift 2 ;;
        --max-grad-norm) MAX_GRAD_NORM="$2"; shift 2 ;;
        --save-steps) SAVE_STEPS="$2"; shift 2 ;;
        --eval-steps) EVAL_STEPS="$2"; shift 2 ;;
        --logging-steps) LOGGING_STEPS="$2"; shift 2 ;;
        --seed) SEED="$2"; shift 2 ;;
        --max-seq-length) MAX_SEQ_LENGTH="$2"; shift 2 ;;
        --log-level) LOG_LEVEL="$2"; shift 2 ;;
        --deepspeed) DEEPSPEED="true"; shift ;;
        --deepspeed-stage) DEEPSPEED_STAGE="$2"; shift 2 ;;
        --lora-rank) LORA_RANK="$2"; shift 2 ;;
        --lora-alpha) LORA_ALPHA="$2"; shift 2 ;;
        --lora-dropout) LORA_DROPOUT="$2"; shift 2 ;;
        --lora-target-modules) LORA_TARGET_MODULES="$2"; shift 2 ;;
        -h|--help)
            echo "Usage: $0 --model <model> --dataset <dataset> [options]"
            echo ""
            echo "Required:"
            echo "  --model <path>            Model name or path"
            echo "  --dataset <path>          Dataset name or path"
            echo ""
            echo "Training:"
            echo "  --output-dir <dir>        Output directory (default: ./output)"
            echo "  --batch-size <int>        Per-device batch size (default: 8)"
            echo "  --learning-rate <float>   Learning rate (default: 5e-5)"
            echo "  --epochs <int>            Number of epochs (default: 3)"
            echo "  --max-steps <int>         Max training steps, -1=auto (default: -1)"
            echo "  --warmup-steps <int>      Warmup steps (default: 0)"
            echo "  --gradient-accumulation <int>  Gradient accumulation steps (default: 1)"
            echo "  --weight-decay <float>    Weight decay (default: 0.01)"
            echo "  --max-grad-norm <float>   Max gradient norm (default: 1.0)"
            echo "  --save-steps <int>        Checkpoint save interval (default: 500)"
            echo "  --eval-steps <int>        Evaluation interval (default: 500)"
            echo "  --logging-steps <int>     Logging interval (default: 10)"
            echo "  --max-seq-length <int>    Max sequence length (default: 2048)"
            echo "  --seed <int>              Random seed (default: 42)"
            echo ""
            echo "Precision:"
            echo "  --bf16 <true|false>       Enable BF16 (default: true)"
            echo "  --fp16 <true|false>       Enable FP16 (default: false)"
            echo ""
            echo "LoRA:"
            echo "  --lora-rank <int>         LoRA rank (enables LoRA training)"
            echo "  --lora-alpha <int>        LoRA alpha (default: 32)"
            echo "  --lora-dropout <float>    LoRA dropout (default: 0.05)"
            echo "  --lora-target-modules <modules>  Comma-separated target modules"
            echo ""
            echo "Distributed:"
            echo "  --deepspeed               Enable DeepSpeed"
            echo "  --deepspeed-stage <0-3>   ZeRO stage (default: 2)"
            exit 0
            ;;
        *) echo "Unknown option: $1"; exit 1 ;;
    esac
done

if [[ -z "$MODEL" ]]; then
    echo "Error: --model is required" >&2
    exit 1
fi
if [[ -z "$DATASET" ]]; then
    echo "Error: --dataset is required" >&2
    exit 1
fi

echo "============================================"
echo "  muLLM Training"
echo "============================================"
echo "Model:           $MODEL"
echo "Dataset:         $DATASET"
echo "Output:          $OUTPUT_DIR"
echo "Batch size:      $BATCH_SIZE"
echo "Learning rate:   $LEARNING_RATE"
echo "Epochs:          $EPOCHS"
echo "Max steps:       $MAX_STEPS"
echo "Warmup steps:    $WARMUP_STEPS"
echo "BF16:            $BF16"
echo "FP16:            $FP16"
echo "Grad accum:      $GRADIENT_ACCUMULATION"
echo "Seed:            $SEED"
echo "Log level:       $LOG_LEVEL"
if [[ -n "$LORA_RANK" ]]; then
    echo "LoRA rank:       $LORA_RANK"
    echo "LoRA alpha:      $LORA_ALPHA"
    echo "LoRA dropout:    $LORA_DROPOUT"
fi
if [[ "$DEEPSPEED" == "true" ]]; then
    echo "DeepSpeed:       enabled (stage $DEEPSPEED_STAGE)"
fi
echo "============================================"

mkdir -p "$OUTPUT_DIR"

export MULLM_MODEL_PATH="$MODEL"
export MULLM_DATASET_PATH="$DATASET"
export MULLM_OUTPUT_DIR="$OUTPUT_DIR"
export MULLM_BATCH_SIZE="$BATCH_SIZE"
export MULLM_LEARNING_RATE="$LEARNING_RATE"
export MULLM_EPOCHS="$EPOCHS"
export MULLM_MAX_STEPS="$MAX_STEPS"
export MULLM_WARMUP_STEPS="$WARMUP_STEPS"
export MULLM_BF16="$BF16"
export MULLM_FP16="$FP16"
export MULLM_GRADIENT_ACCUMULATION_STEPS="$GRADIENT_ACCUMULATION"
export MULLM_WEIGHT_DECAY="$WEIGHT_DECAY"
export MULLM_MAX_GRAD_NORM="$MAX_GRAD_NORM"
export MULLM_SAVE_STEPS="$SAVE_STEPS"
export MULLM_EVAL_STEPS="$EVAL_STEPS"
export MULLM_LOGGING_STEPS="$LOGGING_STEPS"
export MULLM_SEED="$SEED"
export MULLM_MAX_SEQ_LENGTH="$MAX_SEQ_LENGTH"
export MULLM_LOG_LEVEL="$LOG_LEVEL"

if [[ -n "$LORA_RANK" ]]; then
    export MULLM_LORA_RANK="$LORA_RANK"
    export MULLM_LORA_ALPHA="$LORA_ALPHA"
    export MULLM_LORA_DROPOUT="$LORA_DROPOUT"
    [[ -n "$LORA_TARGET_MODULES" ]] && export MULLM_LORA_TARGET_MODULES="$LORA_TARGET_MODULES"
fi

if [[ "$DEEPSPEED" == "true" ]]; then
    export MULLM_DEEPSPEED="true"
    export MULLM_DEEPSPEED_STAGE="$DEEPSPEED_STAGE"

    CMD=(deepspeed --num_gpus="${NUM_GPUS:-$(nvidia-smi -L 2>/dev/null | wc -l || echo 1)}" -m mullm.core.trainer.trainer)
else
    CMD=(python -m mullm.core.trainer.trainer)
fi

echo "Starting training..."
exec "${CMD[@]}"
