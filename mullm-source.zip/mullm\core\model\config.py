from dataclasses import dataclass, field
from typing import Optional, Any, Dict, Type


@dataclass
class GPTConfig:
    vocab_size: int = 50257
    hidden_size: int = 768
    num_hidden_layers: int = 12
    num_attention_heads: int = 12
    num_kv_heads: Optional[int] = None
    intermediate_size: int = 3072
    max_position_embeddings: int = 1024
    dropout: float = 0.1
    attention_dropout: float = 0.1
    layer_norm_eps: float = 1e-5
    activation_function: str = "gelu"
    use_bias: bool = True
    use_cache: bool = True
    tie_word_embeddings: bool = False
    initializer_range: float = 0.02
    bos_token_id: int = 50256
    eos_token_id: int = 50256
    pad_token_id: int = 50256
    attention_type: str = "multi_head"
    sliding_window: Optional[int] = None
    rope_theta: float = 10000.0
    rope_scaling: Optional[Dict[str, Any]] = None
    num_experts: Optional[int] = None
    num_experts_per_tok: Optional[int] = None
    expert_intermediate_size: Optional[int] = None
    output_hidden_states: bool = False
    output_attentions: bool = False
    torch_dtype: str = "float32"

    @classmethod
    def from_pretrained(cls, pretrained_model_name_or_path: str) -> "GPTConfig":
        return cls()

    def to_dict(self) -> Dict[str, Any]:
        return {k: v for k, v in self.__dict__.items()}


@dataclass
class LlamaConfig:
    vocab_size: int = 32000
    hidden_size: int = 4096
    num_hidden_layers: int = 32
    num_attention_heads: int = 32
    num_kv_heads: Optional[int] = 8
    intermediate_size: int = 11008
    max_position_embeddings: int = 2048
    dropout: float = 0.0
    attention_dropout: float = 0.0
    layer_norm_eps: float = 1e-5
    activation_function: str = "silu"
    use_bias: bool = False
    use_cache: bool = True
    tie_word_embeddings: bool = False
    initializer_range: float = 0.02
    bos_token_id: int = 1
    eos_token_id: int = 2
    pad_token_id: int = 0
    attention_type: str = "grouped_query"
    sliding_window: Optional[int] = None
    rope_theta: float = 10000.0
    rope_scaling: Optional[Dict[str, Any]] = None
    num_experts: Optional[int] = None
    num_experts_per_tok: Optional[int] = None
    expert_intermediate_size: Optional[int] = None
    output_hidden_states: bool = False
    output_attentions: bool = False
    torch_dtype: str = "bfloat16"

    @classmethod
    def from_pretrained(cls, pretrained_model_name_or_path: str) -> "LlamaConfig":
        return cls()

    def to_dict(self) -> Dict[str, Any]:
        return {k: v for k, v in self.__dict__.items()}


@dataclass
class MistralConfig:
    vocab_size: int = 32000
    hidden_size: int = 4096
    num_hidden_layers: int = 32
    num_attention_heads: int = 32
    num_kv_heads: Optional[int] = 8
    intermediate_size: int = 14336
    max_position_embeddings: int = 32768
    dropout: float = 0.0
    attention_dropout: float = 0.0
    layer_norm_eps: float = 1e-5
    activation_function: str = "silu"
    use_bias: bool = False
    use_cache: bool = True
    tie_word_embeddings: bool = False
    initializer_range: float = 0.02
    bos_token_id: int = 1
    eos_token_id: int = 2
    pad_token_id: int = 0
    attention_type: str = "sliding_window"
    sliding_window: int = 4096
    rope_theta: float = 10000.0
    rope_scaling: Optional[Dict[str, Any]] = None
    num_experts: Optional[int] = None
    num_experts_per_tok: Optional[int] = None
    expert_intermediate_size: Optional[int] = None
    output_hidden_states: bool = False
    output_attentions: bool = False
    torch_dtype: str = "bfloat16"

    @classmethod
    def from_pretrained(cls, pretrained_model_name_or_path: str) -> "MistralConfig":
        return cls()

    def to_dict(self) -> Dict[str, Any]:
        return {k: v for k, v in self.__dict__.items()}


@dataclass
class DeepSeekConfig:
    vocab_size: int = 102400
    hidden_size: int = 4096
    num_hidden_layers: int = 32
    num_attention_heads: int = 32
    num_kv_heads: Optional[int] = 8
    intermediate_size: int = 11008
    max_position_embeddings: int = 4096
    dropout: float = 0.0
    attention_dropout: float = 0.0
    layer_norm_eps: float = 1e-5
    activation_function: str = "silu"
    use_bias: bool = False
    use_cache: bool = True
    tie_word_embeddings: bool = False
    initializer_range: float = 0.02
    bos_token_id: int = 1
    eos_token_id: int = 2
    pad_token_id: int = 0
    attention_type: str = "grouped_query"
    sliding_window: Optional[int] = None
    rope_theta: float = 10000.0
    rope_scaling: Optional[Dict[str, Any]] = None
    num_experts: int = 64
    num_experts_per_tok: int = 6
    expert_intermediate_size: int = 1408
    expert_shared_intermediate_size: int = 2816
    moe_layer_frequency: int = 1
    output_hidden_states: bool = False
    output_attentions: bool = False
    torch_dtype: str = "bfloat16"

    @classmethod
    def from_pretrained(cls, pretrained_model_name_or_path: str) -> "DeepSeekConfig":
        return cls()

    def to_dict(self) -> Dict[str, Any]:
        return {k: v for k, v in self.__dict__.items()}


CONFIG_MAP: Dict[str, Type] = {
    "gpt": GPTConfig,
    "llama": LlamaConfig,
    "mistral": MistralConfig,
    "deepseek": DeepSeekConfig,
}

MODEL_SIZE_CONFIGS: Dict[str, Dict[str, Any]] = {
    "125M": {
        "hidden_size": 768,
        "num_hidden_layers": 12,
        "num_attention_heads": 12,
        "intermediate_size": 3072,
    },
    "350M": {
        "hidden_size": 1024,
        "num_hidden_layers": 24,
        "num_attention_heads": 16,
        "intermediate_size": 4096,
    },
    "760M": {
        "hidden_size": 1536,
        "num_hidden_layers": 24,
        "num_attention_heads": 16,
        "intermediate_size": 6144,
    },
    "1.3B": {
        "hidden_size": 2048,
        "num_hidden_layers": 24,
        "num_attention_heads": 32,
        "intermediate_size": 8192,
    },
    "2.7B": {
        "hidden_size": 2560,
        "num_hidden_layers": 32,
        "num_attention_heads": 32,
        "intermediate_size": 10240,
    },
    "6.7B": {
        "hidden_size": 4096,
        "num_hidden_layers": 32,
        "num_attention_heads": 32,
        "intermediate_size": 16384,
    },
    "13B": {
        "hidden_size": 5120,
        "num_hidden_layers": 40,
        "num_attention_heads": 40,
        "intermediate_size": 20480,
    },
    "70B": {
        "hidden_size": 8192,
        "num_hidden_layers": 80,
        "num_attention_heads": 64,
        "intermediate_size": 32768,
    },
}


class ModelFactory:
    @staticmethod
    def create_config(model_type: str, size: Optional[str] = None, **kwargs) -> Any:
        model_type = model_type.lower()
        if model_type not in CONFIG_MAP:
            raise ValueError(f"Unknown model type: {model_type}. Available: {list(CONFIG_MAP.keys())}")
        config_cls = CONFIG_MAP[model_type]
        base_kwargs = {}
        if size is not None:
            if size not in MODEL_SIZE_CONFIGS:
                raise ValueError(f"Unknown model size: {size}. Available: {list(MODEL_SIZE_CONFIGS.keys())}")
            base_kwargs.update(MODEL_SIZE_CONFIGS[size])
        base_kwargs.update(kwargs)
        return config_cls(**base_kwargs)

    @staticmethod
    def create_model(model_type: str, size: Optional[str] = None, **kwargs) -> Any:
        from .model import GPTModel, LlamaModel, MistralModel, DeepSeekModel

        config = ModelFactory.create_config(model_type, size, **kwargs)
        model_map = {
            "gpt": GPTModel,
            "llama": LlamaModel,
            "mistral": MistralModel,
            "deepseek": DeepSeekModel,
        }
        model_cls = model_map[model_type]
        return model_cls(config)

    @staticmethod
    def get_default_config(model_type: str, size: str) -> Dict[str, Any]:
        if size not in MODEL_SIZE_CONFIGS:
            raise ValueError(f"Unknown model size: {size}")
        if model_type not in CONFIG_MAP:
            raise ValueError(f"Unknown model type: {model_type}")
        config_cls = CONFIG_MAP[model_type]
        base = MODEL_SIZE_CONFIGS[size].copy()
        defaults = {k: v for k, v in config_cls().__dict__.items() if k not in base}
        defaults.update(base)
        return defaults
