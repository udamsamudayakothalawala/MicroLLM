from __future__ import annotations

import json
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional, Union


class OptimizerType(str, Enum):
    adamw = "adamw"
    lion = "lion"
    adafactor = "adafactor"


class SchedulerType(str, Enum):
    warmup_linear = "warmup_linear"
    warmup_cosine = "warmup_cosine"
    warmup_constant = "warmup_constant"
    cosine_with_min_lr = "cosine_with_min_lr"
    polynomial_decay = "polynomial_decay"


class ShardingStrategy(str, Enum):
    full_shard = "full_shard"
    shard_grad_op = "shard_grad_op"
    no_shard = "no_shard"
    hybrid_shard = "hybrid_shard"


class BackendType(str, Enum):
    ddp = "ddp"
    fsdp = "fsdp"
    deepspeed = "deepspeed"


class OffloadDevice(str, Enum):
    cpu = "cpu"
    nvme = "nvme"


class PrecisionType(str, Enum):
    fp32 = "fp32"
    fp16 = "fp16"
    bf16 = "bf16"
    fp8 = "fp8"


class ActivationCheckpointingType(str, Enum):
    none = "none"
    selective = "selective"
    full = "full"


class TensorParallelMode(str, Enum):
    column_wise = "column_wise"
    row_wise = "row_wise"


@dataclass
class AdamWConfig:
    lr: float = 1e-4
    betas: tuple[float, float] = (0.9, 0.999)
    eps: float = 1e-8
    weight_decay: float = 0.01
    foreach: bool = True
    fused: bool = False
    decoupled_weight_decay: bool = True


@dataclass
class LionConfig:
    lr: float = 1e-4
    betas: tuple[float, float] = (0.9, 0.99)
    weight_decay: float = 0.01
    decoupled_weight_decay: bool = True


@dataclass
class AdafactorConfig:
    lr: Optional[float] = None
    eps: tuple[float, float] = (1e-30, 1e-3)
    clip_threshold: float = 1.0
    decay_rate: float = -0.8
    beta1: Optional[float] = None
    weight_decay: float = 0.0
    scale_parameter: bool = True
    relative_step: bool = True
    warmup_init: bool = False


@dataclass
class OptimizerConfig:
    optimizer_type: OptimizerType = OptimizerType.adamw
    adamw: AdamWConfig = field(default_factory=AdamWConfig)
    lion: LionConfig = field(default_factory=LionConfig)
    adafactor: AdafactorConfig = field(default_factory=AdafactorConfig)
    param_groups_decay: bool = True
    no_decay_params: List[str] = field(
        default_factory=lambda: [
            "bias",
            "layer_norm",
            "layernorm",
            "ln",
            "norm",
            "embed_tokens",
            "embedding",
        ]
    )


@dataclass
class SchedulerConfig:
    scheduler_type: SchedulerType = SchedulerType.warmup_cosine
    warmup_steps: int = 0
    warmup_ratio: float = 0.0
    num_training_steps: int = 100000
    num_cycles: float = 0.5
    min_lr_ratio: float = 0.0
    polynomial_power: float = 1.0
    lr_end: float = 0.0


@dataclass
class FSDPConfig:
    sharding_strategy: ShardingStrategy = ShardingStrategy.full_shard
    cpu_offload: bool = False
    mixed_precision: bool = True
    auto_wrap_policy: str = "transformer_auto_wrap_policy"
    transformer_layer_cls: List[str] = field(
        default_factory=lambda: [
            "TransformerLayer",
            "DecoderLayer",
            "GPT2Block",
            "LlamaDecoderLayer",
            "MistralDecoderLayer",
        ]
    )
    min_num_params: int = 100_000_000
    backward_prefetch: str = "backward_pre"
    forward_prefetch: bool = False
    limit_all_gathers: bool = True
    use_orig_params: bool = False
    param_init_fn: Optional[str] = None
    sync_module_states: bool = True


@dataclass
class DeepSpeedZeroConfig:
    stage: int = 2
    offload_optimizer: bool = False
    offload_optimizer_device: OffloadDevice = OffloadDevice.cpu
    offload_optimizer_pin_memory: bool = False
    offload_optimizer_fast_init: bool = False
    offload_param: bool = False
    offload_param_device: OffloadDevice = OffloadDevice.cpu
    offload_param_pin_memory: bool = False
    contiguous_gradients: bool = True
    overlap_comm: bool = True
    allgather_bucket_size: int = 500_000_000
    reduce_bucket_size: int = 500_000_000
    reduce_scatter: bool = True
    allgather_partitions: bool = True
    allgather_bucket_size_in_mb: float = 500.0
    reduce_bucket_size_in_mb: float = 500.0
    round_robin_gradients: bool = False
    zero_hpz_partition_size: int = 1
    zero_quantized_weights: bool = False
    zero_quantized_nontrainable_weights: bool = False
    nvme_path: Optional[str] = None
    activation_checkpointing: ActivationCheckpointingType = ActivationCheckpointingType.none
    activation_checkpointing_interval: int = 0
    activation_checkpointing_number: int = 1
    communication_data_type: Optional[PrecisionType] = None
    gradient_predivide_factor: float = 1.0


@dataclass
class TensorParallelConfig:
    enabled: bool = False
    world_size: int = 1
    mode: TensorParallelMode = TensorParallelMode.column_wise
    gather_output: bool = True
    async_communication: bool = False


@dataclass
class PipelineParallelConfig:
    enabled: bool = False
    num_micro_batches: int = 1
    chunks: int = 1
    num_stages: int = 1
    schedule: str = "1f1b"
    overlap_p2p_communication: bool = True
    batch_size: int = 1


@dataclass
class SequenceParallelConfig:
    enabled: bool = False
    sequence_length: int = 2048
    ring_ratio: float = 0.5


@dataclass
class ContextParallelConfig:
    enabled: bool = False
    context_size: int = 2048
    world_size: int = 1
    overlap: bool = True


@dataclass
class ParallelismConfig:
    tensor_parallel: TensorParallelConfig = field(default_factory=TensorParallelConfig)
    pipeline_parallel: PipelineParallelConfig = field(default_factory=PipelineParallelConfig)
    sequence_parallel: SequenceParallelConfig = field(default_factory=SequenceParallelConfig)
    context_parallel: ContextParallelConfig = field(default_factory=ContextParallelConfig)


@dataclass
class LossConfig:
    label_smoothing: float = 0.0
    z_loss: float = 0.0
    focal_loss_gamma: float = 2.0
    focal_loss_alpha: Optional[float] = None
    moe_aux_loss_coef: float = 0.01
    moe_z_loss_coef: float = 0.001
    kl_penalty_coef: float = 0.0
    adaptive_loss: bool = False
    adaptive_loss_temperature: float = 1.0
    vocab_size: int = 32000


@dataclass
class DataConfig:
    dataset_path: str = ""
    dataset_name: str = ""
    dataset_split: str = "train"
    eval_dataset_path: str = ""
    eval_dataset_name: str = ""
    eval_dataset_split: str = "validation"
    tokenizer_path: str = ""
    max_seq_length: int = 2048
    padding: Union[bool, str] = False
    truncation: bool = True
    streaming: bool = False
    shuffle_buffer_size: int = 10000
    num_workers: int = 4
    prefetch_factor: int = 2
    persistent_workers: bool = True
    packing: bool = True
    packing_max_length: int = 2048
    dynamic_batching: bool = False
    dynamic_batch_max_tokens: int = 8192
    collator_pad_token_id: int = 0
    collator_ignore_index: int = -100
    collator_mask_instruction: bool = False
    seed: int = 42


@dataclass
class LoggingConfig:
    log_steps: int = 10
    log_level: str = "INFO"
    log_format: str = "json"
    wandb_enabled: bool = False
    wandb_project: Optional[str] = None
    wandb_entity: Optional[str] = None
    wandb_run_name: Optional[str] = None
    wandb_tags: List[str] = field(default_factory=list)
    tensorboard_enabled: bool = True
    tensorboard_dir: Optional[str] = None
    console_log: bool = True
    save_log_to_file: bool = False
    log_file_path: Optional[str] = None


@dataclass
class CheckpointConfig:
    save_steps: int = 1000
    save_epochs: int = 1
    save_total_limit: int = 5
    save_best_only: bool = True
    save_optimizer: bool = True
    save_scheduler: bool = True
    save_rng_state: bool = True
    load_best_at_end: bool = True
    metric_to_monitor: str = "eval_loss"
    metric_mode: str = "min"
    checkpoint_dir: str = "./checkpoints"
    resume_from_checkpoint: Optional[str] = None
    auto_checkpoint: bool = False


@dataclass
class EvaluationConfig:
    eval_steps: int = 500
    eval_epochs: int = 1
    eval_batch_size: int = 8
    eval_max_steps: int = -1
    eval_accumulation_steps: int = 1
    eval_metrics: List[str] = field(default_factory=lambda: ["loss", "perplexity"])
    eval_dataloader_workers: int = 1
    early_stopping_patience: int = 0
    early_stopping_threshold: float = 0.0


@dataclass
class TrainerConfig:
    output_dir: str = "./outputs"
    seed: int = 42
    device: str = "auto"
    backend: BackendType = BackendType.ddp
    precision: PrecisionType = PrecisionType.bf16
    gradient_accumulation_steps: int = 1
    max_grad_norm: float = 1.0
    gradient_checkpointing: bool = False
    batch_size: int = 8
    eval_batch_size: int = 8
    num_epochs: int = 3
    max_steps: int = -1
    max_train_samples: Optional[int] = None
    max_eval_samples: Optional[int] = None
    dataloader_num_workers: int = 4
    ddp_find_unused_parameters: bool = False
    ddp_bucket_cap_mb: int = 25
    ddp_static_graph: bool = False
    local_rank: int = -1
    rank: int = 0
    world_size: int = 1
    main_process: bool = True
    master_addr: str = "localhost"
    master_port: str = "29500"
    deepspeed_config_path: Optional[str] = None
    deepspeed_enabled: bool = False
    fsdp_enabled: bool = False
    compile_model: bool = False
    disable_tqdm: bool = False
    profile: bool = False
    profile_steps: int = 5
    skip_first_n_profile_steps: int = 0
    log_params: bool = False
    log_gradients: bool = False
    log_param_norm: bool = False
    log_grad_norm: bool = False
    find_unused_parameters: bool = False
    amp: bool = True

    optimizer: OptimizerConfig = field(default_factory=OptimizerConfig)
    scheduler: SchedulerConfig = field(default_factory=SchedulerConfig)
    fsdp: FSDPConfig = field(default_factory=FSDPConfig)
    deepspeed_zero: DeepSpeedZeroConfig = field(default_factory=DeepSpeedZeroConfig)
    parallelism: ParallelismConfig = field(default_factory=ParallelismConfig)
    loss: LossConfig = field(default_factory=LossConfig)
    data: DataConfig = field(default_factory=DataConfig)
    logging: LoggingConfig = field(default_factory=LoggingConfig)
    checkpoint: CheckpointConfig = field(default_factory=CheckpointConfig)
    evaluation: EvaluationConfig = field(default_factory=EvaluationConfig)

    def to_dict(self) -> Dict[str, Any]:
        def _to_dict(obj: Any) -> Any:
            if isinstance(obj, Enum):
                return obj.value
            if isinstance(obj, tuple):
                return list(obj)
            if hasattr(obj, "__dataclass_fields__"):
                return {k: _to_dict(v) for k, v in obj.__dataclass_fields__.items()}
            return obj

        return _to_dict(self)

    def to_json(self, path: Optional[Union[str, Path]] = None) -> Optional[str]:
        data = json.loads(json.dumps(self, default=lambda o: o.value if isinstance(o, Enum) else str(o)))
        if path:
            Path(path).write_text(json.dumps(data, indent=2, default=str))
            return None
        return json.dumps(data, indent=2, default=str)

    @classmethod
    def from_json(cls, path: Union[str, Path]) -> TrainerConfig:
        data = json.loads(Path(path).read_text())
        return cls(**data)

    def to_yaml(self, path: Union[str, Path]) -> None:
        import yaml

        data = json.loads(self.to_json())
        with open(path, "w") as f:
            yaml.dump(data, f, default_flow_style=False, sort_keys=False)

    @classmethod
    def from_yaml(cls, path: Union[str, Path]) -> TrainerConfig:
        import yaml

        with open(path) as f:
            data = yaml.safe_load(f)
        return cls(**data)
