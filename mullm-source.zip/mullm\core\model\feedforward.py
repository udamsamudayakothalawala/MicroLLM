from typing import Optional, Tuple, List

import torch
import torch.nn as nn
import torch.nn.functional as F


class FeedForward(nn.Module):
    def __init__(
        self,
        hidden_size: int,
        intermediate_size: int,
        activation: str = "gelu",
        bias: bool = True,
        dropout: float = 0.0,
    ):
        super().__init__()
        from .activation import get_activation

        self.gate_proj = nn.Linear(hidden_size, intermediate_size, bias=bias)
        self.act = get_activation(activation)
        self.down_proj = nn.Linear(intermediate_size, hidden_size, bias=bias)
        self.dropout = nn.Dropout(dropout)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = self.gate_proj(x)
        x = self.act(x)
        x = self.dropout(x)
        x = self.down_proj(x)
        return x


class GatedFeedForward(nn.Module):
    def __init__(
        self,
        hidden_size: int,
        intermediate_size: int,
        activation: str = "silu",
        bias: bool = False,
        dropout: float = 0.0,
    ):
        super().__init__()
        from .activation import get_activation

        self.gate_proj = nn.Linear(hidden_size, intermediate_size, bias=bias)
        self.up_proj = nn.Linear(hidden_size, intermediate_size, bias=bias)
        self.act = get_activation(activation)
        self.down_proj = nn.Linear(intermediate_size, hidden_size, bias=bias)
        self.dropout = nn.Dropout(dropout)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        gate = self.act(self.gate_proj(x))
        up = self.up_proj(x)
        x = gate * up
        x = self.dropout(x)
        x = self.down_proj(x)
        return x


class Router(nn.Module):
    def __init__(self, hidden_size: int, num_experts: int, noisy_gating: bool = True, noise_epsilon: float = 1e-2):
        super().__init__()
        self.hidden_size = hidden_size
        self.num_experts = num_experts
        self.noisy_gating = noisy_gating
        self.noise_epsilon = noise_epsilon
        self.w_gate = nn.Linear(hidden_size, num_experts, bias=False)
        if noisy_gating:
            self.w_noise = nn.Linear(hidden_size, num_experts, bias=False)
            self.w_noise.weight.data.normal_(mean=0.0, std=0.01)

    def _softmax_noisy_gating(self, x: torch.Tensor, train: bool, noise_scale: float = 1.0) -> torch.Tensor:
        clean_logits = self.w_gate(x)
        if self.noisy_gating and train:
            raw_noise_std = self.w_noise(x)
            noise_std = F.softplus(raw_noise_std) + self.noise_epsilon
            noise = torch.randn_like(clean_logits) * noise_std * noise_scale
            clean_logits = clean_logits + noise
        return F.softmax(clean_logits, dim=-1)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self._softmax_noisy_gating(x, self.training)


class MoEFeedForward(nn.Module):
    def __init__(
        self,
        hidden_size: int,
        intermediate_size: int,
        num_experts: int = 8,
        num_experts_per_tok: int = 2,
        activation: str = "silu",
        bias: bool = False,
        dropout: float = 0.0,
        noisy_gating: bool = True,
        expert_balanced_loss_coef: float = 0.01,
    ):
        super().__init__()
        self.hidden_size = hidden_size
        self.num_experts = num_experts
        self.num_experts_per_tok = num_experts_per_tok
        self.expert_balanced_loss_coef = expert_balanced_loss_coef

        from .activation import get_activation

        self.router = Router(hidden_size, num_experts, noisy_gating=noisy_gating)

        self.gate_projs = nn.ModuleList([
            nn.Linear(hidden_size, intermediate_size, bias=bias)
            for _ in range(num_experts)
        ])
        self.up_projs = nn.ModuleList([
            nn.Linear(hidden_size, intermediate_size, bias=bias)
            for _ in range(num_experts)
        ])
        self.down_projs = nn.ModuleList([
            nn.Linear(intermediate_size, hidden_size, bias=bias)
            for _ in range(num_experts)
        ])

        self.act = get_activation(activation)
        self.dropout = nn.Dropout(dropout)

    def forward(
        self,
        x: torch.Tensor,
        output_aux_loss: bool = True,
    ) -> Tuple[torch.Tensor, Optional[torch.Tensor]]:
        original_shape = x.shape
        batch_size, seq_len, hidden_size = x.shape
        x_flat = x.view(-1, hidden_size)
        num_tokens = x_flat.size(0)

        router_logits = self.router.w_gate(x_flat)
        if self.training and self.router.noisy_gating:
            raw_noise_std = F.softplus(self.router.w_noise(x_flat)) + self.router.noise_epsilon
            noise = torch.randn_like(router_logits) * raw_noise_std
            router_logits = router_logits + noise

        routing_weights = F.softmax(router_logits, dim=-1, dtype=torch.float32)
        topk_weights, topk_indices = torch.topk(routing_weights, self.num_experts_per_tok, dim=-1)
        topk_weights = topk_weights.to(x.dtype)
        topk_weights = topk_weights / (topk_weights.sum(dim=-1, keepdim=True) + 1e-9)

        final_output = torch.zeros_like(x_flat)
        aux_loss = torch.tensor(0.0, device=x.device, dtype=torch.float32)

        experts_used = torch.zeros(self.num_experts, device=x.device)
        for expert_idx in range(self.num_experts):
            mask = topk_indices == expert_idx
            token_indices, rank_positions = torch.where(mask)
            if token_indices.numel() == 0:
                continue

            expert_input = x_flat[token_indices]
            expert_weight = topk_weights[token_indices, rank_positions].unsqueeze(-1)

            hidden = self.act(self.gate_projs[expert_idx](expert_input)) * self.up_projs[expert_idx](expert_input)
            hidden = self.dropout(hidden)
            expert_output = self.down_projs[expert_idx](hidden)
            final_output.index_add_(0, token_indices, expert_output * expert_weight)
            experts_used[expert_idx] += token_indices.size(0)

        if output_aux_loss:
            num_tokens_float = num_tokens
            expert_load = experts_used / (num_tokens_float + 1e-9)
            router_prob = routing_weights.float().mean(dim=0)
            aux_loss = self.expert_balanced_loss_coef * self.num_experts * (expert_load * router_prob).sum()

        final_output = final_output.view(original_shape)

        if output_aux_loss:
            return final_output, aux_loss
        return final_output, None
