"""Retrieval Augmented Generation system for LLM knowledge integration."""

from __future__ import annotations

import hashlib
import json
import math
import re
import time
import uuid
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any, Callable, Dict, List, Optional, Set, Tuple


@dataclass
class Document:
    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    content: str = ""
    metadata: Dict[str, Any] = field(default_factory=dict)
    source: str = ""
    title: str = ""
    timestamp: datetime = field(default_factory=datetime.utcnow)
    embedding: Optional[List[float]] = None

    @property
    def content_hash(self) -> str:
        return hashlib.md5(self.content.encode()).hexdigest()

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "content": self.content,
            "metadata": self.metadata,
            "source": self.source,
            "title": self.title,
            "timestamp": self.timestamp.isoformat(),
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Document":
        return cls(
            id=data.get("id", ""),
            content=data.get("content", ""),
            metadata=data.get("metadata", {}),
            source=data.get("source", ""),
            title=data.get("title", ""),
            timestamp=datetime.fromisoformat(data["timestamp"]) if "timestamp" in data else datetime.utcnow(),
        )


@dataclass
class Chunk:
    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    content: str = ""
    document_id: str = ""
    document_source: str = ""
    chunk_index: int = 0
    metadata: Dict[str, Any] = field(default_factory=dict)
    embedding: Optional[List[float]] = None

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "content": self.content,
            "document_id": self.document_id,
            "document_source": self.document_source,
            "chunk_index": self.chunk_index,
            "metadata": self.metadata,
        }


@dataclass
class RetrievalResult:
    chunks: List[Chunk] = field(default_factory=list)
    query: str = ""
    query_embedding: Optional[List[float]] = None
    scores: List[float] = field(default_factory=list)
    total_time: float = 0.0

    @property
    def top_chunk(self) -> Optional[Chunk]:
        return self.chunks[0] if self.chunks else None

    @property
    def contents(self) -> List[str]:
        return [c.content for c in self.chunks]

    @property
    def combined_content(self) -> str:
        return "\n\n".join(self.contents)


@dataclass
class Citation:
    chunk_id: str = ""
    document_id: str = ""
    source: str = ""
    text: str = ""
    relevance_score: float = 0.0

    def format(self) -> str:
        return f"[{self.source}]" if self.source else f"[{self.document_id[:8]}]"

    def to_dict(self) -> Dict[str, Any]:
        return {
            "chunk_id": self.chunk_id,
            "document_id": self.document_id,
            "source": self.source,
            "text": self.text,
            "relevance_score": self.relevance_score,
        }


@dataclass
class ContextWindow:
    content: str = ""
    chunks: List[Chunk] = field(default_factory=list)
    citations: List[Citation] = field(default_factory=list)
    token_count: int = 0
    max_tokens: int = 4096

    def add_chunk(self, chunk: Chunk, score: float) -> None:
        self.chunks.append(chunk)
        self.content += f"\n\n{chunk.content}" if self.content else chunk.content
        citation = Citation(
            chunk_id=chunk.id,
            document_id=chunk.document_id,
            source=chunk.document_source,
            text=chunk.content[:200],
            relevance_score=score,
        )
        self.citations.append(citation)

    def format_with_citations(self) -> str:
        parts = [self.content, "", "References:"]
        for i, cit in enumerate(self.citations, 1):
            parts.append(f"[{i}] {cit.source}: {cit.text[:100]}...")
        return "\n".join(parts)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "content": self.content,
            "chunks": [c.to_dict() for c in self.chunks],
            "citations": [c.to_dict() for c in self.citations],
            "token_count": self.token_count,
            "max_tokens": self.max_tokens,
        }


class ChunkingStrategy(Enum):
    RECURSIVE = "recursive"
    SEMANTIC = "semantic"
    FIXED_SIZE = "fixed_size"
    SENTENCE = "sentence"
    PARAGRAPH = "paragraph"


class DocumentChunker:
    def __init__(
        self,
        strategy: ChunkingStrategy = ChunkingStrategy.RECURSIVE,
        chunk_size: int = 512,
        chunk_overlap: int = 64,
        separators: Optional[List[str]] = None,
    ) -> None:
        self.strategy = strategy
        self.chunk_size = chunk_size
        self.chunk_overlap = chunk_overlap
        self.separators = separators or ["\n\n", "\n", ". ", " ", ""]

    def chunk_document(self, document: Document) -> List[Chunk]:
        if self.strategy == ChunkingStrategy.RECURSIVE:
            return self._recursive_chunk(document)
        elif self.strategy == ChunkingStrategy.FIXED_SIZE:
            return self._fixed_size_chunk(document)
        elif self.strategy == ChunkingStrategy.SENTENCE:
            return self._sentence_chunk(document)
        elif self.strategy == ChunkingStrategy.PARAGRAPH:
            return self._paragraph_chunk(document)
        elif self.strategy == ChunkingStrategy.SEMANTIC:
            return self._semantic_chunk(document)
        return self._recursive_chunk(document)

    def chunk_text(self, text: str, source: str = "") -> List[Chunk]:
        doc = Document(content=text, source=source)
        return self.chunk_document(doc)

    def _recursive_chunk(self, document: Document) -> List[Chunk]:
        chunks: List[Chunk] = []
        text = document.content
        chunk_idx = 0

        while text:
            if len(text) <= self.chunk_size:
                chunk = Chunk(
                    content=text,
                    document_id=document.id,
                    document_source=document.source,
                    chunk_index=chunk_idx,
                    metadata={"strategy": "recursive"},
                )
                chunks.append(chunk)
                break

            split_point = self._find_split(text, self.chunk_size)
            chunk_content = text[:split_point].strip()
            if chunk_content:
                chunk = Chunk(
                    content=chunk_content,
                    document_id=document.id,
                    document_source=document.source,
                    chunk_index=chunk_idx,
                    metadata={"strategy": "recursive"},
                )
                chunks.append(chunk)
                chunk_idx += 1

            overlap_start = max(0, split_point - self.chunk_overlap)
            text = text[overlap_start:]

        return chunks

    def _fixed_size_chunk(self, document: Document) -> List[Chunk]:
        chunks: List[Chunk] = []
        text = document.content
        for i in range(0, len(text), self.chunk_size - self.chunk_overlap):
            chunk_content = text[i:i + self.chunk_size].strip()
            if chunk_content:
                chunk = Chunk(
                    content=chunk_content,
                    document_id=document.id,
                    document_source=document.source,
                    chunk_index=len(chunks),
                    metadata={"strategy": "fixed_size", "start": i},
                )
                chunks.append(chunk)
        return chunks

    def _sentence_chunk(self, document: Document) -> List[Chunk]:
        chunks: List[Chunk] = []
        sentences = re.split(r'(?<=[.!?])\s+', document.content)
        current = ""
        for sentence in sentences:
            if len(current) + len(sentence) <= self.chunk_size:
                current += sentence + " "
            else:
                if current.strip():
                    chunk = Chunk(
                        content=current.strip(),
                        document_id=document.id,
                        document_source=document.source,
                        chunk_index=len(chunks),
                        metadata={"strategy": "sentence"},
                    )
                    chunks.append(chunk)
                current = sentence + " "
        if current.strip():
            chunk = Chunk(
                content=current.strip(),
                document_id=document.id,
                document_source=document.source,
                chunk_index=len(chunks),
                metadata={"strategy": "sentence"},
            )
            chunks.append(chunk)
        return chunks

    def _paragraph_chunk(self, document: Document) -> List[Chunk]:
        chunks: List[Chunk] = []
        paragraphs = re.split(r'\n\s*\n', document.content)
        current = ""
        for para in paragraphs:
            if len(current) + len(para) <= self.chunk_size:
                current += para + "\n\n"
            else:
                if current.strip():
                    chunk = Chunk(
                        content=current.strip(),
                        document_id=document.id,
                        document_source=document.source,
                        chunk_index=len(chunks),
                        metadata={"strategy": "paragraph"},
                    )
                    chunks.append(chunk)
                current = para + "\n\n"
        if current.strip():
            chunk = Chunk(
                content=current.strip(),
                document_id=document.id,
                document_source=document.source,
                chunk_index=len(chunks),
                metadata={"strategy": "paragraph"},
            )
            chunks.append(chunk)
        return chunks

    def _semantic_chunk(self, document: Document) -> List[Chunk]:
        return self._recursive_chunk(document)

    def _find_split(self, text: str, target: int) -> int:
        if len(text) <= target:
            return len(text)

        split_at = target
        for sep in self.separators:
            pos = text.rfind(sep, 0, target)
            if pos > target // 2:
                split_at = pos + len(sep)
                break

        return min(split_at, len(text))


class EmbeddingProvider(ABC):
    @abstractmethod
    def embed(self, texts: List[str]) -> List[List[float]]: ...

    @abstractmethod
    def embed_query(self, text: str) -> List[float]: ...

    @property
    @abstractmethod
    def dimension(self) -> int: ...


class SparseRetriever:
    def __init__(self) -> None:
        self._chunks: List[Chunk] = []
        self._index: Dict[str, Dict[str, float]] = {}

    def index(self, chunks: List[Chunk]) -> None:
        for chunk in chunks:
            self._chunks.append(chunk)
            tf = self._compute_tf(chunk.content)
            self._index[chunk.id] = tf

    def search(self, query: str, top_k: int = 5) -> List[Tuple[Chunk, float]]:
        query_terms = self._tokenize(query)
        idf = self._compute_idf()

        scored: List[Tuple[Chunk, float]] = []
        for chunk in self._chunks:
            score = 0.0
            chunk_tf = self._index.get(chunk.id, {})
            for term in query_terms:
                tf = chunk_tf.get(term, 0.0)
                idf_val = idf.get(term, 1.0)
                score += tf * idf_val
            scored.append((chunk, score))

        scored.sort(key=lambda x: x[1], reverse=True)
        return scored[:top_k]

    def _compute_tf(self, text: str) -> Dict[str, float]:
        terms = self._tokenize(text)
        total = len(terms)
        if total == 0:
            return {}
        term_counts: Dict[str, int] = {}
        for term in terms:
            term_counts[term] = term_counts.get(term, 0) + 1
        return {term: count / total for term, count in term_counts.items()}

    def _compute_idf(self) -> Dict[str, float]:
        n = len(self._chunks)
        if n == 0:
            return {}
        df: Dict[str, int] = {}
        for chunk in self._chunks:
            terms = set(self._tokenize(chunk.content))
            for term in terms:
                df[term] = df.get(term, 0) + 1
        return {term: math.log((n + 1) / (doc_count + 1)) + 1 for term, doc_count in df.items()}

    def _tokenize(self, text: str) -> List[str]:
        return re.findall(r'\w+', text.lower())


class HybridRetriever:
    def __init__(
        self,
        dense_provider: Optional[EmbeddingProvider] = None,
        sparse_retriever: Optional[SparseRetriever] = None,
        dense_weight: float = 0.5,
    ) -> None:
        self.dense_provider = dense_provider
        self.sparse_retriever = sparse_retriever or SparseRetriever()
        self.dense_weight = dense_weight
        self._chunks: List[Chunk] = []

    def index(self, chunks: List[Chunk]) -> None:
        self._chunks = chunks
        self.sparse_retriever.index(chunks)
        if self.dense_provider:
            texts = [c.content for c in chunks]
            embeddings = self.dense_provider.embed(texts)
            for chunk, emb in zip(chunks, embeddings):
                chunk.embedding = emb

    def search(self, query: str, top_k: int = 5) -> RetrievalResult:
        start = time.monotonic()

        dense_scores: Dict[str, float] = {}
        if self.dense_provider and self._chunks:
            query_emb = self.dense_provider.embed_query(query)
            for chunk in self._chunks:
                if chunk.embedding:
                    sim = self._cosine_similarity(query_emb, chunk.embedding)
                    dense_scores[chunk.id] = sim

        sparse_results = self.sparse_retriever.search(query, top_k=top_k * 2)
        sparse_scores: Dict[str, float] = {c.id: s for c, s in sparse_results}

        combined: Dict[str, float] = {}
        all_ids = set(dense_scores.keys()) | set(sparse_scores.keys())
        for chunk_id in all_ids:
            dense = dense_scores.get(chunk_id, 0.0)
            sparse = sparse_scores.get(chunk_id, 0.0)
            combined[chunk_id] = self.dense_weight * dense + (1 - self.dense_weight) * sparse

        chunk_map = {c.id: c for c in self._chunks}
        sorted_ids = sorted(combined.keys(), key=lambda x: combined[x], reverse=True)[:top_k]

        result_chunks: List[Chunk] = []
        result_scores: List[float] = []
        for cid in sorted_ids:
            if cid in chunk_map:
                result_chunks.append(chunk_map[cid])
                result_scores.append(combined[cid])

        return RetrievalResult(
            chunks=result_chunks,
            query=query,
            scores=result_scores,
            total_time=time.monotonic() - start,
        )

    def _cosine_similarity(self, a: List[float], b: List[float]) -> float:
        if len(a) != len(b) or not a:
            return 0.0
        dot = sum(x * y for x, y in zip(a, b))
        norm_a = math.sqrt(sum(x * x for x in a))
        norm_b = math.sqrt(sum(y * y for y in b))
        if norm_a == 0 or norm_b == 0:
            return 0.0
        return dot / (norm_a * norm_b)


class ContextBuilder:
    def __init__(self, max_tokens: int = 4096) -> None:
        self.max_tokens = max_tokens

    def build(self, result: RetrievalResult, query: str, system_prompt: str = "") -> ContextWindow:
        context = ContextWindow(max_tokens=self.max_tokens)
        current_tokens = 0

        prompt_tokens = len(system_prompt.split()) + len(query.split())
        available = self.max_tokens - prompt_tokens

        for chunk, score in zip(result.chunks, result.scores):
            chunk_tokens = len(chunk.content.split())
            if current_tokens + chunk_tokens > available:
                break
            context.add_chunk(chunk, score)
            current_tokens += chunk_tokens

        context.token_count = current_tokens
        return context

    def build_rag_prompt(self, query: str, context: ContextWindow, system_prompt: str = "") -> str:
        parts = []
        if system_prompt:
            parts.append(system_prompt)
        parts.append("Context information:")
        parts.append(context.content)
        parts.append("")
        parts.append(f"Question: {query}")
        parts.append("")
        if context.citations:
            sources = ", ".join(set(c.source for c in context.citations if c.source))
            parts.append(f"Sources: {sources}")
        parts.append("Answer based on the context above.")
        return "\n".join(parts)


@dataclass
class RAGConfig:
    chunk_size: int = 512
    chunk_overlap: int = 64
    chunking_strategy: ChunkingStrategy = ChunkingStrategy.RECURSIVE
    top_k: int = 5
    dense_weight: float = 0.5
    max_context_tokens: int = 4096
    use_hybrid_search: bool = True
    embed_on_index: bool = True


class RAGEngine:
    def __init__(
        self,
        config: Optional[RAGConfig] = None,
        embedding_provider: Optional[EmbeddingProvider] = None,
        retriever: Optional[HybridRetriever] = None,
    ) -> None:
        self.config = config or RAGConfig()
        self.embedding_provider = embedding_provider
        self.chunker = DocumentChunker(
            strategy=self.config.chunking_strategy,
            chunk_size=self.config.chunk_size,
            chunk_overlap=self.config.chunk_overlap,
        )
        self.sparse_retriever = SparseRetriever()
        self.retriever = retriever or HybridRetriever(
            dense_provider=embedding_provider,
            sparse_retriever=self.sparse_retriever,
            dense_weight=self.config.dense_weight,
        )
        self.context_builder = ContextBuilder(max_tokens=self.config.max_context_tokens)
        self._documents: List[Document] = []
        self._chunks: List[Chunk] = []

    def add_document(self, document: Document) -> List[Chunk]:
        self._documents.append(document)
        chunks = self.chunker.chunk_document(document)
        self._chunks.extend(chunks)
        self.retriever.index(self._chunks)
        return chunks

    def add_text(self, text: str, source: str = "", metadata: Optional[Dict[str, Any]] = None) -> List[Chunk]:
        doc = Document(
            content=text,
            source=source,
            metadata=metadata or {},
        )
        return self.add_document(doc)

    def add_documents(self, documents: List[Document]) -> List[Chunk]:
        all_chunks: List[Chunk] = []
        for doc in documents:
            all_chunks.extend(self.add_document(doc))
        return all_chunks

    def query(self, question: str, system_prompt: str = "") -> RetrievalResult:
        result = self.retriever.search(question, top_k=self.config.top_k)
        return result

    def query_with_context(self, question: str, system_prompt: str = "") -> ContextWindow:
        result = self.query(question)
        context = self.context_builder.build(result, question, system_prompt)
        return context

    def generate_prompt(self, question: str, system_prompt: str = "") -> str:
        context = self.query_with_context(question, system_prompt)
        return self.context_builder.build_rag_prompt(question, context, system_prompt)

    def get_stats(self) -> Dict[str, Any]:
        return {
            "documents": len(self._documents),
            "chunks": len(self._chunks),
            "chunk_size": self.config.chunk_size,
            "chunk_overlap": self.config.chunk_overlap,
            "top_k": self.config.top_k,
            "strategy": self.config.chunking_strategy.value,
        }


class RAGEvaluator:
    def __init__(self, engine: RAGEngine) -> None:
        self.engine = engine

    def evaluate_hit_rate(
        self,
        queries: List[str],
        relevant_docs: List[List[str]],
        top_k: int = 5,
    ) -> float:
        hits = 0
        total = 0
        for query, relevant in zip(queries, relevant_docs):
            result = self.engine.retriever.search(query, top_k=top_k)
            retrieved_ids = {c.id for c in result.chunks}
            if any(doc_id in retrieved_ids for doc_id in relevant):
                hits += 1
            total += 1
        return hits / total if total > 0 else 0.0

    def evaluate_mrr(
        self,
        queries: List[str],
        relevant_docs: List[List[str]],
        top_k: int = 10,
    ) -> float:
        reciprocal_ranks: List[float] = []
        for query, relevant in zip(queries, relevant_docs):
            result = self.engine.retriever.search(query, top_k=top_k)
            for rank, chunk in enumerate(result.chunks, 1):
                if any(chunk.id == doc_id or chunk.document_id == doc_id for doc_id in relevant):
                    reciprocal_ranks.append(1.0 / rank)
                    break
            else:
                reciprocal_ranks.append(0.0)
        return sum(reciprocal_ranks) / len(reciprocal_ranks) if reciprocal_ranks else 0.0

    def evaluate_ndcg(
        self,
        queries: List[str],
        relevant_docs: List[List[str]],
        top_k: int = 10,
    ) -> float:
        ndcg_scores: List[float] = []
        for query, relevant in zip(queries, relevant_docs):
            result = self.engine.retriever.search(query, top_k=top_k)
            ideal_dcg = sum(1.0 / math.log2(i + 2) for i in range(min(len(relevant), top_k)))
            if ideal_dcg == 0:
                continue
            dcg = 0.0
            for rank, chunk in enumerate(result.chunks, 1):
                if any(chunk.id == doc_id or chunk.document_id == doc_id for doc_id in relevant):
                    dcg += 1.0 / math.log2(rank + 1)
            ndcg_scores.append(dcg / ideal_dcg)

        return sum(ndcg_scores) / len(ndcg_scores) if ndcg_scores else 0.0
