"""Data labeling framework with manual, rule-based, and active learning strategies."""

from __future__ import annotations

import json
import logging
import random
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Optional

import numpy as np

logger = logging.getLogger(__name__)


@dataclass
class LabelConfig:
    label_names: list[str] = field(default_factory=lambda: ["positive", "negative", "neutral"])
    multi_label: bool = False
    allow_empty: bool = False
    confidence_threshold: float = 0.0


@dataclass
class Label:
    name: str
    confidence: float = 1.0
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class LabeledItem:
    id: str
    text: str
    labels: list[Label]
    source: str = "manual"
    metadata: dict[str, Any] = field(default_factory=dict)


class RuleBasedLabeler:
    def __init__(self, rules: dict[str, Callable[[str], float]], config: Optional[LabelConfig] = None) -> None:
        self.rules = rules
        self.config = config or LabelConfig()

    def label(self, text: str) -> list[Label]:
        result = []
        for label_name, rule_fn in self.rules.items():
            score = rule_fn(text)
            if score >= self.config.confidence_threshold:
                result.append(Label(name=label_name, confidence=score, metadata={"rule": label_name}))
        if not result and not self.config.allow_empty:
            result.append(Label(name=self.config.label_names[0], confidence=0.0, metadata={"rule": "fallback"}))
        return result

    def label_batch(self, texts: list[str]) -> list[list[Label]]:
        return [self.label(t) for t in texts]


class ActiveLearningLabeler:
    def __init__(self, config: Optional[LabelConfig] = None) -> None:
        self.config = config or LabelConfig()
        self.labeled: list[tuple[str, list[Label]]] = []
        self.unlabeled: list[str] = []
        self._model: Optional[Callable[[str], list[Label]]] = None

    def set_model(self, model_fn: Callable[[str], list[Label]]) -> None:
        self._model = model_fn

    def add_unlabeled(self, texts: list[str]) -> None:
        self.unlabeled.extend(texts)

    def add_labeled(self, text: str, labels: list[Label]) -> None:
        self.labeled.append((text, labels))
        if text in self.unlabeled:
            self.unlabeled.remove(text)

    def query_uncertainty(self, k: int = 5) -> list[tuple[str, float]]:
        if self._model is None:
            return self._sample_random(k)
        scores = []
        for text in self.unlabeled:
            preds = self._model(text)
            confs = [p.confidence for p in preds]
            uncertainty = 1.0 - (max(confs) if confs else 0.0)
            scores.append((text, uncertainty))
        scores.sort(key=lambda x: x[1], reverse=True)
        return scores[:k]

    def query_diversity(self, k: int = 5) -> list[tuple[str, float]]:
        if len(self.unlabeled) <= k:
            return [(t, 1.0) for t in self.unlabeled]
        selected = random.sample(self.unlabeled, k)
        return [(t, 1.0) for t in selected]

    def _sample_random(self, k: int) -> list[tuple[str, float]]:
        pool = self.unlabeled[:]
        random.shuffle(pool)
        return [(t, 1.0) for t in pool[:k]]


class LabelManager:
    def __init__(self, config: Optional[LabelConfig] = None) -> None:
        self.config = config or LabelConfig()
        self.items: dict[str, LabeledItem] = {}
        self._rule_labeler: Optional[RuleBasedLabeler] = None
        self._active_labeler: Optional[ActiveLearningLabeler] = None

    def set_rule_labeler(self, labeler: RuleBasedLabeler) -> None:
        self._rule_labeler = labeler

    def set_active_labeler(self, labeler: ActiveLearningLabeler) -> None:
        self._active_labeler = labeler

    def add_item(self, item: LabeledItem) -> None:
        self.items[item.id] = item

    def get_item(self, item_id: str) -> Optional[LabeledItem]:
        return self.items.get(item_id)

    def auto_label(self, text: str, source: str = "auto") -> Optional[LabeledItem]:
        if self._rule_labeler is None:
            return None
        labels = self._rule_labeler.label(text)
        item_id = f"auto_{len(self.items)}_{random.randint(1000, 9999)}"
        item = LabeledItem(id=item_id, text=text, labels=labels, source=source)
        self.items[item_id] = item
        return item

    def export_json(self, path: str) -> None:
        data = []
        for item in self.items.values():
            data.append({
                "id": item.id,
                "text": item.text,
                "labels": [{"name": l.name, "confidence": l.confidence, "metadata": l.metadata} for l in item.labels],
                "source": item.source,
                "metadata": item.metadata,
            })
        Path(path).write_text(json.dumps(data, indent=2), encoding="utf-8")

    def import_json(self, path: str) -> list[LabeledItem]:
        data = json.loads(Path(path).read_text(encoding="utf-8"))
        imported = []
        for entry in data:
            labels = [Label(name=l["name"], confidence=l.get("confidence", 1.0), metadata=l.get("metadata", {})) for l in entry.get("labels", [])]
            item = LabeledItem(id=entry["id"], text=entry["text"], labels=labels, source=entry.get("source", "import"), metadata=entry.get("metadata", {}))
            self.items[item.id] = item
            imported.append(item)
        return imported

    def label_distribution(self) -> dict[str, int]:
        dist: dict[str, int] = {}
        for item in self.items.values():
            for label in item.labels:
                dist[label.name] = dist.get(label.name, 0) + 1
        return dist

    def filter_by_label(self, label_name: str, min_confidence: float = 0.0) -> list[LabeledItem]:
        return [item for item in self.items.values() if any(l.name == label_name and l.confidence >= min_confidence for l in item.labels)]
