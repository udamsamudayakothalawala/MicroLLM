import torch  # noqa: F401,E402  (load before PyQt5 to avoid DLL conflicts)

"""muLLM GUI - Dataset tab: load and preview training data."""

import os
from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QPushButton, QLabel,
    QTableWidget, QTableWidgetItem, QFileDialog, QMessageBox,
    QSplitter, QListWidget, QListWidgetItem, QAbstractItemView,
    QTextEdit, QHeaderView
)
from PyQt5.QtCore import Qt, pyqtSignal


class DatasetTab(QWidget):
    dataset_loaded = pyqtSignal(list)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.datasets = {}
        self.current_data = []
        self.build_ui()

    def build_ui(self):
        main = QHBoxLayout(self)
        main.setContentsMargins(12, 12, 12, 12)
        splitter = QSplitter(Qt.Horizontal)

        left = QWidget()
        left_layout = QVBoxLayout(left)
        left_layout.setContentsMargins(0, 0, 0, 0)

        header = QLabel("TRAINING DATA")
        header.setProperty("class", "heading")
        left_layout.addWidget(header)

        sub = QLabel("Load a .txt, .json, .jsonl, or .csv file to train on.")
        sub.setProperty("class", "subheading")
        left_layout.addWidget(sub)

        btn_row = QHBoxLayout()
        self.import_btn = QPushButton("+ Import Data")
        self.import_btn.clicked.connect(self.import_dataset)
        self.sample_btn = QPushButton("Load Sample")
        self.sample_btn.setProperty("class", "btn-secondary")
        self.sample_btn.clicked.connect(self.load_sample)
        btn_row.addWidget(self.import_btn)
        btn_row.addWidget(self.sample_btn)
        btn_row.addStretch()
        left_layout.addLayout(btn_row)

        self.dataset_list = QListWidget()
        self.dataset_list.itemClicked.connect(self.on_dataset_selected)
        left_layout.addWidget(self.dataset_list)

        splitter.addWidget(left)

        right = QWidget()
        right_layout = QVBoxLayout(right)
        right_layout.setContentsMargins(0, 0, 0, 0)

        detail_header = QLabel("PREVIEW & STATS")
        detail_header.setProperty("class", "heading")
        right_layout.addWidget(detail_header)

        self.stats_label = QLabel("No dataset selected")
        self.stats_label.setProperty("class", "subheading")
        right_layout.addWidget(self.stats_label)

        self.preview_table = QTableWidget()
        self.preview_table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.preview_table.setAlternatingRowColors(True)
        right_layout.addWidget(self.preview_table)

        self.source_preview = QTextEdit()
        self.source_preview.setReadOnly(True)
        self.source_preview.setMaximumHeight(140)
        self.source_preview.setPlaceholderText("Raw text preview...")
        right_layout.addWidget(self.source_preview)

        splitter.addWidget(right)
        splitter.setStretchFactor(0, 1)
        splitter.setStretchFactor(1, 3)
        main.addWidget(splitter)

    def import_dataset(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "Import Dataset", "",
            "Datasets (*.txt *.json *.jsonl *.csv);;JSON (*.json *.jsonl);;Text (*.txt);;CSV (*.csv)"
        )
        if not path:
            return
        name = os.path.splitext(os.path.basename(path))[0]
        try:
            from mullm.core.data.text_dataset import load_text_file
            data = load_text_file(path)
            if not data:
                QMessageBox.warning(self, "Empty", "No text found in file.")
                return
            self.datasets[name] = {"path": path, "data": data}
            self.current_data = data
            self._refresh_list()
            self._show_preview(data, name, path)
            self.dataset_loaded.emit(data)
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to load dataset:\n{e}")

    def load_sample(self):
        sample = [
            "The quick brown fox jumps over the lazy dog.\n\n",
            "Artificial intelligence is the simulation of human intelligence in machines.\n\n",
            "Neural networks learn by adjusting weights through backpropagation.\n\n",
            "Language models predict the next token in a sequence given previous tokens.\n\n",
            "Machine learning is a subset of artificial intelligence that lets systems learn from data.\n\n",
            "Deep learning uses multiple layers of neural networks to model complex patterns.\n\n",
            "Attention is all you need introduced the transformer architecture.\n\n",
            "Small language models can be trained on a single GPU with a few million tokens.\n\n",
            "Tokenization converts text into a sequence of integer IDs for model consumption.\n\n",
            "Fine-tuning adapts a pretrained model to a specific downstream task.\n\n",
        ]
        self.datasets["sample_data"] = {"path": "(sample)", "data": sample}
        self.current_data = sample
        self._refresh_list()
        self._show_preview(sample, "sample_data", "(sample)")
        self.dataset_loaded.emit(sample)

    def delete_selected(self):
        item = self.dataset_list.currentItem()
        if item and item.text() in self.datasets:
            del self.datasets[item.text()]
            self._refresh_list()
            self.preview_table.setRowCount(0)
            self.stats_label.setText("No dataset selected")
            self.source_preview.clear()

    def on_dataset_selected(self, item):
        name = item.text()
        if name in self.datasets:
            info = self.datasets[name]
            self.current_data = info["data"]
            self._show_preview(info["data"], name, info["path"])

    def _refresh_list(self):
        self.dataset_list.clear()
        for name in self.datasets:
            info = self.datasets[name]
            item = QListWidgetItem(f"{name}  ({len(info['data'])} samples)")
            self.dataset_list.addItem(item)

    def _show_preview(self, data, name, path):
        total_chars = sum(len(t) for t in data)
        self.stats_label.setText(
            f"{name}  |  {len(data)} samples  |  {total_chars:,} chars  (~{total_chars/1000:.0f}K tokens)"
        )
        self.preview_table.setColumnCount(2)
        self.preview_table.setHorizontalHeaderLabels(["#", "Text (truncated)"])
        rows = min(len(data), 30)
        self.preview_table.setRowCount(rows)
        for r in range(rows):
            self.preview_table.setItem(r, 0, QTableWidgetItem(str(r + 1)))
            txt = data[r].replace("\n", " ")
            self.preview_table.setItem(r, 1, QTableWidgetItem(txt[:200]))
        self.preview_table.resizeColumnsToContents()
        self.preview_table.setColumnWidth(1, max(400, self.preview_table.columnWidth(1)))

        self.source_preview.clear()
        self.source_preview.append(f"# {path}\n")
        for t in data[:15]:
            self.source_preview.append(t[:300])

    def get_training_data(self):
        return self.current_data or None