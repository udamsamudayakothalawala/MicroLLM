"""Dataset balancing with stratified sampling, reservoir sampling, and distribution control."""

from __future__ import annotations

import logging
import random
from collections import Counter, defaultdict
from dataclasses import dataclass, field
from typing import Any, Callable, Generic, Optional, TypeVar

logger = logging.getLogger(__name__)

T = TypeVar("T")


@dataclass
class BalancingConfig:
    """Configuration for dataset balancing."""

    target_size: Optional[int] = None
    max_imbalance_ratio: float = 1.5
    min_samples_per_class: int = 10
    strategy: str = "oversample"
    random_seed: int = 42
    stratify_key: str = "category"
    domain_key: str = "domain"
    language_key: str = "language"
    length_key: str = "length"


@dataclass
class DistributionInfo:
    """Information about a class distribution."""

    class_name: str
    count: int
    ratio: float
    indices: list[int]


class CategoryBalancer:
    """Balances dataset by category/class distribution."""

    def __init__(self, config: BalancingConfig) -> None:
        self.config = config
        self._rng = random.Random(config.random_seed)

    def compute_distribution(
        self, items: list[dict[str, Any]], key: str
    ) -> dict[str, DistributionInfo]:
        class_indices: dict[str, list[int]] = defaultdict(list)
        for i, item in enumerate(items):
            label = str(item.get(key, "unknown"))
            class_indices[label].append(i)

        total = len(items)
        distribution: dict[str, DistributionInfo] = {}
        for cls, indices in class_indices.items():
            distribution[cls] = DistributionInfo(
                class_name=cls,
                count=len(indices),
                ratio=len(indices) / max(total, 1),
                indices=indices,
            )
        return distribution

    def _oversample(
        self, items: list[dict[str, Any]], key: str
    ) -> list[dict[str, Any]]:
        distribution = self.compute_distribution(items, key)
        if not distribution:
            return items

        max_count = max(d.info.count if hasattr(d, 'info') else d.count for d in distribution.values())
        balanced: list[dict[str, Any]] = []

        for cls, info in distribution.items():
            class_items = [items[i] for i in info.indices]
            balanced.extend(class_items)

            if info.count < max_count:
                needed = max_count - info.count
                for _ in range(needed):
                    balanced.append(self._rng.choice(class_items))

        self._rng.shuffle(balanced)
        return balanced

    def _undersample(
        self, items: list[dict[str, Any]], key: str
    ) -> list[dict[str, Any]]:
        distribution = self.compute_distribution(items, key)
        if not distribution:
            return items

        min_count = min(d.count for d in distribution.values())
        min_count = max(min_count, self.config.min_samples_per_class)

        balanced: list[dict[str, Any]] = []
        for cls, info in distribution.items():
            class_items = [items[i] for i in info.indices]
            sampled = self._rng.sample(class_items, min(len(class_items), min_count))
            balanced.extend(sampled)

        self._rng.shuffle(balanced)
        return balanced

    def _hybrid(
        self, items: list[dict[str, Any]], key: str
    ) -> list[dict[str, Any]]:
        distribution = self.compute_distribution(items, key)
        if not distribution:
            return items

        counts = [d.count for d in distribution.values()]
        median_count = sorted(counts)[len(counts) // 2]
        target = max(median_count, self.config.min_samples_per_class)

        balanced: list[dict[str, Any]] = []
        for cls, info in distribution.items():
            class_items = [items[i] for i in info.indices]

            if info.count >= target:
                sampled = self._rng.sample(class_items, target)
                balanced.extend(sampled)
            else:
                balanced.extend(class_items)
                needed = target - info.count
                for _ in range(needed):
                    balanced.append(self._rng.choice(class_items))

        self._rng.shuffle(balanced)
        return balanced

    def balance(
        self, items: list[dict[str, Any]], key: Optional[str] = None, strategy: Optional[str] = None
    ) -> list[dict[str, Any]]:
        key = key or self.config.stratify_key
        strat = strategy or self.config.strategy

        if strat == "oversample":
            return self._oversample(items, key)
        elif strat == "undersample":
            return self._undersample(items, key)
        elif strat == "hybrid":
            return self._hybrid(items, key)
        else:
            raise ValueError(f"Unknown strategy: {strat}")


class DomainBalancer:
    """Balances dataset across domains."""

    def __init__(self, config: BalancingConfig) -> None:
        self.config = config
        self._category_balancer = CategoryBalancer(config)

    def balance(
        self, items: list[dict[str, Any]], domain_key: Optional[str] = None
    ) -> list[dict[str, Any]]:
        key = domain_key or self.config.domain_key
        return self._category_balancer.balance(items, key=key)


class LanguageBalancer:
    """Balances dataset across languages."""

    def __init__(self, config: BalancingConfig) -> None:
        self.config = config
        self._category_balancer = CategoryBalancer(config)

    def balance(
        self, items: list[dict[str, Any]], language_key: Optional[str] = None
    ) -> list[dict[str, Any]]:
        key = language_key or self.config.language_key
        return self._category_balancer.balance(items, key=key)


class LengthBalancer:
    """Balances dataset across length buckets."""

    BUCKET_EDGES = (0, 100, 500, 1000, 5000, 10000, 50000)

    def __init__(self, config: BalancingConfig) -> None:
        self.config = config
        self._rng = random.Random(config.random_seed)

    def _get_bucket(self, length: int) -> str:
        for i in range(len(self.BUCKET_EDGES) - 1):
            if self.BUCKET_EDGES[i] <= length < self.BUCKET_EDGES[i + 1]:
                return f"{self.BUCKET_EDGES[i]}-{self.BUCKET_EDGES[i + 1]}"
        return f"{self.BUCKET_EDGES[-1]}+"

    def _compute_length(self, item: dict[str, Any]) -> int:
        if "text" in item:
            return len(str(item["text"]))
        if "content" in item:
            return len(str(item["content"]))
        length_val = item.get(self.config.length_key)
        if length_val is not None:
            return int(length_val)
        return 0

    def balance(self, items: list[dict[str, Any]]) -> list[dict[str, Any]]:
        bucketed: dict[str, list[dict[str, Any]]] = defaultdict(list)
        for item in items:
            length = self._compute_length(item)
            bucket = self._get_bucket(length)
            bucketed[bucket].append(item)

        if not bucketed:
            return items

        target_count = max(
            self.config.min_samples_per_class,
            min(len(v) for v in bucketed.values()),
        )

        balanced: list[dict[str, Any]] = []
        for bucket, bucket_items in bucketed.items():
            if len(bucket_items) >= target_count:
                balanced.extend(self._rng.sample(bucket_items, target_count))
            else:
                balanced.extend(bucket_items)
                needed = target_count - len(bucket_items)
                for _ in range(needed):
                    balanced.append(self._rng.choice(bucket_items))

        self._rng.shuffle(balanced)
        return balanced


class StratifiedSampler:
    """Stratified sampling ensuring representation across multiple keys."""

    def __init__(self, config: BalancingConfig) -> None:
        self.config = config
        self._rng = random.Random(config.random_seed)

    def sample(
        self,
        items: list[dict[str, Any]],
        strata_keys: list[str],
        sample_size: Optional[int] = None,
    ) -> list[dict[str, Any]]:
        strata: dict[tuple[str, ...], list[dict[str, Any]]] = defaultdict(list)
        for item in items:
            key = tuple(str(item.get(k, "unknown")) for k in strata_keys)
            strata[key].append(item)

        target = sample_size or len(items)
        total_items = len(items)

        sampled: list[dict[str, Any]] = []
        for stratum_key, stratum_items in strata.items():
            proportion = len(stratum_items) / max(total_items, 1)
            n_samples = max(1, int(target * proportion))
            n_samples = min(n_samples, len(stratum_items))
            sampled.extend(self._rng.sample(stratum_items, n_samples))

        self._rng.shuffle(sampled)
        return sampled[:target]


class ReservoirSampler(Generic[T]):
    """Reservoir sampling for streaming/large datasets."""

    def __init__(self, k: int, seed: int = 42) -> None:
        self.k = k
        self._rng = random.Random(seed)
        self._reservoir: list[T] = []
        self._count = 0

    def add(self, item: T) -> None:
        self._count += 1
        if len(self._reservoir) < self.k:
            self._reservoir.append(item)
        else:
            j = self._rng.randint(0, self._count - 1)
            if j < self.k:
                self._reservoir[j] = item

    def add_batch(self, items: list[T]) -> None:
        for item in items:
            self.add(item)

    @property
    def samples(self) -> list[T]:
        return list(self._reservoir)

    @property
    def count(self) -> int:
        return self._count

    def reset(self) -> None:
        self._reservoir.clear()
        self._count = 0


class DatasetBalancer:
    """Unified dataset balancing interface."""

    def __init__(self, config: Optional[BalancingConfig] = None) -> None:
        self.config = config or BalancingConfig()
        self._category = CategoryBalancer(self.config)
        self._domain = DomainBalancer(self.config)
        self._language = LanguageBalancer(self.config)
        self._length = LengthBalancer(self.config)
        self._stratified = StratifiedSampler(self.config)

    def balance(
        self,
        items: list[dict[str, Any]],
        by: str = "category",
        strategy: Optional[str] = None,
        **kwargs,
    ) -> list[dict[str, Any]]:
        if by == "category":
            return self._category.balance(items, strategy=strategy, **kwargs)
        elif by == "domain":
            return self._domain.balance(items, **kwargs)
        elif by == "language":
            return self._language.balance(items, **kwargs)
        elif by == "length":
            return self._length.balance(items)
        elif by == "stratified":
            keys = kwargs.get("strata_keys", ["category", "language"])
            return self._stratified.sample(items, keys, **kwargs)
        else:
            raise ValueError(f"Unknown balancing method: {by}")

    def get_distribution(self, items: list[dict[str, Any]], key: str) -> dict[str, int]:
        counter = Counter()
        for item in items:
            counter[str(item.get(key, "unknown"))] += 1
        return dict(counter)

    def get_stats(self, items: list[dict[str, Any]], key: str) -> dict[str, Any]:
        dist = self.get_distribution(items, key)
        if not dist:
            return {"total": 0, "num_classes": 0}
        values = list(dist.values())
        return {
            "total": sum(values),
            "num_classes": len(values),
            "min_class_size": min(values),
            "max_class_size": max(values),
            "mean_class_size": sum(values) / len(values),
            "imbalance_ratio": max(values) / max(min(values), 1),
            "distribution": dist,
        }
