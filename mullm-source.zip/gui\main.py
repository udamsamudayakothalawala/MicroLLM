"""muLLM GUI - Entry point.

Launch with:  python -m gui.main   or   mullm gui
"""

import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import torch  # noqa: E402  (must load before PyQt5 to avoid DLL conflicts on Windows)

from PyQt5.QtWidgets import QApplication
from PyQt5.QtGui import QFont, QIcon

from gui.main_window import MainWindow


def main():
    app = QApplication(sys.argv)
    app.setApplicationName("muLLM")
    _icon_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "assets")
    _icon = os.path.join(_icon_dir, "MULLMICON.png")
    if os.path.exists(_icon):
        app.setWindowIcon(QIcon(_icon))
    font = QFont("Segoe UI", 10)
    font.setStyleStrategy(QFont.PreferAntialias)
    app.setFont(font)
    window = MainWindow()
    window.show()
    sys.exit(app.exec_())


if __name__ == "__main__":
    main()