import math
from typing import Optional, Dict, Any

import torch
import torch.nn as nn
import torch.nn.functional as F


class AbsolutePositionalEmbedding(nn.Module):
    def __init__(self, max_position_embeddings: int, hidden_size: int, dropout: float = 0.0):
        super().__init__()
        self.max_position_embeddings = max_position_embeddings
        self.embedding = nn.Embedding(max_position_embeddings, hidden_size)
        self.dropout = nn.Dropout(dropout)

    def forward(self, x: torch.Tensor, position_ids: Optional[torch.Tensor] = None) -> torch.Tensor:
        seq_len = x.size(1)
        if position_ids is None:
            position_ids = torch.arange(seq_len, dtype=torch.long, device=x.device)
            position_ids = position_ids.unsqueeze(0).expand(x.size(0), -1)
        pos_emb = self.embedding(position_ids)
        return self.dropout(x + pos_emb)


class RotaryPositionalEmbedding(nn.Module):
    def __init__(
        self,
        dim: int,
        max_position_embeddings: int = 2048,
        base: float = 10000.0,
        scaling_factor: float = 1.0,
        theta: Optional[float] = None,
    ):
        super().__init__()
        self.dim = dim
        self.max_position_embeddings = max_position_embeddings
        self.base = base if theta is None else theta
        self.scaling_factor = scaling_factor
        inv_freq = 1.0 / (
            self.base ** (torch.arange(0, dim, 2, dtype=torch.float32) / dim)
        )
        self.register_buffer("inv_freq", inv_freq, persistent=False)
        self._cached_cos: Optional[torch.Tensor] = None
        self._cached_sin: Optional[torch.Tensor] = None
        self._cached_seq_len: int = 0

    def _build_cache(self, seq_len: int, device: torch.device) -> None:
        if seq_len <= self._cached_seq_len and self._cached_cos is not None:
            return
        t = torch.arange(seq_len, device=device, dtype=torch.float32)
        t = t / self.scaling_factor
        freqs = torch.einsum("i,j->ij", t, self.inv_freq)
        emb = torch.cat((freqs, freqs), dim=-1)
        self._cached_cos = emb.cos().to(device)
        self._cached_sin = emb.sin().to(device)
        self._cached_seq_len = seq_len

    @staticmethod
    def rotate_half(x: torch.Tensor) -> torch.Tensor:
        x1 = x[..., : x.shape[-1] // 2]
        x2 = x[..., x.shape[-1] // 2 :]
        return torch.cat((-x2, x1), dim=-1)

    def apply_rotary(self, x: torch.Tensor, cos: torch.Tensor, sin: torch.Tensor) -> torch.Tensor:
        cos = cos[: x.shape[-2], :].unsqueeze(0).unsqueeze(0)
        sin = sin[: x.shape[-2], :].unsqueeze(0).unsqueeze(0)
        return (x * cos) + (self.rotate_half(x) * sin)

    def forward(
        self,
        q: torch.Tensor,
        k: torch.Tensor,
        position_ids: Optional[torch.Tensor] = None,
    ) -> tuple:
        seq_len = q.size(2)
        self._build_cache(seq_len, q.device)
        cos = self._cached_cos[:seq_len]
        sin = self._cached_sin[:seq_len]
        q_rot = self.apply_rotary(q, cos, sin)
        k_rot = self.apply_rotary(k, cos, sin)
        return q_rot, k_rot


class YaRNSinusoidalPositionalEmbedding(nn.Module):
    def __init__(
        self,
        dim: int,
        max_position_embeddings: int = 2048,
        base: float = 10000.0,
        scale: float = 1.0,
        original_max_position_embeddings: int = 2048,
        extrapolation_factor: float = 1.0,
        attn_factor: float = 1.0,
        beta_fast: float = 32.0,
        beta_slow: float = 1.0,
    ):
        super().__init__()
        self.dim = dim
        self.max_position_embeddings = max_position_embeddings
        self.base = base
        self.scale = scale
        self.original_max_position_embeddings = original_max_position_embeddings
        self.extrapolation_factor = extrapolation_factor
        self.attn_factor = attn_factor
        self.beta_fast = beta_fast
        self.beta_slow = beta_slow

        inv_freq = 1.0 / (base ** (torch.arange(0, dim, 2, dtype=torch.float32) / dim))
        self.register_buffer("inv_freq", inv_freq, persistent=False)

        self._compute_yarnd_freqs(max_position_embeddings)

    def _compute_yarnd_freqs(self, seq_len: int) -> None:
        dim = self.dim
        inv_freq = self.inv_freq
        t = torch.arange(seq_len, dtype=torch.float32) / self.scale
        freqs = torch.einsum("i,j->ij", t, inv_freq)
        emb = torch.cat((freqs, freqs), dim=-1)

        dims = dim // 2
        freqs = inv_freq
        low, high = freqs.min(), freqs.max()
        freqs_low = 1.0 / (self.original_max_position_embeddings / (2 * math.pi))
        freqs_high = 1.0 / (8 * math.pi)

        ramp = torch.sigmoid(
            self.beta_fast * (freqs - freqs_low) / (freqs_high - freqs_low)
            - self.beta_slow * (freqs_high - freqs) / (freqs_high - freqs_low)
        )
        self.register_buffer("ramp", ramp, persistent=False)

        new_freqs = (1.0 - ramp) * freqs / self.scale + ramp * freqs
        self.register_buffer("yarnd_inv_freq", new_freqs, persistent=False)

    @staticmethod
    def rotate_half(x: torch.Tensor) -> torch.Tensor:
        x1 = x[..., : x.shape[-1] // 2]
        x2 = x[..., x.shape[-1] // 2 :]
        return torch.cat((-x2, x1), dim=-1)

    def forward(
        self,
        q: torch.Tensor,
        k: torch.Tensor,
        position_ids: Optional[torch.Tensor] = None,
    ) -> tuple:
        seq_len = q.size(2)
        t = torch.arange(seq_len, device=q.device, dtype=torch.float32) / self.scale
        freqs = torch.einsum("i,j->ij", t, self.yarnd_inv_freq)
        emb = torch.cat((freqs, freqs), dim=-1)
        cos = emb.cos() * self.attn_factor
        sin = emb.sin() * self.attn_factor
        cos = cos[:seq_len].unsqueeze(0).unsqueeze(0)
        sin = sin[:seq_len].unsqueeze(0).unsqueeze(0)
        q_rot = (q * cos) + (self.rotate_half(q) * sin)
        k_rot = (k * cos) + (self.rotate_half(k) * sin)
        return q_rot, k_rot


class ALiBi(nn.Module):
    def __init__(self, num_heads: int, max_position_embeddings: int = 2048):
        super().__init__()
        self.num_heads = num_heads
        self.max_position_embeddings = max_position_embeddings
        slopes = self._compute_slopes(num_heads)
        self.register_buffer("slopes", slopes, persistent=False)

    @staticmethod
    def _compute_slopes(num_heads: int) -> torch.Tensor:
        def get_slopes_power_of_2(n: int) -> list:
            start = 2 ** (-(2 ** -(math.log2(n) - 3)))
            ratio = start
            return [start * ratio**i for i in range(n)]

        if math.log2(num_heads).is_integer():
            slopes = get_slopes_power_of_2(num_heads)
        else:
            n = 2 ** math.floor(math.log2(num_heads))
            slopes_power_of_2 = get_slopes_power_of_2(n)
            extra = num_heads - n
            slopes_extra = [
                2 ** (-(2 ** -(math.log2(2 * n) - 3) * (i + 1)))
                for i in range(extra)
            ]
            slopes = slopes_power_of_2 + slopes_extra
        return torch.tensor(slopes, dtype=torch.float32)

    def forward(self, attention_scores: torch.Tensor) -> torch.Tensor:
        batch_size, num_heads, seq_len_q, seq_len_k = attention_scores.shape
        device = attention_scores.device
        position_ids_q = torch.arange(seq_len_q, device=device, dtype=torch.float32).unsqueeze(1)
        position_ids_k = torch.arange(seq_len_k, device=device, dtype=torch.float32).unsqueeze(0)
        distance = (position_ids_k - position_ids_q).abs()
        slopes = self.slopes[:num_heads].unsqueeze(1).unsqueeze(2)
        alibi_bias = -slopes * distance.unsqueeze(0)
        return attention_scores + alibi_bias
