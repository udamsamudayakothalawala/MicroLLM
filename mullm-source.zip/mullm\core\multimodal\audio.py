import math
from abc import ABC, abstractmethod
from typing import Any, Dict, List, Optional, Tuple

import torch
import torch.nn as nn
import torch.nn.functional as F


class MelSpectrogram(nn.Module):
    def __init__(
        self,
        sample_rate: int = 16000,
        n_fft: int = 400,
        hop_length: int = 160,
        n_mels: int = 80,
        f_min: float = 0.0,
        f_max: Optional[float] = None,
    ):
        super().__init__()
        self.sample_rate = sample_rate
        self.n_fft = n_fft
        self.hop_length = hop_length
        self.n_mels = n_mels
        self.f_min = f_min
        self.f_max = f_max or sample_rate // 2

        self.register_buffer("mel_basis", self._build_mel_basis())
        window = torch.hann_window(n_fft)
        self.register_buffer("window", window)

    def _build_mel_basis(self) -> torch.Tensor:
        n_fft = self.n_fft
        n_mels = self.n_mels
        f_min = self.f_min
        f_max = self.f_max
        sample_rate = self.sample_rate

        low = f_min
        high = f_max
        mel_min = 2595 * math.log10(1 + low / 700)
        mel_max = 2595 * math.log10(1 + high / 700)
        mel_points = torch.linspace(mel_min, mel_max, n_mels + 2)
        hz_points = 700 * (10 ** (mel_points / 2595) - 1)

        bin_width = sample_rate / n_fft
        fft_bins = hz_points / bin_width
        fft_bins = fft_bins.round().long()

        mel_basis = torch.zeros(n_mels, n_fft // 2 + 1)
        for m in range(1, n_mels + 1):
            left = int(fft_bins[m - 1])
            center = int(fft_bins[m])
            right = int(fft_bins[m + 1])

            if left >= center or center >= right:
                continue

            for i in range(left, center):
                mel_basis[m - 1, i] = (i - left) / (center - left)
            for i in range(center, right):
                mel_basis[m - 1, i] = (right - i) / (right - center)

        return mel_basis

    def forward(self, waveform: torch.Tensor) -> torch.Tensor:
        if waveform.ndim == 2:
            waveform = waveform.unsqueeze(1)
        if waveform.ndim == 3:
            waveform = waveform.squeeze(1)

        stft = torch.stft(
            waveform,
            n_fft=self.n_fft,
            hop_length=self.hop_length,
            win_length=self.n_fft,
            window=self.window,
            return_complex=True,
        )
        magnitude = stft.abs()
        mel_spec = torch.matmul(self.mel_basis, magnitude)
        mel_spec = torch.log(torch.clamp(mel_spec, min=1e-5))
        return mel_spec


class AudioEncoder(nn.Module):
    def __init__(self, n_mels: int = 80, hidden_dim: int = 512, num_layers: int = 6, num_heads: int = 8):
        super().__init__()
        self.mel_spec = MelSpectrogram(n_mels=n_mels)
        self.input_proj = nn.Conv1d(n_mels, hidden_dim, kernel_size=3, padding=1)
        self.positional_encoding = PositionalEncoding(hidden_dim)

        encoder_layer = nn.TransformerEncoderLayer(d_model=hidden_dim, nhead=num_heads, dim_feedforward=hidden_dim * 4, batch_first=True)
        self.transformer = nn.TransformerEncoder(encoder_layer, num_layers)

        self.output_norm = nn.LayerNorm(hidden_dim)

    def forward(self, waveform: torch.Tensor) -> torch.Tensor:
        mel = self.mel_spec(waveform)
        mel = self.input_proj(mel)
        mel = mel.transpose(1, 2)
        mel = self.positional_encoding(mel)
        hidden = self.transformer(mel)
        hidden = self.output_norm(hidden)
        return hidden

    def encode(self, waveform: torch.Tensor) -> torch.Tensor:
        return self.forward(waveform)


class PositionalEncoding(nn.Module):
    def __init__(self, d_model: int, max_len: int = 5000):
        super().__init__()
        pe = torch.zeros(max_len, d_model)
        position = torch.arange(0, max_len, dtype=torch.float).unsqueeze(1)
        div_term = torch.exp(torch.arange(0, d_model, 2).float() * (-math.log(10000.0) / d_model))
        pe[:, 0::2] = torch.sin(position * div_term)
        pe[:, 1::2] = torch.cos(position * div_term)
        pe = pe.unsqueeze(0)
        self.register_buffer("pe", pe)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return x + self.pe[:, :x.shape[1], :]


class Conv1DBlock(nn.Module):
    def __init__(self, in_dim: int, out_dim: int, kernel_size: int = 3, stride: int = 1, dropout: float = 0.1):
        super().__init__()
        self.conv = nn.Conv1d(in_dim, out_dim, kernel_size, stride, padding=kernel_size // 2)
        self.norm = nn.LayerNorm(out_dim)
        self.act = nn.GELU()
        self.dropout = nn.Dropout(dropout)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        residual = x
        x = self.conv(x)
        x = x.transpose(1, 2)
        x = self.norm(x)
        x = x.transpose(1, 2)
        x = self.act(x)
        x = self.dropout(x)
        if residual.shape == x.shape:
            x = x + residual
        return x


class WhisperStyleEncoder(nn.Module):
    def __init__(self, n_mels: int = 80, d_model: int = 512, num_layers: int = 4, dropout: float = 0.1):
        super().__init__()
        self.mel_spec = MelSpectrogram(n_mels=n_mels)
        self.conv1 = nn.Conv1d(n_mels, d_model, kernel_size=3, padding=1)
        self.conv2 = nn.Conv1d(d_model, d_model, kernel_size=3, stride=2, padding=1)

        self.blocks = nn.ModuleList([
            Conv1DBlock(d_model, d_model, dropout=dropout) for _ in range(num_layers)
        ])

        self.positional_encoding = PositionalEncoding(d_model)
        self.output_norm = nn.LayerNorm(d_model)

    def forward(self, waveform: torch.Tensor) -> torch.Tensor:
        mel = self.mel_spec(waveform)
        x = self.conv1(mel)
        x = self.conv2(x)
        for block in self.blocks:
            x = block(x)
        x = x.transpose(1, 2)
        x = self.positional_encoding(x)
        x = self.output_norm(x)
        return x

    def encode(self, waveform: torch.Tensor) -> torch.Tensor:
        return self.forward(waveform)


class AudioProcessor:
    def __init__(self, sample_rate: int = 16000, n_mels: int = 80):
        self.sample_rate = sample_rate
        self.mel_spec = MelSpectrogram(sample_rate=sample_rate, n_mels=n_mels)

    def resample(self, waveform: torch.Tensor, orig_rate: int, target_rate: int) -> torch.Tensor:
        if orig_rate == target_rate:
            return waveform
        if orig_rate < target_rate and target_rate % orig_rate == 0:
            ratio = target_rate // orig_rate
            return waveform.repeat_interleave(ratio, dim=-1)
        if orig_rate > target_rate and orig_rate % target_rate == 0:
            ratio = orig_rate // target_rate
            return waveform[..., ::ratio]
        num_samples = int(waveform.shape[-1] * target_rate / orig_rate)
        return F.interpolate(waveform.unsqueeze(1), size=num_samples, mode="linear", align_corners=False).squeeze(1)

    def normalize(self, waveform: torch.Tensor) -> torch.Tensor:
        std, mean = torch.std_mean(waveform, dim=-1, keepdim=True)
        return (waveform - mean) / (std + 1e-8)

    def augment(self, waveform: torch.Tensor, noise_level: float = 0.005, time_shift_max: int = 3) -> torch.Tensor:
        if noise_level > 0:
            noise = torch.randn_like(waveform) * noise_level
            waveform = waveform + noise
        if time_shift_max > 0:
            shift = torch.randint(-time_shift_max, time_shift_max, (1,)).item()
            waveform = torch.roll(waveform, shift, dims=-1)
        return waveform

    def extract_mel(self, waveform: torch.Tensor) -> torch.Tensor:
        return self.mel_spec(waveform)

    def __call__(self, waveform: torch.Tensor, sample_rate: int = 16000) -> torch.Tensor:
        if sample_rate != self.sample_rate:
            waveform = self.resample(waveform, sample_rate, self.sample_rate)
        waveform = self.normalize(waveform)
        return waveform


class SpeechRecognizer(nn.Module):
    def __init__(self, vocab_size: int = 1000, d_model: int = 512, num_encoder_layers: int = 6, num_decoder_layers: int = 6, num_heads: int = 8):
        super().__init__()
        self.encoder = WhisperStyleEncoder(n_mels=80, d_model=d_model)
        self.word_embedding = nn.Embedding(vocab_size, d_model)
        self.pos_encoding = PositionalEncoding(d_model)

        decoder_layer = nn.TransformerDecoderLayer(d_model=d_model, nhead=num_heads, dim_feedforward=d_model * 4, batch_first=True)
        self.decoder = nn.TransformerDecoder(decoder_layer, num_decoder_layers)

        self.output_proj = nn.Linear(d_model, vocab_size)

    def forward(self, waveform: torch.Tensor, text_tokens: Optional[torch.Tensor] = None) -> torch.Tensor:
        memory = self.encoder(waveform)
        if text_tokens is not None:
            tgt = self.word_embedding(text_tokens)
            tgt = self.pos_encoding(tgt)
            tgt_mask = nn.Transformer.generate_square_subsequent_mask(tgt.shape[1], device=waveform.device)
            output = self.decoder(tgt, memory, tgt_mask=tgt_mask)
            logits = self.output_proj(output)
            return logits
        return memory

    def transcribe(self, waveform: torch.Tensor, start_token: int = 0, end_token: int = 2, max_len: int = 256) -> torch.Tensor:
        memory = self.encoder(waveform)
        B = waveform.shape[0]
        generated = torch.full((B, 1), start_token, dtype=torch.long, device=waveform.device)

        for _ in range(max_len - 1):
            seq_len = generated.shape[1]
            tgt = self.word_embedding(generated)
            tgt = self.pos_encoding(tgt)
            tgt_mask = nn.Transformer.generate_square_subsequent_mask(seq_len, device=waveform.device)
            output = self.decoder(tgt, memory, tgt_mask=tgt_mask)
            logits = self.output_proj(output[:, -1:, :])
            next_token = logits.argmax(dim=-1)
            generated = torch.cat([generated, next_token], dim=1)
            if (next_token == end_token).all():
                break
        return generated


class AudioEmbeddingExtractor(nn.Module):
    def __init__(self, n_mels: int = 80, embed_dim: int = 768, num_layers: int = 8, num_heads: int = 8):
        super().__init__()
        self.mel_spec = MelSpectrogram(n_mels=n_mels)
        self.input_proj = nn.Conv1d(n_mels, embed_dim, kernel_size=3, padding=1)

        encoder_layer = nn.TransformerEncoderLayer(d_model=embed_dim, nhead=num_heads, dim_feedforward=embed_dim * 4, batch_first=True)
        self.transformer = nn.TransformerEncoder(encoder_layer, num_layers)

        self.global_pool = nn.Sequential(
            nn.AdaptiveAvgPool1d(1),
            nn.Flatten(),
        )

        self.projection = nn.Linear(embed_dim, embed_dim)
        self.norm = nn.LayerNorm(embed_dim)

    def forward(self, waveform: torch.Tensor) -> Dict[str, torch.Tensor]:
        mel = self.mel_spec(waveform)
        x = self.input_proj(mel)
        x = x.transpose(1, 2)
        x = self.transformer(x)
        global_embed = self.global_pool(x.transpose(1, 2))
        projected = self.projection(global_embed)
        normalized = self.norm(projected)
        return {
            "global_embedding": global_embed,
            "projected_embedding": normalized,
            "token_features": x,
        }

    def extract_embedding(self, waveform: torch.Tensor) -> torch.Tensor:
        output = self.forward(waveform)
        return output["projected_embedding"]


class SpeakerDiarizer(nn.Module):
    def __init__(self, num_speakers: int = 8, embed_dim: int = 512, num_layers: int = 4):
        super().__init__()
        self.audio_encoder = AudioEmbeddingExtractor(embed_dim=embed_dim)
        self.segment_size = 256

        encoder_layer = nn.TransformerEncoderLayer(d_model=embed_dim, nhead=8, dim_feedforward=embed_dim * 4, batch_first=True)
        self.temporal_encoder = nn.TransformerEncoder(encoder_layer, num_layers)

        self.speaker_classifier = nn.Linear(embed_dim, num_speakers)
        self.segment_embedding = nn.Parameter(torch.randn(1, 1, embed_dim) * 0.02)

    def forward(self, waveform: torch.Tensor) -> torch.Tensor:
        embeddings = self.audio_encoder(waveform)
        token_features = embeddings["token_features"]
        B, T, D = token_features.shape

        num_segments = math.ceil(T / self.segment_size)
        pad_len = num_segments * self.segment_size - T
        if pad_len > 0:
            token_features = F.pad(token_features, (0, 0, 0, pad_len))

        segments = token_features.reshape(B, num_segments, self.segment_size, D).mean(dim=2)
        segments = segments + self.segment_embedding.expand(B, -1, -1)
        segments = self.temporal_encoder(segments)
        speaker_logits = self.speaker_classifier(segments)
        return speaker_logits

    def diarize(self, waveform: torch.Tensor, threshold: float = 0.5) -> List[Dict[str, Any]]:
        speaker_logits = self.forward(waveform)
        speaker_probs = torch.sigmoid(speaker_logits)
        B, T, S = speaker_probs.shape
        results = []
        for b in range(B):
            active_speakers = (speaker_probs[b] > threshold).int()
            segments = []
            current_speaker = -1
            start = 0
            for t in range(T):
                dominant = active_speakers[t].argmax().item() if active_speakers[t].sum() > 0 else -1
                if dominant != current_speaker:
                    if current_speaker >= 0:
                        segments.append({
                            "speaker": current_speaker,
                            "start": start * self.segment_size / 16000,
                            "end": t * self.segment_size / 16000,
                        })
                    current_speaker = dominant
                    start = t
            if current_speaker >= 0:
                segments.append({
                    "speaker": current_speaker,
                    "start": start * self.segment_size / 16000,
                    "end": T * self.segment_size / 16000,
                })
            results.append({"segments": segments, "speaker_probs": speaker_probs[b]})
        return results


class LanguageIdentifier(nn.Module):
    def __init__(self, num_languages: int = 100, embed_dim: int = 512, num_layers: int = 4):
        super().__init__()
        self.audio_encoder = AudioEmbeddingExtractor(embed_dim=embed_dim)
        self.classifier = nn.Sequential(
            nn.Linear(embed_dim, embed_dim * 2),
            nn.GELU(),
            nn.Dropout(0.1),
            nn.Linear(embed_dim * 2, embed_dim),
            nn.GELU(),
            nn.Dropout(0.1),
            nn.Linear(embed_dim, num_languages),
        )

    def forward(self, waveform: torch.Tensor) -> torch.Tensor:
        embeddings = self.audio_encoder(waveform)
        lang_logits = self.classifier(embeddings["global_embedding"])
        return lang_logits

    def identify(self, waveform: torch.Tensor) -> Dict[str, Any]:
        logits = self.forward(waveform)
        probs = F.softmax(logits, dim=-1)
        predictions = logits.argmax(dim=-1)
        confidences = probs.max(dim=-1).values
        return {
            "logits": logits,
            "probs": probs,
            "predictions": predictions,
            "confidences": confidences,
        }
