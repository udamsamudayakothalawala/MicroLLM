#Requires -Version 5.1
<#
.SYNOPSIS
    muLLM Evaluation Launcher (PowerShell)

.EXAMPLE
    .\eval.ps1 -ModelName "my-model" -Benchmarks "hellaswag,mmlu"
#>

[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [string]$ModelName,

    [string]$Benchmarks = "hellaswag",
    [int]$MaxSamples,
    [string]$OutputDir = ".\eval_results",
    [string]$CacheDir = ".\eval_cache",
    [switch]$NoCache,
    [int]$NumGpus = 1,
    [int]$BatchSize = 1,
    [int]$Timeout = 300,
    [int]$MaxTokens = 256,
    [string]$ServerHost = "localhost",
    [int]$ServerPort = 8000,
    [string]$ApiKey
)

$ErrorActionPreference = "Stop"

Write-Host "============================================" -ForegroundColor Cyan
Write-Host "  muLLM Evaluation" -ForegroundColor Cyan
Write-Host "============================================" -ForegroundColor Cyan
Write-Host "Model:          $ModelName"
Write-Host "Benchmarks:     $Benchmarks"
Write-Host "Max samples:    $(if ($MaxSamples -gt 0) { $MaxSamples } else { 'auto' })"
Write-Host "Output:         $OutputDir"
Write-Host "Cache:          $CacheDir"
Write-Host "Server:         ${ServerHost}:${ServerPort}"
Write-Host "============================================" -ForegroundColor Cyan

$args_ = @(
    "-m", "mullm.cli.main", "eval",
    "--model-name", $ModelName,
    "--benchmarks", $Benchmarks,
    "--output-dir", $OutputDir,
    "--cache-dir", $CacheDir,
    "--num-gpus", $NumGpus.ToString(),
    "--batch-size", $BatchSize.ToString(),
    "--timeout", $Timeout.ToString(),
    "--max-tokens", $MaxTokens.ToString(),
    "--server-host", $ServerHost,
    "--server-port", $ServerPort.ToString()
)

if ($MaxSamples -gt 0) { $args_ += "--max-samples"; $args_ += $MaxSamples.ToString() }
if ($NoCache) { $args_ += "--no-cache" }
if ($ApiKey) { $args_ += "--api-key"; $args_ += $ApiKey }

Write-Host "Starting evaluation..." -ForegroundColor Green
& python @args_

if ($LASTEXITCODE -ne 0) {
    Write-Error "Evaluation failed with exit code $LASTEXITCODE"
    exit $LASTEXITCODE
}

Write-Host "Evaluation complete." -ForegroundColor Green
