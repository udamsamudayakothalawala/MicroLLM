from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

import torch
import torch.nn as nn
import torch.nn.functional as F


@dataclass
class PrefixTuningConfig:
    num_prefix_tokens: int = 10
    reparam: bool = True
    encoder_hidden: int = 512
    encoder_dropout: float = 0.0
    prefix_projection: bool = True
    init_by_vocab: bool = True
    num_layers: Optional[int] = None
    num_heads: Optional[int] = None
    head_dim: Optional[int] = None
    hidden_size: Optional[int] = None


class PrefixEncoder(nn.Module):
    def __init__(
        self,
        num_prefix_tokens: int,
        hidden_size: int,
        num_layers: int,
        num_heads: int,
        head_dim: int,
        encoder_hidden: int = 512,
        encoder_dropout: float = 0.0,
        prefix_projection: bool = True,
    ):
        super().__init__()
        self.num_prefix_tokens = num_prefix_tokens
        self.hidden_size = hidden_size
        self.num_layers = num_layers
        self.num_heads = num_heads
        self.head_dim = head_dim
        self.prefix_projection = prefix_projection
        self.total_kv_tokens = num_prefix_tokens * 2 * num_layers

        if prefix_projection:
            self.embed = nn.Embedding(num_prefix_tokens, hidden_size)
            self.mlp = nn.Sequential(
                nn.Linear(hidden_size, encoder_hidden),
                nn.Tanh(),
                nn.Dropout(encoder_dropout),
                nn.Linear(encoder_hidden, num_layers * 2 * num_heads * head_dim),
            )
        else:
            self.embed = nn.Embedding(num_prefix_tokens, num_layers * 2 * num_heads * head_dim)
            self.mlp = nn.Identity()

        self._init_weights()

    def _init_weights(self):
        nn.init.normal_(self.embed.weight, mean=0.0, std=0.02)
        for module in self.mlp.modules():
            if isinstance(module, nn.Linear):
                nn.init.normal_(module.weight, mean=0.0, std=0.02)
                if module.bias is not None:
                    nn.init.zeros_(module.bias)

    def forward(self, batch_size: int, device: torch.device, dtype: torch.dtype) -> Tuple[torch.Tensor, torch.Tensor]:
        input_ids = torch.arange(self.num_prefix_tokens, device=device).unsqueeze(0).expand(batch_size, -1)
        embeddings = self.embed(input_ids)
        past_key_values = self.mlp(embeddings)
        past_key_values = past_key_values.view(
            batch_size,
            self.num_prefix_tokens,
            self.num_layers * 2,
            self.num_heads,
            self.head_dim,
        )
        past_key_values = past_key_values.permute([2, 0, 3, 1, 4])
        past_key_values = past_key_values.chunk(2, dim=0)
        keys = past_key_values[0].squeeze(0)
        values = past_key_values[1].squeeze(0)
        return keys, values


class PrefixTuningWrapper(nn.Module):
    def __init__(
        self,
        attention: nn.Module,
        config: PrefixTuningConfig,
        layer_id: int,
    ):
        super().__init__()
        self.attention = attention
        self.layer_id = layer_id
        self.num_prefix_tokens = config.num_prefix_tokens
        self.num_heads = config.num_heads or self._infer_num_heads(attention)
        self.head_dim = config.head_dim or self._infer_head_dim(attention)
        self.hidden_size = config.hidden_size or self._infer_hidden_size(attention)
        self.num_layers = config.num_layers or 1

        self.prefix_encoder = PrefixEncoder(
            num_prefix_tokens=config.num_prefix_tokens,
            hidden_size=self.hidden_size,
            num_layers=1,
            num_heads=self.num_heads,
            head_dim=self.head_dim,
            encoder_hidden=config.encoder_hidden,
            encoder_dropout=config.encoder_dropout,
            prefix_projection=config.prefix_projection,
        )

    def _infer_num_heads(self, attention: nn.Module) -> int:
        if hasattr(attention, "num_heads"):
            return attention.num_heads
        if hasattr(attention, "num_kv_heads"):
            return attention.num_kv_heads
        return 1

    def _infer_head_dim(self, attention: nn.Module) -> int:
        if hasattr(attention, "head_dim"):
            return attention.head_dim
        if hasattr(attention, "hidden_size") and hasattr(attention, "num_heads"):
            return attention.hidden_size // attention.num_heads
        return 1

    def _infer_hidden_size(self, attention: nn.Module) -> int:
        if hasattr(attention, "hidden_size"):
            return attention.hidden_size
        for proj in ["q_proj", "k_proj", "v_proj"]:
            if hasattr(attention, proj):
                return getattr(attention, proj).weight.size(1)
        for proj in ["q_proj", "k_proj", "v_proj"]:
            if hasattr(self.attention, proj):
                module = getattr(self.attention, proj)
                if hasattr(module, "in_features"):
                    return module.in_features
        return 768

    def forward(
        self,
        hidden_states: torch.Tensor,
        attention_mask: Optional[torch.Tensor] = None,
        past_key_value: Optional[object] = None,
        position_ids: Optional[torch.Tensor] = None,
        use_cache: Optional[bool] = None,
        output_attentions: bool = False,
    ) -> Tuple[torch.Tensor, Optional[torch.Tensor], Optional[object]]:
        batch_size = hidden_states.size(0)
        device = hidden_states.device
        dtype = hidden_states.dtype

        prefix_keys, prefix_values = self.prefix_encoder(batch_size, device, dtype)

        full_keys = torch.cat([prefix_keys, torch.zeros_like(prefix_keys)], dim=2)
        full_values = torch.cat([prefix_values, torch.zeros_like(prefix_values)], dim=2)

        if past_key_value is not None and hasattr(past_key_value, "set_prefix_cache"):
            past_key_value.set_prefix_cache(str(self.layer_id), prefix_keys, prefix_values, self.num_prefix_tokens)

        attn_output, attn_weights, past_key_value = self.attention(
            hidden_states,
            attention_mask=attention_mask,
            past_key_value=past_key_value,
            position_ids=position_ids,
            use_cache=use_cache,
            output_attentions=output_attentions,
        )

        return attn_output, attn_weights, past_key_value

    def get_prefix_params(self) -> Dict[str, torch.Tensor]:
        params = {}
        for name, param in self.prefix_encoder.named_parameters():
            params[f"prefix_encoder.{name}"] = param
        return params


def inject_prefix_tuning(
    model: nn.Module,
    config: PrefixTuningConfig,
) -> nn.Module:
    layer_count = 0
    for name, module in model.named_modules():
        if isinstance(module, (nn.MultiheadAttention,)) or any(
            attn_cls in type(module).__name__ for attn_cls in [
                "MultiHeadAttention", "GroupedQueryAttention", "MultiQueryAttention",
                "FlashAttentionWrapper", "SlidingWindowAttention", "SparseAttention",
            ]
        ):
            for param in module.parameters():
                param.requires_grad = False
            wrapper = PrefixTuningWrapper(module, config, layer_id=layer_count)
            parent_name, child_name = name.rsplit(".", 1) if "." in name else ("", name)
            parent = model
            if parent_name:
                for p in parent_name.split("."):
                    parent = getattr(parent, p)
            setattr(parent, child_name, wrapper)
            if config.num_layers is not None and layer_count >= config.num_layers - 1:
                break
            layer_count += 1

    return model
