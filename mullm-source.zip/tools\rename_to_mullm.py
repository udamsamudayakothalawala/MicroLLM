"""Rename project openllm/microllm/microLLM -> mullm/muLLM across content AND file/dir names."""

import os

ROOT = r"D:\Projects\openllm-platform"
SKIP_DIRS = {
    ".git", "dist", "build", "venv", ".venv", "__pycache__",
    ".pytest_cache", ".ruff_cache", "node_modules",
}
SKIP_NAMES = {
    "microllm.zip", "microLLM-User-Guide.pdf", "mullm.zip", "muLLM-User-Guide.pdf",
    "rename_to_mullm.py",
}

TEXT_EXT = {".py", ".toml", ".txt", ".md", ".iss", ".bat", ".json", ".yaml", ".yml",
            ".cfg", ".ini", ".ps1", ".sh", ".in", ".spec", ".html", ".css", ".js", ".makefile"}

REPLACEMENTS = [
    ("microLLM", "muLLM"),
    ("MicroLLM", "muLLM"),
    ("MICROLLM", "MULLM"),
    ("microllm", "mullm"),
    ("OpenLLM", "muLLM"),
    ("OPENLLM", "MULLM"),
    ("openllm", "mullm"),
]


def rename_text(content: str) -> str:
    for old, new in REPLACEMENTS:
        content = content.replace(old, new)
    return content


def process_dir(directory: str) -> int:
    count = 0
    # process children recursively first (files then subdirs), then rename entries
    for entry in os.scandir(directory):
        if entry.is_dir():
            if entry.name not in SKIP_DIRS:
                count += process_dir(entry.path)
    for entry in os.scandir(directory):
        if entry.is_file():
            if entry.name in SKIP_NAMES:
                continue
            ext = os.path.splitext(entry.name)[1].lower()
            if ext in TEXT_EXT or entry.name == "Makefile":
                with open(entry.path, encoding="utf-8", errors="ignore") as f:
                    original = f.read()
                updated = rename_text(original)
                if updated != original:
                    with open(entry.path, "w", encoding="utf-8", newline="") as f:
                        f.write(updated)
                    count += 1
        elif entry.is_dir():
            pass
    # Rename files then subdirs with old tokens in basename (bottom-up within this dir)
    for entry in sorted(os.scandir(directory), key=lambda e: (not e.is_dir(), 1)):
        if entry.name in SKIP_NAMES or entry.name in SKIP_DIRS:
            continue
        new_name = entry.name
        for old, new in REPLACEMENTS:
            if old in new_name:
                new_name = new_name.replace(old, new)
        if new_name != entry.name:
            new_path = os.path.join(directory, new_name)
            os.rename(entry.path, new_path)
            count += 1
    return count


if __name__ == "__main__":
    changed = process_dir(ROOT)
    print(f"Renamed {changed} items (contents + file/dir names)")