from __future__ import annotations

import math
import random
from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Any, Dict, Iterator, List, Optional, Sequence, Tuple, Union

import numpy as np
import torch
from torch.utils.data import DataLoader, Dataset, DistributedSampler, IterableDataset, Sampler

from mullm.core.trainer.training_config import DataConfig


@dataclass
class DataCollatorForCausalLM:
    tokenizer: Any
    max_length: int = 2048
    pad_token_id: int = 0
    ignore_index: int = -100
    mask_instruction: bool = False
    padding: Union[bool, str] = False
    truncation: bool = True
    return_tensors: str = "pt"

    def __call__(self, features: List[Dict[str, Any]]) -> Dict[str, torch.Tensor]:
        batch = {}

        input_ids_list = []
        labels_list = []
        attention_mask_list = []

        for feature in features:
            input_ids = self._process_input_ids(feature)
            labels = self._process_labels(feature, input_ids)
            attention_mask = [1] * len(input_ids)

            if self.truncation and len(input_ids) > self.max_length:
                input_ids = input_ids[: self.max_length]
                labels = labels[: self.max_length]
                attention_mask = attention_mask[: self.max_length]

            input_ids_list.append(torch.tensor(input_ids, dtype=torch.long))
            labels_list.append(torch.tensor(labels, dtype=torch.long))
            attention_mask_list.append(torch.tensor(attention_mask, dtype=torch.long))

        if self.padding or self.padding == "max_length":
            max_len = self.max_length if self.padding == "max_length" else max(len(t) for t in input_ids_list)
            padded_input_ids = []
            padded_labels = []
            padded_attention_mask = []

            for i in range(len(input_ids_list)):
                length = len(input_ids_list[i])
                pad_len = max_len - length

                if pad_len > 0:
                    padded_input_ids.append(
                        torch.cat([input_ids_list[i], torch.full((pad_len,), self.pad_token_id, dtype=torch.long)])
                    )
                    padded_labels.append(
                        torch.cat([labels_list[i], torch.full((pad_len,), self.ignore_index, dtype=torch.long)])
                    )
                    padded_attention_mask.append(
                        torch.cat([attention_mask_list[i], torch.zeros(pad_len, dtype=torch.long)])
                    )
                else:
                    padded_input_ids.append(input_ids_list[i])
                    padded_labels.append(labels_list[i])
                    padded_attention_mask.append(attention_mask_list[i])

            batch["input_ids"] = torch.stack(padded_input_ids)
            batch["labels"] = torch.stack(padded_labels)
            batch["attention_mask"] = torch.stack(padded_attention_mask)
        else:
            batch["input_ids"] = torch.stack(input_ids_list)
            batch["labels"] = torch.stack(labels_list)
            batch["attention_mask"] = torch.stack(attention_mask_list)

        return batch

    def _process_input_ids(self, feature: Dict[str, Any]) -> List[int]:
        if "input_ids" in feature:
            ids = feature["input_ids"]
            if isinstance(ids, torch.Tensor):
                return ids.tolist()
            if isinstance(ids, np.ndarray):
                return ids.tolist()
            return list(ids)
        if "text" in feature:
            return self.tokenizer.encode(feature["text"])
        raise KeyError("Feature must contain 'input_ids' or 'text'")

    def _process_labels(self, feature: Dict[str, Any], input_ids: List[int]) -> List[int]:
        if "labels" in feature:
            labels = feature["labels"]
            if isinstance(labels, torch.Tensor):
                return labels.tolist()
            if isinstance(labels, np.ndarray):
                return labels.tolist()
            return list(labels)
        if self.mask_instruction and "instruction_length" in feature:
            labels = [self.ignore_index] * feature["instruction_length"]
            labels.extend(input_ids[feature["instruction_length"] :])
            return labels
        return input_ids.copy()


@dataclass
class DataCollatorForSeq2Seq:
    tokenizer: Any
    max_length: int = 2048
    pad_token_id: int = 0
    ignore_index: int = -100
    padding: Union[bool, str] = True
    truncation: bool = True

    def __call__(self, features: List[Dict[str, Any]]) -> Dict[str, torch.Tensor]:
        input_ids_list = []
        labels_list = []
        attention_mask_list = []

        for feature in features:
            input_ids = feature.get("input_ids", self.tokenizer.encode(feature.get("text", "")))
            if isinstance(input_ids, torch.Tensor):
                input_ids = input_ids.tolist()
            if isinstance(input_ids, np.ndarray):
                input_ids = input_ids.tolist()

            labels = feature.get("labels", input_ids.copy())
            if isinstance(labels, torch.Tensor):
                labels = labels.tolist()
            if isinstance(labels, np.ndarray):
                labels = labels.tolist()

            if self.truncation:
                input_ids = input_ids[: self.max_length]
                labels = labels[: self.max_length]

            attention_mask = [1] * len(input_ids)

            input_ids_list.append(torch.tensor(input_ids, dtype=torch.long))
            labels_list.append(torch.tensor(labels, dtype=torch.long))
            attention_mask_list.append(torch.tensor(attention_mask, dtype=torch.long))

        max_len = max(len(t) for t in input_ids_list)
        padded_input_ids = []
        padded_labels = []
        padded_attention_mask = []

        for i in range(len(input_ids_list)):
            pad_len = max_len - len(input_ids_list[i])
            if pad_len > 0:
                padded_input_ids.append(
                    torch.cat([input_ids_list[i], torch.full((pad_len,), self.pad_token_id, dtype=torch.long)])
                )
                padded_labels.append(
                    torch.cat([labels_list[i], torch.full((pad_len,), self.ignore_index, dtype=torch.long)])
                )
                padded_attention_mask.append(
                    torch.cat([attention_mask_list[i], torch.zeros(pad_len, dtype=torch.long)])
                )
            else:
                padded_input_ids.append(input_ids_list[i])
                padded_labels.append(labels_list[i])
                padded_attention_mask.append(attention_mask_list[i])

        return {
            "input_ids": torch.stack(padded_input_ids),
            "labels": torch.stack(padded_labels),
            "attention_mask": torch.stack(padded_attention_mask),
        }


class PackingCollator:
    def __init__(
        self,
        tokenizer: Any,
        max_length: int = 2048,
        pad_token_id: int = 0,
        ignore_index: int = -100,
    ) -> None:
        self.tokenizer = tokenizer
        self.max_length = max_length
        self.pad_token_id = pad_token_id
        self.ignore_index = ignore_index
        self._buffer: List[int] = []

    def __call__(self, features: List[Dict[str, Any]]) -> Dict[str, torch.Tensor]:
        all_input_ids: List[int] = []
        for feature in features:
            input_ids = feature.get("input_ids", self.tokenizer.encode(feature.get("text", "")))
            if isinstance(input_ids, torch.Tensor):
                input_ids = input_ids.tolist()
            if isinstance(input_ids, np.ndarray):
                input_ids = input_ids.tolist()
            all_input_ids.extend(input_ids)

        all_input_ids = self._buffer + all_input_ids
        self._buffer = []

        total = len(all_input_ids)
        num_packs = total // self.max_length
        remainder = total % self.max_length

        if remainder > 0:
            self._buffer = all_input_ids[-remainder:]
            all_input_ids = all_input_ids[: num_packs * self.max_length]
        else:
            self._buffer = []

        if num_packs == 0:
            input_tensor = torch.tensor(all_input_ids, dtype=torch.long)
            padding = self.max_length - len(input_tensor)
            if padding > 0:
                input_tensor = torch.cat([input_tensor, torch.full((padding,), self.pad_token_id, dtype=torch.long)])
            label_tensor = input_tensor.clone()
            label_tensor[:1] = self.ignore_index
            return {
                "input_ids": input_tensor.unsqueeze(0),
                "labels": label_tensor.unsqueeze(0),
                "attention_mask": (input_tensor != self.pad_token_id).long().unsqueeze(0),
            }

        chunks = torch.tensor(all_input_ids, dtype=torch.long).view(num_packs, self.max_length)
        labels = chunks.clone()
        labels[:, :1] = self.ignore_index

        return {
            "input_ids": chunks,
            "labels": labels,
            "attention_mask": torch.ones_like(chunks),
        }


class StreamingDataset(IterableDataset):
    def __init__(
        self,
        source: Any,
        tokenizer: Any,
        max_length: int = 2048,
        shuffle_buffer_size: int = 10000,
        shuffle: bool = True,
        seed: int = 42,
    ) -> None:
        self.source = source
        self.tokenizer = tokenizer
        self.max_length = max_length
        self.shuffle_buffer_size = shuffle_buffer_size
        self.shuffle = shuffle
        self.seed = seed
        self._epoch = 0

    def set_epoch(self, epoch: int) -> None:
        self._epoch = epoch

    def __iter__(self) -> Iterator[Dict[str, Any]]:
        buffer: List[Dict[str, Any]] = []
        rng = random.Random(self.seed + self._epoch)
        worker_info = torch.utils.data.get_worker_info()

        source_iter = iter(self.source)
        if worker_info is not None:
            num_workers = worker_info.num_workers
            worker_id = worker_info.id
            source_iter = self._shard_iter(source_iter, worker_id, num_workers)

        for item in source_iter:
            processed = self._process_item(item)
            if processed is None:
                continue

            if self.shuffle:
                buffer.append(processed)
                if len(buffer) >= self.shuffle_buffer_size:
                    rng.shuffle(buffer)
                    yield from buffer
                    buffer = []
            else:
                yield processed

        if self.shuffle and buffer:
            rng.shuffle(buffer)
            yield from buffer

    def _shard_iter(self, iterator: Iterator, worker_id: int, num_workers: int) -> Iterator:
        for i, item in enumerate(iterator):
            if i % num_workers == worker_id:
                yield item

    def _process_item(self, item: Any) -> Optional[Dict[str, Any]]:
        if isinstance(item, dict):
            if "input_ids" in item:
                return item
            if "text" in item:
                input_ids = self.tokenizer.encode(item["text"])
                if len(input_ids) > self.max_length:
                    input_ids = input_ids[: self.max_length]
                if len(input_ids) < 2:
                    return None
                return {"input_ids": input_ids, "labels": input_ids.copy()}
        if isinstance(item, str):
            input_ids = self.tokenizer.encode(item)
            if len(input_ids) > self.max_length:
                input_ids = input_ids[: self.max_length]
            if len(input_ids) < 2:
                return None
            return {"input_ids": input_ids, "labels": input_ids.copy()}
        return None


class DynamicBatchSampler(Sampler[List[int]]):
    def __init__(
        self,
        dataset: Dataset,
        max_tokens: int = 8192,
        max_seq_length: int = 2048,
        shuffle: bool = True,
        seed: int = 42,
        drop_last: bool = False,
    ) -> None:
        self.dataset = dataset
        self.max_tokens = max_tokens
        self.max_seq_length = max_seq_length
        self.shuffle = shuffle
        self.seed = seed
        self.drop_last = drop_last
        self.epoch = 0

    def __len__(self) -> int:
        lengths = self._get_lengths()
        total_tokens = sum(lengths)
        avg_batch_tokens = self.max_tokens
        num_batches = math.ceil(total_tokens / avg_batch_tokens)
        return max(1, num_batches)

    def __iter__(self) -> Iterator[List[int]]:
        lengths = self._get_lengths()
        indices = list(range(len(lengths)))

        if self.shuffle:
            rng = random.Random(self.seed + self.epoch)
            rng.shuffle(indices)

        batch: List[int] = []
        batch_tokens = 0

        for idx in indices:
            seq_len = lengths[idx]
            if batch_tokens + seq_len > self.max_tokens and batch:
                yield batch
                batch = []
                batch_tokens = 0

            if seq_len > self.max_seq_length:
                continue

            batch.append(idx)
            batch_tokens += seq_len

            if batch_tokens >= self.max_tokens:
                yield batch
                batch = []
                batch_tokens = 0

        if batch and (not self.drop_last):
            yield batch

    def set_epoch(self, epoch: int) -> None:
        self.epoch = epoch

    def _get_lengths(self) -> List[int]:
        if hasattr(self.dataset, "lengths"):
            return self.dataset.lengths
        if hasattr(self.dataset, "get_lengths"):
            return self.dataset.get_lengths()
        lengths = []
        for i in range(len(self.dataset)):
            sample = self.dataset[i]
            if isinstance(sample, dict):
                if "input_ids" in sample:
                    lengths.append(len(sample["input_ids"]))
                elif "text" in sample:
                    lengths.append(len(sample["text"]))
                else:
                    lengths.append(self.max_seq_length)
            else:
                lengths.append(self.max_seq_length)
        return lengths


class DistributedDataLoader:
    def __init__(
        self,
        dataset: Dataset,
        batch_size: int = 8,
        shuffle: bool = True,
        seed: int = 42,
        drop_last: bool = False,
        num_workers: int = 4,
        prefetch_factor: int = 2,
        persistent_workers: bool = True,
        pin_memory: bool = True,
        collator: Optional[Any] = None,
        world_size: int = 1,
        rank: int = 0,
        dynamic_batch: bool = False,
        dynamic_max_tokens: int = 8192,
        max_seq_length: int = 2048,
        distributed: bool = True,
    ) -> None:
        self.dataset = dataset
        self.batch_size = batch_size
        self.shuffle = shuffle
        self.seed = seed
        self.drop_last = drop_last
        self.num_workers = num_workers
        self.prefetch_factor = prefetch_factor
        self.persistent_workers = persistent_workers
        self.pin_memory = pin_memory
        self.collator = collator
        self.world_size = world_size
        self.rank = rank
        self.dynamic_batch = dynamic_batch
        self.dynamic_max_tokens = dynamic_max_tokens
        self.max_seq_length = max_seq_length
        self.distributed = distributed
        self._epoch = 0

    def __iter__(self) -> Iterator[Dict[str, torch.Tensor]]:
        sampler = self._build_sampler()
        dataloader = DataLoader(
            self.dataset,
            batch_sampler=sampler if self.dynamic_batch else None,
            batch_size=1 if self.dynamic_batch else self.batch_size,
            shuffle=False if self.dynamic_batch else (self.shuffle and not self.distributed),
            sampler=sampler if (not self.dynamic_batch and self.distributed) else None,
            collate_fn=self.collator if self.collator else self._default_collate,
            num_workers=self.num_workers,
            prefetch_factor=self.prefetch_factor if self.num_workers > 0 else None,
            persistent_workers=self.persistent_workers if self.num_workers > 0 else False,
            pin_memory=self.pin_memory,
            drop_last=False if self.dynamic_batch else self.drop_last,
        )
        return iter(dataloader)

    def __len__(self) -> int:
        if self.distributed:
            if self.dynamic_batch:
                return len(DynamicBatchSampler(
                    self.dataset,
                    max_tokens=self.dynamic_max_tokens,
                    max_seq_length=self.max_seq_length,
                ))
            per_device = len(self.dataset) // self.world_size
            if not self.drop_last and len(self.dataset) % self.world_size > self.rank:
                per_device += 1
            return math.ceil(per_device / self.batch_size)
        if self.dynamic_batch:
            return len(DynamicBatchSampler(
                self.dataset,
                max_tokens=self.dynamic_max_tokens,
                max_seq_length=self.max_seq_length,
            ))
        return math.ceil(len(self.dataset) / self.batch_size)

    def set_epoch(self, epoch: int) -> None:
        self._epoch = epoch

    def _build_sampler(self) -> Optional[Sampler]:
        if self.dynamic_batch:
            sampler = DynamicBatchSampler(
                self.dataset,
                max_tokens=self.dynamic_max_tokens,
                max_seq_length=self.max_seq_length,
                shuffle=self.shuffle,
                seed=self.seed,
                drop_last=self.drop_last,
            )
            sampler.set_epoch(self._epoch)
            return sampler

        if self.distributed:
            sampler = DistributedSampler(
                self.dataset,
                num_replicas=self.world_size,
                rank=self.rank,
                shuffle=self.shuffle,
                seed=self.seed,
                drop_last=self.drop_last,
            )
            sampler.set_epoch(self._epoch)
            return sampler

        return None

    @staticmethod
    def _default_collate(batch: List[Any]) -> Any:
        if isinstance(batch[0], dict):
            result: Dict[str, torch.Tensor] = {}
            for key in batch[0].keys():
                values = [b[key] for b in batch]
                if isinstance(values[0], torch.Tensor):
                    if values[0].ndim == 1:
                        result[key] = torch.stack(values)
                    else:
                        result[key] = torch.cat(values, dim=0)
                elif isinstance(values[0], np.ndarray):
                    result[key] = torch.from_numpy(np.stack(values))
                else:
                    result[key] = torch.tensor(values)
            return result
        return torch.utils.data.default_collate(batch)


def create_dataloader(
    dataset: Dataset,
    config: DataConfig,
    world_size: int = 1,
    rank: int = 0,
    collator: Optional[Any] = None,
) -> DistributedDataLoader:
    if collator is None:
        collator = DataCollatorForCausalLM(
            tokenizer=None,
            max_length=config.max_seq_length,
            pad_token_id=config.collator_pad_token_id,
            ignore_index=config.collator_ignore_index,
            padding=config.padding,
            truncation=config.truncation,
        )

    return DistributedDataLoader(
        dataset=dataset,
        batch_size=1,
        shuffle=True,
        seed=config.seed,
        drop_last=False,
        num_workers=config.num_workers,
        prefetch_factor=config.prefetch_factor,
        persistent_workers=config.persistent_workers,
        pin_memory=True,
        collator=collator,
        world_size=world_size,
        rank=rank,
        dynamic_batch=config.dynamic_batching,
        dynamic_max_tokens=config.dynamic_batch_max_tokens,
        max_seq_length=config.max_seq_length,
        distributed=world_size > 1,
    )
