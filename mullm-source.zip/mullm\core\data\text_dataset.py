"""
text_dataset.py - Simple text dataset for training from raw text files.
No HuggingFace dependency.
"""

import json
import os
from typing import Optional

import torch
from torch.utils.data import Dataset


class TextDataset(Dataset):
    def __init__(
        self,
        data: list[str],
        tokenizer=None,
        max_len: int = 512,
    ):
        self.data = data
        self.tokenizer = tokenizer
        self.max_len = max_len

    def __len__(self) -> int:
        return len(self.data)

    def __getitem__(self, idx: int) -> dict:
        text = self.data[idx]

        if self.tokenizer is not None:
            ids = self.tokenizer.encode(text, add_special_tokens=False)[: self.max_len]
        else:
            ids = [ord(c) % 32000 for c in text[: self.max_len]]

        if len(ids) < self.max_len:
            ids = ids + [0] * (self.max_len - len(ids))

        input_ids = torch.tensor(ids, dtype=torch.long)
        labels = input_ids.clone()
        attention_mask = torch.zeros(self.max_len, dtype=torch.long)
        attention_mask[: len(ids)] = 1

        return {
            "input_ids": input_ids,
            "labels": labels,
            "attention_mask": attention_mask,
        }


def load_text_file(path: str) -> list[str]:
    ext = os.path.splitext(path)[1].lower()

    if ext == ".json":
        with open(path, encoding="utf-8") as f:
            raw = json.load(f)
        if isinstance(raw, list):
            data = raw
        elif isinstance(raw, dict):
            data = raw.get("data", raw.get("items", [raw]))
        else:
            data = [raw]
        texts = []
        for item in data:
            if isinstance(item, dict):
                texts.append(item.get("text", item.get("instruction", "") + " " + item.get("response", "")))
            else:
                texts.append(str(item))
        return texts

    elif ext == ".jsonl":
        texts = []
        with open(path, encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    obj = json.loads(line)
                    if isinstance(obj, dict):
                        texts.append(obj.get("text", obj.get("instruction", "") + " " + obj.get("response", "")))
                    else:
                        texts.append(str(obj))
                except json.JSONDecodeError:
                    texts.append(line)
        return texts

    elif ext == ".csv":
        import csv

        texts = []
        with open(path, encoding="utf-8") as f:
            reader = csv.DictReader(f)
            for row in reader:
                texts.append(" ".join(str(v) for v in row.values()))
        return texts

    else:
        with open(path, encoding="utf-8") as f:
            text = f.read()
        paragraphs = [p.strip() for p in text.split("\n\n") if p.strip()]
        if not paragraphs:
            paragraphs = [line.strip() for line in text.split("\n") if line.strip()]
        return paragraphs
