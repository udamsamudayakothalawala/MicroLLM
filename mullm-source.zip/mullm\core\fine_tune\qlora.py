import math
from dataclasses import dataclass, field
from typing import Dict, Optional, Tuple

import torch
import torch.nn as nn
import torch.nn.functional as F

from .lora import LoRAConfig, LoRALayer, LoRALinear


_NF4_LEVELS: torch.Tensor = None


def _get_nf4_levels() -> torch.Tensor:
    global _NF4_LEVELS
    if _NF4_LEVELS is not None:
        return _NF4_LEVELS
    levels = [
        -1.0, -0.6961928009986877, -0.5250730514526367, -0.39491748809814453,
        -0.28444138169288635, -0.18477343022823334, -0.09105003625154495, 0.0,
        0.0795802993774414, 0.16093020141124725, 0.24611230194568634,
        0.33791524171829224, 0.44070982933044434, 0.5626170039176941,
        0.7229568362236023, 1.0,
    ]
    _NF4_LEVELS = torch.tensor(levels, dtype=torch.float32)
    return _NF4_LEVELS


def nf4_quantize_tensor(tensor: torch.Tensor, block_size: int = 64) -> Tuple[torch.Tensor, torch.Tensor]:
    orig_shape = tensor.shape
    flat = tensor.view(-1)
    num_blocks = (flat.numel() + block_size - 1) // block_size
    padded_len = num_blocks * block_size
    if padded_len > flat.numel():
        flat = F.pad(flat, (0, padded_len - flat.numel()))

    blocks = flat.view(num_blocks, block_size)
    abs_max = blocks.abs().max(dim=1, keepdim=True).values
    abs_max = abs_max.clamp(min=1e-12)
    normalized = blocks / abs_max

    nf4 = _get_nf4_levels().to(normalized.device)
    dist = (normalized.unsqueeze(-1) - nf4.unsqueeze(0).unsqueeze(0)).abs()
    indices = dist.argmin(dim=-1).to(torch.uint8)

    return indices, abs_max.view(-1)


def nf4_dequantize_tensor(
    indices: torch.Tensor,
    abs_max: torch.Tensor,
    block_size: int = 64,
    shape: Optional[torch.Size] = None,
) -> torch.Tensor:
    nf4 = _get_nf4_levels().to(indices.device)
    num_blocks = abs_max.size(0)
    if indices.dim() == 1:
        indices = indices.view(num_blocks, block_size)
    quantized = nf4[indices.long()]
    quantized = quantized * abs_max.view(-1, 1)
    flat = quantized.view(-1)
    if shape is not None:
        flat = flat[: shape.numel()]
        return flat.view(shape)
    return quantized


def quantize_to_nf4(
    weight: torch.Tensor,
    block_size: int = 64,
) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
    indices, abs_max = nf4_quantize_tensor(weight, block_size)
    return indices, abs_max, weight


def dequantize_nf4(
    indices: torch.Tensor,
    abs_max: torch.Tensor,
    shape: torch.Size,
    block_size: int = 64,
) -> torch.Tensor:
    return nf4_dequantize_tensor(indices, abs_max, block_size, shape)


def double_quantize(
    weight: torch.Tensor,
    block_size: int = 64,
    second_block_size: int = 256,
) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
    first_indices, first_absmax = nf4_quantize_tensor(weight, block_size)
    second_indices, second_absmax = nf4_quantize_tensor(first_absmax, second_block_size)
    return first_indices, second_indices, second_absmax


@dataclass
class QLoRAConfig:
    lora_config: LoRAConfig = field(default_factory=LoRAConfig)
    quantization_bits: int = 4
    quant_type: str = "nf4"
    double_quant: bool = True
    quant_block_size: int = 64
    double_quant_block_size: int = 256
    use_gradient_checkpointing: bool = False
    bnb_4bit_compute_dtype: torch.dtype = torch.bfloat16
    bnb_4bit_use_double_quant: bool = True


class NF4Linear(nn.Module):
    def __init__(
        self,
        in_features: int,
        out_features: int,
        bias: bool = True,
        block_size: int = 64,
        double_quant: bool = True,
        double_quant_block_size: int = 256,
        compute_dtype: torch.dtype = torch.bfloat16,
    ):
        super().__init__()
        self.in_features = in_features
        self.out_features = out_features
        self.block_size = block_size
        self.double_quant = double_quant
        self.double_quant_block_size = double_quant_block_size
        self.compute_dtype = compute_dtype

        numel = out_features * in_features
        num_blocks = (numel + block_size - 1) // block_size
        padded_len = num_blocks * block_size

        self.register_buffer("quant_weight_indices", torch.zeros(padded_len, dtype=torch.uint8))
        self.register_buffer("quant_absmax", torch.zeros(num_blocks, dtype=torch.float32))
        if double_quant:
            num_second_blocks = (num_blocks + double_quant_block_size - 1) // double_quant_block_size
            second_padded = num_second_blocks * double_quant_block_size
            self.register_buffer("double_quant_indices", torch.zeros(second_padded, dtype=torch.uint8))
            self.register_buffer("double_quant_absmax", torch.zeros(num_second_blocks, dtype=torch.float32))
        else:
            self.double_quant_indices = None
            self.double_quant_absmax = None

        if bias:
            self.bias = nn.Parameter(torch.empty(out_features, dtype=compute_dtype))
        else:
            self.register_parameter("bias", None)

    def _get_weight(self) -> torch.Tensor:
        if self.double_quant:
            inner_absmax = nf4_dequantize_tensor(
                self.double_quant_indices,
                self.double_quant_absmax,
                self.double_quant_block_size,
                self.quant_absmax.shape,
            )
        else:
            inner_absmax = self.quant_absmax
        weight = nf4_dequantize_tensor(
            self.quant_weight_indices,
            inner_absmax,
            self.block_size,
            torch.Size([self.out_features, self.in_features]),
        )
        return weight

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        weight = self._get_weight().to(self.compute_dtype)
        return F.linear(x.to(self.compute_dtype), weight, self.bias.to(self.compute_dtype) if self.bias is not None else None)

    @classmethod
    def from_float(cls, linear: nn.Linear, block_size: int = 64, double_quant: bool = True, compute_dtype: torch.dtype = torch.bfloat16) -> "NF4Linear":
        quant = cls(
            in_features=linear.in_features,
            out_features=linear.out_features,
            bias=linear.bias is not None,
            block_size=block_size,
            double_quant=double_quant,
            compute_dtype=compute_dtype,
        )
        with torch.no_grad():
            weight = linear.weight.data.float()
            indices, absmax = nf4_quantize_tensor(weight, block_size)
            quant.quant_weight_indices = nn.Parameter(indices.view(-1), requires_grad=False)
            quant.quant_absmax = nn.Parameter(absmax.view(-1), requires_grad=False)
            if double_quant:
                d_indices, d_absmax = nf4_quantize_tensor(absmax.view(-1), 256)
                quant.double_quant_indices = nn.Parameter(d_indices.view(-1), requires_grad=False)
                quant.double_quant_absmax = nn.Parameter(d_absmax.view(-1), requires_grad=False)
            if linear.bias is not None:
                quant.bias.data = linear.bias.data.to(compute_dtype)
        return quant


class QLoRABnbLinear(nn.Module):
    def __init__(
        self,
        in_features: int,
        out_features: int,
        lora_config: LoRAConfig,
        bias: bool = True,
        block_size: int = 64,
        double_quant: bool = True,
        compute_dtype: torch.dtype = torch.bfloat16,
    ):
        super().__init__()
        self.linear = NF4Linear(
            in_features=in_features,
            out_features=out_features,
            bias=bias,
            block_size=block_size,
            double_quant=double_quant,
            compute_dtype=compute_dtype,
        )
        self.lora = LoRALayer(
            in_features=in_features,
            out_features=out_features,
            r=lora_config.r,
            alpha=lora_config.alpha,
            dropout=lora_config.dropout,
            fan_in_fan_out=lora_config.fan_in_fan_out,
            use_rslora=lora_config.use_rslora,
            use_dora=lora_config.use_dora,
            dtype=compute_dtype,
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        compute_dtype = self.lora.lora_A.dtype if self.lora.lora_A is not None else self.linear.compute_dtype
        deq_weight = self.linear._get_weight().to(compute_dtype)
        bias = self.linear.bias
        x = x.to(compute_dtype)
        return self.lora(x, deq_weight) + (bias if bias is not None else 0)

    def merge(self):
        if self.lora.merged:
            return
        deq_weight = self.linear._get_weight()
        with torch.no_grad():
            merged = self.lora.merge(deq_weight)
            new_indices, new_absmax = nf4_quantize_tensor(merged.float(), self.linear.block_size)
            self.linear.quant_weight_indices.data = new_indices.view(-1)
            self.linear.quant_absmax.data = new_absmax.view(-1)
        self.lora.merged = True

    def unmerge(self):
        if not self.lora.merged:
            return
        deq_weight = self.linear._get_weight()
        with torch.no_grad():
            unmerged = self.lora.unmerge(deq_weight)
            new_indices, new_absmax = nf4_quantize_tensor(unmerged.float(), self.linear.block_size)
            self.linear.quant_weight_indices.data = new_indices.view(-1)
            self.linear.quant_absmax.data = new_absmax.view(-1)
        self.lora.merged = False
