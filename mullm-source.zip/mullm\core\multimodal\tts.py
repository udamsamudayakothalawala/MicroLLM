import math
import re
from abc import ABC, abstractmethod
from typing import Any, Dict, List, Optional, Tuple

import torch
import torch.nn as nn
import torch.nn.functional as F


class TTSInterface(ABC):
    @abstractmethod
    def synthesize(self, text: str, voice_id: Optional[str] = None) -> torch.Tensor:
        pass

    @abstractmethod
    def get_sample_rate(self) -> int:
        pass


class Prenet(nn.Module):
    def __init__(self, in_dim: int, hidden_dims: List[int] = [256, 128]):
        super().__init__()
        layers = []
        prev_dim = in_dim
        for h_dim in hidden_dims:
            layers.extend([
                nn.Linear(prev_dim, h_dim),
                nn.ReLU(inplace=True),
                nn.Dropout(0.5),
            ])
            prev_dim = h_dim
        self.net = nn.Sequential(*layers)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.net(x)


class EncoderRNN(nn.Module):
    def __init__(self, vocab_size: int, embed_dim: int, hidden_dim: int):
        super().__init__()
        self.embedding = nn.Embedding(vocab_size, embed_dim)
        self.lstm = nn.LSTM(embed_dim, hidden_dim, num_layers=1, batch_first=True, bidirectional=True)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        embedded = self.embedding(x)
        outputs, _ = self.lstm(embedded)
        return outputs


class DecoderRNN(nn.Module):
    def __init__(self, hidden_dim: int, n_mels: int = 80, rnn_dim: int = 256):
        super().__init__()
        self.n_mels = n_mels
        self.rnn_dim = rnn_dim
        self.prenet = Prenet(n_mels, [256, 128])
        self.attention_rnn = nn.LSTMCell(hidden_dim + 128, rnn_dim)
        self.decoder_rnn = nn.LSTMCell(rnn_dim + hidden_dim, rnn_dim)
        self.attention_proj = nn.Linear(hidden_dim, hidden_dim)
        self.attention_v = nn.Linear(hidden_dim, 1)
        self.mel_proj = nn.Linear(rnn_dim + hidden_dim, n_mels)
        self.stop_proj = nn.Linear(rnn_dim + hidden_dim, 1)

    def forward(self, memory: torch.Tensor, mel_targets: Optional[torch.Tensor] = None, max_len: int = 500) -> Tuple[torch.Tensor, torch.Tensor]:
        B, T, D = memory.shape
        device = memory.device

        attn_hidden = torch.zeros(B, self.rnn_dim, device=device)
        attn_cell = torch.zeros(B, self.rnn_dim, device=device)
        dec_hidden = torch.zeros(B, self.rnn_dim, device=device)
        dec_cell = torch.zeros(B, self.rnn_dim, device=device)

        attn_weights = torch.zeros(B, T, device=device)
        attn_context = torch.zeros(B, D, device=device)

        mel_input = torch.zeros(B, 1, self.n_mels, device=device)
        mel_outputs = []
        stop_tokens = []

        memory_projected = self.attention_proj(memory)

        if mel_targets is not None:
            max_steps = mel_targets.shape[1]
        else:
            max_steps = max_len

        for t in range(max_steps):
            prenet_out = self.prenet(mel_input.squeeze(1))
            attn_hidden, attn_cell = self.attention_rnn(
                torch.cat([prenet_out, attn_context], dim=-1),
                (attn_hidden, attn_cell),
            )

            energy = torch.tanh(memory_projected + attn_hidden.unsqueeze(1).expand(-1, T, -1))
            energy = self.attention_v(energy).squeeze(-1)
            attn_weights = F.softmax(energy, dim=-1)
            attn_context = (memory * attn_weights.unsqueeze(-1)).sum(dim=1)

            dec_hidden, dec_cell = self.decoder_rnn(
                torch.cat([attn_hidden, attn_context], dim=-1),
                (dec_hidden, dec_cell),
            )

            dec_output = torch.cat([dec_hidden, attn_context], dim=-1)
            mel_output = self.mel_proj(dec_output).unsqueeze(1)
            stop_output = torch.sigmoid(self.stop_proj(dec_output))
            mel_outputs.append(mel_output)
            stop_tokens.append(stop_output)

            if mel_targets is not None:
                mel_input = mel_targets[:, t:t+1, :]
            else:
                mel_input = mel_output

            if mel_targets is None and stop_output.item() > 0.5 and t > 10:
                break

        mel_outputs = torch.cat(mel_outputs, dim=1)
        stop_tokens = torch.cat(stop_tokens, dim=1)
        return mel_outputs, stop_tokens


class TacotronDecoder(nn.Module):
    def __init__(self, vocab_size: int, embed_dim: int = 256, encoder_hidden: int = 256, decoder_rnn_dim: int = 256, n_mels: int = 80):
        super().__init__()
        self.encoder = EncoderRNN(vocab_size, embed_dim, encoder_hidden)
        self.encoder_proj = nn.Linear(encoder_hidden * 2, encoder_hidden)
        self.decoder = DecoderRNN(encoder_hidden, n_mels, decoder_rnn_dim)

    def forward(self, text_tokens: torch.Tensor, mel_targets: Optional[torch.Tensor] = None) -> Tuple[torch.Tensor, torch.Tensor]:
        encoded = self.encoder(text_tokens)
        memory = self.encoder_proj(encoded)
        mel_outputs, stop_tokens = self.decoder(memory, mel_targets)
        return mel_outputs, stop_tokens

    def generate_mel(self, text_tokens: torch.Tensor, max_len: int = 500) -> torch.Tensor:
        encoded = self.encoder(text_tokens)
        memory = self.encoder_proj(encoded)
        mel_outputs, _ = self.decoder(memory, None, max_len)
        return mel_outputs


class VocoderInterface(ABC):
    @abstractmethod
    def forward(self, mel_spec: torch.Tensor) -> torch.Tensor:
        pass

    @abstractmethod
    def mel_to_waveform(self, mel_spec: torch.Tensor) -> torch.Tensor:
        pass


class MelGANGenerator(nn.Module, VocoderInterface):
    def __init__(self, n_mels: int = 80, upsample_rates: List[int] = [8, 8, 2, 2], upsample_kernels: List[int] = [16, 16, 4, 4], resblock_kernel_sizes: List[int] = [3, 7, 11], resblock_dilations: List[List[int]] = [[1, 3, 5], [1, 3, 5], [1, 3, 5]]):
        super().__init__()
        self.n_mels = n_mels
        self.num_kernels = len(resblock_kernel_sizes)
        self.num_upsamples = len(upsample_rates)

        self.conv_pre = nn.Conv1d(n_mels, 512, kernel_size=7, padding=3)

        self.upsamples = nn.ModuleList()
        for i, (u_rate, u_kernel) in enumerate(zip(upsample_rates, upsample_kernels)):
            self.upsamples.append(
                nn.Sequential(
                    nn.ConvTranspose1d(512 // (2 ** i), 512 // (2 ** (i + 1)), kernel_size=u_kernel, stride=u_rate, padding=(u_kernel - u_rate) // 2),
                    nn.LeakyReLU(0.1),
                )
            )

        self.resblocks = nn.ModuleList()
        for i in range(len(upsample_rates)):
            ch = 512 // (2 ** (i + 1))
            for k, d in zip(resblock_kernel_sizes, resblock_dilations):
                self.resblocks.append(ResidualBlock(ch, k, d))

        self.conv_post = nn.Conv1d(512 // (2 ** len(upsample_rates)), 1, kernel_size=7, padding=3)

    def forward(self, mel_spec: torch.Tensor) -> torch.Tensor:
        x = self.conv_pre(mel_spec)
        for i, upsample in enumerate(self.upsamples):
            x = upsample(x)
            xs = None
            for j in range(self.num_kernels):
                resblock = self.resblocks[i * self.num_kernels + j]
                if xs is None:
                    xs = resblock(x)
                else:
                    xs = xs + resblock(x)
            x = xs / self.num_kernels
        x = self.conv_post(x)
        x = torch.tanh(x)
        return x

    def mel_to_waveform(self, mel_spec: torch.Tensor) -> torch.Tensor:
        return self.forward(mel_spec)


class ResidualBlock(nn.Module):
    def __init__(self, channels: int, kernel_size: int = 3, dilations: List[int] = [1, 3, 5]):
        super().__init__()
        self.convs1 = nn.ModuleList()
        self.convs2 = nn.ModuleList()
        for d in dilations:
            self.convs1.append(nn.Conv1d(channels, channels, kernel_size, padding=d * (kernel_size - 1) // 2, dilation=d))
            self.convs2.append(nn.Conv1d(channels, channels, kernel_size, padding=d * (kernel_size - 1) // 2, dilation=d))

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        for c1, c2 in zip(self.convs1, self.convs2):
            xt = F.leaky_relu(x, 0.1)
            xt = c1(xt)
            xt = F.leaky_relu(xt, 0.1)
            xt = c2(xt)
            x = xt + x
        return x


class MultiVoiceSupport(nn.Module):
    def __init__(self, num_voices: int = 10, embed_dim: int = 256, tacotron: Optional[TacotronDecoder] = None):
        super().__init__()
        self.num_voices = num_voices
        self.voice_embeddings = nn.Embedding(num_voices, embed_dim)
        self.tacotron = tacotron
        self.voice_proj = nn.Linear(embed_dim, embed_dim)

    def forward(self, text_tokens: torch.Tensor, voice_ids: torch.Tensor, mel_targets: Optional[torch.Tensor] = None) -> Tuple[torch.Tensor, torch.Tensor]:
        assert self.tacotron is not None, "TacotronDecoder required"
        encoded = self.tacotron.encoder(text_tokens)
        memory = self.tacotron.encoder_proj(encoded)
        voice_embed = self.voice_embeddings(voice_ids)
        voice_embed = self.voice_proj(voice_embed).unsqueeze(1)
        memory = memory + voice_embed
        mel_outputs, stop_tokens = self.tacotron.decoder(memory, mel_targets)
        return mel_outputs, stop_tokens

    def synthesize(self, text_tokens: torch.Tensor, voice_ids: torch.Tensor, max_len: int = 500) -> torch.Tensor:
        return self.forward(text_tokens, voice_ids, None)[0]

    def add_voice(self, voice_embedding: torch.Tensor) -> int:
        new_id = self.num_voices
        new_emb = nn.Parameter(voice_embedding.unsqueeze(0))
        self.voice_embeddings = nn.Embedding.from_pretrained(
            torch.cat([self.voice_embeddings.weight.data, new_emb], dim=0),
            freeze=False,
        )
        self.num_voices += 1
        return new_id


class SSMLParser:
    def __init__(self):
        self.tag_pattern = re.compile(r"<(\w+)([^>]*)>(.*?)</\1>", re.DOTALL)
        self.attr_pattern = re.compile(r'(\w+)=["\']([^"\']*)["\']')

    def parse(self, ssml: str) -> List[Dict[str, Any]]:
        segments = []
        pos = 0
        for match in self.tag_pattern.finditer(ssml):
            if match.start() > pos:
                text = ssml[pos:match.start()].strip()
                if text:
                    segments.append({"type": "text", "content": text})
            tag_name = match.group(1)
            attrs_str = match.group(2)
            content = match.group(3)
            attrs = dict(self.attr_pattern.findall(attrs_str))
            segments.append({
                "type": tag_name,
                "content": content,
                "attributes": attrs,
            })
            pos = match.end()
        if pos < len(ssml):
            text = ssml[pos:].strip()
            if text:
                segments.append({"type": "text", "content": text})
        return segments

    def extract_plain_text(self, ssml: str) -> str:
        return self.tag_pattern.sub(r"\3", ssml)

    def get_prosody(self, ssml: str) -> Dict[str, Any]:
        segments = self.parse(ssml)
        prosody = {"rate": 1.0, "pitch": 0.0, "volume": 1.0}
        for seg in segments:
            if seg["type"] == "prosody":
                attrs = seg["attributes"]
                if "rate" in attrs:
                    rate_str = attrs["rate"]
                    if rate_str.endswith("%"):
                        prosody["rate"] = float(rate_str[:-1]) / 100
                    else:
                        prosody["rate"] = float(rate_str)
                if "pitch" in attrs:
                    pitch_str = attrs["pitch"]
                    if pitch_str.endswith("st"):
                        prosody["pitch"] = float(pitch_str[:-2])
                    else:
                        prosody["pitch"] = float(pitch_str)
                if "volume" in attrs:
                    vol_str = attrs["volume"]
                    if vol_str.endswith("dB"):
                        prosody["volume"] = 10 ** (float(vol_str[:-2]) / 20)
                    else:
                        prosody["volume"] = float(vol_str)
        return prosody


class AudioOutputConverter:
    def __init__(self, sample_rate: int = 22050):
        self.sample_rate = sample_rate

    def to_wav(self, waveform: torch.Tensor) -> bytes:
        if waveform.ndim == 1:
            waveform = waveform.unsqueeze(0)
        waveform = waveform.clamp(-1, 1)
        waveform = (waveform * 32767).short()
        num_channels = waveform.shape[0]
        num_samples = waveform.shape[1]
        bytes_per_sample = 2
        data_size = num_samples * num_channels * bytes_per_sample
        sample_rate = self.sample_rate
        byte_rate = sample_rate * num_channels * bytes_per_sample
        block_align = num_channels * bytes_per_sample

        header = bytearray()
        header.extend(b"RIFF")
        header.extend((36 + data_size).to_bytes(4, "little"))
        header.extend(b"WAVE")
        header.extend(b"fmt ")
        header.extend((16).to_bytes(4, "little"))
        header.extend((1).to_bytes(2, "little"))
        header.extend(num_channels.to_bytes(2, "little"))
        header.extend(sample_rate.to_bytes(4, "little"))
        header.extend(byte_rate.to_bytes(4, "little"))
        header.extend(block_align.to_bytes(2, "little"))
        header.extend((bytes_per_sample * 8).to_bytes(2, "little"))
        header.extend(b"data")
        header.extend(data_size.to_bytes(4, "little"))
        header.extend(waveform.cpu().numpy().tobytes())
        return bytes(header)

    def to_mp3_bytes(self, waveform: torch.Tensor) -> bytes:
        if waveform.ndim == 1:
            waveform = waveform.unsqueeze(0)
        waveform = waveform.clamp(-1, 1)
        waveform = (waveform * 32767).short()
        return waveform.cpu().numpy().tobytes()

    def resample_waveform(self, waveform: torch.Tensor, orig_rate: int, target_rate: int) -> torch.Tensor:
        if orig_rate == target_rate:
            return waveform
        num_samples = int(waveform.shape[-1] * target_rate / orig_rate)
        if waveform.ndim == 1:
            waveform = waveform.unsqueeze(0).unsqueeze(0)
            resampled = F.interpolate(waveform, size=num_samples, mode="linear", align_corners=False)
            return resampled.squeeze(0).squeeze(0)
        waveform = waveform.unsqueeze(0)
        resampled = F.interpolate(waveform, size=num_samples, mode="linear", align_corners=False)
        return resampled.squeeze(0)

    def convert(self, waveform: torch.Tensor, format: str = "wav", target_sample_rate: Optional[int] = None) -> bytes:
        if target_sample_rate and target_sample_rate != self.sample_rate:
            waveform = self.resample_waveform(waveform, self.sample_rate, target_sample_rate)
        if format == "wav":
            return self.to_wav(waveform)
        return self.to_mp3_bytes(waveform)


class TTSPipeline(nn.Module, TTSInterface):
    def __init__(
        self,
        vocab_size: int = 1000,
        n_mels: int = 80,
        num_voices: int = 10,
        sample_rate: int = 22050,
    ):
        super().__init__()
        self._sample_rate = sample_rate
        self.tacotron = TacotronDecoder(vocab_size=vocab_size, n_mels=n_mels)
        self.vocoder = MelGANGenerator(n_mels=n_mels)
        self.voice_support = MultiVoiceSupport(num_voices=num_voices)
        self.voice_support.tacotron = self.tacotron
        self.ssml_parser = SSMLParser()
        self.output_converter = AudioOutputConverter(sample_rate=sample_rate)

    def forward(self, text_tokens: torch.Tensor, voice_ids: Optional[torch.Tensor] = None) -> Tuple[torch.Tensor, torch.Tensor]:
        if voice_ids is not None:
            mel, _ = self.voice_support(text_tokens, voice_ids)
        else:
            mel, _ = self.tacotron(text_tokens)
        waveform = self.vocoder.mel_to_waveform(mel)
        return mel, waveform

    def synthesize(self, text: str, voice_id: Optional[str] = None) -> torch.Tensor:
        parts = self.ssml_parser.parse(text)
        plain_text = self.ssml_parser.extract_plain_text(text)
        tokens = torch.randint(0, 100, (1, len(plain_text.split())), dtype=torch.long)
        if voice_id is not None:
            vid = torch.tensor([int(voice_id)], dtype=torch.long)
            _, waveform = self.forward(tokens, vid)
        else:
            _, waveform = self.forward(tokens)
        return waveform

    def get_sample_rate(self) -> int:
        return self._sample_rate
