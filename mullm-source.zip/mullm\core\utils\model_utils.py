from __future__ import annotations

from typing import Any, Dict, Iterator, Optional, Tuple, Union

import torch
import torch.nn as nn


def count_parameters(
    model: nn.Module,
    trainable_only: bool = False,
) -> int:
    """Count the number of parameters in a model.

    Args:
        model: The PyTorch model.
        trainable_only: If True, only count parameters with ``requires_grad=True``.

    Returns:
        Total parameter count.
    """
    if trainable_only:
        return sum(p.numel() for p in model.parameters() if p.requires_grad)
    return sum(p.numel() for p in model.parameters())


def get_dtype_size(dtype: torch.dtype) -> int:
    """Return the byte size of a PyTorch data type.

    Args:
        dtype: A PyTorch data type.

    Returns:
        Number of bytes per element.
    """
    mapping: Dict[torch.dtype, int] = {
        torch.float32: 4,
        torch.float: 4,
        torch.float64: 8,
        torch.double: 8,
        torch.float16: 2,
        torch.half: 2,
        torch.bfloat16: 2,
        torch.int8: 1,
        torch.uint8: 1,
        torch.int16: 2,
        torch.short: 2,
        torch.int32: 4,
        torch.int: 4,
        torch.int64: 8,
        torch.long: 8,
        torch.bool: 1,
        torch.complex64: 8,
        torch.complex128: 16,
        torch.cfloat: 8,
        torch.cdouble: 16,
        torch.quint8: 1,
        torch.qint8: 1,
        torch.qint32: 4,
    }
    return mapping.get(dtype, 4)


def get_model_size(
    model: nn.Module,
    dtype: Optional[torch.dtype] = None,
    trainable_only: bool = False,
) -> float:
    """Estimate model memory footprint in gigabytes.

    Args:
        model: The PyTorch model.
        dtype: Data type to assume for all parameters. If None, use each
            parameter's own dtype.
        trainable_only: Only count trainable parameters.

    Returns:
        Model size in GB.
    """
    total_bytes = 0
    for p in model.parameters():
        if trainable_only and not p.requires_grad:
            continue
        element_size = get_dtype_size(dtype if dtype is not None else p.dtype)
        total_bytes += p.numel() * element_size
    return total_bytes / (1024**3)


def human_readable_size(num_bytes: Union[int, float]) -> str:
    """Convert a byte count to a human-readable string.

    Args:
        num_bytes: Number of bytes.

    Returns:
        Human-readable size string (e.g., "2.50 GB").
    """
    units = ["B", "KB", "MB", "GB", "TB", "PB"]
    value = float(num_bytes)
    for unit in units:
        if value < 1024.0:
            return f"{value:.2f} {unit}"
        value /= 1024.0
    return f"{value:.2f} EB"


def get_model_device(model: nn.Module) -> torch.device:
    """Get the device of a model's first parameter.

    Args:
        model: The PyTorch model.

    Returns:
        The device where the model resides.
    """
    for p in model.parameters():
        return p.device
    return torch.device("cpu")


def get_parameter_distribution(model: nn.Module) -> Dict[str, int]:
    """Return a breakdown of parameter counts per module name.

    Args:
        model: The PyTorch model.

    Returns:
        Dictionary mapping module names to parameter counts.
    """
    distribution: Dict[str, int] = {}
    for name, module in model.named_modules():
        params = sum(p.numel() for p in module.parameters(recurse=False))
        if params > 0:
            distribution[name] = params
    return distribution


def estimate_activation_memory(
    batch_size: int,
    seq_len: int,
    hidden_size: int,
    num_layers: int,
    num_attention_heads: int,
    dtype: torch.dtype = torch.float16,
    gradient_checkpointing: bool = False,
) -> float:
    """Estimate activation memory during training (forward pass).

    Uses a simplified approximation based on the transformer architecture.
    Actual memory usage depends on the specific implementation.

    Args:
        batch_size: Micro batch size.
        seq_len: Sequence length.
        hidden_size: Model hidden dimension.
        num_layers: Number of transformer layers.
        num_attention_heads: Number of attention heads.
        dtype: Data type used for activations.
        gradient_checkpointing: Whether gradient checkpointing is enabled.

    Returns:
        Estimated activation memory in GB.
    """
    bytes_per_elem = get_dtype_size(dtype)
    head_dim = hidden_size // num_attention_heads

    # Attention: QKV projections + attention matrix + output
    # QKV: 3 * batch * seq * hidden
    # Attention scores: batch * num_heads * seq * seq
    # Softmax + dropout: same size
    # Attention output: batch * seq * hidden
    attn_per_layer = (
        3 * batch_size * seq_len * hidden_size  # QKV
        + 2 * batch_size * num_attention_heads * seq_len * seq_len  # scores + softmax
        + 1 * batch_size * num_attention_heads * seq_len * head_dim  # attn output reshape
        + batch_size * seq_len * hidden_size  # output projection
    )

    # FFN: up/gate/down projections (approx 3 * intermediate * hidden)
    intermediate_size = 4 * hidden_size  # standard feed-forward expansion
    ffn_per_layer = (
        batch_size * seq_len * hidden_size * intermediate_size // hidden_size
        + batch_size * seq_len * intermediate_size
        + batch_size * seq_len * intermediate_size * hidden_size // intermediate_size
    )

    # Layer norms (2 per layer)
    norm_per_layer = 2 * batch_size * seq_len * hidden_size

    total_elements = num_layers * (attn_per_layer + ffn_per_layer + norm_per_layer)

    # Embeddings + final norm + LM head
    total_elements += 3 * batch_size * seq_len * hidden_size

    memory_bytes = total_elements * bytes_per_elem

    if gradient_checkpointing:
        memory_bytes *= 0.3  # approximate: ~30% of full activation memory

    return memory_bytes / (1024**3)


def get_model_flops(
    batch_size: int,
    seq_len: int,
    vocab_size: int,
    hidden_size: int,
    num_layers: int,
    num_attention_heads: int,
    intermediate_size: int,
) -> Dict[str, float]:
    """Estimate FLOPs per forward pass for a transformer model.

    Args:
        batch_size: Batch size.
        seq_len: Sequence length.
        vocab_size: Vocabulary size (used for embedding + LM head).
        hidden_size: Model hidden dimension.
        num_layers: Number of transformer layers.
        num_attention_heads: Number of attention heads.
        intermediate_size: FFN intermediate dimension.

    Returns:
        Dictionary with FLOP breakdown.
    """
    head_dim = hidden_size // num_attention_heads

    # Embedding: vocab_size * hidden_size (lookup, negligible)
    embed_flops = batch_size * seq_len * hidden_size

    # Per-layer FLOPs
    # QKV projection: 3 * 2 * batch * seq * hidden * hidden
    qkv_flops = 3 * 2 * batch_size * seq_len * hidden_size * hidden_size

    # Attention scores: 2 * batch * num_heads * seq * seq * head_dim
    attn_scores_flops = 2 * batch_size * num_attention_heads * seq_len * seq_len * head_dim

    # Attention output: 2 * batch * num_heads * seq * head_dim * seq
    attn_output_flops = 2 * batch_size * num_attention_heads * seq_len * head_dim * seq_len

    # Output projection: 2 * batch * seq * hidden * hidden
    out_proj_flops = 2 * batch_size * seq_len * hidden_size * hidden_size

    # FFN: up/gate (2) + down (1) projections each: 2 * batch * seq * hidden * intermediate
    ffn_flops = 3 * 2 * batch_size * seq_len * hidden_size * intermediate_size

    # Layer norms: 2 * 2 * batch * seq * hidden
    norm_flops = 2 * 2 * batch_size * seq_len * hidden_size

    per_layer_flops = qkv_flops + attn_scores_flops + attn_output_flops + out_proj_flops + ffn_flops + norm_flops

    # LM head: 2 * batch * seq * hidden * vocab
    lm_head_flops = 2 * batch_size * seq_len * hidden_size * vocab_size

    total_flops = embed_flops + num_layers * per_layer_flops + lm_head_flops

    return {
        "embedding": embed_flops,
        "per_layer": {
            "qkv": qkv_flops,
            "attention_scores": attn_scores_flops,
            "attention_output": attn_output_flops,
            "output_projection": out_proj_flops,
            "ffn": ffn_flops,
            "norm": norm_flops,
            "total": per_layer_flops,
        },
        "lm_head": lm_head_flops,
        "total": total_flops,
    }


def get_model_info(model: nn.Module) -> Dict[str, Any]:
    """Collect comprehensive information about a model.

    Args:
        model: The PyTorch model.

    Returns:
        Dictionary with model metadata.
    """
    total_params = count_parameters(model)
    trainable_params = count_parameters(model, trainable_only=True)

    # Determine dtype from first parameter
    first_param = next(model.parameters(), None)
    dtype = first_param.dtype if first_param is not None else torch.float32

    return {
        "total_parameters": total_params,
        "trainable_parameters": trainable_params,
        "frozen_parameters": total_params - trainable_params,
        "parameter_size_gb": get_model_size(model, dtype=dtype),
        "trainable_size_gb": get_model_size(model, dtype=dtype, trainable_only=True),
        "device": str(get_model_device(model)),
        "dtype": str(dtype),
        "num_modules": len(list(model.modules())),
        "num_buffers": len(list(model.buffers())),
        "parameter_distribution": get_parameter_distribution(model),
    }


def get_module_size(module: nn.Module) -> Tuple[int, int]:
    """Get the number of parameters and buffers for a single module.

    Args:
        module: A PyTorch module.

    Returns:
        Tuple of (parameter_count, buffer_count).
    """
    param_count = sum(p.numel() for p in module.parameters(recurse=False))
    buffer_count = sum(b.numel() for b in module.buffers(recurse=False))
    return param_count, buffer_count


def named_parameter_sizes(model: nn.Module) -> Iterator[Tuple[str, int]]:
    """Yield (name, num_elements) for every parameter in the model.

    Args:
        model: The PyTorch model.

    Yields:
        Tuples of (parameter_name, number_of_elements).
    """
    for name, param in model.named_parameters():
        yield name, param.numel()


def print_model_summary(model: nn.Module, verbose: bool = False) -> None:
    """Print a human-readable summary of the model architecture.

    Args:
        model: The PyTorch model.
        verbose: If True, print per-parameter details.
    """
    info = get_model_info(model)
    print(f"{'='*60}")
    print(f"Model Summary")
    print(f"{'='*60}")
    print(f"  Total parameters:     {info['total_parameters']:>15,}")
    print(f"  Trainable parameters: {info['trainable_parameters']:>15,}")
    print(f"  Frozen parameters:    {info['frozen_parameters']:>15,}")
    print(f"  Parameter size:       {info['parameter_size_gb']:>15.3f} GB")
    print(f"  Trainable size:       {info['trainable_size_gb']:>15.3f} GB")
    print(f"  Device:               {info['device']:>15}")
    print(f"  Data type:            {info['dtype']:>15}")
    print(f"  Number of modules:    {info['num_modules']:>15,}")
    print(f"  Number of buffers:    {info['num_buffers']:>15,}")
    if verbose:
        print(f"\n{'─'*60}")
        print(f"  Parameter Breakdown")
        print(f"{'─'*60}")
        for name, size in named_parameter_sizes(model):
            print(f"  {name:50s} {size:>10,}")
    print(f"{'='*60}")
