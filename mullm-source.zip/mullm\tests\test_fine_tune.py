import torch
import pytest


class TestLoRA:
    def test_lora_linear_forward(self):
        from mullm.core.fine_tune.lora import LoRALinear, LoRAConfig
        config = LoRAConfig(r=8, alpha=16, dropout=0.1)
        layer = LoRALinear(in_features=64, out_features=128, config=config)
        x = torch.randn(2, 16, 64)
        output = layer(x)
        assert output.shape == (2, 16, 128)
        assert hasattr(layer, "lora_A")
        assert hasattr(layer, "lora_B")

    def test_lora_merge_unmerge(self):
        from mullm.core.fine_tune.lora import LoRALinear, LoRAConfig
        config = LoRAConfig(r=4, alpha=8, dropout=0.0)
        layer = LoRALinear(in_features=32, out_features=64, config=config)
        x = torch.randn(1, 32)
        before = layer(x)
        layer.merge()
        after_merge = layer(x)
        assert torch.allclose(before, after_merge, atol=1e-5)
        layer.unmerge()
        after_unmerge = layer(x)
        assert torch.allclose(before, after_unmerge, atol=1e-5)


class TestPrefixTuning:
    def test_prefix_encoder(self):
        from mullm.core.fine_tune.prefix_tuning import PrefixEncoder, PrefixTuningConfig
        config = PrefixTuningConfig(num_prefix_tokens=10, hidden_size=64, num_layers=2)
        encoder = PrefixEncoder(config)
        batch_size = 2
        prefix = encoder(batch_size)
        assert prefix.shape == (2, 2, 10, 64)


class TestPromptTuning:
    def test_prompt_embedding(self):
        from mullm.core.fine_tune.prompt_tuning import PromptEmbedding, PromptTuningConfig
        config = PromptTuningConfig(num_virtual_tokens=8, hidden_size=64)
        embedding = PromptEmbedding(config)
        batch_size = 2
        prompt = embedding(batch_size)
        assert prompt.shape == (2, 8, 64)


class TestInstructionTuning:
    def test_format_instruction(self):
        from mullm.core.fine_tune.instruction_tuning import format_instruction
        result = format_instruction("alpaca", instruction="Solve this", response="42", input="What is 6*7?")
        assert "Solve this" in result
        assert "42" in result
