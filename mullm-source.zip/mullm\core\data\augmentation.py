"""Data augmentation for text with synonym replacement, back-translation simulation, noise injection, and paraphrasing."""

from __future__ import annotations

import logging
import random
import re
from dataclasses import dataclass, field
from typing import Optional

logger = logging.getLogger(__name__)


@dataclass
class AugmentationConfig:
    synonym_prob: float = 0.3
    noise_prob: float = 0.1
    backtranslate_prob: float = 0.0
    max_augmentations: int = 5
    preserve_length: bool = True
    seed: int = 42


class SynonymReplacer:
    def __init__(self, synonym_dict: Optional[dict[str, list[str]]] = None) -> None:
        self.synonym_dict = synonym_dict or self._default_synonyms()

    def _default_synonyms(self) -> dict[str, list[str]]:
        return {
            "good": ["excellent", "great", "superb", "fine", "positive"],
            "bad": ["poor", "terrible", "awful", "negative", "inferior"],
            "big": ["large", "huge", "enormous", "massive", "great"],
            "small": ["tiny", "little", "miniature", "compact", "minor"],
            "fast": ["quick", "rapid", "swift", "speedy", "brisk"],
            "slow": ["sluggish", "leisurely", "unhurried", "gradual"],
            "happy": ["glad", "joyful", "cheerful", "delighted", "pleased"],
            "sad": ["unhappy", "sorrowful", "gloomy", "melancholy", "downcast"],
            "important": ["significant", "crucial", "vital", "essential", "critical"],
            "beautiful": ["lovely", "gorgeous", "stunning", "attractive", "pretty"],
        }

    def augment(self, text: str, prob: float = 0.3) -> str:
        words = text.split()
        result = []
        for word in words:
            clean = word.lower().strip(string.punctuation) if hasattr(__import__("string"), "punctuation") else word.lower()
            if clean in self.synonym_dict and random.random() < prob:
                synonym = random.choice(self.synonym_dict[clean])
                case_preserved = synonym if word.islower() else synonym.capitalize()
                result.append(case_preserved)
            else:
                result.append(word)
        return " ".join(result)

    def augment_batch(self, texts: list[str], prob: float = 0.3) -> list[str]:
        return [self.augment(t, prob) for t in texts]


import string


class NoiseInjector:
    def __init__(self, config: Optional[AugmentationConfig] = None) -> None:
        self.config = config or AugmentationConfig()

    def inject(self, text: str, prob: Optional[float] = None) -> str:
        p = prob if prob is not None else self.config.noise_prob
        chars = list(text)
        for i in range(len(chars)):
            if random.random() < p:
                op = random.choice(["delete", "insert", "swap", "replace"])
                if op == "delete":
                    chars[i] = ""
                elif op == "insert":
                    chars[i] = chars[i] + random.choice(string.ascii_lowercase)
                elif op == "swap" and i + 1 < len(chars):
                    chars[i], chars[i + 1] = chars[i + 1], chars[i]
                elif op == "replace":
                    chars[i] = random.choice(string.ascii_lowercase)
        return "".join(c for c in chars)

    def inject_batch(self, texts: list[str], prob: Optional[float] = None) -> list[str]:
        return [self.inject(t, prob) for t in texts]


class BackTranslator:
    def __init__(self, pivot_language: str = "fr") -> None:
        self.pivot_language = pivot_language
        self._phrase_map: dict[str, str] = {
            "hello world": "bonjour le monde",
            "how are you": "comment allez-vous",
            "good morning": "bonjour",
            "thank you": "merci",
            "I am": "je suis",
            "you are": "tu es",
            "we are": "nous sommes",
            "they are": "ils sont",
            "the weather": "le temps",
            "very good": "très bien",
        }
        self._reverse_map: dict[str, str] = {v: k for k, v in self._phrase_map.items()}

    def translate_forward(self, text: str) -> str:
        result = text
        for eng, foreign in self._phrase_map.items():
            result = result.replace(eng, foreign)
        return result

    def translate_backward(self, text: str) -> str:
        result = text
        for foreign, eng in self._reverse_map.items():
            result = result.replace(foreign, eng)
        return result

    def augment(self, text: str, prob: float = 0.0) -> str:
        if random.random() >= prob:
            return text
        intermediate = self.translate_forward(text)
        return self.translate_backward(intermediate)


class Paraphraser:
    def __init__(self) -> None:
        self._patterns: list[tuple[str, str]] = [
            (r"\b(I am|I'm)\b", "I'm"),
            (r"\b(it is|it's)\b", "it's"),
            (r"\b(do not|don't)\b", "don't"),
            (r"\b(cannot|can't)\b", "can't"),
            (r"\b(will not|won't)\b", "won't"),
            (r"\b(is not|isn't)\b", "isn't"),
            (r"\b(are not|aren't)\b", "aren't"),
        ]

    def paraphrase(self, text: str) -> str:
        result = text
        for pattern, replacement in self._patterns:
            if random.random() < 0.5:
                result = re.sub(pattern, replacement, result, flags=re.IGNORECASE)
        return result

    def paraphrase_batch(self, texts: list[str]) -> list[str]:
        return [self.paraphrase(t) for t in texts]


class TextAugmenter:
    def __init__(self, config: Optional[AugmentationConfig] = None) -> None:
        self.config = config or AugmentationConfig()
        random.seed(self.config.seed)
        self.synonym_replacer = SynonymReplacer()
        self.noise_injector = NoiseInjector(self.config)
        self.back_translator = BackTranslator()
        self.paraphraser = Paraphraser()

    def augment(self, text: str) -> list[str]:
        results = [text]
        for _ in range(self.config.max_augmentations - 1):
            aug = text
            aug = self.synonym_replacer.augment(aug, self.config.synonym_prob)
            aug = self.noise_injector.inject(aug, self.config.noise_prob)
            aug = self.back_translator.augment(aug, self.config.backtranslate_prob)
            aug = self.paraphraser.paraphrase(aug)
            if aug != text and (not self.config.preserve_length or abs(len(aug) - len(text)) / max(len(text), 1) < 0.5):
                results.append(aug)
        return results[:self.config.max_augmentations]

    def augment_batch(self, texts: list[str]) -> list[list[str]]:
        return [self.augment(t) for t in texts]

    def augment_balanced(self, texts: list[str], labels: list[int]) -> tuple[list[str], list[int]]:
        from collections import Counter
        label_counts = Counter(labels)
        max_count = max(label_counts.values())
        new_texts = list(texts)
        new_labels = list(labels)
        for label, count in label_counts.items():
            if count < max_count:
                class_texts = [t for t, l in zip(texts, labels) if l == label]
                needed = max_count - count
                for _ in range(needed):
                    if class_texts:
                        src = random.choice(class_texts)
                        augs = self.augment(src)
                        if augs:
                            new_texts.append(augs[0] if len(augs) > 1 else augs[-1])
                            new_labels.append(label)
        return new_texts, new_labels
