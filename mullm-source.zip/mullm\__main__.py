import sys
from mullm.cli.main import main
sys.exit(main())
