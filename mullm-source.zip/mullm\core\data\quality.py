"""Quality scoring pipeline with perplexity, length, punctuation, and composite scoring."""

from __future__ import annotations

import logging
import math
import re
import string
from collections import Counter
from dataclasses import dataclass, field
from typing import Optional

logger = logging.getLogger(__name__)

STOP_WORDS: set[str] = {
    "the", "be", "to", "of", "and", "a", "in", "that", "have", "i",
    "it", "for", "not", "on", "with", "he", "as", "you", "do", "at",
    "this", "but", "his", "by", "from", "they", "we", "say", "her",
    "she", "or", "an", "will", "my", "one", "all", "would", "there",
    "their", "what", "so", "up", "out", "if", "about", "who", "get",
    "which", "go", "me", "when", "make", "can", "like", "time", "no",
    "just", "him", "know", "take", "people", "into", "year", "your",
    "good", "some", "could", "them", "see", "other", "than", "then",
    "now", "look", "only", "come", "its", "over", "think", "also",
    "back", "after", "use", "two", "how", "our", "work", "first",
    "well", "way", "even", "new", "want", "because", "any", "these",
    "give", "day", "most", "us", "is", "are", "was", "were", "been",
    "being", "has", "had", "did", "does", "am",
}


@dataclass
class QualityConfig:
    """Configuration for quality scoring."""

    min_text_length: int = 50
    max_text_length: int = 1000000
    min_word_count: int = 10
    max_mean_word_length: float = 20.0
    min_punctuation_ratio: float = 0.05
    max_punctuation_ratio: float = 0.5
    min_symbol_ratio: float = 0.0
    max_symbol_ratio: float = 0.3
    min_stop_word_ratio: float = 0.1
    min_compression_ratio: float = 0.1
    perplexity_threshold: float = 1000.0
    quality_threshold: float = 0.5
    weights: dict[str, float] = field(default_factory=lambda: {
        "length": 0.1,
        "punctuation": 0.1,
        "symbol": 0.1,
        "stop_word": 0.2,
        "compression": 0.1,
        "repetition": 0.2,
        "coherence": 0.2,
    })


@dataclass
class QualityScore:
    """Quality scoring results."""

    overall_score: float
    length_score: float
    punctuation_score: float
    symbol_score: float
    stop_word_score: float
    compression_score: float
    repetition_score: float
    coherence_score: float
    passes_threshold: bool
    details: dict[str, float] = field(default_factory=dict)


class LengthScorer:
    """Scores text based on length characteristics."""

    def __init__(self, config: QualityConfig) -> None:
        self.config = config

    def score(self, text: str) -> float:
        char_count = len(text)
        word_count = len(text.split())

        if char_count < self.config.min_text_length:
            return 0.0
        if char_count > self.config.max_text_length:
            return 0.5
        if word_count < self.config.min_word_count:
            return 0.0

        ideal_min = 100
        ideal_max = 10000
        if ideal_min <= char_count <= ideal_max:
            length_score = 1.0
        elif char_count < ideal_min:
            length_score = char_count / ideal_min
        else:
            length_score = max(0.5, 1.0 - (char_count - ideal_max) / (ideal_max * 10))

        words = text.split()
        mean_word_length = sum(len(w) for w in words) / max(len(words), 1)
        if mean_word_length > self.config.max_mean_word_length:
            length_score *= 0.5

        return min(length_score, 1.0)


class PunctuationScorer:
    """Scores text based on punctuation usage."""

    def __init__(self, config: QualityConfig) -> None:
        self.config = config

    def score(self, text: str) -> float:
        if not text:
            return 0.0

        total_chars = len(text)
        punct_count = sum(1 for c in text if c in string.punctuation)
        punct_ratio = punct_count / max(total_chars, 1)

        if punct_ratio < self.config.min_punctuation_ratio:
            return max(0.0, punct_ratio / self.config.min_punctuation_ratio)
        elif punct_ratio > self.config.max_punctuation_ratio:
            excess = punct_ratio - self.config.max_punctuation_ratio
            return max(0.0, 1.0 - excess * 5)
        else:
            ideal_ratio = 0.1
            deviation = abs(punct_ratio - ideal_ratio)
            return max(0.0, 1.0 - deviation * 2)

    def has_balanced_punctuation(self, text: str) -> bool:
        pairs = {")": "(", "]": "[", "}": "{", '"': '"', "'": "'"}
        stack: list[str] = []
        for c in text:
            if c in pairs.values():
                stack.append(c)
            elif c in pairs:
                if not stack or stack[-1] != pairs[c]:
                    return False
                stack.pop()
        return len(stack) == 0


class SymbolScorer:
    """Scores text based on symbol-to-word ratio."""

    def __init__(self, config: QualityConfig) -> None:
        self.config = config

    def score(self, text: str) -> float:
        if not text:
            return 0.0

        words = text.split()
        if not words:
            return 0.0

        symbol_count = sum(
            1 for c in text if not c.isalnum() and not c.isspace()
        )
        symbol_ratio = symbol_count / max(len(words), 1)

        if symbol_ratio < self.config.min_symbol_ratio:
            return 1.0
        elif symbol_ratio > self.config.max_symbol_ratio:
            return max(0.0, 1.0 - (symbol_ratio - self.config.max_symbol_ratio) * 5)
        return 1.0


class StopWordScorer:
    """Scores text based on stop word ratio."""

    def __init__(self, config: QualityConfig) -> None:
        self.config = config

    def score(self, text: str) -> float:
        if not text:
            return 0.0

        words = text.lower().split()
        if not words:
            return 0.0

        stop_count = sum(1 for w in words if w in STOP_WORDS)
        ratio = stop_count / len(words)

        if ratio < self.config.min_stop_word_ratio * 0.5:
            return 0.2
        elif ratio >= self.config.min_stop_word_ratio:
            return min(1.0, 0.5 + ratio)
        else:
            return ratio / self.config.min_stop_word_ratio * 0.5


class CompressionScorer:
    """Scores text based on compression ratio (entropy proxy)."""

    def __init__(self, config: QualityConfig) -> None:
        self.config = config

    def score(self, text: str) -> float:
        if not text or len(text) < 100:
            return 0.5

        sample = text[:10000]
        byte_len = len(sample.encode("utf-8"))

        try:
            import zlib

            compressed = len(zlib.compress(sample.encode("utf-8")))
            ratio = compressed / max(byte_len, 1)
        except Exception:
            char_counts = Counter(sample)
            entropy = 0.0
            total = len(sample)
            for count in char_counts.values():
                p = count / total
                if p > 0:
                    entropy -= p * math.log2(p)
            ratio = entropy / 8.0

        if ratio < self.config.min_compression_ratio:
            return 0.1
        elif ratio > 0.8:
            return 0.3
        else:
            return min(1.0, ratio * 1.5)


class RepetitionScorer:
    """Scores text based on repetition patterns."""

    def __init__(self, config: QualityConfig) -> None:
        self.config = config

    def score(self, text: str) -> float:
        if not text:
            return 0.0

        sentences = re.split(r"[.!?]+", text)
        sentences = [s.strip() for s in sentences if s.strip()]

        if len(sentences) < 2:
            return 0.5

        unique_sentences = set(sentences)
        sentence_dup_ratio = 1.0 - (len(unique_sentences) / len(sentences))

        words = text.lower().split()
        if len(words) < 10:
            return 0.5

        bigrams = [f"{words[i]} {words[i+1]}" for i in range(len(words) - 1)]
        bigram_counts = Counter(bigrams)
        repeated_bigrams = sum(c - 1 for c in bigram_counts.values() if c > 1)
        bigram_dup_ratio = repeated_bigrams / max(len(bigrams), 1)

        trigrams = [f"{words[i]} {words[i+1]} {words[i+2]}" for i in range(len(words) - 2)]
        trigram_counts = Counter(trigrams)
        repeated_trigrams = sum(c - 1 for c in trigram_counts.values() if c > 1)
        trigram_dup_ratio = repeated_trigrams / max(len(trigrams), 1)

        penalty = sentence_dup_ratio * 0.4 + bigram_dup_ratio * 0.3 + trigram_dup_ratio * 0.3
        return max(0.0, 1.0 - penalty * 2)


class CoherenceScorer:
    """Scores text coherence based on lexical diversity and structure."""

    def __init__(self, config: QualityConfig) -> None:
        self.config = config

    def score(self, text: str) -> float:
        if not text:
            return 0.0

        words = text.lower().split()
        if len(words) < 5:
            return 0.3

        unique_words = set(words)
        ttr = len(unique_words) / len(words)

        sentences = re.split(r"[.!?]+", text)
        sentences = [s.strip() for s in sentences if s.strip()]

        avg_sentence_length = len(words) / max(len(sentences), 1)
        if avg_sentence_length < 3:
            sentence_score = 0.3
        elif avg_sentence_length > 50:
            sentence_score = 0.5
        else:
            sentence_score = 1.0

        has_upper = text[0].isupper() if text else False
        has_ending = text.rstrip()[-1] in ".!?" if text.strip() else False
        structure_score = (0.5 if has_upper else 0.0) + (0.5 if has_ending else 0.0)

        coherence = ttr * 0.4 + sentence_score * 0.3 + structure_score * 0.3
        return min(1.0, coherence)


class QualityScorer:
    """Composite quality scorer combining multiple quality signals."""

    def __init__(self, config: Optional[QualityConfig] = None) -> None:
        self.config = config or QualityConfig()
        self._length = LengthScorer(self.config)
        self._punctuation = PunctuationScorer(self.config)
        self._symbol = SymbolScorer(self.config)
        self._stop_word = StopWordScorer(self.config)
        self._compression = CompressionScorer(self.config)
        self._repetition = RepetitionScorer(self.config)
        self._coherence = CoherenceScorer(self.config)

    def score(self, text: str) -> QualityScore:
        scores = {
            "length": self._length.score(text),
            "punctuation": self._punctuation.score(text),
            "symbol": self._symbol.score(text),
            "stop_word": self._stop_word.score(text),
            "compression": self._compression.score(text),
            "repetition": self._repetition.score(text),
            "coherence": self._coherence.score(text),
        }

        weights = self.config.weights
        total_weight = sum(weights.get(k, 0) for k in scores)
        if total_weight == 0:
            overall = 0.0
        else:
            overall = sum(
                scores[k] * weights.get(k, 0) for k in scores
            ) / total_weight

        return QualityScore(
            overall_score=overall,
            length_score=scores["length"],
            punctuation_score=scores["punctuation"],
            symbol_score=scores["symbol"],
            stop_word_score=scores["stop_word"],
            compression_score=scores["compression"],
            repetition_score=scores["repetition"],
            coherence_score=scores["coherence"],
            passes_threshold=overall >= self.config.quality_threshold,
            details=scores,
        )

    def score_batch(self, texts: list[str]) -> list[QualityScore]:
        return [self.score(text) for text in texts]

    def filter_texts(
        self, texts: list[str], threshold: Optional[float] = None
    ) -> list[tuple[str, QualityScore]]:
        thresh = threshold or self.config.quality_threshold
        results: list[tuple[str, QualityScore]] = []
        for text in texts:
            qs = self.score(text)
            if qs.overall_score >= thresh:
                results.append((text, qs))
        return results

    def rank_texts(self, texts: list[str]) -> list[tuple[str, QualityScore]]:
        scored = [(text, self.score(text)) for text in texts]
        return sorted(scored, key=lambda x: x[1].overall_score, reverse=True)
