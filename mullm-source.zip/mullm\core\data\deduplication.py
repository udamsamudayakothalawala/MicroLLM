"""Deduplication using hash-based exact matching, MinHash+LSH, and SimHash."""

from __future__ import annotations

import hashlib
import logging
import re
import struct
from dataclasses import dataclass, field
from typing import Optional

import mmh3

logger = logging.getLogger(__name__)


@dataclass
class DeduplicationConfig:
    """Configuration for deduplication."""

    num_perm: int = 128
    lsh_num_bands: int = 16
    lsh_band_width: int = 8
    jaccard_threshold: float = 0.8
    simhash_hamming_threshold: int = 3
    ngram_size: int = 5
    min_text_length: int = 10
    normalize_text: bool = True
    shingle_type: str = "word"


class TextNormalizer:
    """Normalizes text for consistent deduplication."""

    @staticmethod
    def normalize(text: str) -> str:
        text = text.lower().strip()
        text = re.sub(r"\s+", " ", text)
        text = re.sub(r"[^\w\s]", "", text)
        return text

    @staticmethod
    def get_shingles(text: str, k: int = 5, shingle_type: str = "word") -> set[str]:
        normalized = TextNormalizer.normalize(text)
        if shingle_type == "char":
            return {normalized[i : i + k] for i in range(max(0, len(normalized) - k + 1))}
        words = normalized.split()
        return {" ".join(words[i : i + k]) for i in range(max(0, len(words) - k + 1))}

    @staticmethod
    def get_char_ngrams(text: str, n: int = 3) -> list[str]:
        normalized = TextNormalizer.normalize(text)
        return [normalized[i : i + n] for i in range(max(0, len(normalized) - n + 1))]


class ExactDeduplicator:
    """Hash-based exact duplicate removal."""

    def __init__(self) -> None:
        self._seen_hashes: set[str] = set()
        self._hash_to_text: dict[str, str] = {}

    def _hash(self, text: str) -> str:
        return hashlib.sha256(text.encode("utf-8")).hexdigest()

    def is_duplicate(self, text: str) -> bool:
        h = self._hash(text)
        if h in self._seen_hashes:
            return True
        self._seen_hashes.add(h)
        return False

    def get_hash(self, text: str) -> str:
        return self._hash(text)

    def deduplicate(self, texts: list[str]) -> list[str]:
        unique: list[str] = []
        for text in texts:
            if not self.is_duplicate(text):
                unique.append(text)
        return unique

    def get_stats(self) -> dict[str, int]:
        return {"unique_hashes": len(self._seen_hashes)}

    def reset(self) -> None:
        self._seen_hashes.clear()
        self._hash_to_text.clear()


class MinHashSignature:
    """Computes MinHash signatures for set similarity estimation."""

    def __init__(self, num_perm: int = 128) -> None:
        self.num_perm = num_perm
        self._max_val = (1 << 32) - 1

    def _hash_func(self, seed: int, value: str) -> int:
        h = mmh3.hash(value, seed)
        return h & self._max_val

    def compute(self, shingles: set[str]) -> list[int]:
        signature = []
        for i in range(self.num_perm):
            min_hash = self._max_val
            for shingle in shingles:
                h = self._hash_func(i, shingle)
                if h < min_hash:
                    min_hash = h
            signature.append(min_hash)
        return signature

    @staticmethod
    def jaccard_estimate(sig1: list[int], sig2: list[int]) -> float:
        if len(sig1) != len(sig2) or not sig1:
            return 0.0
        matches = sum(1 for a, b in zip(sig1, sig2) if a == b)
        return matches / len(sig1)


class LSHIndex:
    """Locality-Sensitive Hashing index for efficient near-duplicate search."""

    def __init__(self, num_bands: int = 16, band_width: int = 8) -> None:
        self.num_bands = num_bands
        self.band_width = band_width
        self._buckets: dict[tuple[int, int], list[int]] = {}

    def _hash_band(self, band_idx: int, signature: list[int]) -> int:
        start = band_idx * self.band_width
        end = start + self.band_width
        band_values = tuple(signature[start:end])
        return hash(band_values)

    def index(self, doc_id: int, signature: list[int]) -> None:
        for band_idx in range(self.num_bands):
            bucket_hash = self._hash_band(band_idx, signature)
            key = (band_idx, bucket_hash)
            if key not in self._buckets:
                self._buckets[key] = []
            self._buckets[key].append(doc_id)

    def query(self, signature: list[int]) -> set[int]:
        candidates: set[int] = set()
        for band_idx in range(self.num_bands):
            bucket_hash = self._hash_band(band_idx, signature)
            key = (band_idx, bucket_hash)
            if key in self._buckets:
                candidates.update(self._buckets[key])
        return candidates

    def clear(self) -> None:
        self._buckets.clear()


class SimHash:
    """SimHash for efficient similarity detection."""

    def __init__(self, hash_bits: int = 64) -> None:
        self.hash_bits = hash_bits

    def _tokenize(self, text: str) -> list[str]:
        normalized = TextNormalizer.normalize(text)
        return normalized.split()

    def compute(self, text: str) -> int:
        tokens = self._tokenize(text)
        if not tokens:
            return 0

        vector = [0] * self.hash_bits
        for token in tokens:
            token_hash = mmh3.hash64(token)
            h = token_hash[0] & ((1 << self.hash_bits) - 1)
            for i in range(self.hash_bits):
                if h & (1 << i):
                    vector[i] += 1
                else:
                    vector[i] -= 1

        fingerprint = 0
        for i in range(self.hash_bits):
            if vector[i] > 0:
                fingerprint |= (1 << i)
        return fingerprint

    @staticmethod
    def hamming_distance(hash1: int, hash2: int) -> int:
        return bin(hash1 ^ hash2).count("1")

    @staticmethod
    def similarity(hash1: int, hash2: int, hash_bits: int = 64) -> float:
        distance = SimHash.hamming_distance(hash1, hash2)
        return 1.0 - (distance / hash_bits)


class MinHashDeduplicator:
    """Near-duplicate detection using MinHash + LSH."""

    def __init__(self, config: Optional[DeduplicationConfig] = None) -> None:
        self.config = config or DeduplicationConfig()
        self._minhash = MinHashSignature(self.config.num_perm)
        self._lsh = LSHIndex(self.config.lsh_num_bands, self.config.lsh_band_width)
        self._signatures: list[list[int]] = []
        self._texts: list[str] = []

    def compute_signature(self, text: str) -> list[int]:
        shingles = TextNormalizer.get_shingles(
            text, self.config.ngram_size, self.config.shingle_type
        )
        if not shingles:
            shingles = set(text.lower()[:100])
        return self._minhash.compute(shingles)

    def add(self, text: str) -> int:
        sig = self.compute_signature(text)
        doc_id = len(self._signatures)
        self._signatures.append(sig)
        self._texts.append(text)
        self._lsh.index(doc_id, sig)
        return doc_id

    def find_near_duplicates(self, text: str) -> list[tuple[int, float]]:
        sig = self.compute_signature(text)
        candidates = self._lsh.query(sig)

        results: list[tuple[int, float]] = []
        for candidate_id in candidates:
            if candidate_id < len(self._signatures):
                jaccard = MinHashSignature.jaccard_estimate(
                    sig, self._signatures[candidate_id]
                )
                if jaccard >= self.config.jaccard_threshold:
                    results.append((candidate_id, jaccard))

        return sorted(results, key=lambda x: x[1], reverse=True)

    def deduplicate(self, texts: list[str]) -> list[str]:
        unique: list[str] = []
        for text in texts:
            if len(text) < self.config.min_text_length:
                unique.append(text)
                continue

            duplicates = self.find_near_duplicates(text)
            if not duplicates:
                unique.append(text)
                self.add(text)

        return unique

    def get_similarity_matrix(self) -> list[list[float]]:
        n = len(self._signatures)
        matrix: list[list[float]] = []
        for i in range(n):
            row: list[float] = []
            for j in range(n):
                if i == j:
                    row.append(1.0)
                elif j < i:
                    row.append(matrix[j][i])
                else:
                    row.append(
                        MinHashSignature.jaccard_estimate(
                            self._signatures[i], self._signatures[j]
                        )
                    )
            matrix.append(row)
        return matrix

    def clear(self) -> None:
        self._signatures.clear()
        self._texts.clear()
        self._lsh.clear()


class SimHashDeduplicator:
    """Fast near-duplicate detection using SimHash."""

    def __init__(self, config: Optional[DeduplicationConfig] = None) -> None:
        self.config = config or DeduplicationConfig()
        self._simhash = SimHash()
        self._hashes: dict[int, list[int]] = {}
        self._texts: list[str] = []

    def add(self, text: str) -> int:
        h = self._simhash.compute(text)
        doc_id = len(self._texts)
        self._texts.append(text)
        if h not in self._hashes:
            self._hashes[h] = []
        self._hashes[h].append(doc_id)
        return doc_id

    def find_near_duplicates(self, text: str) -> list[tuple[int, float]]:
        h = self._simhash.compute(text)
        results: list[tuple[int, float]] = []

        for stored_hash, doc_ids in self._hashes.items():
            distance = SimHash.hamming_distance(h, stored_hash)
            if distance <= self.config.simhash_hamming_threshold:
                similarity = SimHash.similarity(h, stored_hash)
                for doc_id in doc_ids:
                    results.append((doc_id, similarity))

        return sorted(results, key=lambda x: x[1], reverse=True)

    def deduplicate(self, texts: list[str]) -> list[str]:
        unique: list[str] = []
        for text in texts:
            if len(text) < self.config.min_text_length:
                unique.append(text)
                continue

            duplicates = self.find_near_duplicates(text)
            if not duplicates:
                unique.append(text)
                self.add(text)

        return unique

    def clear(self) -> None:
        self._hashes.clear()
        self._texts.clear()


class Deduplicator:
    """Unified deduplication interface combining exact, MinHash, and SimHash."""

    def __init__(self, config: Optional[DeduplicationConfig] = None) -> None:
        self.config = config or DeduplicationConfig()
        self._exact = ExactDeduplicator()
        self._minhash = MinHashDeduplicator(config)
        self._simhash = SimHashDeduplicator(config)

    def deduplicate(
        self,
        texts: list[str],
        method: str = "exact",
        **kwargs,
    ) -> list[str]:
        if method == "exact":
            return self._exact.deduplicate(texts)
        elif method == "minhash":
            return self._minhash.deduplicate(texts, **kwargs)
        elif method == "simhash":
            return self._simhash.deduplicate(texts, **kwargs)
        elif method == "combined":
            exact_unique = self._exact.deduplicate(texts)
            minhash_unique = self._minhash.deduplicate(exact_unique)
            return minhash_unique
        else:
            raise ValueError(f"Unknown method: {method}")

    def is_duplicate(self, text: str, method: str = "exact") -> bool:
        if method == "exact":
            return self._exact.is_duplicate(text)
        elif method == "minhash":
            duplicates = self._minhash.find_near_duplicates(text)
            return len(duplicates) > 0
        elif method == "simhash":
            duplicates = self._simhash.find_near_duplicates(text)
            return len(duplicates) > 0
        return False

    def compute_jaccard(self, text1: str, text2: str) -> float:
        shingles1 = TextNormalizer.get_shingles(text1, self.config.ngram_size)
        shingles2 = TextNormalizer.get_shingles(text2, self.config.ngram_size)
        if not shingles1 and not shingles2:
            return 1.0
        if not shingles1 or not shingles2:
            return 0.0
        intersection = len(shingles1 & shingles2)
        union = len(shingles1 | shingles2)
        return intersection / union if union > 0 else 0.0

    def compute_similarity(self, text1: str, text2: str) -> float:
        h1 = self._minhash.compute_signature(text1)
        h2 = self._minhash.compute_signature(text2)
        return MinHashSignature.jaccard_estimate(h1, h2)

    @property
    def exact_dedup(self) -> ExactDeduplicator:
        return self._exact

    @property
    def minhash_dedup(self) -> MinHashDeduplicator:
        return self._minhash

    @property
    def simhash_dedup(self) -> SimHashDeduplicator:
        return self._simhash
