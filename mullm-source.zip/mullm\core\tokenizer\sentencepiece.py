import json
import math
import os
import re
from collections import Counter, defaultdict
from typing import Dict, Iterator, List, Optional, Sequence, Set, Tuple

from .base import BaseTokenizer, SpecialTokens


class SentencePieceTokenizer(BaseTokenizer):
    def __init__(
        self,
        model_path: Optional[str] = None,
        special_tokens: Optional[SpecialTokens] = None,
        vocab: Optional[Dict[str, int]] = None,
        unk_id: int = 0,
        bos_id: int = 1,
        eos_id: int = 2,
        pad_id: int = -1,
    ) -> None:
        super().__init__(special_tokens)
        self._vocab: Dict[str, int] = {}
        self._decoder: Dict[int, str] = {}
        self._unk_id = unk_id
        self._bos_id = bos_id
        self._eos_id = eos_id
        self._pad_id = pad_id
        self._normalization_rule: Optional[str] = None
        self._byte_fallback = False
        self._model_proto: Optional[bytes] = None

        if vocab is not None:
            self._vocab = dict(vocab)
            self._decoder = {v: k for k, v in self._vocab.items()}

        if model_path is not None:
            self._load_model(model_path)

        self._sp_processor: Optional["SentencePieceProcessor"] = None
        self._init_sentencepiece()

    def _init_sentencepiece(self) -> None:
        try:
            import sentencepiece as _sp

            self._sp_processor = _sp.SentencePieceProcessor()
            if self._model_proto is not None:
                self._sp_processor.LoadFromSerializedProto(self._model_proto)
        except ImportError:
            self._sp_processor = None

    def _load_model(self, model_path: str) -> None:
        with open(model_path, "rb") as f:
            self._model_proto = f.read()
        try:
            import sentencepiece as _sp

            sp = _sp.SentencePieceProcessor()
            sp.Load(model_path)
            self._unk_id = sp.unk_id()
            self._bos_id = sp.bos_id()
            self._eos_id = sp.eos_id()
            self._pad_id = sp.pad_id()
            vocab_size = sp.GetPieceSize()
            self._vocab = {}
            for i in range(vocab_size):
                piece = sp.IdToPiece(i)
                score = sp.GetScore(i)
                self._vocab[piece] = (i, score)
            self._vocab = {k: v[0] for k, v in self._vocab.items()}
            self._decoder = {v: k for k, v in self._vocab.items()}
        except ImportError:
            pass

    @property
    def vocab_size(self) -> int:
        return len(self._vocab) + len(self._added_tokens)

    def _token_to_id(self, token: str) -> int:
        if token in self._added_tokens:
            return self._added_tokens[token]
        if token in self._vocab:
            return self._vocab[token]
        if self._sp_processor is not None:
            return self._sp_processor.PieceToId(token)
        return self._unk_id

    def _id_to_token(self, idx: int) -> str:
        if idx in self._added_tokens_decoder:
            return self._added_tokens_decoder[idx]
        if idx in self._decoder:
            return self._decoder[idx]
        if self._sp_processor is not None:
            return self._sp_processor.IdToPiece(idx)
        return f"<{idx}>"

    def _get_vocab(self) -> Dict[str, int]:
        full = dict(self._vocab)
        full.update(self._added_tokens)
        return full

    def _set_vocab(self, vocab: Dict[str, int]) -> None:
        added = {k: v for k, v in vocab.items() if k in self._added_tokens or k in self._special_tokens.all_special_tokens}
        base = {k: v for k, v in vocab.items() if k not in added}
        self._vocab = base
        self._decoder = {v: k for k, v in self._vocab.items()}
        self._added_tokens = added
        self._added_tokens_decoder = {v: k for k, v in added.items()}

    def encode(self, text: str, add_special_tokens: bool = True) -> List[int]:
        tokens: List[int] = []
        if add_special_tokens:
            bos = self.bos_token_id() if self._bos_id >= 0 else None
            if bos is not None:
                tokens.append(bos)
        if self._sp_processor is not None:
            ids = self._sp_processor.EncodeAsIds(text)
            tokens.extend(ids)
        else:
            tokens.extend(self._encode_fallback(text))
        if add_special_tokens:
            eos = self.eos_token_id() if self._eos_id >= 0 else None
            if eos is not None:
                tokens.append(eos)
        return tokens

    def _encode_fallback(self, text: str) -> List[int]:
        ids: List[int] = []
        for char in text:
            token = char
            idx = self._token_to_id(token)
            ids.append(idx)
        return ids

    def decode(self, ids: Sequence[int], skip_special_tokens: bool = True) -> str:
        special_ids = set(self.all_special_ids()) if skip_special_tokens else set()
        if self._sp_processor is not None:
            filtered = [i for i in ids if i not in special_ids]
            return self._sp_processor.DecodeIds(filtered)
        pieces: List[str] = []
        for idx in ids:
            if idx in special_ids:
                continue
            token = self._id_to_token(idx)
            pieces.append(token)
        return "".join(pieces).replace("\u2581", " ")

    def set_normalization_rule(self, rule: str) -> None:
        self._normalization_rule = rule

    def set_byte_fallback(self, enabled: bool) -> None:
        self._byte_fallback = enabled
        if self._sp_processor is not None:
            self._sp_processor.SetByteFallback(enabled)

    def save_model(self, path: str) -> None:
        if self._model_proto is not None:
            with open(path, "wb") as f:
                f.write(self._model_proto)
        else:
            data = {
                "vocab": self._vocab,
                "special_tokens": self._special_tokens.to_dict(),
                "added_tokens": self._added_tokens,
                "unk_id": self._unk_id,
                "bos_id": self._bos_id,
                "eos_id": self._eos_id,
                "pad_id": self._pad_id,
            }
            with open(path + ".json", "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False, indent=2)

    @classmethod
    def from_pretrained(cls, name_or_path: str) -> "SentencePieceTokenizer":
        if os.path.isfile(name_or_path):
            return cls(model_path=name_or_path)
        try:
            from transformers import AutoTokenizer

            hf_tokenizer = AutoTokenizer.from_pretrained(name_or_path)
            if hasattr(hf_tokenizer, "sp_model"):
                sp_model = hf_tokenizer.sp_model
                vocab_size = sp_model.GetPieceSize()
                vocab = {}
                for i in range(vocab_size):
                    piece = sp_model.IdToPiece(i)
                    vocab[piece] = i
                special = SpecialTokens(
                    bos_token=hf_tokenizer.bos_token,
                    eos_token=hf_tokenizer.eos_token,
                    unk_token=hf_tokenizer.unk_token,
                    pad_token=hf_tokenizer.pad_token,
                )
                return cls(vocab=vocab, special_tokens=special)
        except ImportError:
            pass
        raise ValueError(f"Cannot load SentencePiece model from {name_or_path}")


class UnigramTokenizer(BaseTokenizer):
    def __init__(
        self,
        vocab: Optional[Dict[str, int]] = None,
        scores: Optional[Dict[str, float]] = None,
        special_tokens: Optional[SpecialTokens] = None,
        unk_score: float = 0.0,
    ) -> None:
        super().__init__(special_tokens)
        self._vocab: Dict[str, int] = {}
        self._decoder: Dict[int, str] = {}
        self._scores: Dict[str, float] = {}
        self._unk_score = unk_score

        if vocab is not None:
            self._vocab = dict(vocab)
            self._decoder = {v: k for k, v in self._vocab.items()}
        if scores is not None:
            self._scores = dict(scores)

        for st in self._special_tokens.all_special_tokens:
            if st not in self._vocab:
                idx = len(self._vocab) + len(self._added_tokens)
                self._added_tokens[st] = idx
                self._added_tokens_decoder[idx] = st

    @property
    def vocab_size(self) -> int:
        return len(self._vocab) + len(self._added_tokens)

    def _token_to_id(self, token: str) -> int:
        if token in self._added_tokens:
            return self._added_tokens[token]
        if token in self._vocab:
            return self._vocab[token]
        unk = self._special_tokens.unk_token
        if unk is not None and unk in self._vocab:
            return self._vocab[unk]
        return 0

    def _id_to_token(self, idx: int) -> str:
        if idx in self._added_tokens_decoder:
            return self._added_tokens_decoder[idx]
        return self._decoder.get(idx, self._special_tokens.unk_token or "<unk>")

    def _get_vocab(self) -> Dict[str, int]:
        full = dict(self._vocab)
        full.update(self._added_tokens)
        return full

    def _set_vocab(self, vocab: Dict[str, int]) -> None:
        added = {k: v for k, v in vocab.items() if k in self._added_tokens or k in self._special_tokens.all_special_tokens}
        base = {k: v for k, v in vocab.items() if k not in added}
        self._vocab = base
        self._decoder = {v: k for k, v in self._vocab.items()}
        self._added_tokens = added
        self._added_tokens_decoder = {v: k for k, v in added.items()}

    def _viterbi_segment(self, word: str) -> Tuple[List[str], float]:
        n = len(word)
        dp = [float("-inf")] * (n + 1)
        dp[0] = 0.0
        backpointer = [-1] * (n + 1)

        for i in range(1, n + 1):
            for j in range(i):
                subword = word[j:i]
                if subword in self._scores:
                    log_prob = self._scores[subword]
                elif subword in self._vocab:
                    log_prob = self._unk_score
                else:
                    continue
                cand = dp[j] + log_prob
                if cand > dp[i]:
                    dp[i] = cand
                    backpointer[i] = j

        tokens: List[str] = []
        pos = n
        while pos > 0:
            j = backpointer[pos]
            if j < 0:
                tokens.insert(0, word[:pos])
                break
            tokens.insert(0, word[j:pos])
            pos = j

        return tokens, dp[n]

    def encode(self, text: str, add_special_tokens: bool = True) -> List[int]:
        tokens: List[int] = []
        if add_special_tokens:
            bos = self.bos_token_id()
            if bos is not None:
                tokens.append(bos)

        for word in re.findall(r"\S+|\s+", text):
            subwords, _ = self._viterbi_segment(word)
            for subword in subwords:
                token_id = self._token_to_id(subword)
                tokens.append(token_id)

        if add_special_tokens:
            eos = self.eos_token_id()
            if eos is not None:
                tokens.append(eos)

        return tokens

    def decode(self, ids: Sequence[int], skip_special_tokens: bool = True) -> str:
        special_ids = set(self.all_special_ids()) if skip_special_tokens else set()
        pieces: List[str] = []
        for idx in ids:
            if idx in special_ids:
                continue
            token = self._id_to_token(idx)
            pieces.append(token)
        return "".join(pieces).replace("\u2581", " ")

    def _build_seed_vocab(
        self, word_freqs: Counter[str], max_subword_len: int = 15, min_freq: int = 2
    ) -> Set[str]:
        vocab: Set[str] = set()
        for word, freq in word_freqs.items():
            for ch in word:
                vocab.add(ch)
        if min_freq <= 1:
            min_freq = 1
        for word, freq in word_freqs.items():
            if freq < min_freq:
                continue
            wlen = len(word)
            for i in range(wlen):
                for j in range(i + 2, min(wlen + 1, i + max_subword_len + 1)):
                    subword = word[i:j]
                    vocab.add(subword)
        return vocab

    def _estimate_probs_em(
        self, word_freqs: Counter[str], vocab: Set[str], num_iterations: int = 5
    ) -> Dict[str, float]:
        scores: Dict[str, float] = {sw: -math.log(1.0 / len(vocab)) for sw in vocab}
        smoothing_epsilon = 1e-10

        for iteration in range(num_iterations):
            total_count: Counter[str] = Counter()
            total_log_likelihood = 0.0
            total_tokens = 0

            for word, freq in word_freqs.items():
                subwords, log_prob = self._viterbi_segment_from_scores(word, scores)
                if log_prob == float("-inf"):
                    continue
                total_log_likelihood += log_prob * freq
                for sw in subwords:
                    total_count[sw] += freq
                    total_tokens += freq

            if total_tokens == 0:
                break

            for sw in scores:
                count = total_count.get(sw, 0)
                if len(sw) == 1:
                    count = max(count, 1)
                if count > 0:
                    prob = count / (total_tokens + smoothing_epsilon * len(scores))
                    scores[sw] = math.log(max(prob, smoothing_epsilon))
                else:
                    scores[sw] = -math.log(1e6)

        return scores

    def _viterbi_segment_from_scores(
        self, word: str, scores: Dict[str, float]
    ) -> Tuple[List[str], float]:
        n = len(word)
        dp = [float("-inf")] * (n + 1)
        dp[0] = 0.0
        backpointer = [-1] * (n + 1)

        for i in range(1, n + 1):
            for j in range(i):
                subword = word[j:i]
                if subword in scores and scores[subword] != float("-inf"):
                    cand = dp[j] + scores[subword]
                    if cand > dp[i]:
                        dp[i] = cand
                        backpointer[i] = j

        tokens: List[str] = []
        pos = n
        while pos > 0:
            j = backpointer[pos]
            if j < 0:
                tokens.insert(0, word[:pos])
                break
            tokens.insert(0, word[j:pos])
            pos = j

        return tokens, dp[n]

    def train_from_iterator(
        self,
        texts: Iterator[str],
        vocab_size: int,
        show_progress: bool = True,
        max_subword_len: int = 15,
        min_frequency: int = 2,
        em_iterations: int = 5,
        pruning_factor: float = 0.5,
    ) -> None:
        self._vocab = {}
        self._decoder = {}
        self._scores = {}
        self._added_tokens = {}
        self._added_tokens_decoder = {}

        word_freqs: Counter[str] = Counter()
        for text in texts:
            for word in re.findall(r"\S+|\s+", text):
                word_freqs[word] += 1

        seed_vocab = self._build_seed_vocab(word_freqs, max_subword_len, min_frequency)

        current_vocab: Set[str] = set(seed_vocab)
        for st in self._special_tokens.all_special_tokens:
            current_vocab.add(st)

        if len(current_vocab) >= vocab_size:
            sorted_v = sorted(current_vocab)
            self._vocab = {t: i for i, t in enumerate(sorted_v[:vocab_size])}
            self._decoder = {v: k for k, v in self._vocab.items()}
            self._scores = {t: -math.log(1.0 / len(self._vocab)) for t in self._vocab}
            return

        single_chars: Set[str] = set()
        for word in word_freqs:
            for ch in word:
                single_chars.add(ch)

        if show_progress:
            try:
                from tqdm import tqdm

                iterator = tqdm(
                    desc="Training Unigram tokenizer", unit="step"
                )
            except ImportError:
                iterator = None
        else:
            iterator = None

        while len(current_vocab) > vocab_size:
            scores = self._estimate_probs_em(
                word_freqs, current_vocab, num_iterations=em_iterations
            )

            loss_scores: List[Tuple[str, float]] = []
            for sw in current_vocab:
                if sw in self._special_tokens.all_special_tokens:
                    continue
                if len(sw) == 1:
                    continue
                if sw not in scores or scores[sw] == float("-inf"):
                    loss_scores.append((sw, float("inf")))
                    continue
                score = scores[sw]
                count = 0
                for word, freq in word_freqs.items():
                    if sw in word:
                        count += freq
                contribution = -score * count
                loss_scores.append((sw, contribution))

            loss_scores.sort(key=lambda x: x[1])

            num_to_remove = max(
                1, int((len(current_vocab) - vocab_size) * pruning_factor)
            )
            removed = 0
            for sw, _ in loss_scores:
                if len(current_vocab) - removed <= vocab_size:
                    break
                current_vocab.discard(sw)
                removed += 1

            if iterator is not None:
                iterator.update(1)

        if iterator is not None:
            iterator.close()

        sorted_vocab = sorted(current_vocab)
        self._vocab = {t: i for i, t in enumerate(sorted_vocab)}
        self._decoder = {v: k for k, v in self._vocab.items()}

        final_scores = self._estimate_probs_em(
            word_freqs, current_vocab, num_iterations=em_iterations
        )
        self._scores = {}
        min_log_prob = -math.log(1.0 / len(self._vocab))
        for t in self._vocab:
            score = final_scores.get(t, min_log_prob)
            if score == float("-inf") or math.isnan(score):
                score = min_log_prob
            self._scores[t] = score

    def save(self, path: str) -> None:
        os.makedirs(os.path.dirname(path) if os.path.dirname(path) else ".", exist_ok=True)
        data = {
            "vocab": self._vocab,
            "scores": {k: float(v) for k, v in self._scores.items()},
            "special_tokens": self._special_tokens.to_dict(),
            "added_tokens": self._added_tokens,
        }
        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)

    @classmethod
    def load(cls, path: str) -> "UnigramTokenizer":
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        special_tokens = SpecialTokens.from_dict(data.get("special_tokens", {}))
        scores = data.get("scores")
        return cls(
            vocab=data.get("vocab"),
            scores={k: float(v) for k, v in scores.items()} if scores else None,
            special_tokens=special_tokens,
        )
