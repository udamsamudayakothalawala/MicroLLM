"""Async web crawler with polite crawling, rate limiting, and URL deduplication."""

from __future__ import annotations

import asyncio
import hashlib
import logging
import re
import time
from dataclasses import dataclass, field
from typing import AsyncIterator, Callable, Optional
from urllib.parse import urljoin, urlparse, urlunparse
from urllib.robotparser import RobotFileParser

import aiohttp

logger = logging.getLogger(__name__)


class BloomFilter:
    """Space-efficient probabilistic set for URL deduplication."""

    def __init__(self, capacity: int = 1_000_000, error_rate: float = 0.001) -> None:
        import math

        self.size = int(-capacity * math.log(error_rate) / (math.log(2) ** 2))
        self.num_hashes = int((self.size / capacity) * math.log(2))
        self.bit_array = bytearray((self.size + 7) // 8)

    def _hashes(self, item: str) -> list[int]:
        h1 = int(hashlib.md5(item.encode()).hexdigest(), 16)
        h2 = int(hashlib.sha1(item.encode()).hexdigest(), 16)
        return [(h1 + i * h2) % self.size for i in range(self.num_hashes)]

    def add(self, item: str) -> None:
        for pos in self._hashes(item):
            self.bit_array[pos // 8] |= 1 << (pos % 8)

    def __contains__(self, item: str) -> bool:
        return all(
            self.bit_array[pos // 8] & (1 << (pos % 8))
            for pos in self._hashes(item)
        )


@dataclass
class CrawlConfig:
    """Configuration for the web crawler."""

    max_depth: int = 3
    max_pages: int = 1000
    concurrency: int = 10
    rate_limit: float = 1.0
    timeout: int = 30
    retry_count: int = 3
    respect_robots: bool = True
    user_agent: str = "muLLM-Crawler/1.0"
    allowed_domains: list[str] = field(default_factory=list)
    blocked_domains: list[str] = field(default_factory=list)
    allowed_schemes: tuple[str, ...] = ("http", "https")
    follow_external: bool = False


@dataclass
class CrawlResult:
    """Result of a single page crawl."""

    url: str
    status: int
    content_type: str
    body: str
    depth: int
    headers: dict[str, str]
    elapsed: float
    links: list[str] = field(default_factory=list)
    error: Optional[str] = None


class DomainRateLimiter:
    """Per-domain rate limiter."""

    def __init__(self, default_delay: float = 1.0) -> None:
        self._default_delay = default_delay
        self._last_access: dict[str, float] = {}
        self._delays: dict[str, float] = {}
        self._locks: dict[str, asyncio.Lock] = {}

    def set_delay(self, domain: str, delay: float) -> None:
        self._delays[domain] = delay

    def _get_lock(self, domain: str) -> asyncio.Lock:
        if domain not in self._locks:
            self._locks[domain] = asyncio.Lock()
        return self._locks[domain]

    async def wait(self, domain: str) -> None:
        lock = self._get_lock(domain)
        async with lock:
            delay = self._delays.get(domain, self._default_delay)
            last = self._last_access.get(domain, 0.0)
            now = time.monotonic()
            wait_time = max(0.0, delay - (now - last))
            if wait_time > 0:
                await asyncio.sleep(wait_time)
            self._last_access[domain] = time.monotonic()


class RobotsChecker:
    """Checks robots.txt compliance with caching."""

    def __init__(self, user_agent: str = "muLLM-Crawler/1.0") -> None:
        self._user_agent = user_agent
        self._parsers: dict[str, RobotFileParser] = {}
        self._fetched: set[str] = set()
        self._lock = asyncio.Lock()

    async def can_fetch(self, session: aiohttp.ClientSession, url: str) -> bool:
        parsed = urlparse(url)
        base = f"{parsed.scheme}://{parsed.netloc}"

        async with self._lock:
            if base not in self._parsers:
                rp = RobotFileParser()
                self._parsers[base] = rp
                robots_url = f"{base}/robots.txt"
                try:
                    async with session.get(
                        robots_url, timeout=aiohttp.ClientTimeout(total=10)
                    ) as resp:
                        if resp.status == 200:
                            text = await resp.text()
                            rp.parse(text.splitlines())
                        else:
                            rp.parse([])
                        self._fetched.add(base)
                except Exception:
                    rp.parse([])
                    self._fetched.add(base)

        parser = self._parsers[base]
        if not parser.entries:
            return True

        crawl_delay = parser.crawl_delay(self._user_agent)
        return parser.can_fetch(self._user_agent, url), crawl_delay


class WebCrawler:
    """Async web crawler with politeness, rate limiting, and depth control."""

    def __init__(self, config: Optional[CrawlConfig] = None) -> None:
        self.config = config or CrawlConfig()
        self._visited = BloomFilter()
        self._rate_limiter = DomainRateLimiter(self.config.rate_limit)
        self._robots = RobotsChecker(self.config.user_agent)
        self._semaphore = asyncio.Semaphore(self.config.concurrency)
        self._page_count = 0
        self._results: list[CrawlResult] = []
        self._session: Optional[aiohttp.ClientSession] = None
        self._on_page: Optional[Callable[[CrawlResult], None]] = None

    def on_page(self, callback: Callable[[CrawlResult], None]) -> None:
        self._on_page = callback

    def _normalize_url(self, url: str) -> str:
        parsed = urlparse(url)
        normalized = parsed._replace(fragment="", query=parsed.query.lower())
        return urlunparse(normalized)

    def _is_allowed(self, url: str) -> bool:
        parsed = urlparse(url)
        if parsed.scheme not in self.config.allowed_schemes:
            return False
        domain = parsed.netloc.lower()
        if self.config.blocked_domains:
            if any(domain.endswith(bd) for bd in self.config.blocked_domains):
                return False
        if self.config.allowed_domains:
            if not any(domain.endswith(ad) for ad in self.config.allowed_domains):
                return False
        return True

    def _extract_links(self, base_url: str, html: str) -> list[str]:
        links = []
        pattern = re.compile(r'<a\s+[^>]*href=["\']([^"\']+)["\']', re.IGNORECASE)
        for match in pattern.finditer(html):
            href = match.group(1)
            absolute = urljoin(base_url, href)
            normalized = self._normalize_url(absolute)
            if self._is_allowed(normalized):
                links.append(normalized)
        return links

    def _domain_of(self, url: str) -> str:
        return urlparse(url).netloc

    async def _fetch_page(self, url: str, depth: int) -> CrawlResult:
        start = time.monotonic()
        domain = self._domain_of(url)

        await self._rate_limiter.wait(domain)

        if self.config.respect_robots:
            can_fetch = await self._robots.can_fetch(self._session, url)  # type: ignore
            if not can_fetch:
                return CrawlResult(
                    url=url,
                    status=0,
                    content_type="",
                    body="",
                    depth=depth,
                    headers={},
                    elapsed=0.0,
                    error="Blocked by robots.txt",
                )

        last_error: Optional[str] = None
        for attempt in range(self.config.retry_count):
            try:
                timeout = aiohttp.ClientTimeout(total=self.config.timeout)
                headers = {"User-Agent": self.config.user_agent}
                async with self._session.get(url, timeout=timeout, headers=headers) as resp:  # type: ignore
                    content_type = resp.headers.get("Content-Type", "")
                    if "text" not in content_type and "html" not in content_type:
                        return CrawlResult(
                            url=url,
                            status=resp.status,
                            content_type=content_type,
                            body="",
                            depth=depth,
                            headers=dict(resp.headers),
                            elapsed=time.monotonic() - start,
                            error="Non-text content type",
                        )
                    body = await resp.text(errors="replace")
                    links = self._extract_links(url, body)
                    return CrawlResult(
                        url=url,
                        status=resp.status,
                        content_type=content_type,
                        body=body,
                        depth=depth,
                        headers=dict(resp.headers),
                        elapsed=time.monotonic() - start,
                        links=links,
                    )
            except asyncio.TimeoutError:
                last_error = "Timeout"
            except aiohttp.ClientError as e:
                last_error = str(e)
            except Exception as e:
                last_error = str(e)

            backoff = min(2 ** attempt * self.config.rate_limit, 30.0)
            await asyncio.sleep(backoff)

        return CrawlResult(
            url=url,
            status=0,
            content_type="",
            body="",
            depth=depth,
            headers={},
            elapsed=time.monotonic() - start,
            error=f"Failed after {self.config.retry_count} retries: {last_error}",
        )

    async def _crawl_url(self, url: str, depth: int) -> list[tuple[str, int]]:
        if self._page_count >= self.config.max_pages:
            return []

        normalized = self._normalize_url(url)
        if normalized in self._visited:
            return []
        self._visited.add(normalized)
        self._page_count += 1

        async with self._semaphore:
            logger.info("Crawling [depth=%d]: %s", depth, url)
            result = await self._fetch_page(url, depth)
            self._results.append(result)

            if self._on_page:
                self._on_page(result)

            next_urls = []
            if depth < self.config.max_depth and result.status == 200:
                for link in result.links:
                    link_domain = self._domain_of(link)
                    base_domain = self._domain_of(url)
                    if not self.config.follow_external and link_domain != base_domain:
                        continue
                    next_urls.append((link, depth + 1))
            return next_urls

    async def crawl(self, seed_urls: list[str]) -> list[CrawlResult]:
        self._session = aiohttp.ClientSession()
        try:
            queue: asyncio.Queue[tuple[str, int]] = asyncio.Queue()
            for url in seed_urls:
                await queue.put((url, 0))

            active_tasks = 0
            all_tasks: list[asyncio.Task] = []

            async def process_queue() -> None:
                nonlocal active_tasks
                while not queue.empty() or active_tasks > 0:
                    if self._page_count >= self.config.max_pages:
                        break
                    try:
                        url, depth = await asyncio.wait_for(queue.get(), timeout=1.0)
                    except asyncio.TimeoutError:
                        if active_tasks == 0:
                            break
                        continue

                    active_tasks += 1

                    async def crawl_and_enqueue(u: str, d: int) -> None:
                        nonlocal active_tasks
                        try:
                            next_urls = await self._crawl_url(u, d)
                            for nu, nd in next_urls:
                                if self._page_count < self.config.max_pages:
                                    await queue.put((nu, nd))
                        finally:
                            active_tasks -= 1

                    task = asyncio.create_task(crawl_and_enqueue(url, depth))
                    all_tasks.append(task)

            await process_queue()
            if all_tasks:
                await asyncio.gather(*all_tasks, return_exceptions=True)

            return list(self._results)
        finally:
            await self._session.close()  # type: ignore

    async def crawl_stream(self, seed_urls: list[str]) -> AsyncIterator[CrawlResult]:
        self._session = aiohttp.ClientSession()
        try:
            queue: asyncio.Queue[tuple[str, int]] = asyncio.Queue()
            for url in seed_urls:
                await queue.put((url, 0))

            while not queue.empty():
                if self._page_count >= self.config.max_pages:
                    break
                url, depth = await queue.get()
                results = await self._crawl_url(url, depth)
                for result in self._results[-1:]:
                    yield result
                for next_url, next_depth in results:
                    await queue.put((next_url, next_depth))
        finally:
            await self._session.close()  # type: ignore
