#Requires -Version 5.1
<#
.SYNOPSIS
    muLLM API Server Launcher (PowerShell)

.EXAMPLE
    .\serve.ps1 -Port 8000 -ModelPath "meta-llama/Llama-2-7b"
#>

[CmdletBinding()]
param(
    [string]$Host_ = $env:MULLM_SERVE_HOST,
    [int]$Port = if ($env:MULLM_SERVE_PORT) { [int]$env:MULLM_SERVE_PORT } else { 8000 },
    [int]$Workers = if ($env:MULLM_SERVE_WORKERS) { [int]$env:MULLM_SERVE_WORKERS } else { 1 },
    [string]$LogLevel = if ($env:MULLM_LOG_LEVEL) { $env:MULLM_LOG_LEVEL } else { "INFO" },
    [string]$LogFormat = if ($env:MULLM_LOG_FORMAT) { $env:MULLM_LOG_FORMAT } else { "plain" },
    [string]$LogFile = $env:MULLM_LOG_FILE,
    [string]$ModelPath = $env:MULLM_MODEL_PATH,
    [string]$ModelPrecision = if ($env:MULLM_MODEL_PRECISION) { $env:MULLM_MODEL_PRECISION } else { "fp16" },
    [string]$DeviceMap = if ($env:MULLM_DEVICE_MAP) { $env:MULLM_DEVICE_MAP } else { "auto" },
    [int]$MaxSeqLen = if ($env:MULLM_MAX_SEQ_LEN) { [int]$env:MULLM_MAX_SEQ_LEN } else { 4096 },
    [int]$MaxBatchSize = if ($env:MULLM_MAX_BATCH_SIZE) { [int]$env:MULLM_MAX_BATCH_SIZE } else { 64 },
    [string]$CorsOrigins = if ($env:MULLM_CORS_ORIGINS) { $env:MULLM_CORS_ORIGINS } else { "*" },
    [int]$RateLimitRpm = if ($env:MULLM_RATE_LIMIT_RPM) { [int]$env:MULLM_RATE_LIMIT_RPM } else { 60 },
    [string]$SslCertfile = $env:MULLM_SSL_CERTFILE,
    [string]$SslKeyfile = $env:MULLM_SSL_KEYFILE,
    [switch]$Reload
)

$ErrorActionPreference = "Stop"

if (-not $Host_) { $Host_ = "0.0.0.0" }

Write-Host "============================================" -ForegroundColor Cyan
Write-Host "  muLLM API Server" -ForegroundColor Cyan
Write-Host "============================================" -ForegroundColor Cyan
Write-Host "Host:           $Host_"
Write-Host "Port:           $Port"
Write-Host "Workers:        $Workers"
Write-Host "Log level:      $LogLevel"
Write-Host "Model path:     $(if ($ModelPath) { $ModelPath } else { '<not set>' })"
Write-Host "Precision:      $ModelPrecision"
Write-Host "Device map:     $DeviceMap"
Write-Host "Max seq len:    $MaxSeqLen"
Write-Host "Reload:         $Reload"
Write-Host "============================================" -ForegroundColor Cyan

$env:MULLM_SERVE_HOST = $Host_
$env:MULLM_SERVE_PORT = $Port.ToString()
$env:MULLM_SERVE_WORKERS = $Workers.ToString()

$args_ = @(
    "-m", "mullm.core.api.server",
    "--host", $Host_,
    "--port", $Port.ToString(),
    "--workers", $Workers.ToString(),
    "--log-level", $LogLevel,
    "--log-format", $LogFormat,
    "--model-precision", $ModelPrecision,
    "--device-map", $DeviceMap,
    "--max-seq-len", $MaxSeqLen.ToString(),
    "--max-batch-size", $MaxBatchSize.ToString(),
    "--cors-origins", $CorsOrigins,
    "--rate-limit-rpm", $RateLimitRpm.ToString()
)

if ($LogFile) { $args_ += "--log-file"; $args_ += $LogFile }
if ($ModelPath) { $args_ += "--model-path"; $args_ += $ModelPath }
if ($SslCertfile) { $args_ += "--ssl-certfile"; $args_ += $SslCertfile }
if ($SslKeyfile) { $args_ += "--ssl-keyfile"; $args_ += $SslKeyfile }
if ($Reload) { $args_ += "--reload" }

Write-Host "Starting server..." -ForegroundColor Green
& python @args_

if ($LASTEXITCODE -ne 0) {
    Write-Error "Server exited with code $LASTEXITCODE"
    exit $LASTEXITCODE
}
