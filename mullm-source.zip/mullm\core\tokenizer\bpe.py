import json
import os
import re
from collections import Counter, defaultdict
from typing import Dict, Iterator, List, Optional, Sequence, Set, Tuple

from .base import BaseTokenizer, SpecialTokens

try:
    import regex as _regex

    _has_regex = True
except ImportError:
    _has_regex = False

GPT2_SPLIT_PATTERN = (
    r"""(?i:'s|'t|'re|'ve|'m|'ll|'d)| ?\p{L}+| ?\p{N}+| ?[^\s\p{L}\p{N}]+|\s+(?!\S)|\s+"""
)
FALLBACK_SPLIT_PATTERN = r"""'(?:[sdmt]|ll|re|ve|m)| ?\w+| ?\S+"""

if _has_regex:
    _split_re = _regex.compile(GPT2_SPLIT_PATTERN)
else:
    _split_re = re.compile(FALLBACK_SPLIT_PATTERN)


def bytes_to_unicode() -> Dict[int, str]:
    bs = (
        list(range(ord("!"), ord("~") + 1))
        + list(range(ord("\xa1"), ord("\xac") + 1))
        + list(range(ord("\xae"), ord("\xff") + 1))
    )
    cs = bs[:]
    n = 0
    for b in range(256):
        if b not in bs:
            bs.append(b)
            cs.append(256 + n)
            n += 1
    return dict(zip(bs, [chr(c) for c in cs]))


_byte_encoder = bytes_to_unicode()
_byte_decoder = {v: k for k, v in _byte_encoder.items()}


def _pretokenize(text: str) -> List[str]:
    return _split_re.findall(text)


def _get_pairs(word: Tuple[str, ...]) -> Set[Tuple[str, str]]:
    pairs: Set[Tuple[str, str]] = set()
    prev_char = word[0]
    for char in word[1:]:
        pairs.add((prev_char, char))
        prev_char = char
    return pairs


class BPETokenizer(BaseTokenizer):
    def __init__(
        self,
        vocab: Optional[Dict[str, int]] = None,
        merges: Optional[List[Tuple[str, str]]] = None,
        special_tokens: Optional[SpecialTokens] = None,
    ) -> None:
        super().__init__(special_tokens)
        self._vocab: Dict[str, int] = {}
        self._decoder: Dict[int, str] = {}
        self._merges: Dict[Tuple[str, str], str] = {}
        self._merges_list: List[Tuple[str, str]] = []
        self._cache: Dict[str, str] = {}
        self._unk_token = (special_tokens or SpecialTokens()).unk_token or "<unk>"

        if vocab is not None:
            self._vocab = dict(vocab)
            self._decoder = {v: k for k, v in self._vocab.items()}
        if merges is not None:
            self._merges_list = list(merges)
            self._merges = {m: m[0] + m[1] for m in merges}

        for st in self._special_tokens.all_special_tokens:
            if st not in self._vocab:
                idx = len(self._vocab) + len(self._added_tokens)
                self._added_tokens[st] = idx
                self._added_tokens_decoder[idx] = st

    @property
    def vocab_size(self) -> int:
        return len(self._vocab) + len(self._added_tokens)

    @property
    def merges(self) -> List[Tuple[str, str]]:
        return list(self._merges_list)

    def _token_to_id(self, token: str) -> int:
        if token in self._added_tokens:
            return self._added_tokens[token]
        if token in self._vocab:
            return self._vocab[token]
        return self._vocab.get(self._unk_token, len(self._vocab))

    def _id_to_token(self, idx: int) -> str:
        if idx in self._added_tokens_decoder:
            return self._added_tokens_decoder[idx]
        return self._decoder.get(idx, self._unk_token)

    def _get_vocab(self) -> Dict[str, int]:
        full = dict(self._vocab)
        full.update(self._added_tokens)
        return full

    def _set_vocab(self, vocab: Dict[str, int]) -> None:
        added = {k: v for k, v in vocab.items() if k in self._added_tokens or k in self._special_tokens.all_special_tokens}
        base = {k: v for k, v in vocab.items() if k not in added}
        self._vocab = base
        self._decoder = {v: k for k, v in self._vocab.items()}
        self._added_tokens = added
        self._added_tokens_decoder = {v: k for k, v in added.items()}

    def _bpe(self, token: str) -> str:
        if token in self._cache:
            return self._cache[token]

        word = tuple(token)

        while True:
            pairs = _get_pairs(word)
            if not pairs:
                break

            best_pair: Optional[Tuple[str, str]] = None
            best_rank = len(self._merges_list)
            for pair in pairs:
                rank = self._merges_list.index(pair) if pair in self._merges else len(self._merges_list)
                if rank < best_rank:
                    best_rank = rank
                    best_pair = pair

            if best_pair is None or best_pair not in self._merges:
                break

            first, second = best_pair
            new_word: List[str] = []
            i = 0
            while i < len(word):
                if (
                    i < len(word) - 1
                    and word[i] == first
                    and word[i + 1] == second
                ):
                    new_word.append(first + second)
                    i += 2
                else:
                    new_word.append(word[i])
                    i += 1
            word = tuple(new_word)
            if len(word) == 1:
                break

        result = " ".join(word)
        self._cache[token] = result
        return result

    def encode(self, text: str, add_special_tokens: bool = True) -> List[int]:
        tokens: List[int] = []
        if add_special_tokens:
            bos = self.bos_token_id()
            if bos is not None:
                tokens.append(bos)

        for raw_token in _pretokenize(text):
            encoded = bytearray(raw_token.encode("utf-8"))
            bpe_str = "".join([_byte_encoder[b] for b in encoded])
            bpe_subwords = self._bpe(bpe_str).split(" ")
            for subword in bpe_subwords:
                token_id = self._token_to_id(subword)
                tokens.append(token_id)

        if add_special_tokens:
            eos = self.eos_token_id()
            if eos is not None:
                tokens.append(eos)

        return tokens

    def decode(self, ids: Sequence[int], skip_special_tokens: bool = True) -> str:
        special_ids = set(self.all_special_ids()) if skip_special_tokens else set()
        byte_chunks: List[int] = []
        for idx in ids:
            if idx in special_ids:
                continue
            if idx in self._added_tokens_decoder:
                token = self._added_tokens_decoder[idx]
                byte_chunks.extend(token.encode("utf-8"))
                continue
            token = self._decoder.get(idx, self._unk_token)
            for ch in token:
                byte_chunks.append(_byte_decoder.get(ch, ord(ch)))
        return bytearray(byte_chunks).decode("utf-8", errors="replace")

    def _build_word_frequencies(self, texts: Iterator[str]) -> Counter[str]:
        freq: Counter[str] = Counter()
        for text in texts:
            for token in _pretokenize(text):
                encoded = bytearray(token.encode("utf-8"))
                bpe_str = "".join([_byte_encoder[b] for b in encoded])
                freq[bpe_str] += 1
        return freq

    def train_from_iterator(
        self,
        texts: Iterator[str],
        vocab_size: int,
        show_progress: bool = True,
    ) -> None:
        self._vocab = {}
        self._decoder = {}
        self._merges = {}
        self._merges_list = []
        self._cache = {}
        self._added_tokens = {}
        self._added_tokens_decoder = {}

        word_freqs = self._build_word_frequencies(texts)

        base_vocab: Set[str] = set()
        for word in word_freqs:
            for char in word:
                base_vocab.add(char)
        sorted_vocab = sorted(base_vocab)
        self._vocab = {ch: i for i, ch in enumerate(sorted_vocab)}
        self._decoder = {v: k for k, v in self._vocab.items()}

        if self._special_tokens.unk_token is not None and self._special_tokens.unk_token not in self._vocab:
            idx = len(self._vocab)
            self._vocab[self._special_tokens.unk_token] = idx
            self._decoder[idx] = self._special_tokens.unk_token

        symbols = {word: list(word) for word in word_freqs}

        num_merges = vocab_size - len(self._vocab)
        if num_merges <= 0:
            return

        if show_progress:
            try:
                from tqdm import tqdm

                iterator = tqdm(range(num_merges), desc="Training BPE merges")
            except ImportError:
                iterator = range(num_merges)
        else:
            iterator = range(num_merges)

        for _ in iterator:
            pair_freqs: Counter[Tuple[str, str]] = Counter()
            for word, splits in symbols.items():
                freq = word_freqs[word]
                for i in range(len(splits) - 1):
                    pair_freqs[(splits[i], splits[i + 1])] += freq

            if not pair_freqs:
                break

            most_frequent = pair_freqs.most_common(1)[0][0]
            merged_token = most_frequent[0] + most_frequent[1]

            self._merges[most_frequent] = merged_token
            self._merges_list.append(most_frequent)
            self._vocab[merged_token] = len(self._vocab)
            self._decoder[self._vocab[merged_token]] = merged_token

            for word in symbols:
                splits = symbols[word]
                new_splits: List[str] = []
                i = 0
                while i < len(splits):
                    if i < len(splits) - 1 and (splits[i], splits[i + 1]) == most_frequent:
                        new_splits.append(merged_token)
                        i += 2
                    else:
                        new_splits.append(splits[i])
                        i += 1
                symbols[word] = new_splits

                if len(new_splits) == 1 and len(word) > 1:
                    self._cache[word] = word

    def save(self, path: str) -> None:
        os.makedirs(os.path.dirname(path) if os.path.dirname(path) else ".", exist_ok=True)
        data = {
            "vocab": self._vocab,
            "merges": self._merges_list,
            "special_tokens": self._special_tokens.to_dict(),
            "added_tokens": self._added_tokens,
        }
        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)

    @classmethod
    def load(cls, path: str) -> "BPETokenizer":
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        special_tokens = SpecialTokens.from_dict(data.get("special_tokens", {}))
        return cls(
            vocab=data.get("vocab"),
            merges=data.get("merges"),
            special_tokens=special_tokens,
        )

    def save_vocab_as_merges(self, path: str) -> None:
        with open(path, "w", encoding="utf-8") as f:
            f.write("#version: 0.2\n")
            for merge in self._merges_list:
                f.write(f"{merge[0]} {merge[1]}\n")

    @classmethod
    def from_merges_file(
        cls, merges_path: str, vocab_path: str, special_tokens: Optional[SpecialTokens] = None
    ) -> "BPETokenizer":
        vocab: Dict[str, int] = {}
        with open(vocab_path, "r", encoding="utf-8") as f:
            vocab_data = json.load(f)
            if isinstance(vocab_data, dict):
                vocab = vocab_data
            elif isinstance(vocab_data, list):
                vocab = {t: i for i, t in enumerate(vocab_data)}

        merges: List[Tuple[str, str]] = []
        with open(merges_path, "r", encoding="utf-8") as f:
            for line in f:
                if line.startswith("#"):
                    continue
                parts = line.strip().split()
                if len(parts) == 2:
                    merges.append((parts[0], parts[1]))

        return cls(vocab=vocab, merges=merges, special_tokens=special_tokens)
