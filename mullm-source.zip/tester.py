from mullm.core.tokenizer.bpe import BPETokenizer
def train_tokenizer_from_file(path, vocab_size=5000):
    with open(path, "r", encoding="utf-8") as f:
        lines = (line.strip() for line in f if
                 line.strip())
        tok = BPETokenizer()
        tok.train_from_iterator(lines, vocab_size=vocab_size, show_progress=True)
        tok.save("tokenizer.json")
    return tok
