from typing import Optional, Tuple, List, Dict, Any, Union

import torch
import torch.nn as nn

from .attention import (
    MultiHeadAttention,
    MultiQueryAttention,
    GroupedQueryAttention,
    FlashAttentionWrapper,
    SlidingWindowAttention,
    SparseAttention,
    KVCache,
    ATTENTION_MAP,
)
from .normalization import LayerNorm, RMSNorm, PreNorm
from .feedforward import FeedForward, GatedFeedForward, MoEFeedForward
from .positional import RotaryPositionalEmbedding
from .activation import get_activation


class TransformerDecoderLayer(nn.Module):
    def __init__(
        self,
        hidden_size: int,
        num_attention_heads: int,
        intermediate_size: int,
        num_kv_heads: Optional[int] = None,
        attention_type: str = "grouped_query",
        activation: str = "silu",
        layer_norm_eps: float = 1e-5,
        dropout: float = 0.0,
        attention_dropout: float = 0.0,
        use_bias: bool = False,
        use_cache: bool = False,
        layer_id: Optional[str] = None,
        sliding_window: Optional[int] = None,
        rope_theta: float = 10000.0,
        max_position_embeddings: int = 2048,
        num_experts: Optional[int] = None,
        num_experts_per_tok: Optional[int] = None,
        expert_intermediate_size: Optional[int] = None,
        use_cross_attention: bool = False,
        ffn_type: str = "gated",
        rotary_emb: Optional[nn.Module] = None,
    ):
        super().__init__()
        self.hidden_size = hidden_size
        self.use_cross_attention = use_cross_attention

        attn_kwargs = dict(
            hidden_size=hidden_size,
            num_heads=num_attention_heads,
            num_kv_heads=num_kv_heads or num_attention_heads,
            dropout=attention_dropout,
            bias=use_bias,
            use_cache=use_cache,
            layer_id=layer_id,
            rotary_emb=rotary_emb,
        )
        if attention_type == "sliding_window":
            attn_kwargs["window_size"] = sliding_window or 4096
        elif attention_type == "flash":
            attn_kwargs["sliding_window"] = sliding_window
        elif attention_type == "sparse":
            attn_kwargs["block_size"] = 64

        self.self_attn = ATTENTION_MAP.get(attention_type, GroupedQueryAttention)(**attn_kwargs)

        if use_cross_attention:
            cross_attn_kwargs = dict(
                hidden_size=hidden_size,
                num_heads=num_attention_heads,
                num_kv_heads=num_kv_heads or num_attention_heads,
                dropout=attention_dropout,
                bias=use_bias,
                use_cache=use_cache,
                layer_id=f"{layer_id}_cross" if layer_id else None,
                rotary_emb=None,
            )
            self.cross_attn = ATTENTION_MAP.get(attention_type, GroupedQueryAttention)(**cross_attn_kwargs)
            self.cross_attn_norm = RMSNorm(hidden_size, eps=layer_norm_eps)

        if num_experts and num_experts > 1:
            self.feed_forward = MoEFeedForward(
                hidden_size=hidden_size,
                intermediate_size=expert_intermediate_size or intermediate_size,
                num_experts=num_experts,
                num_experts_per_tok=num_experts_per_tok or 2,
                activation=activation,
                bias=use_bias,
                dropout=dropout,
                noisy_gating=True,
            )
        elif ffn_type == "gated":
            self.feed_forward = GatedFeedForward(
                hidden_size=hidden_size,
                intermediate_size=intermediate_size,
                activation=activation,
                bias=use_bias,
                dropout=dropout,
            )
        else:
            self.feed_forward = FeedForward(
                hidden_size=hidden_size,
                intermediate_size=intermediate_size,
                activation=activation,
                bias=use_bias,
                dropout=dropout,
            )

        self.self_attn_norm = RMSNorm(hidden_size, eps=layer_norm_eps)
        self.ffn_norm = RMSNorm(hidden_size, eps=layer_norm_eps)

        self.dropout = nn.Dropout(dropout)

    def forward(
        self,
        hidden_states: torch.Tensor,
        attention_mask: Optional[torch.Tensor] = None,
        encoder_hidden_states: Optional[torch.Tensor] = None,
        encoder_attention_mask: Optional[torch.Tensor] = None,
        past_key_value: Optional[KVCache] = None,
        position_ids: Optional[torch.Tensor] = None,
        use_cache: Optional[bool] = None,
        output_attentions: bool = False,
        output_aux_loss: bool = False,
    ) -> Tuple[torch.Tensor, Optional[torch.Tensor], Optional[KVCache], Optional[torch.Tensor]]:
        residual = hidden_states
        hidden_states = self.self_attn_norm(hidden_states)
        hidden_states, self_attn_weights, past_key_value = self.self_attn(
            hidden_states=hidden_states,
            attention_mask=attention_mask,
            past_key_value=past_key_value,
            position_ids=position_ids,
            use_cache=use_cache,
            output_attentions=output_attentions,
        )
        hidden_states = self.dropout(hidden_states)
        hidden_states = residual + hidden_states

        if self.use_cross_attention and encoder_hidden_states is not None:
            residual = hidden_states
            hidden_states = self.cross_attn_norm(hidden_states)
            hidden_states, cross_attn_weights, _ = self.cross_attn(
                hidden_states=hidden_states,
                attention_mask=encoder_attention_mask,
                past_key_value=None,
                position_ids=None,
                use_cache=False,
                output_attentions=output_attentions,
            )
            hidden_states = self.dropout(hidden_states)
            hidden_states = residual + hidden_states

        residual = hidden_states
        hidden_states = self.ffn_norm(hidden_states)
        if isinstance(self.feed_forward, MoEFeedForward):
            ffn_output, aux_loss = self.feed_forward(hidden_states, output_aux_loss=output_aux_loss)
        else:
            ffn_output = self.feed_forward(hidden_states)
            aux_loss = None
        hidden_states = residual + self.dropout(ffn_output)

        return hidden_states, self_attn_weights, past_key_value, aux_loss


class ParallelTransformerBlock(nn.Module):
    def __init__(
        self,
        hidden_size: int,
        num_attention_heads: int,
        intermediate_size: int,
        num_kv_heads: Optional[int] = None,
        attention_type: str = "grouped_query",
        activation: str = "silu",
        layer_norm_eps: float = 1e-5,
        dropout: float = 0.0,
        attention_dropout: float = 0.0,
        use_bias: bool = False,
        use_cache: bool = False,
        layer_id: Optional[str] = None,
        sliding_window: Optional[int] = None,
        rope_theta: float = 10000.0,
        max_position_embeddings: int = 2048,
        ffn_type: str = "gated",
        rotary_emb: Optional[nn.Module] = None,
    ):
        super().__init__()
        attn_kwargs = dict(
            hidden_size=hidden_size,
            num_heads=num_attention_heads,
            num_kv_heads=num_kv_heads or num_attention_heads,
            dropout=attention_dropout,
            bias=use_bias,
            use_cache=use_cache,
            layer_id=layer_id,
            rotary_emb=rotary_emb,
        )
        if attention_type == "sliding_window":
            attn_kwargs["window_size"] = sliding_window or 4096
        elif attention_type == "flash":
            attn_kwargs["sliding_window"] = sliding_window

        self.self_attn = ATTENTION_MAP.get(attention_type, GroupedQueryAttention)(**attn_kwargs)

        if ffn_type == "gated":
            self.feed_forward = GatedFeedForward(
                hidden_size=hidden_size,
                intermediate_size=intermediate_size,
                activation=activation,
                bias=use_bias,
                dropout=dropout,
            )
        else:
            self.feed_forward = FeedForward(
                hidden_size=hidden_size,
                intermediate_size=intermediate_size,
                activation=activation,
                bias=use_bias,
                dropout=dropout,
            )

        self.norm = RMSNorm(hidden_size, eps=layer_norm_eps)
        self.dropout = nn.Dropout(dropout)

    def forward(
        self,
        hidden_states: torch.Tensor,
        attention_mask: Optional[torch.Tensor] = None,
        past_key_value: Optional[KVCache] = None,
        position_ids: Optional[torch.Tensor] = None,
        use_cache: Optional[bool] = None,
        output_attentions: bool = False,
    ) -> Tuple[torch.Tensor, Optional[torch.Tensor], Optional[KVCache]]:
        residual = hidden_states
        hidden_states = self.norm(hidden_states)

        attn_out, attn_weights, past_key_value = self.self_attn(
            hidden_states=hidden_states,
            attention_mask=attention_mask,
            past_key_value=past_key_value,
            position_ids=position_ids,
            use_cache=use_cache,
            output_attentions=output_attentions,
        )

        ffn_out = self.feed_forward(hidden_states)

        hidden_states = residual + self.dropout(attn_out) + self.dropout(ffn_out)

        return hidden_states, attn_weights, past_key_value


class TransformerDecoder(nn.Module):
    def __init__(
        self,
        vocab_size: int,
        hidden_size: int,
        num_hidden_layers: int,
        num_attention_heads: int,
        intermediate_size: int,
        num_kv_heads: Optional[int] = None,
        max_position_embeddings: int = 2048,
        attention_type: str = "grouped_query",
        activation: str = "silu",
        layer_norm_eps: float = 1e-5,
        dropout: float = 0.0,
        attention_dropout: float = 0.0,
        use_bias: bool = False,
        use_cache: bool = True,
        tie_word_embeddings: bool = False,
        sliding_window: Optional[int] = None,
        rope_theta: float = 10000.0,
        rope_scaling: Optional[Dict[str, Any]] = None,
        num_experts: Optional[int] = None,
        num_experts_per_tok: Optional[int] = None,
        expert_intermediate_size: Optional[int] = None,
        output_hidden_states: bool = False,
        output_attentions: bool = False,
        parallel_attention_ffn: bool = False,
        ffn_type: str = "gated",
        use_rotary: bool = True,
    ):
        super().__init__()
        self.vocab_size = vocab_size
        self.hidden_size = hidden_size
        self.num_hidden_layers = num_hidden_layers
        self.output_hidden_states = output_hidden_states
        self.output_attentions = output_attentions
        self.use_cache = use_cache

        self.embed_tokens = nn.Embedding(vocab_size, hidden_size)
        self.dropout = nn.Dropout(dropout)

        rope_dim = hidden_size // num_attention_heads
        self.rotary_emb = (
            RotaryPositionalEmbedding(
                dim=rope_dim,
                max_position_embeddings=max_position_embeddings,
                base=rope_theta,
            ) if use_rotary else None
        )

        block_class = ParallelTransformerBlock if parallel_attention_ffn else TransformerDecoderLayer

        self.layers = nn.ModuleList([
            block_class(
                hidden_size=hidden_size,
                num_attention_heads=num_attention_heads,
                intermediate_size=intermediate_size,
                num_kv_heads=num_kv_heads,
                attention_type=attention_type,
                activation=activation,
                layer_norm_eps=layer_norm_eps,
                dropout=dropout,
                attention_dropout=attention_dropout,
                use_bias=use_bias,
                use_cache=use_cache,
                layer_id=str(i),
                sliding_window=sliding_window,
                rope_theta=rope_theta,
                max_position_embeddings=max_position_embeddings,
                num_experts=num_experts,
                num_experts_per_tok=num_experts_per_tok,
                expert_intermediate_size=expert_intermediate_size,
                ffn_type=ffn_type,
                rotary_emb=self.rotary_emb,
            )
            for i in range(num_hidden_layers)
        ])

        self.final_norm = RMSNorm(hidden_size, eps=layer_norm_eps)

        self.lm_head = nn.Linear(hidden_size, vocab_size, bias=False)
        if tie_word_embeddings:
            self.lm_head.weight = self.embed_tokens.weight

    def forward(
        self,
        input_ids: torch.Tensor,
        attention_mask: Optional[torch.Tensor] = None,
        past_key_values: Optional[KVCache] = None,
        position_ids: Optional[torch.Tensor] = None,
        use_cache: Optional[bool] = None,
        output_hidden_states: Optional[bool] = None,
        output_attentions: Optional[bool] = None,
    ) -> Dict[str, Any]:
        use_cache = self.use_cache if use_cache is None else use_cache
        output_hidden_states = self.output_hidden_states if output_hidden_states is None else output_hidden_states
        output_attentions = self.output_attentions if output_attentions is None else output_attentions

        hidden_states = self.embed_tokens(input_ids)
        hidden_states = self.dropout(hidden_states)

        all_hidden_states = [hidden_states] if output_hidden_states else None
        all_self_attns = [] if output_attentions else None
        total_aux_loss = torch.tensor(0.0, device=hidden_states.device, dtype=torch.float32)

        for i, layer in enumerate(self.layers):
            hidden_states, self_attn_weights, past_key_values, aux_loss = layer(
                hidden_states=hidden_states,
                attention_mask=attention_mask,
                past_key_value=past_key_values,
                position_ids=position_ids,
                use_cache=use_cache,
                output_attentions=output_attentions,
                output_aux_loss=True,
            )

            if aux_loss is not None:
                total_aux_loss = total_aux_loss + aux_loss

            if output_hidden_states:
                all_hidden_states.append(hidden_states)
            if output_attentions and self_attn_weights is not None:
                all_self_attns.append(self_attn_weights)

        hidden_states = self.final_norm(hidden_states)
        logits = self.lm_head(hidden_states)

        return {
            "logits": logits,
            "hidden_states": all_hidden_states if output_hidden_states else None,
            "attentions": all_self_attns if output_attentions else None,
            "past_key_values": past_key_values,
            "aux_loss": total_aux_loss,
        }
