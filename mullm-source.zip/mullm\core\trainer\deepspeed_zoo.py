from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

import torch

from mullm.core.trainer.training_config import (
    ActivationCheckpointingType,
    DeepSpeedZeroConfig,
    OffloadDevice,
    PrecisionType,
)


def _build_zero_config(
    stage: int,
    offload_optimizer: bool = False,
    offload_optimizer_device: str = "cpu",
    offload_optimizer_pin_memory: bool = False,
    offload_optimizer_fast_init: bool = False,
    offload_param: bool = False,
    offload_param_device: str = "cpu",
    offload_param_pin_memory: bool = False,
    contiguous_gradients: bool = True,
    overlap_comm: bool = True,
    allgather_bucket_size: int = 500_000_000,
    reduce_bucket_size: int = 500_000_000,
    reduce_scatter: bool = True,
    allgather_partitions: bool = True,
    round_robin_gradients: bool = False,
    zero_hpz_partition_size: int = 1,
    zero_quantized_weights: bool = False,
    zero_quantized_nontrainable_weights: bool = False,
    nvme_path: Optional[str] = None,
) -> Dict[str, Any]:
    zero_cfg: Dict[str, Any] = {
        "stage": stage,
        "contiguous_gradients": contiguous_gradients,
        "overlap_comm": overlap_comm,
        "allgather_bucket_size": allgather_bucket_size,
        "reduce_bucket_size": reduce_bucket_size,
        "allgather_partitions": allgather_partitions,
        "round_robin_gradients": round_robin_gradients,
    }

    if stage >= 3:
        zero_cfg["reduce_scatter"] = reduce_scatter
        zero_cfg["zero_hpz_partition_size"] = zero_hpz_partition_size
        zero_cfg["zero_quantized_weights"] = zero_quantized_weights
        zero_cfg["zero_quantized_nontrainable_weights"] = zero_quantized_nontrainable_weights

    if offload_optimizer:
        offload_opt: Dict[str, Any] = {"device": offload_optimizer_device}
        if offload_optimizer_device == "nvme" and nvme_path:
            offload_opt["nvme_path"] = nvme_path
        offload_opt["pin_memory"] = offload_optimizer_pin_memory
        offload_opt["fast_init"] = offload_optimizer_fast_init
        zero_cfg["offload_optimizer"] = offload_opt

    if offload_param:
        offload_p: Dict[str, Any] = {"device": offload_param_device}
        if offload_param_device == "nvme" and nvme_path:
            offload_p["nvme_path"] = nvme_path
        offload_p["pin_memory"] = offload_param_pin_memory
        zero_cfg["offload_param"] = offload_p

    return zero_cfg


def build_deepspeed_config(
    config: DeepSpeedZeroConfig,
    train_batch_size: Optional[int] = None,
    train_micro_batch_size_per_gpu: Optional[int] = None,
    gradient_accumulation_steps: int = 1,
    gradient_clipping: float = 1.0,
    optimizer_config: Optional[Dict[str, Any]] = None,
    scheduler_config: Optional[Dict[str, Any]] = None,
    fp16_enabled: bool = False,
    bf16_enabled: bool = False,
) -> Dict[str, Any]:
    ds_config: Dict[str, Any] = {
        "train_batch_size": train_batch_size,
        "train_micro_batch_size_per_gpu": train_micro_batch_size_per_gpu,
        "gradient_accumulation_steps": gradient_accumulation_steps,
        "gradient_clipping": gradient_clipping,
        "zero_optimization": _build_zero_config(
            stage=config.stage,
            offload_optimizer=config.offload_optimizer,
            offload_optimizer_device=config.offload_optimizer_device.value,
            offload_optimizer_pin_memory=config.offload_optimizer_pin_memory,
            offload_optimizer_fast_init=config.offload_optimizer_fast_init,
            offload_param=config.offload_param,
            offload_param_device=config.offload_param_device.value,
            offload_param_pin_memory=config.offload_param_pin_memory,
            contiguous_gradients=config.contiguous_gradients,
            overlap_comm=config.overlap_comm,
            allgather_bucket_size=config.allgather_bucket_size,
            reduce_bucket_size=config.reduce_bucket_size,
            reduce_scatter=config.reduce_scatter,
            allgather_partitions=config.allgather_partitions,
            round_robin_gradients=config.round_robin_gradients,
            zero_hpz_partition_size=config.zero_hpz_partition_size,
            zero_quantized_weights=config.zero_quantized_weights,
            zero_quantized_nontrainable_weights=config.zero_quantized_nontrainable_weights,
            nvme_path=config.nvme_path,
        ),
    }

    if optimizer_config is not None:
        ds_config["optimizer"] = optimizer_config

    if scheduler_config is not None:
        ds_config["scheduler"] = scheduler_config

    if fp16_enabled:
        ds_config["fp16"] = {
            "enabled": True,
            "auto_cast": True,
            "loss_scale": 0,
            "initial_scale_power": 16,
            "loss_scale_window": 1000,
            "hysteresis": 2,
            "min_loss_scale": 1,
        }

    if bf16_enabled:
        ds_config["bf16"] = {"enabled": True}

    if config.communication_data_type is not None:
        ds_config["communication_data_type"] = config.communication_data_type.value

    if config.gradient_predivide_factor != 1.0:
        ds_config["gradient_predivide_factor"] = config.gradient_predivide_factor

    if config.activation_checkpointing != ActivationCheckpointingType.none:
        ds_config["activation_checkpointing"] = {
            "partition_activations": config.activation_checkpointing == ActivationCheckpointingType.full,
            "cpu_checkpointing": False,
            "number_checkpoints": config.activation_checkpointing_interval or 1,
            "synchronize_checkpoint_boundary": False,
            "profile": False,
        }

    return ds_config


def create_zero1_config(
    offload_optimizer: bool = False,
    offload_device: str = "cpu",
) -> Dict[str, Any]:
    return _build_zero_config(
        stage=1,
        offload_optimizer=offload_optimizer,
        offload_optimizer_device=offload_device,
    )


def create_zero2_config(
    offload_optimizer: bool = True,
    offload_device: str = "cpu",
    overlap_comm: bool = True,
    contiguous_gradients: bool = True,
) -> Dict[str, Any]:
    return _build_zero_config(
        stage=2,
        offload_optimizer=offload_optimizer,
        offload_optimizer_device=offload_device,
        overlap_comm=overlap_comm,
        contiguous_gradients=contiguous_gradients,
    )


def create_zero3_config(
    offload_optimizer: bool = True,
    offload_param: bool = False,
    offload_device: str = "cpu",
    overlap_comm: bool = True,
    contiguous_gradients: bool = True,
    reduce_scatter: bool = True,
    nvme_path: Optional[str] = None,
) -> Dict[str, Any]:
    return _build_zero_config(
        stage=3,
        offload_optimizer=offload_optimizer,
        offload_optimizer_device=offload_device,
        offload_param=offload_param,
        offload_param_device=offload_device,
        overlap_comm=overlap_comm,
        contiguous_gradients=contiguous_gradients,
        reduce_scatter=reduce_scatter,
        nvme_path=nvme_path,
    )


def create_adam_optimizer_config(
    lr: float = 1e-4,
    betas: List[float] = None,
    eps: float = 1e-8,
    weight_decay: float = 0.01,
) -> Dict[str, Any]:
    if betas is None:
        betas = [0.9, 0.999]
    return {
        "type": "Adam",
        "params": {
            "lr": lr,
            "betas": betas,
            "eps": eps,
            "weight_decay": weight_decay,
        },
    }


def create_adamw_optimizer_config(
    lr: float = 1e-4,
    betas: List[float] = None,
    eps: float = 1e-8,
    weight_decay: float = 0.01,
) -> Dict[str, Any]:
    if betas is None:
        betas = [0.9, 0.999]
    return {
        "type": "AdamW",
        "params": {
            "lr": lr,
            "betas": betas,
            "eps": eps,
            "weight_decay": weight_decay,
        },
    }


def create_lion_optimizer_config(
    lr: float = 1e-4,
    betas: List[float] = None,
    weight_decay: float = 0.0,
) -> Dict[str, Any]:
    if betas is None:
        betas = [0.9, 0.99]
    return {
        "type": "Lion",
        "params": {
            "lr": lr,
            "betas": betas,
            "weight_decay": weight_decay,
        },
    }


def create_warmup_cosine_scheduler_config(
    warmup_steps: int = 0,
    total_steps: int = 100000,
    min_lr: float = 0.0,
) -> Dict[str, Any]:
    return {
        "type": "WarmupCosineLR",
        "params": {
            "warmup_min_lr": 0.0,
            "warmup_max_lr": 1.0,
            "warmup_num_steps": warmup_steps,
            "total_num_steps": total_steps,
        },
    }


def create_warmup_linear_scheduler_config(
    warmup_steps: int = 0,
    total_steps: int = 100000,
) -> Dict[str, Any]:
    return {
        "type": "WarmupDecayLR",
        "params": {
            "warmup_min_lr": 0.0,
            "warmup_max_lr": 1.0,
            "warmup_num_steps": warmup_steps,
            "total_num_steps": total_steps,
        },
    }


def create_warmup_constant_scheduler_config(
    warmup_steps: int = 0,
) -> Dict[str, Any]:
    return {
        "type": "WarmupLR",
        "params": {
            "warmup_min_lr": 0.0,
            "warmup_max_lr": 1.0,
            "warmup_num_steps": warmup_steps,
        },
    }


def create_activation_checkpointing_config(
    partition_activations: bool = True,
    cpu_checkpointing: bool = False,
    number_checkpoints: int = 1,
    synchronize_checkpoint_boundary: bool = False,
    profile: bool = False,
) -> Dict[str, Any]:
    return {
        "partition_activations": partition_activations,
        "cpu_checkpointing": cpu_checkpointing,
        "number_checkpoints": number_checkpoints,
        "synchronize_checkpoint_boundary": synchronize_checkpoint_boundary,
        "profile": profile,
    }


def deepspeed_available() -> bool:
    try:
        import deepspeed  # noqa: F401

        return True
    except ImportError:
        return False
