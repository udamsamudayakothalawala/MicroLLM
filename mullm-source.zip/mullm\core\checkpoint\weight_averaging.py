from __future__ import annotations

import copy
import logging
import math
import random
from abc import ABC, abstractmethod
from collections import OrderedDict
from typing import Any, Dict, Iterator, List, Optional, Tuple, Union

import torch
import torch.nn as nn
from torch.optim.optimizer import Optimizer

logger = logging.getLogger(__name__)


class WeightAverager(ABC):
    @abstractmethod
    def update(self, model: nn.Module, **kwargs: Any) -> None:
        ...

    @abstractmethod
    def get_averaged_model(self) -> nn.Module:
        ...

    @abstractmethod
    def state_dict(self) -> Dict[str, Any]:
        ...

    @abstractmethod
    def load_state_dict(self, state_dict: Dict[str, Any]) -> None:
        ...


class EMAWeightAverager(WeightAverager):
    def __init__(
        self,
        model: nn.Module,
        decay: float = 0.999,
        warmup_steps: int = 0,
        use_weighting: bool = False,
    ) -> None:
        self.decay = decay
        self.warmup_steps = warmup_steps
        self.use_weighting = use_weighting
        self.step = 0
        self.shadow: Dict[str, torch.Tensor] = {}
        self.backup: Dict[str, torch.Tensor] = {}
        for name, param in model.named_parameters():
            if param.requires_grad:
                self.shadow[name] = param.data.clone()
        self.num_params = sum(p.numel() for p in model.parameters() if p.requires_grad)

    def _get_decay(self) -> float:
        if self.step < self.warmup_steps:
            return min(self.decay, (1 + self.step) / (10 + self.step))
        return self.decay

    def update(self, model: nn.Module, **kwargs: Any) -> None:
        self.step += 1
        decay = self._get_decay()
        model_params = dict(model.named_parameters())
        for name in self.shadow:
            if name in model_params:
                if self.use_weighting:
                    param_norm = model_params[name].data.norm()
                    shadow_norm = self.shadow[name].norm()
                    adaptive_decay = min(decay, (shadow_norm + 1e-8) / (param_norm + 1e-8))
                    self.shadow[name].mul_(adaptive_decay).add_(
                        model_params[name].data, alpha=1.0 - adaptive_decay
                    )
                else:
                    self.shadow[name].mul_(decay).add_(
                        model_params[name].data, alpha=1.0 - decay
                    )

    def get_averaged_model(self) -> nn.Module:
        avg_params = self.shadow
        averaged = copy.deepcopy(avg_params)
        return averaged

    def apply_shadow(self, model: nn.Module) -> None:
        self.backup = {}
        for name, param in model.named_parameters():
            if name in self.shadow:
                self.backup[name] = param.data.clone()
                param.data.copy_(self.shadow[name])

    def restore(self, model: nn.Module) -> None:
        for name, param in model.named_parameters():
            if name in self.backup:
                param.data.copy_(self.backup[name])
        self.backup = {}

    def state_dict(self) -> Dict[str, Any]:
        return {
            "decay": self.decay,
            "warmup_steps": self.warmup_steps,
            "use_weighting": self.use_weighting,
            "step": self.step,
            "shadow": self.shadow,
            "num_params": self.num_params,
        }

    def load_state_dict(self, state_dict: Dict[str, Any]) -> None:
        self.decay = state_dict["decay"]
        self.warmup_steps = state_dict["warmup_steps"]
        self.use_weighting = state_dict.get("use_weighting", False)
        self.step = state_dict["step"]
        self.shadow = state_dict["shadow"]
        self.num_params = state_dict.get("num_params", 0)


class SWAWeightAverager(WeightAverager):
    def __init__(
        self,
        optimizer: Optimizer,
        swa_start: int = 0,
        swa_freq: int = 1,
        swa_lr: float = 0.005,
    ) -> None:
        self.optimizer = optimizer
        self.swa_start = swa_start
        self.swa_freq = swa_freq
        self.swa_lr = swa_lr
        self.step_count = 0
        self.swa_n: int = 0
        self.swa_params: Optional[Dict[str, torch.Tensor]] = None

    def update(self, model: nn.Module, **kwargs: Any) -> None:
        self.step_count += 1
        if self.step_count < self.swa_start:
            return
        if (self.step_count - self.swa_start) % self.swa_freq != 0:
            return
        if self.swa_params is None:
            self.swa_params = {}
            for name, param in model.named_parameters():
                self.swa_params[name] = param.data.clone()
            self.swa_n = 1
        else:
            self.swa_n += 1
            for name, param in model.named_parameters():
                if name in self.swa_params:
                    self.swa_params[name].add_(
                        param.data - self.swa_params[name], alpha=1.0 / self.swa_n
                    )

    def update_bn(
        self,
        model: nn.Module,
        loader: Any,
        device: Optional[torch.device] = None,
    ) -> nn.Module:
        model.train()
        batch_norms: List[nn.BatchNorm1d] = []
        for module in model.modules():
            if isinstance(module, (nn.BatchNorm1d, nn.BatchNorm2d, nn.GroupNorm)):
                batch_norms.append(module)
        if not batch_norms:
            return model
        for bn in batch_norms:
            bn.reset_running_stats()
            bn.reset_parameters()
            bn.training = True
        with torch.no_grad():
            for batch in loader:
                if isinstance(batch, (list, tuple)):
                    inputs = batch[0]
                else:
                    inputs = batch
                if device is not None:
                    inputs = inputs.to(device)
                model(inputs)
        for bn in batch_norms:
            bn.training = False
        return model

    def get_averaged_model(self) -> nn.Module:
        if self.swa_params is None:
            raise RuntimeError("No SWA parameters collected yet")
        averaged = copy.deepcopy(self.swa_params)
        return averaged

    def state_dict(self) -> Dict[str, Any]:
        return {
            "swa_start": self.swa_start,
            "swa_freq": self.swa_freq,
            "swa_lr": self.swa_lr,
            "step_count": self.step_count,
            "swa_n": self.swa_n,
            "swa_params": self.swa_params,
        }

    def load_state_dict(self, state_dict: Dict[str, Any]) -> None:
        self.swa_start = state_dict["swa_start"]
        self.swa_freq = state_dict["swa_freq"]
        self.swa_lr = state_dict["swa_lr"]
        self.step_count = state_dict["step_count"]
        self.swa_n = state_dict["swa_n"]
        self.swa_params = state_dict["swa_params"]


class LookaheadOptimizer(Optimizer):
    def __init__(
        self,
        base_optimizer: Optimizer,
        k: int = 5,
        alpha: float = 0.5,
    ) -> None:
        if not isinstance(base_optimizer, Optimizer):
            raise TypeError(f"base_optimizer must be an Optimizer, got {type(base_optimizer)}")
        self.base_optimizer = base_optimizer
        self.k = k
        self.alpha = alpha
        self._step_count = 0
        self.slow_weights: Dict[str, torch.Tensor] = {}
        for group in self.base_optimizer.param_groups:
            for p in group["params"]:
                if p.requires_grad:
                    param_id = id(p)
                    self.slow_weights[param_id] = p.data.clone()

    @property
    def param_groups(self) -> List[Dict[str, Any]]:
        return self.base_optimizer.param_groups

    def step(self, closure: Optional[Any] = None) -> Optional[float]:
        loss = self.base_optimizer.step(closure)
        self._step_count += 1
        if self._step_count % self.k == 0:
            for group in self.base_optimizer.param_groups:
                for p in group["params"]:
                    if p.requires_grad:
                        param_id = id(p)
                        if param_id in self.slow_weights:
                            slow = self.slow_weights[param_id]
                            slow.add_(p.data - slow, alpha=self.alpha)
                            p.data.copy_(slow)
        return loss

    def zero_grad(self, set_to_none: bool = True) -> None:
        self.base_optimizer.zero_grad(set_to_none=set_to_none)

    def state_dict(self) -> Dict[str, Any]:
        return {
            "base_optimizer": self.base_optimizer.state_dict(),
            "k": self.k,
            "alpha": self.alpha,
            "_step_count": self._step_count,
            "slow_weights": self.slow_weights,
        }

    def load_state_dict(self, state_dict: Dict[str, Any]) -> None:
        self.base_optimizer.load_state_dict(state_dict["base_optimizer"])
        self.k = state_dict["k"]
        self.alpha = state_dict["alpha"]
        self._step_count = state_dict["_step_count"]
        self.slow_weights = state_dict["slow_weights"]

    def add_param_group(self, param_group: Dict[str, Any]) -> None:
        self.base_optimizer.add_param_group(param_group)
        for p in param_group["params"]:
            if p.requires_grad:
                param_id = id(p)
                self.slow_weights[param_id] = p.data.clone()

    @property
    def optimizer(self) -> Optimizer:
        return self.base_optimizer

    @property
    def param_groups_info(self) -> List[Dict[str, Any]]:
        return self.base_optimizer.param_groups


class PolyakAverager(WeightAverager):
    def __init__(
        self,
        model: nn.Module,
        averaging_period: Optional[int] = None,
        use_time_average: bool = True,
        tau: float = 0.001,
    ) -> None:
        self.averaging_period = averaging_period
        self.use_time_average = use_time_average
        self.tau = tau
        self.step_count = 0
        self.params: Dict[str, torch.Tensor] = {}
        self.time_averaged_params: Optional[Dict[str, torch.Tensor]] = None
        self.averaged_count = 0
        for name, param in model.named_parameters():
            if param.requires_grad:
                self.params[name] = param.data.clone()
        self.snapshot: Optional[Dict[str, torch.Tensor]] = None

    def update(self, model: nn.Module, **kwargs: Any) -> None:
        self.step_count += 1
        model_params = dict(model.named_parameters())
        for name in self.params:
            if name in model_params:
                if self.use_time_average:
                    if self.time_averaged_params is None:
                        self.time_averaged_params = {
                            n: p.data.clone() for n, p in model.named_parameters()
                            if n in self.params
                        }
                        self.averaged_count = 1
                    else:
                        for n in self.time_averaged_params:
                            if n in model_params:
                                self.time_averaged_params[n].add_(
                                    model_params[n] - self.time_averaged_params[n],
                                    alpha=1.0 / (self.averaged_count + 1),
                                )
                        self.averaged_count += 1
                else:
                    self.params[name].copy_(model_params[name])

    def store(self, model: nn.Module) -> None:
        self.snapshot = {}
        for name, param in model.named_parameters():
            self.snapshot[name] = param.data.clone()

    def restore(self, model: nn.Module) -> None:
        if self.snapshot is None:
            raise RuntimeError("No snapshot to restore. Call store() first.")
        for name, param in model.named_parameters():
            if name in self.snapshot:
                param.data.copy_(self.snapshot[name])
        self.snapshot = None

    def get_averaged_model(self) -> nn.Module:
        if self.use_time_average and self.time_averaged_params is not None:
            return self.time_averaged_params
        return self.params

    def state_dict(self) -> Dict[str, Any]:
        return {
            "averaging_period": self.averaging_period,
            "use_time_average": self.use_time_average,
            "tau": self.tau,
            "step_count": self.step_count,
            "params": self.params,
            "time_averaged_params": self.time_averaged_params,
            "averaged_count": self.averaged_count,
        }

    def load_state_dict(self, state_dict: Dict[str, Any]) -> None:
        self.averaging_period = state_dict["averaging_period"]
        self.use_time_average = state_dict["use_time_average"]
        self.tau = state_dict["tau"]
        self.step_count = state_dict["step_count"]
        self.params = state_dict["params"]
        self.time_averaged_params = state_dict.get("time_averaged_params")
        self.averaged_count = state_dict.get("averaged_count", 0)


__all__ = [
    "WeightAverager",
    "EMAWeightAverager",
    "SWAWeightAverager",
    "LookaheadOptimizer",
    "PolyakAverager",
]
