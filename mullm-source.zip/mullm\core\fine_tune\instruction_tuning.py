from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional, Tuple, Union

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader


@dataclass
class InstructionTemplate:
    system_format: str = "{system}"
    instruction_format: str = "{instruction}"
    input_format: str = "{input}"
    response_format: str = "{response}"
    system_instruction_format: str = "{system}\n{instruction}"
    instruction_input_format: str = "{instruction}\n{input}"
    system_instruction_input_format: str = "{system}\n{instruction}\n{input}"
    response_split: str = "{response}"
    label_format: str = "{response}"
    ignore_index: int = -100
    system_role: str = "system"
    user_role: str = "user"
    assistant_role: str = "assistant"


ALPACA_TEMPLATE = InstructionTemplate(
    instruction_format="### Instruction:\n{instruction}",
    input_format="### Input:\n{input}",
    response_format="### Response:\n{response}",
    instruction_input_format="### Instruction:\n{instruction}\n\n### Input:\n{input}",
    response_split="\n### Response:\n",
    label_format="{response}",
)


VICUNA_TEMPLATE = InstructionTemplate(
    system_format="{system} ",
    instruction_format="USER: {instruction}",
    input_format=" {input}",
    response_format=" ASSISTANT: {response}",
    system_instruction_format="{system} {instruction}",
    instruction_input_format="USER: {instruction}\n{input}",
    system_instruction_input_format="{system} USER: {instruction}\n{input}",
    response_split=" ASSISTANT: ",
    label_format="{response}",
    system_role="system",
    user_role="USER",
    assistant_role="ASSISTANT",
)


CHATML_TEMPLATE = InstructionTemplate(
    system_format="<|im_start|>system\n{system}<|im_end|>\n",
    instruction_format="<|im_start|>user\n{instruction}<|im_end|>\n",
    input_format="<|im_start|>user\n{input}<|im_end|>\n",
    response_format="<|im_start|>assistant\n{response}<|im_end|>",
    system_instruction_format="<|im_start|>system\n{system}<|im_end|>\n<|im_start|>user\n{instruction}<|im_end|>\n",
    instruction_input_format="<|im_start|>user\n{instruction}\n{input}<|im_end|>\n",
    system_instruction_input_format="<|im_start|>system\n{system}<|im_end|>\n<|im_start|>user\n{instruction}\n{input}<|im_end|>\n",
    response_split="<|im_start|>assistant\n",
    label_format="{response}<|im_end|>",
)


def format_instruction(
    instruction: str,
    input: Optional[str] = None,
    response: Optional[str] = None,
    system: Optional[str] = None,
    template: InstructionTemplate = ALPACA_TEMPLATE,
    add_response: bool = True,
) -> str:
    if system and input:
        text = template.system_instruction_input_format.format(system=system, instruction=instruction, input=input)
    elif system and not input:
        text = template.system_instruction_format.format(system=system, instruction=instruction)
    elif input and not system:
        text = template.instruction_input_format.format(instruction=instruction, input=input)
    else:
        text = template.instruction_format.format(instruction=instruction)

    if add_response and response is not None:
        text += template.response_split
    return text


def format_instruction_dataset(
    dataset: List[Dict[str, str]],
    template: InstructionTemplate = ALPACA_TEMPLATE,
    add_response: bool = True,
    system_field: str = "system",
    instruction_field: str = "instruction",
    input_field: str = "input",
    response_field: str = "response",
) -> List[Dict[str, str]]:
    formatted = []
    for item in dataset:
        instruction = item.get(instruction_field, "")
        input_text = item.get(input_field, "")
        response = item.get(response_field, "")
        system = item.get(system_field, "")

        formatted_text = format_instruction(
            instruction=instruction,
            input=input_text if input_text else None,
            response=response,
            system=system if system else None,
            template=template,
            add_response=add_response,
        )

        formatted_item = {"text": formatted_text}
        if response:
            formatted_item["response"] = response
        formatted.append(formatted_item)

    return formatted


def pack_instructions(
    dataset: List[Dict[str, str]],
    tokenizer: Any,
    max_length: int = 2048,
    template: InstructionTemplate = ALPACA_TEMPLATE,
) -> List[Dict[str, Any]]:
    packed_batches = []
    current_batch: Dict[str, Any] = {"input_ids": [], "labels": [], "attention_mask": []}
    current_length = 0

    for item in dataset:
        text = format_instruction(
            instruction=item.get("instruction", ""),
            input=item.get("input"),
            response=item.get("response"),
            system=item.get("system"),
            template=template,
            add_response=True,
        )

        tokens = tokenizer.encode(text, add_special_tokens=False)
        response_split = template.response_split
        response_text = item.get("response", "")

        prompt_text = text[:text.find(response_split)] if response_split in text else text
        prompt_tokens = tokenizer.encode(prompt_text, add_special_tokens=False)
        full_tokens = tokens + [tokenizer.eos_token_id] if hasattr(tokenizer, "eos_token_id") else tokens

        if current_length + len(full_tokens) > max_length:
            if current_batch["input_ids"]:
                packed_batches.append(current_batch)
            current_batch = {"input_ids": [], "labels": [], "attention_mask": []}
            current_length = 0

        labels_mask = [-100] * len(prompt_tokens) + full_tokens[len(prompt_tokens):]
        if len(labels_mask) < len(full_tokens):
            labels_mask = labels_mask + [-100] * (len(full_tokens) - len(labels_mask))

        current_batch["input_ids"].extend(full_tokens)
        current_batch["labels"].extend(labels_mask[:len(full_tokens)])
        current_batch["attention_mask"].extend([1] * len(full_tokens))
        current_length += len(full_tokens)

    if current_batch["input_ids"]:
        packed_batches.append(current_batch)

    for batch in packed_batches:
        batch["input_ids"] = torch.tensor(batch["input_ids"], dtype=torch.long)
        batch["labels"] = torch.tensor(batch["labels"], dtype=torch.long)
        batch["attention_mask"] = torch.tensor(batch["attention_mask"], dtype=torch.long)

    return packed_batches


class InstructionDataset(Dataset):
    def __init__(
        self,
        data: List[Dict[str, str]],
        tokenizer: Any,
        template: InstructionTemplate = ALPACA_TEMPLATE,
        max_length: int = 2048,
        mask_instruction: bool = True,
        instruction_field: str = "instruction",
        input_field: str = "input",
        response_field: str = "response",
        system_field: str = "system",
    ):
        self.tokenizer = tokenizer
        self.template = template
        self.max_length = max_length
        self.mask_instruction = mask_instruction
        self.instruction_field = instruction_field
        self.input_field = input_field
        self.response_field = response_field
        self.system_field = system_field

        self.examples = []
        for item in data:
            example = self._process_item(item)
            if example is not None:
                self.examples.append(example)

    def _process_item(self, item: Dict[str, str]) -> Optional[Dict[str, torch.Tensor]]:
        instruction = item.get(self.instruction_field, "")
        input_text = item.get(self.input_field, "")
        response = item.get(self.response_field, "")
        system = item.get(self.system_field, "")

        if not instruction and not response:
            return None

        prompt = format_instruction(
            instruction=instruction,
            input=input_text if input_text else None,
            response=response,
            system=system if system else None,
            template=self.template,
            add_response=True,
        )

        full_text = prompt + response if self.template.response_split not in prompt else prompt
        tokenized = self.tokenizer(
            full_text,
            max_length=self.max_length,
            truncation=True,
            padding=False,
            return_tensors=None,
        )
        input_ids = tokenized["input_ids"]
        if isinstance(input_ids, list):
            input_ids = input_ids

        prompt_with_split = format_instruction(
            instruction=instruction,
            input=input_text if input_text else None,
            response=response,
            system=system if system else None,
            template=self.template,
            add_response=True,
        )
        prompt_tokens = self.tokenizer.encode(
            prompt_with_split,
            add_special_tokens=False,
        )
        if isinstance(prompt_tokens, list):
            prompt_tokens = prompt_tokens

        response_tokens = self.tokenizer.encode(response, add_special_tokens=False)
        if isinstance(response_tokens, list):
            response_tokens = response_tokens

        eos_id = self.tokenizer.eos_token_id if hasattr(self.tokenizer, "eos_token_id") and self.tokenizer.eos_token_id is not None else 0
        all_input_ids = prompt_tokens + response_tokens + [eos_id]
        all_input_ids = all_input_ids[:self.max_length]

        if self.mask_instruction:
            labels = [-100] * len(prompt_tokens) + response_tokens + [eos_id]
        else:
            labels = all_input_ids[:]

        labels = labels[:self.max_length]
        if len(labels) < len(all_input_ids):
            labels = labels + [-100] * (len(all_input_ids) - len(labels))

        attention_mask = [1] * len(all_input_ids)
        if len(attention_mask) < self.max_length:
            pad_len = self.max_length - len(attention_mask)
            all_input_ids = all_input_ids + [self.tokenizer.pad_token_id] * pad_len if hasattr(self.tokenizer, "pad_token_id") else all_input_ids + [0] * pad_len
            labels = labels + [-100] * pad_len
            attention_mask = attention_mask + [0] * pad_len
        else:
            all_input_ids = all_input_ids[:self.max_length]
            labels = labels[:self.max_length]
            attention_mask = attention_mask[:self.max_length]

        return {
            "input_ids": torch.tensor(all_input_ids, dtype=torch.long),
            "labels": torch.tensor(labels, dtype=torch.long),
            "attention_mask": torch.tensor(attention_mask, dtype=torch.long),
        }

    def __len__(self) -> int:
        return len(self.examples)

    def __getitem__(self, idx: int) -> Dict[str, torch.Tensor]:
        return self.examples[idx]


class InstructionDataCollator:
    def __init__(
        self,
        tokenizer: Any,
        max_length: int = 2048,
        pad_token_id: int = 0,
        ignore_index: int = -100,
    ):
        self.tokenizer = tokenizer
        self.max_length = max_length
        self.pad_token_id = pad_token_id if hasattr(tokenizer, "pad_token_id") else pad_token_id
        self.ignore_index = ignore_index

    def __call__(self, batch: List[Dict[str, torch.Tensor]]) -> Dict[str, torch.Tensor]:
        input_ids = [item["input_ids"] for item in batch]
        labels = [item["labels"] for item in batch]
        attention_masks = [item["attention_mask"] for item in batch]

        max_len = max(ids.size(0) for ids in input_ids)
        max_len = min(max_len, self.max_length)

        padded_input_ids = []
        padded_labels = []
        padded_attention_masks = []

        for i in range(len(input_ids)):
            ids = input_ids[i]
            lbls = labels[i]
            mask = attention_masks[i]

            seq_len = ids.size(0)
            if seq_len > max_len:
                padded_input_ids.append(ids[:max_len])
                padded_labels.append(lbls[:max_len])
                padded_attention_masks.append(mask[:max_len])
            else:
                pad_len = max_len - seq_len
                padded_input_ids.append(
                    F.pad(ids, (0, pad_len), value=self.pad_token_id)
                )
                padded_labels.append(
                    F.pad(lbls, (0, pad_len), value=self.ignore_index)
                )
                padded_attention_masks.append(
                    F.pad(mask, (0, pad_len), value=0)
                )

        return {
            "input_ids": torch.stack(padded_input_ids, dim=0),
            "labels": torch.stack(padded_labels, dim=0),
            "attention_mask": torch.stack(padded_attention_masks, dim=0),
        }


class InstructionTuner:
    def __init__(
        self,
        model: nn.Module,
        tokenizer: Any,
        template: InstructionTemplate = ALPACA_TEMPLATE,
        max_length: int = 2048,
        learning_rate: float = 2e-5,
        weight_decay: float = 0.01,
        num_epochs: int = 3,
        batch_size: int = 8,
        gradient_accumulation_steps: int = 1,
        max_grad_norm: float = 1.0,
        warmup_steps: int = 100,
        device: Optional[torch.device] = None,
    ):
        self.model = model
        self.tokenizer = tokenizer
        self.template = template
        self.max_length = max_length
        self.learning_rate = learning_rate
        self.weight_decay = weight_decay
        self.num_epochs = num_epochs
        self.batch_size = batch_size
        self.gradient_accumulation_steps = gradient_accumulation_steps
        self.max_grad_norm = max_grad_norm
        self.warmup_steps = warmup_steps
        self.device = device or torch.device("cuda" if torch.cuda.is_available() else "cpu")

        self.model.to(self.device)

        no_decay = ["bias", "LayerNorm", "layer_norm", "layernorm", "ln", "norm"]
        decay_params = []
        no_decay_params = []
        for name, param in self.model.named_parameters():
            if not param.requires_grad:
                continue
            if any(nd in name.lower() for nd in no_decay):
                no_decay_params.append(param)
            else:
                decay_params.append(param)

        param_groups = [
            {"params": decay_params, "weight_decay": weight_decay},
            {"params": no_decay_params, "weight_decay": 0.0},
        ]
        self.optimizer = torch.optim.AdamW(param_groups, lr=learning_rate)

    def _create_scheduler(self, num_training_steps: int) -> torch.optim.lr_scheduler.LambdaLR:
        def lr_lambda(current_step: int) -> float:
            if current_step < self.warmup_steps:
                return float(current_step) / float(max(1, self.warmup_steps))
            progress = float(current_step - self.warmup_steps) / float(
                max(1, num_training_steps - self.warmup_steps)
            )
            return 0.5 * (1.0 + torch.cos(torch.tensor(progress * torch.pi)).item())

        return torch.optim.lr_scheduler.LambdaLR(self.optimizer, lr_lambda)

    def train(
        self,
        dataset: InstructionDataset,
        eval_dataset: Optional[InstructionDataset] = None,
        output_dir: str = "./instruction_tuning_output",
    ) -> Dict[str, float]:
        collator = InstructionDataCollator(
            tokenizer=self.tokenizer,
            max_length=self.max_length,
        )

        dataloader = DataLoader(
            dataset,
            batch_size=self.batch_size,
            shuffle=True,
            collate_fn=collator,
        )

        num_training_steps = len(dataloader) * self.num_epochs // self.gradient_accumulation_steps
        scheduler = self._create_scheduler(num_training_steps)

        self.model.train()
        global_step = 0
        total_loss = 0.0
        best_loss = float("inf")

        for epoch in range(self.num_epochs):
            epoch_loss = 0.0
            num_batches = 0

            for batch_idx, batch in enumerate(dataloader):
                batch = {k: v.to(self.device) for k, v in batch.items()}

                outputs = self.model(**batch)
                loss = outputs["loss"] if isinstance(outputs, dict) else outputs.loss

                loss = loss / self.gradient_accumulation_steps
                loss.backward()

                epoch_loss += loss.item()
                num_batches += 1

                if (batch_idx + 1) % self.gradient_accumulation_steps == 0:
                    if self.max_grad_norm > 0.0:
                        torch.nn.utils.clip_grad_norm_(self.model.parameters(), self.max_grad_norm)
                    self.optimizer.step()
                    scheduler.step()
                    self.optimizer.zero_grad()
                    global_step += 1

                if global_step % 100 == 0 and global_step > 0:
                    avg_loss = total_loss / max(1, 100)
                    total_loss = 0.0

            avg_epoch_loss = epoch_loss / max(1, num_batches)

            if eval_dataset is not None:
                eval_loss = self.evaluate(eval_dataset)
                if eval_loss < best_loss:
                    best_loss = eval_loss
                    self.save_pretrained(output_dir)

        return {"loss": avg_epoch_loss, "best_eval_loss": best_loss}

    def evaluate(self, dataset: InstructionDataset) -> float:
        collator = InstructionDataCollator(
            tokenizer=self.tokenizer,
            max_length=self.max_length,
        )
        dataloader = DataLoader(
            dataset,
            batch_size=self.batch_size,
            shuffle=False,
            collate_fn=collator,
        )

        self.model.eval()
        total_loss = 0.0
        num_batches = 0

        with torch.no_grad():
            for batch in dataloader:
                batch = {k: v.to(self.device) for k, v in batch.items()}
                outputs = self.model(**batch)
                loss = outputs["loss"] if isinstance(outputs, dict) else outputs.loss
                total_loss += loss.item()
                num_batches += 1

        self.model.train()
        return total_loss / max(1, num_batches)

    def generate(
        self,
        instruction: str,
        input_text: Optional[str] = None,
        system: Optional[str] = None,
        max_new_tokens: int = 256,
        temperature: float = 0.7,
        top_p: float = 0.9,
        top_k: int = 50,
        **kwargs,
    ) -> str:
        prompt = format_instruction(
            instruction=instruction,
            input=input_text,
            system=system,
            template=self.template,
            add_response=True,
        )

        self.model.eval()
        input_ids = self.tokenizer.encode(prompt, return_tensors="pt").to(self.device)

        generated_ids = []
        past_key_values = None

        for _ in range(max_new_tokens):
            with torch.no_grad():
                if past_key_values is None:
                    outputs = self.model(input_ids=input_ids, use_cache=True)
                else:
                    outputs = self.model(
                        input_ids=next_token.unsqueeze(0),
                        past_key_values=past_key_values,
                        use_cache=True,
                    )

            logits = outputs["logits"] if isinstance(outputs, dict) else outputs.logits
            next_logits = logits[:, -1, :] / temperature

            if top_k > 0:
                indices_to_remove = next_logits < torch.topk(next_logits, top_k)[0][..., -1, None]
                next_logits[indices_to_remove] = float("-inf")

            if top_p < 1.0:
                sorted_logits, sorted_indices = torch.sort(next_logits, descending=True)
                cumulative_probs = torch.cumsum(F.softmax(sorted_logits, dim=-1), dim=-1)
                sorted_indices_to_remove = cumulative_probs > top_p
                sorted_indices_to_remove[..., 1:] = sorted_indices_to_remove[..., :-1].clone()
                sorted_indices_to_remove[..., 0] = 0
                indices_to_remove = sorted_indices_to_remove.scatter(
                    dim=-1, index=sorted_indices, src=sorted_indices_to_remove
                )
                next_logits[indices_to_remove] = float("-inf")

            probs = F.softmax(next_logits, dim=-1)
            next_token = torch.multinomial(probs, num_samples=1)

            if hasattr(self.tokenizer, "eos_token_id") and next_token.item() == self.tokenizer.eos_token_id:
                break

            generated_ids.append(next_token.item())
            past_key_values = outputs.get("past_key_values") if isinstance(outputs, dict) else getattr(outputs, "past_key_values", None)

        return self.tokenizer.decode(generated_ids, skip_special_tokens=True)

    def save_pretrained(self, output_dir: str) -> None:
        import os
        os.makedirs(output_dir, exist_ok=True)
        torch.save(self.model.state_dict(), os.path.join(output_dir, "pytorch_model.bin"))

    def from_pretrained(self, model_path: str) -> None:
        state_dict = torch.load(model_path, map_location=self.device)
        self.model.load_state_dict(state_dict)
