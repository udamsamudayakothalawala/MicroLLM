import json
import os
import re
from typing import Any, Dict, Iterator, List, Optional, Sequence, Type, Union

from .base import BaseTokenizer, SpecialTokens
from .bpe import BPETokenizer
from .chat_template import ChatTemplate
from .sentencepiece import SentencePieceTokenizer, UnigramTokenizer
from .wordpiece import WordPieceTokenizer


TOKENIZER_REGISTRY: Dict[str, Type[BaseTokenizer]] = {}


def register_tokenizer(name: str, cls: Type[BaseTokenizer]) -> None:
    TOKENIZER_REGISTRY[name] = cls


register_tokenizer("bpe", BPETokenizer)
register_tokenizer("sentencepiece", SentencePieceTokenizer)
register_tokenizer("unigram", UnigramTokenizer)
register_tokenizer("wordpiece", WordPieceTokenizer)


def _detect_tokenizer_type(name_or_path: str) -> str:
    lower = name_or_path.lower()

    if os.path.isdir(name_or_path) or os.path.isfile(name_or_path):
        return _detect_from_path(name_or_path)

    if "llama" in lower or "mistral" in lower or "mixtral" in lower or "gpt" in lower:
        return "bpe"
    if "gemma" in lower or "bert" in lower:
        return "wordpiece"
    if "sentencepiece" in lower or "spm" in lower:
        return "sentencepiece"
    if "unigram" in lower:
        return "unigram"

    return "bpe"


def _detect_from_path(path: str) -> str:
    if os.path.isdir(path):
        files = os.listdir(path)
        for f in files:
            if f.endswith(".model"):
                return "sentencepiece"
            if "merges" in f.lower() and f.endswith(".txt"):
                return "bpe"
            if "vocab" in f.lower() and f.endswith(".json"):
                return _detect_vocab_json(os.path.join(path, f))
            if "tokenizer" in f.lower() and f.endswith(".json"):
                return _detect_from_tokenizer_json(os.path.join(path, f))
        return "bpe"
    else:
        if path.endswith(".model"):
            return "sentencepiece"
        if path.endswith(".txt") and "merges" in path.lower():
            return "bpe"
        if path.endswith(".json"):
            return _detect_vocab_json(path)
        return "bpe"


def _detect_vocab_json(path: str) -> str:
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        if isinstance(data, dict):
            keys = list(data.keys())
            if keys:
                sample = keys[0]
                if sample.startswith("##") or sample.startswith("["):
                    return "wordpiece"
                if "merges" in data:
                    return "bpe"
                if "model" in data and isinstance(data["model"], dict):
                    if "vocab" in data["model"]:
                        return "unigram"
            for key in keys[:10]:
                if key.startswith("##"):
                    return "wordpiece"
            return "bpe"
        elif isinstance(data, list):
            return "wordpiece" if any(t.startswith("##") for t in data[:10]) else "bpe"
    except (json.JSONDecodeError, UnicodeDecodeError):
        pass
    return "bpe"


def _detect_from_tokenizer_json(path: str) -> str:
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        if isinstance(data, dict):
            model_type = data.get("model_type", "")
            if model_type:
                return model_type
            model = data.get("model", {})
            if isinstance(model, dict):
                tok_type = model.get("type", "")
                if tok_type:
                    return tok_type
        return "bpe"
    except (json.JSONDecodeError, UnicodeDecodeError):
        return "bpe"


def load_tokenizer(
    path: str,
    tokenizer_type: Optional[str] = None,
    special_tokens: Optional[SpecialTokens] = None,
    **kwargs: Any,
) -> BaseTokenizer:
    if tokenizer_type is None:
        tokenizer_type = _detect_tokenizer_type(path)

    tokenizer_type = tokenizer_type.lower()

    if os.path.isdir(path):
        return _load_from_directory(
            path, tokenizer_type, special_tokens, **kwargs
        )

    if tokenizer_type in ("bpe", "gpt2", "gpt"):
        if path.endswith(".json"):
            return BPETokenizer.load(path)
        elif path.endswith(".txt"):
            vocab_path = path.replace("merges.txt", "vocab.json")
            if not os.path.exists(vocab_path):
                vocab_path = os.path.join(
                    os.path.dirname(path), "vocab.json"
                )
            return BPETokenizer.from_merges_file(
                path, vocab_path, special_tokens
            )
        else:
            return BPETokenizer.load(path)
    elif tokenizer_type in ("sentencepiece", "spm", "unigram"):
        if path.endswith(".model"):
            return SentencePieceTokenizer(
                model_path=path, special_tokens=special_tokens
            )
        elif path.endswith(".json"):
            try:
                return UnigramTokenizer.load(path)
            except Exception:
                return SentencePieceTokenizer(
                    model_path=path, special_tokens=special_tokens
                )
        else:
            return SentencePieceTokenizer(
                model_path=path, special_tokens=special_tokens
            )
    elif tokenizer_type in ("wordpiece", "bert"):
        if path.endswith(".json"):
            return WordPieceTokenizer.load(path)
        else:
            return WordPieceTokenizer.load(path)
    else:
        raise ValueError(f"Unknown tokenizer type: {tokenizer_type}")


def _load_from_directory(
    path: str,
    tokenizer_type: str,
    special_tokens: Optional[SpecialTokens] = None,
    **kwargs: Any,
) -> BaseTokenizer:
    files = os.listdir(path)

    if tokenizer_type in ("bpe", "gpt2", "gpt"):
        merges_file = None
        vocab_file = None
        for f in files:
            if "merges" in f.lower() and f.endswith(".txt"):
                merges_file = os.path.join(path, f)
            elif "vocab" in f.lower() and f.endswith(".json"):
                vocab_file = os.path.join(path, f)
        if merges_file and vocab_file:
            return BPETokenizer.from_merges_file(
                merges_file, vocab_file, special_tokens
            )
        tokenizer_file = os.path.join(path, "tokenizer.json")
        if os.path.exists(tokenizer_file):
            return _load_from_tokenizer_json(
                tokenizer_file, tokenizer_type, special_tokens
            )

    if tokenizer_type in ("sentencepiece", "spm"):
        for f in files:
            if f.endswith(".model"):
                return SentencePieceTokenizer(
                    model_path=os.path.join(path, f),
                    special_tokens=special_tokens,
                )

    if tokenizer_type in ("unigram",):
        for f in files:
            if f.endswith(".json") and "tokenizer" not in f.lower():
                try:
                    return UnigramTokenizer.load(os.path.join(path, f))
                except Exception:
                    continue
        for f in files:
            if f.endswith(".model"):
                return SentencePieceTokenizer(
                    model_path=os.path.join(path, f),
                    special_tokens=special_tokens,
                )

    if tokenizer_type in ("wordpiece", "bert"):
        for f in files:
            if "vocab" in f.lower() and f.endswith(".json"):
                return WordPieceTokenizer(
                    vocab=json.load(
                        open(os.path.join(path, f), "r", encoding="utf-8")
                    ),
                    special_tokens=special_tokens,
                )
            if "vocab" in f.lower() and f.endswith(".txt"):
                with open(
                    os.path.join(path, f), "r", encoding="utf-8"
                ) as vf:
                    lines = [l.strip() for l in vf if l.strip()]
                vocab = {t: i for i, t in enumerate(lines)}
                return WordPieceTokenizer(
                    vocab=vocab, special_tokens=special_tokens
                )

    tokenizer_file = os.path.join(path, "tokenizer.json")
    if os.path.exists(tokenizer_file):
        return _load_from_tokenizer_json(
            tokenizer_file, tokenizer_type, special_tokens
        )

    raise ValueError(
        f"Could not find suitable tokenizer files in {path}"
    )


def _load_from_tokenizer_json(
    path: str,
    tokenizer_type: str,
    special_tokens: Optional[SpecialTokens] = None,
) -> BaseTokenizer:
    try:
        from transformers import PreTrainedTokenizerFast

        tokenizer = PreTrainedTokenizerFast(
            tokenizer_file=path,
            unk_token=(
                special_tokens.unk_token if special_tokens else None
            ),
            bos_token=(
                special_tokens.bos_token if special_tokens else None
            ),
            eos_token=(
                special_tokens.eos_token if special_tokens else None
            ),
            pad_token=(
                special_tokens.pad_token if special_tokens else None
            ),
        )
        return _HFWrapper(tokenizer)
    except ImportError:
        pass

    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)

    model = data.get("model", {})
    vocab_data = model.get("vocab", {})
    merges_data = model.get("merges", [])

    if merges_data:
        merges: List[Tuple[str, str]] = []
        for m in merges_data:
            parts = m.split()
            if len(parts) == 2:
                merges.append((parts[0], parts[1]))
        return BPETokenizer(
            vocab=vocab_data,
            merges=merges,
            special_tokens=special_tokens,
        )
    else:
        return BPETokenizer(data.get("added_tokens", vocab_data))


class _HFWrapper(BaseTokenizer):
    def __init__(self, hf_tokenizer: Any) -> None:
        special_tokens = SpecialTokens(
            bos_token=hf_tokenizer.bos_token,
            eos_token=hf_tokenizer.eos_token,
            unk_token=hf_tokenizer.unk_token,
            pad_token=hf_tokenizer.pad_token,
            sep_token=getattr(hf_tokenizer, "sep_token", None),
            cls_token=getattr(hf_tokenizer, "cls_token", None),
            mask_token=getattr(hf_tokenizer, "mask_token", None),
        )
        super().__init__(special_tokens)
        self._hf_tokenizer = hf_tokenizer

    @property
    def vocab_size(self) -> int:
        return self._hf_tokenizer.vocab_size

    def encode(self, text: str, add_special_tokens: bool = True) -> List[int]:
        return self._hf_tokenizer.encode(text, add_special_tokens=add_special_tokens)

    def decode(self, ids: Sequence[int], skip_special_tokens: bool = True) -> str:
        return self._hf_tokenizer.decode(ids, skip_special_tokens=skip_special_tokens)

    def _token_to_id(self, token: str) -> int:
        return int(self._hf_tokenizer.convert_tokens_to_ids(token))

    def _id_to_token(self, idx: int) -> str:
        return str(self._hf_tokenizer.convert_ids_to_tokens(idx))

    def _get_vocab(self) -> Dict[str, int]:
        return dict(self._hf_tokenizer.get_vocab())

    def _set_vocab(self, vocab: Dict[str, int]) -> None:
        pass

    def convert_tokens_to_ids(self, tokens: Union[str, List[str]]) -> Union[int, List[int]]:
        return self._hf_tokenizer.convert_tokens_to_ids(tokens)

    def convert_ids_to_tokens(self, ids: Union[int, List[int]]) -> Union[str, List[str]]:
        return self._hf_tokenizer.convert_ids_to_tokens(ids)


class AutoTokenizer:
    @staticmethod
    def from_pretrained(
        name_or_path: str,
        tokenizer_type: Optional[str] = None,
        special_tokens: Optional[Union[Dict[str, Optional[str]], SpecialTokens]] = None,
        **kwargs: Any,
    ) -> BaseTokenizer:
        if special_tokens is not None and not isinstance(special_tokens, SpecialTokens):
            special_tokens = SpecialTokens.from_dict(special_tokens)

        try:
            return _detect_and_load(name_or_path, tokenizer_type, special_tokens, **kwargs)
        except (FileNotFoundError, ValueError, json.JSONDecodeError) as e:
            pass

        try:
            return _load_from_huggingface(name_or_path, special_tokens, **kwargs)
        except ImportError:
            raise ImportError(
                "huggingface_hub and transformers are required to load "
                "tokenizers from HuggingFace. Install with: "
                "pip install huggingface_hub transformers"
            )
        except Exception as e:
            raise ValueError(
                f"Could not load tokenizer '{name_or_path}': {e}"
            )

    @staticmethod
    def from_config(
        config: Dict[str, Any],
        special_tokens: Optional[Union[Dict[str, Optional[str]], SpecialTokens]] = None,
    ) -> BaseTokenizer:
        if special_tokens is not None and not isinstance(special_tokens, SpecialTokens):
            special_tokens = SpecialTokens.from_dict(special_tokens)

        tokenizer_type = config.get("type", "bpe").lower()
        vocab = config.get("vocab")
        vocab_size = config.get("vocab_size", 32000)

        if tokenizer_type in ("bpe", "gpt2"):
            merges = config.get("merges")
            return BPETokenizer(
                vocab=vocab, merges=merges, special_tokens=special_tokens
            )
        elif tokenizer_type in ("sentencepiece", "spm"):
            model_path = config.get("model_path")
            if model_path:
                return SentencePieceTokenizer(
                    model_path=model_path, special_tokens=special_tokens
                )
            return SentencePieceTokenizer(
                vocab=vocab, special_tokens=special_tokens
            )
        elif tokenizer_type == "unigram":
            scores = config.get("scores")
            return UnigramTokenizer(
                vocab=vocab,
                scores=scores,
                special_tokens=special_tokens,
            )
        elif tokenizer_type in ("wordpiece", "bert"):
            return WordPieceTokenizer(
                vocab=vocab, special_tokens=special_tokens
            )
        else:
            raise ValueError(f"Unknown tokenizer type in config: {tokenizer_type}")

    @staticmethod
    def train(
        texts: Iterator[str],
        tokenizer_type: str = "bpe",
        vocab_size: int = 32000,
        special_tokens: Optional[Union[Dict[str, Optional[str]], SpecialTokens]] = None,
        show_progress: bool = True,
        **kwargs: Any,
    ) -> BaseTokenizer:
        if special_tokens is not None and not isinstance(special_tokens, SpecialTokens):
            special_tokens = SpecialTokens.from_dict(special_tokens)

        if tokenizer_type == "bpe":
            tokenizer: BaseTokenizer = BPETokenizer(
                special_tokens=special_tokens
            )
        elif tokenizer_type == "unigram":
            tokenizer = UnigramTokenizer(
                special_tokens=special_tokens
            )
        elif tokenizer_type == "wordpiece":
            tokenizer = WordPieceTokenizer(
                special_tokens=special_tokens
            )
        elif tokenizer_type in ("sentencepiece", "spm"):
            tokenizer = SentencePieceTokenizer(
                special_tokens=special_tokens
            )
        else:
            raise ValueError(f"Unknown tokenizer type for training: {tokenizer_type}")

        train_kwargs: Dict[str, Any] = dict(kwargs)
        if tokenizer_type == "unigram":
            train_kwargs.setdefault("max_subword_len", kwargs.get("max_subword_len", 15))
            train_kwargs.setdefault("min_frequency", kwargs.get("min_frequency", 2))
            train_kwargs.setdefault("em_iterations", kwargs.get("em_iterations", 5))
            train_kwargs.setdefault("pruning_factor", kwargs.get("pruning_factor", 0.5))

        tokenizer.train_from_iterator(
            texts, vocab_size=vocab_size, show_progress=show_progress, **train_kwargs
        )

        return tokenizer

    @staticmethod
    def from_registry(name: str, **kwargs: Any) -> BaseTokenizer:
        if name not in TOKENIZER_REGISTRY:
            raise ValueError(
                f"Unknown tokenizer '{name}'. Registered: {list(TOKENIZER_REGISTRY.keys())}"
            )
        cls = TOKENIZER_REGISTRY[name]
        return cls(**kwargs)


def _detect_and_load(
    name_or_path: str,
    tokenizer_type: Optional[str] = None,
    special_tokens: Optional[SpecialTokens] = None,
    **kwargs: Any,
) -> BaseTokenizer:
    if not os.path.exists(name_or_path):
        raise FileNotFoundError(f"Path not found: {name_or_path}")

    return load_tokenizer(name_or_path, tokenizer_type, special_tokens, **kwargs)


def _load_from_huggingface(
    name_or_path: str,
    special_tokens: Optional[SpecialTokens] = None,
    **kwargs: Any,
) -> BaseTokenizer:
    from transformers import AutoTokenizer as HFAutoTokenizer

    hf_tokenizer = HFAutoTokenizer.from_pretrained(
        name_or_path, **kwargs
    )
    return _HFWrapper(hf_tokenizer)


def create_tokenizer_from_config(config_path: str) -> BaseTokenizer:
    with open(config_path, "r", encoding="utf-8") as f:
        config = json.load(f)
    return AutoTokenizer.from_config(config)


def train_tokenizer_from_dataset(
    dataset,
    text_field: str = "text",
    tokenizer_type: str = "bpe",
    vocab_size: int = 32000,
    special_tokens: Optional[Dict[str, Optional[str]]] = None,
    show_progress: bool = True,
    **kwargs: Any,
) -> BaseTokenizer:
    from datasets import Dataset

    def text_iterator():
        for example in dataset:
            yield example[text_field]

    if special_tokens is not None and not isinstance(special_tokens, SpecialTokens):
        special_tokens = SpecialTokens.from_dict(special_tokens)

    return AutoTokenizer.train(
        text_iterator(),
        tokenizer_type=tokenizer_type,
        vocab_size=vocab_size,
        special_tokens=special_tokens,
        show_progress=show_progress,
        **kwargs,
    )
