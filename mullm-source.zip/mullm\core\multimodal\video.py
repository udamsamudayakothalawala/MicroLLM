import math
from typing import Any, Dict, List, Optional, Tuple

import torch
import torch.nn as nn
import torch.nn.functional as F
from torchvision import models, transforms


class VideoProcessor:
    def __init__(
        self,
        fps: int = 30,
        target_fps: int = 2,
        frame_size: Tuple[int, int] = (224, 224),
        mean: Tuple[float, float, float] = (0.485, 0.456, 0.406),
        std: Tuple[float, float, float] = (0.229, 0.224, 0.225),
    ):
        self.fps = fps
        self.target_fps = target_fps
        self.frame_size = frame_size
        self.mean = mean
        self.std = std
        self.transform = transforms.Compose([
            transforms.ToTensor(),
            transforms.Normalize(mean=mean, std=std),
        ])

    def extract_frames(self, video_tensor: torch.Tensor, sampling_rate: Optional[int] = None) -> torch.Tensor:
        B, C, T, H, W = video_tensor.shape
        rate = sampling_rate or max(1, self.fps // self.target_fps)
        indices = torch.arange(0, T, rate, device=video_tensor.device)
        frames = video_tensor[:, :, indices, :, :]
        if frames.shape[-2:] != self.frame_size:
            frames = F.interpolate(
                frames.reshape(-1, C, H, W),
                size=self.frame_size,
                mode="bilinear",
                align_corners=False,
            ).reshape(B, -1, *self.frame_size)
        frames = frames.permute(0, 2, 1, 3, 4)
        return frames

    def uniform_sampling(self, video_tensor: torch.Tensor, num_frames: int = 16) -> torch.Tensor:
        B, C, T, H, W = video_tensor.shape
        indices = torch.linspace(0, T - 1, num_frames, dtype=torch.long, device=video_tensor.device)
        frames = video_tensor[:, :, indices, :, :]
        if frames.shape[-2:] != self.frame_size:
            frames = F.interpolate(
                frames.reshape(-1, C, H, W),
                size=self.frame_size,
                mode="bilinear",
                align_corners=False,
            ).reshape(B, num_frames, C, *self.frame_size)
        frames = frames.permute(0, 2, 1, 3, 4)
        return frames

    def random_sampling(self, video_tensor: torch.Tensor, num_frames: int = 16) -> torch.Tensor:
        B, C, T, H, W = video_tensor.shape
        indices = torch.sort(torch.randint(0, T, (num_frames,), device=video_tensor.device))[0]
        frames = video_tensor[:, :, indices, :, :]
        if frames.shape[-2:] != self.frame_size:
            frames = F.interpolate(
                frames.reshape(-1, C, H, W),
                size=self.frame_size,
                mode="bilinear",
                align_corners=False,
            ).reshape(B, num_frames, C, *self.frame_size)
        frames = frames.permute(0, 2, 1, 3, 4)
        return frames

    def __call__(self, video_tensor: torch.Tensor, sampling: str = "uniform", num_frames: int = 16) -> torch.Tensor:
        if sampling == "uniform":
            return self.uniform_sampling(video_tensor, num_frames)
        elif sampling == "random":
            return self.random_sampling(video_tensor, num_frames)
        else:
            return self.extract_frames(video_tensor)


class VideoEncoder(nn.Module):
    def __init__(self, embed_dim: int = 512, num_frames: int = 16, num_layers: int = 6, num_heads: int = 8):
        super().__init__()
        self.embed_dim = embed_dim
        self.num_frames = num_frames

        resnet = models.resnet50(weights="DEFAULT")
        self.spatial_encoder = nn.Sequential(*list(resnet.children())[:-2])
        self.spatial_proj = nn.Sequential(
            nn.Conv2d(2048, embed_dim, 1),
            nn.BatchNorm2d(embed_dim),
            nn.ReLU(inplace=True),
        )

        self.temporal_position = nn.Parameter(torch.zeros(1, num_frames, embed_dim))
        self.cls_token = nn.Parameter(torch.zeros(1, 1, embed_dim))

        encoder_layer = nn.TransformerEncoderLayer(d_model=embed_dim, nhead=num_heads, dim_feedforward=embed_dim * 4, batch_first=True)
        self.temporal_encoder = nn.TransformerEncoder(encoder_layer, num_layers)

        self.norm = nn.LayerNorm(embed_dim)

        nn.init.normal_(self.temporal_position, std=0.02)
        nn.init.normal_(self.cls_token, std=0.02)

    def forward(self, frames: torch.Tensor) -> Dict[str, torch.Tensor]:
        B, C, T, H, W = frames.shape

        frames_reshaped = frames.permute(0, 2, 1, 3, 4).reshape(B * T, C, H, W)
        spatial_feats = self.spatial_encoder(frames_reshaped)
        spatial_feats = self.spatial_proj(spatial_feats)

        _, C_feat, H_feat, W_feat = spatial_feats.shape
        spatial_feats = spatial_feats.reshape(B, T, C_feat, H_feat, W_feat)
        spatial_tokens = spatial_feats.flatten(3).transpose(2, 3)
        B, T, N, D = spatial_tokens.shape

        spatial_tokens = spatial_tokens.reshape(B, T * N, D)

        cls_tokens = self.cls_token.expand(B, -1, -1)
        x = torch.cat([cls_tokens, spatial_tokens], dim=1)

        temporal_pos = self.temporal_position.repeat_interleave(N, dim=1) if T == self.num_frames else F.interpolate(
            self.temporal_position.transpose(1, 2), size=T, mode="linear", align_corners=False
        ).transpose(1, 2).repeat_interleave(N, dim=1)
        pos_with_cls = torch.cat([self.cls_token, temporal_pos], dim=1)
        x = x + pos_with_cls

        x = self.temporal_encoder(x)
        x = self.norm(x)

        cls_out = x[:, 0]
        spatial_out = x[:, 1:].reshape(B, T, N, D)

        return {
            "cls_embedding": cls_out,
            "spatial_temporal": spatial_out,
            "sequence": x,
        }

    def encode(self, frames: torch.Tensor) -> torch.Tensor:
        output = self.forward(frames)
        return output["cls_embedding"]


class FrameSelector(nn.Module):
    def __init__(self, embed_dim: int = 512, threshold: float = 0.3):
        super().__init__()
        self.embed_dim = embed_dim
        self.threshold = threshold

        resnet = models.resnet18(weights="DEFAULT")
        self.encoder = nn.Sequential(*list(resnet.children())[:-2])
        self.pool = nn.AdaptiveAvgPool2d(1)

        self.scorer = nn.Sequential(
            nn.Linear(512, 256),
            nn.GELU(),
            nn.Linear(256, 1),
        )

    def forward(self, video_tensor: torch.Tensor) -> Dict[str, Any]:
        B, C, T, H, W = video_tensor.shape
        frames_reshaped = video_tensor.permute(0, 2, 1, 3, 4).reshape(B * T, C, H, W)

        features = self.encoder(frames_reshaped)
        features = self.pool(features).squeeze(-1).squeeze(-1)
        features = features.reshape(B, T, -1)

        scores = self.scorer(features).squeeze(-1)
        selected_indices = self._select_keyframes(scores)

        selected_frames = []
        for b in range(B):
            sel = selected_indices[b]
            frames = video_tensor[b, :, sel, :, :]
            selected_frames.append(frames)
        return {
            "scores": scores,
            "selected_indices": selected_indices,
            "selected_frames": torch.stack(selected_frames),
        }

    def _select_keyframes(self, scores: torch.Tensor) -> List[torch.Tensor]:
        B, T = scores.shape
        selected = []
        for b in range(B):
            diff = scores[b, 1:] - scores[b, :-1]
            peaks = torch.cat([
                torch.zeros(1, device=scores.device),
                (diff[:-1] > 0) & (diff[1:] <= 0),
                torch.zeros(1, device=scores.device),
            ])
            peak_indices = torch.nonzero(peaks > 0).squeeze(-1)
            high_score = scores[b] > self.threshold
            valid = peak_indices[high_score[peak_indices]]
            if valid.numel() == 0:
                valid = torch.tensor([scores[b].argmax()], device=scores.device)
            selected.append(valid)
        return selected

    def select(self, video_tensor: torch.Tensor) -> torch.Tensor:
        output = self.forward(video_tensor)
        return output["selected_frames"]


class VideoCaptioner(nn.Module):
    def __init__(self, vocab_size: int = 30000, embed_dim: int = 512, num_heads: int = 8, num_layers: int = 6, max_len: int = 64):
        super().__init__()
        self.video_encoder = VideoEncoder(embed_dim=embed_dim, num_frames=16)
        self.word_embedding = nn.Embedding(vocab_size, embed_dim)
        self.pos_embedding = nn.Parameter(torch.zeros(1, max_len, embed_dim))

        decoder_layer = nn.TransformerDecoderLayer(d_model=embed_dim, nhead=num_heads, dim_feedforward=embed_dim * 4, batch_first=True)
        self.decoder = nn.TransformerDecoder(decoder_layer, num_layers)

        self.output_proj = nn.Linear(embed_dim, vocab_size)
        self.max_len = max_len

        nn.init.normal_(self.pos_embedding, std=0.02)

    def forward(self, frames: torch.Tensor, captions: Optional[torch.Tensor] = None) -> torch.Tensor:
        encoded = self.video_encoder(frames)
        memory = encoded["sequence"]

        if captions is not None:
            seq_len = captions.shape[1]
            embed = self.word_embedding(captions)
            embed = embed + self.pos_embedding[:, :seq_len, :]
            causal_mask = nn.Transformer.generate_square_subsequent_mask(seq_len, device=frames.device)
            output = self.decoder(embed, memory, tgt_mask=causal_mask)
            logits = self.output_proj(output)
            return logits
        return memory

    def generate_caption(self, frames: torch.Tensor, start_token: int = 0, end_token: int = 2) -> torch.Tensor:
        memory = self.forward(frames)
        B = frames.shape[0]
        generated = torch.full((B, 1), start_token, dtype=torch.long, device=frames.device)

        for _ in range(self.max_len - 1):
            seq_len = generated.shape[1]
            embed = self.word_embedding(generated)
            embed = embed + self.pos_embedding[:, :seq_len, :]
            causal_mask = nn.Transformer.generate_square_subsequent_mask(seq_len, device=frames.device)
            output = self.decoder(embed, memory, tgt_mask=causal_mask)
            logits = self.output_proj(output[:, -1:, :])
            next_token = logits.argmax(dim=-1)
            generated = torch.cat([generated, next_token], dim=1)
            if (next_token == end_token).all():
                break
        return generated


class VideoQuestionAnswering(nn.Module):
    def __init__(self, vocab_size: int = 30000, embed_dim: int = 512, num_heads: int = 8, num_layers: int = 6, num_answers: int = 5000):
        super().__init__()
        self.video_encoder = VideoEncoder(embed_dim=embed_dim, num_frames=16)
        self.text_embedding = nn.Embedding(vocab_size, embed_dim)

        encoder_layer = nn.TransformerEncoderLayer(d_model=embed_dim, nhead=num_heads, dim_feedforward=embed_dim * 4, batch_first=True)
        self.cross_modal_encoder = nn.TransformerEncoder(encoder_layer, num_layers)

        self.fusion = nn.Sequential(
            nn.Linear(embed_dim * 2, embed_dim * 4),
            nn.GELU(),
            nn.Linear(embed_dim * 4, embed_dim),
            nn.GELU(),
        )

        self.classifier = nn.Linear(embed_dim, num_answers)

    def forward(self, frames: torch.Tensor, questions: torch.Tensor) -> torch.Tensor:
        video_output = self.video_encoder(frames)
        video_tokens = video_output["sequence"]

        text_features = self.text_embedding(questions)
        combined = torch.cat([video_tokens, text_features], dim=1)
        cross_feats = self.cross_modal_encoder(combined)

        v_len = video_tokens.shape[1]
        v_out = cross_feats[:, :v_len, :].mean(dim=1)
        t_out = cross_feats[:, v_len:, :].mean(dim=1)
        fused = self.fusion(torch.cat([v_out, t_out], dim=-1))
        logits = self.classifier(fused)
        return logits

    def answer(self, frames: torch.Tensor, questions: torch.Tensor) -> torch.Tensor:
        logits = self.forward(frames, questions)
        return logits.argmax(dim=-1)


class ActionRecognizer(nn.Module):
    def __init__(self, num_actions: int = 400, embed_dim: int = 512, num_frames: int = 16):
        super().__init__()
        self.video_encoder = VideoEncoder(embed_dim=embed_dim, num_frames=num_frames)
        self.classifier = nn.Sequential(
            nn.Linear(embed_dim, embed_dim * 2),
            nn.GELU(),
            nn.Dropout(0.2),
            nn.Linear(embed_dim * 2, embed_dim),
            nn.GELU(),
            nn.Dropout(0.2),
            nn.Linear(embed_dim, num_actions),
        )

    def forward(self, frames: torch.Tensor) -> torch.Tensor:
        encoded = self.video_encoder(frames)
        cls_embed = encoded["cls_embedding"]
        logits = self.classifier(cls_embed)
        return logits

    def recognize(self, frames: torch.Tensor) -> Dict[str, torch.Tensor]:
        logits = self.forward(frames)
        probs = F.softmax(logits, dim=-1)
        predictions = logits.argmax(dim=-1)
        confidences = probs.max(dim=-1).values
        return {
            "logits": logits,
            "probs": probs,
            "predictions": predictions,
            "confidences": confidences,
        }


class VideoTextRetriever(nn.Module):
    def __init__(self, video_embed_dim: int = 512, text_embed_dim: int = 512, proj_dim: int = 256, temperature: float = 0.07):
        super().__init__()
        self.video_encoder = VideoEncoder(embed_dim=video_embed_dim)
        self.text_encoder = nn.TransformerEncoder(
            nn.TransformerEncoderLayer(d_model=text_embed_dim, nhead=8, dim_feedforward=text_embed_dim * 4, batch_first=True),
            num_layers=6,
        )
        self.text_embedding = nn.Embedding(30000, text_embed_dim)
        self.text_pos = nn.Parameter(torch.zeros(1, 64, text_embed_dim))

        self.video_proj = nn.Linear(video_embed_dim, proj_dim)
        self.text_proj = nn.Linear(text_embed_dim, proj_dim)
        self.logit_scale = nn.Parameter(torch.ones([]) * math.log(1 / temperature))
        self.temperature = temperature

        nn.init.normal_(self.text_pos, std=0.02)

    def forward(self, frames: torch.Tensor, texts: torch.Tensor) -> Dict[str, torch.Tensor]:
        video_output = self.video_encoder(frames)
        video_embed = video_output["cls_embedding"]
        video_embed = F.normalize(self.video_proj(video_embed), dim=-1)

        text_embed = self.text_embedding(texts)
        text_embed = text_embed + self.text_pos[:, :texts.shape[1], :]
        text_embed = self.text_encoder(text_embed).mean(dim=1)
        text_embed = F.normalize(self.text_proj(text_embed), dim=-1)

        logit_scale = self.logit_scale.exp()
        logits = logit_scale * video_embed @ text_embed.t()

        return {
            "video_embeddings": video_embed,
            "text_embeddings": text_embed,
            "logits": logits,
            "temperature": self.temperature,
        }

    def retrieve(self, frames: torch.Tensor, texts: torch.Tensor, top_k: int = 5) -> Dict[str, torch.Tensor]:
        output = self.forward(frames, texts)
        scores = output["logits"].softmax(dim=-1)
        top_scores, top_indices = scores.topk(top_k, dim=-1)
        return {
            "scores": top_scores,
            "indices": top_indices,
        }
