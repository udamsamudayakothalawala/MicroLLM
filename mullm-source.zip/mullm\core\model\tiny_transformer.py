"""
tiny_transformer.py - Configurable small GPT/LLaMA-style transformer from scratch.
Pure PyTorch, no HuggingFace dependency.
"""

import math
import torch
import torch.nn as nn
from dataclasses import dataclass, field
from typing import Optional


@dataclass
class TinyConfig:
    vocab_size: int = 32000
    max_seq_len: int = 2048
    n_layers: int = 6
    n_heads: int = 8
    d_model: int = 512
    d_ff: int = 2048
    dropout: float = 0.1
    rope: bool = True
    flash_attn: bool = False

    def head_dim(self) -> int:
        return self.d_model // self.n_heads

    def num_params(self) -> int:
        approx = (
            self.vocab_size * self.d_model
            + self.n_layers * (4 * self.d_model * self.d_model + 4 * self.d_model * self.d_ff)
            + self.d_model * self.vocab_size
        )
        return approx


class RMSNorm(nn.Module):
    def __init__(self, dim: int, eps: float = 1e-6):
        super().__init__()
        self.eps = eps
        self.weight = nn.Parameter(torch.ones(dim))

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        norm = x.float().pow(2).mean(-1, keepdim=True).add(self.eps).rsqrt()
        return (x.float() * norm).type_as(x) * self.weight


class RotaryEmbedding(nn.Module):
    def __init__(self, dim: int, max_seq_len: int = 2048):
        super().__init__()
        inv_freq = 1.0 / (10000 ** (torch.arange(0, dim, 2).float() / dim))
        self.register_buffer("inv_freq", inv_freq)
        t = torch.arange(max_seq_len).float()
        freqs = torch.outer(t, inv_freq)
        # [seq_len, dim/2] -> expand to [1, 1, seq_len, dim] by repeating
        cos_full = freqs.cos().repeat_interleave(2, dim=-1)
        sin_full = freqs.sin().repeat_interleave(2, dim=-1)
        self.register_buffer("cos_cached", cos_full[None, None, :, :])
        self.register_buffer("sin_cached", sin_full[None, None, :, :])

    def forward(self, x: torch.Tensor, seq_len: int) -> tuple[torch.Tensor, torch.Tensor]:
        return (
            self.cos_cached[:, :, :seq_len, :],
            self.sin_cached[:, :, :seq_len, :],
        )


def rotate_half(x: torch.Tensor) -> torch.Tensor:
    x1, x2 = x.chunk(2, dim=-1)
    return torch.cat((-x2, x1), dim=-1)


def apply_rotary_pos_emb(q, k, cos, sin):
    # cos/sin: [1, 1, T, dim]
    cos = cos[:, :, : q.shape[-2], :]
    sin = sin[:, :, : q.shape[-2], :]
    q_embed = (q * cos) + (rotate_half(q) * sin)
    k_embed = (k * cos) + (rotate_half(k) * sin)
    return q_embed, k_embed


class Attention(nn.Module):
    def __init__(self, config: TinyConfig):
        super().__init__()
        self.n_heads = config.n_heads
        self.head_dim = config.head_dim()
        self.d_model = config.d_model
        self.scale = self.head_dim ** -0.5

        self.q_proj = nn.Linear(config.d_model, config.d_model, bias=False)
        self.k_proj = nn.Linear(config.d_model, config.d_model, bias=False)
        self.v_proj = nn.Linear(config.d_model, config.d_model, bias=False)
        self.o_proj = nn.Linear(config.d_model, config.d_model, bias=False)
        self.attn_dropout = nn.Dropout(config.dropout)

        if config.rope:
            self.rope = RotaryEmbedding(self.head_dim, config.max_seq_len)
        else:
            self.rope = None

    def forward(self, x: torch.Tensor, mask: Optional[torch.Tensor] = None) -> torch.Tensor:
        B, T, C = x.shape
        q = self.q_proj(x).view(B, T, self.n_heads, self.head_dim).transpose(1, 2)
        k = self.k_proj(x).view(B, T, self.n_heads, self.head_dim).transpose(1, 2)
        v = self.v_proj(x).view(B, T, self.n_heads, self.head_dim).transpose(1, 2)

        if self.rope is not None:
            cos, sin = self.rope(x, T)
            q, k = apply_rotary_pos_emb(q, k, cos, sin)

        attn = (q @ k.transpose(-2, -1)) * self.scale
        if mask is not None:
            attn = attn.masked_fill(mask[:, :, :T, :T] == 0, float("-inf"))
        attn = torch.softmax(attn, dim=-1)
        attn = self.attn_dropout(attn)

        out = (attn @ v).transpose(1, 2).contiguous().view(B, T, C)
        return self.o_proj(out)


class FeedForward(nn.Module):
    def __init__(self, config: TinyConfig):
        super().__init__()
        self.w1 = nn.Linear(config.d_model, config.d_ff, bias=False)
        self.w2 = nn.Linear(config.d_ff, config.d_model, bias=False)
        self.w3 = nn.Linear(config.d_model, config.d_ff, bias=False)
        self.dropout = nn.Dropout(config.dropout)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.dropout(self.w2(torch.nn.functional.silu(self.w1(x)) * self.w3(x)))


class TransformerBlock(nn.Module):
    def __init__(self, config: TinyConfig):
        super().__init__()
        self.norm1 = RMSNorm(config.d_model)
        self.attn = Attention(config)
        self.norm2 = RMSNorm(config.d_model)
        self.ffn = FeedForward(config)

    def forward(self, x: torch.Tensor, mask: Optional[torch.Tensor] = None) -> torch.Tensor:
        x = x + self.attn(self.norm1(x), mask)
        x = x + self.ffn(self.norm2(x))
        return x


class TinyTransformer(nn.Module):
    def __init__(self, config: Optional[TinyConfig] = None):
        super().__init__()
        self.config = config or TinyConfig()
        self.embed = nn.Embedding(self.config.vocab_size, self.config.d_model)
        self.drop = nn.Dropout(self.config.dropout)
        self.layers = nn.ModuleList([TransformerBlock(self.config) for _ in range(self.config.n_layers)])
        self.norm = RMSNorm(self.config.d_model)
        self.head = nn.Linear(self.config.d_model, self.config.vocab_size, bias=False)
        self.embed.weight = self.head.weight

        mask = torch.tril(torch.ones(self.config.max_seq_len, self.config.max_seq_len))
        self.register_buffer("mask", mask.view(1, 1, self.config.max_seq_len, self.config.max_seq_len))

        self.apply(self._init_weights)

    def _init_weights(self, module):
        if isinstance(module, nn.Linear):
            torch.nn.init.normal_(module.weight, mean=0.0, std=0.02)
            if module.bias is not None:
                torch.nn.init.zeros_(module.bias)
        elif isinstance(module, nn.Embedding):
            torch.nn.init.normal_(module.weight, mean=0.0, std=0.02)

    def forward(
        self,
        input_ids: torch.Tensor,
        labels: Optional[torch.Tensor] = None,
    ) -> dict:
        x = self.drop(self.embed(input_ids))
        for layer in self.layers:
            x = layer(x, self.mask)
        x = self.norm(x)
        logits = self.head(x)

        loss = None
        if labels is not None:
            shift_logits = logits[:, :-1, :].contiguous()
            shift_labels = labels[:, 1:].contiguous()
            loss = torch.nn.functional.cross_entropy(
                shift_logits.view(-1, self.config.vocab_size),
                shift_labels.view(-1),
                ignore_index=0,
            )

        return {"logits": logits, "loss": loss}

    def count_parameters(self) -> int:
        return sum(p.numel() for p in self.parameters() if p.requires_grad)


TINY_CONFIGS = {
    "tiny": TinyConfig(n_layers=4, n_heads=4, d_model=256, d_ff=1024),
    "small": TinyConfig(n_layers=6, n_heads=8, d_model=512, d_ff=2048),
    "base": TinyConfig(n_layers=12, n_heads=12, d_model=768, d_ff=3072),
    "medium": TinyConfig(n_layers=24, n_heads=16, d_model=1024, d_ff=4096),
}
