import torch
import pytest


class TestAttention:
    def test_multi_head_attention_shapes(self, model_config):
        from mullm.core.model.attention import MultiHeadAttention
        attn = MultiHeadAttention(
            hidden_size=model_config.hidden_size,
            num_heads=model_config.num_attention_heads,
        )
        batch, seq, hidden = 2, 16, model_config.hidden_size
        x = torch.randn(batch, seq, hidden)
        mask = torch.ones(batch, 1, seq, seq, dtype=torch.bool).tril()
        output, weights = attn(x, mask)
        assert output.shape == (batch, seq, hidden)
        assert weights.shape == (batch, model_config.num_attention_heads, seq, seq)

    def test_grouped_query_attention_shapes(self, model_config):
        from mullm.core.model.attention import GroupedQueryAttention
        attn = GroupedQueryAttention(
            hidden_size=model_config.hidden_size,
            num_heads=model_config.num_attention_heads,
            num_kv_heads=model_config.num_kv_heads,
        )
        batch, seq, hidden = 2, 16, model_config.hidden_size
        x = torch.randn(batch, seq, hidden)
        mask = torch.ones(batch, 1, seq, seq, dtype=torch.bool).tril()
        output, weights = attn(x, mask)
        assert output.shape == (batch, seq, hidden)

    def test_sliding_window_attention(self, model_config):
        from mullm.core.model.attention import SlidingWindowAttention
        attn = SlidingWindowAttention(
            hidden_size=model_config.hidden_size,
            num_heads=model_config.num_attention_heads,
            window_size=4,
        )
        batch, seq, hidden = 2, 16, model_config.hidden_size
        x = torch.randn(batch, seq, hidden)
        output, weights = attn(x)
        assert output.shape == (batch, seq, hidden)

    def test_kv_cache(self, model_config):
        from mullm.core.model.attention import KVCache
        cache = KVCache(max_batch_size=2, max_seq_length=128, num_heads=4, head_dim=16)
        key = torch.randn(2, 4, 8, 16)
        value = torch.randn(2, 4, 8, 16)
        cache.update(key, value, 0)
        cached_k, cached_v = cache.get(0)
        assert cached_k.shape[-2] == 8
        key2 = torch.randn(2, 4, 4, 16)
        value2 = torch.randn(2, 4, 4, 16)
        cache.update(key2, value2, 0)
        cached_k2, cached_v2 = cache.get(0)
        assert cached_k2.shape[-2] == 12


class TestPositionalEncoding:
    def test_rope_encoding(self, model_config):
        from mullm.core.model.positional import RotaryPositionalEmbedding
        rope = RotaryPositionalEmbedding(dim=model_config.hidden_size // model_config.num_attention_heads, max_seq_len=128)
        batch, seq, hidden = 2, 16, model_config.hidden_size
        x = torch.randn(batch, model_config.num_attention_heads, seq, hidden // model_config.num_attention_heads)
        output = rope(x, torch.arange(seq).unsqueeze(0).expand(batch, -1))
        assert output.shape == x.shape
        assert not torch.allclose(output, x)

    def test_alibi_encoding(self):
        from mullm.core.model.positional import ALiBi
        alibi = ALiBi(num_heads=4)
        batch, seq = 2, 16
        bias = alibi(batch, seq)
        assert bias.shape == (batch, 4, seq, seq)

    def test_absolute_embedding(self, model_config):
        from mullm.core.model.positional import AbsolutePositionalEmbedding
        embed = AbsolutePositionalEmbedding(128, model_config.hidden_size)
        x = torch.randn(2, 16, model_config.hidden_size)
        output = embed(x, torch.arange(16).unsqueeze(0).expand(2, -1))
        assert output.shape == x.shape


class TestNormalization:
    def test_rms_norm(self, model_config):
        from mullm.core.model.normalization import RMSNorm
        rms = RMSNorm(model_config.hidden_size)
        x = torch.randn(2, 16, model_config.hidden_size)
        output = rms(x)
        assert output.shape == x.shape
        assert not torch.allclose(output, x)

    def test_layer_norm(self):
        from mullm.core.model.normalization import LayerNorm
        ln = LayerNorm(64)
        x = torch.randn(2, 16, 64)
        output = ln(x)
        assert output.shape == x.shape


class TestActivation:
    def test_gelu(self):
        from mullm.core.model.activation import GELU
        gelu = GELU(approximate="tanh")
        x = torch.randn(2, 16, 64)
        output = gelu(x)
        assert output.shape == x.shape

    def test_silu(self):
        from mullm.core.model.activation import SiLU
        silu = SiLU()
        x = torch.randn(2, 16, 64)
        output = silu(x)
        assert output.shape == x.shape

    def test_swiglu(self):
        from mullm.core.model.activation import SwiGLU
        swiglu = SwiGLU(hidden_size=64, intermediate_size=256)
        x = torch.randn(2, 16, 64)
        output = swiglu(x)
        assert output.shape[-1] == 64


class TestFeedForward:
    def test_standard_ffn(self, model_config):
        from mullm.core.model.feedforward import FeedForward
        ffn = FeedForward(model_config.hidden_size, model_config.intermediate_size)
        x = torch.randn(2, 16, model_config.hidden_size)
        output = ffn(x)
        assert output.shape == x.shape

    def test_gated_ffn(self, model_config):
        from mullm.core.model.feedforward import GatedFeedForward
        ffn = GatedFeedForward(model_config.hidden_size, model_config.intermediate_size)
        x = torch.randn(2, 16, model_config.hidden_size)
        output = ffn(x)
        assert output.shape == x.shape


class TestTransformer:
    def test_decoder_layer(self, model_config):
        from mullm.core.model.transformer import TransformerDecoderLayer
        layer = TransformerDecoderLayer(
            hidden_size=model_config.hidden_size,
            num_heads=model_config.num_attention_heads,
            intermediate_size=model_config.intermediate_size,
        )
        batch, seq = 2, 16
        x = torch.randn(batch, seq, model_config.hidden_size)
        mask = torch.ones(batch, 1, seq, seq, dtype=torch.bool).tril()
        output = layer(x, mask)
        assert output.shape == x.shape

    def test_full_decoder(self, model_config):
        from mullm.core.model.transformer import TransformerDecoder
        decoder = TransformerDecoder(
            vocab_size=model_config.vocab_size,
            hidden_size=model_config.hidden_size,
            num_layers=model_config.num_layers,
            num_heads=model_config.num_attention_heads,
            intermediate_size=model_config.intermediate_size,
            max_position_embeddings=model_config.max_position_embeddings,
        )
        batch, seq = 2, 16
        input_ids = torch.randint(0, model_config.vocab_size, (batch, seq))
        output = decoder(input_ids)
        assert output.shape == (batch, seq, model_config.hidden_size)


class TestModel:
    def test_llama_forward(self, llama_model, input_ids):
        output = llama_model(input_ids)
        assert output.shape == (2, 16, 1000)

    def test_gpt_forward(self, model_config, input_ids):
        from mullm.core.model.model import GPTModel
        model = GPTModel(model_config)
        output = model(input_ids)
        assert output.shape == (2, 16, model_config.vocab_size)

    def test_mistral_forward(self, model_config, input_ids):
        from mullm.core.model.model import MistralModel
        model_config.attention_type = "sliding_window"
        model_config.sliding_window = 64
        model = MistralModel(model_config)
        output = model(input_ids)
        assert output.shape == (2, 16, model_config.vocab_size)

    def test_base_causal_lm(self, model_config, input_ids):
        from mullm.core.model.model import LlamaModel
        model = LlamaModel(model_config)
        logits = model(input_ids)
        labels = input_ids.clone()
        loss = model.compute_loss(logits, labels)
        assert loss is not None
        assert loss.item() > 0

    def test_model_generate(self, model_config):
        from mullm.core.model.model import LlamaModel
        model = LlamaModel(model_config)
        model.eval()
        input_ids = torch.randint(0, model_config.vocab_size, (1, 8))
        with torch.no_grad():
            output = model.generate(input_ids, max_new_tokens=4, temperature=0.0)
        assert output.shape == (1, 12)

    def test_model_config_presets(self):
        from mullm.core.model.config import ModelFactory
        configs = ["125m", "350m", "760m", "1.3b", "2.7b", "6.7b", "13b", "70b"]
        for name in configs:
            config = ModelFactory.get_config("llama", name)
            assert config is not None
            assert hasattr(config, "hidden_size")
