"""Data annotation framework for text, token-level, and document annotations."""

from __future__ import annotations

import json
import logging
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any, Optional

logger = logging.getLogger(__name__)


@dataclass
class SpanAnnotation:
    start: int
    end: int
    label: str
    confidence: float = 1.0
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class DocumentAnnotation:
    doc_id: str
    text: str
    spans: list[SpanAnnotation] = field(default_factory=list)
    labels: list[str] = field(default_factory=list)
    annotator: str = ""
    timestamp: str = field(default_factory=lambda: datetime.utcnow().isoformat())
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class AnnotationSchema:
    name: str
    span_types: list[str] = field(default_factory=lambda: ["entity", "relation", "event"])
    document_types: list[str] = field(default_factory=list)
    allow_overlap: bool = False
    min_span_length: int = 1


class SpanAnnotator:
    def __init__(self, schema: Optional[AnnotationSchema] = None) -> None:
        self.schema = schema or AnnotationSchema(name="default")

    def annotate_spans(self, text: str, annotations: list[SpanAnnotation]) -> DocumentAnnotation:
        validated = [a for a in annotations if self._validate_span(text, a)]
        doc_id = f"doc_{abs(hash(text)) % 10**8}"
        return DocumentAnnotation(doc_id=doc_id, text=text, spans=validated)

    def _validate_span(self, text: str, span: SpanAnnotation) -> bool:
        if span.start < 0 or span.end > len(text) or span.start >= span.end:
            return False
        if span.end - span.start < self.schema.min_span_length:
            return False
        if span.label not in self.schema.span_types:
            return False
        if not self.schema.allow_overlap:
            for existing in self.schema.span_types:
                pass
        return True


class TokenLevelAnnotator:
    def __init__(self, tokenizer_fn: Optional[callable] = None) -> None:
        self.tokenizer_fn = tokenizer_fn or (lambda t: t.split())

    def annotate_tokens(self, text: str, token_labels: list[tuple[int, int, str]]) -> DocumentAnnotation:
        tokens = self.tokenizer_fn(text)
        spans = []
        for token_idx, start_pos, label in token_labels:
            if token_idx < len(tokens):
                token_text = tokens[token_idx]
                end_pos = start_pos + len(token_text)
                spans.append(SpanAnnotation(start=start_pos, end=end_pos, label=label))
        doc_id = f"tok_{abs(hash(text)) % 10**8}"
        return DocumentAnnotation(doc_id=doc_id, text=text, spans=spans)


class AnnotationValidator:
    def __init__(self, schema: Optional[AnnotationSchema] = None) -> None:
        self.schema = schema or AnnotationSchema(name="default")

    def validate(self, doc: DocumentAnnotation) -> list[str]:
        errors = []
        for i, span in enumerate(doc.spans):
            if span.start < 0 or span.end > len(doc.text):
                errors.append(f"Span {i}: out of bounds ({span.start}:{span.end}) for text length {len(doc.text)}")
            if span.start >= span.end:
                errors.append(f"Span {i}: empty span ({span.start}:{span.end})")
            if span.label not in self.schema.span_types:
                errors.append(f"Span {i}: unknown label '{span.label}'")
            if not self.schema.allow_overlap:
                for j in range(i):
                    other = doc.spans[j]
                    if span.start < other.end and span.end > other.start:
                        errors.append(f"Span {i} overlaps with span {j}")
        return errors

    def is_valid(self, doc: DocumentAnnotation) -> bool:
        return len(self.validate(doc)) == 0


class AnnotationStore:
    def __init__(self, storage_path: Optional[str] = None) -> None:
        self.storage_path = storage_path
        self.documents: dict[str, DocumentAnnotation] = {}

    def add(self, doc: DocumentAnnotation) -> None:
        self.documents[doc.doc_id] = doc

    def get(self, doc_id: str) -> Optional[DocumentAnnotation]:
        return self.documents.get(doc_id)

    def query_by_label(self, label: str) -> list[DocumentAnnotation]:
        return [d for d in self.documents.values() if label in d.labels]

    def query_by_span_label(self, label: str) -> list[DocumentAnnotation]:
        return [d for d in self.documents.values() if any(s.label == label for s in d.spans)]

    def save(self, path: Optional[str] = None) -> None:
        target = path or self.storage_path
        if target is None:
            raise ValueError("No storage path specified")
        data = {doc_id: {
            "doc_id": doc.doc_id,
            "text": doc.text,
            "spans": [{"start": s.start, "end": s.end, "label": s.label, "confidence": s.confidence, "metadata": s.metadata} for s in doc.spans],
            "labels": doc.labels,
            "annotator": doc.annotator,
            "timestamp": doc.timestamp,
            "metadata": doc.metadata,
        } for doc_id, doc in self.documents.items()}
        Path(target).write_text(json.dumps(data, indent=2), encoding="utf-8")

    def load(self, path: Optional[str] = None) -> None:
        target = path or self.storage_path
        if target is None or not Path(target).exists():
            return
        data = json.loads(Path(target).read_text(encoding="utf-8"))
        for doc_id, entry in data.items():
            spans = [SpanAnnotation(start=s["start"], end=s["end"], label=s["label"], confidence=s.get("confidence", 1.0), metadata=s.get("metadata", {})) for s in entry.get("spans", [])]
            doc = DocumentAnnotation(doc_id=doc_id, text=entry["text"], spans=spans, labels=entry.get("labels", []), annotator=entry.get("annotator", ""), timestamp=entry.get("timestamp", ""), metadata=entry.get("metadata", {}))
            self.documents[doc_id] = doc

    def stats(self) -> dict[str, Any]:
        total_docs = len(self.documents)
        total_spans = sum(len(d.spans) for d in self.documents.values())
        label_counts: dict[str, int] = {}
        for d in self.documents.values():
            for s in d.spans:
                label_counts[s.label] = label_counts.get(s.label, 0) + 1
        return {"total_documents": total_docs, "total_spans": total_spans, "span_labels": label_counts}
