import math
import re
from collections import Counter, defaultdict
from typing import Dict, List, Optional, Sequence, Set, Tuple

from .base import BaseTokenizer


class VocabCompressor:
    def __init__(self, tokenizer: BaseTokenizer) -> None:
        self._tokenizer = tokenizer

    def analyze_token_frequencies(
        self, texts: Sequence[str]
    ) -> Dict[int, int]:
        freq: Counter[int] = Counter()
        for text in texts:
            ids = self._tokenizer.encode(text, add_special_tokens=False)
            freq.update(ids)
        return dict(freq)

    def prune_rare_tokens(
        self,
        texts: Sequence[str],
        min_frequency: int = 5,
        preserve_special: bool = True,
    ) -> Tuple[Dict[str, int], List[str]]:
        freq = self.analyze_token_frequencies(texts)
        special_ids = set(self._tokenizer.all_special_ids()) if preserve_special else set()

        removed_tokens: List[str] = []
        preserved_vocab: Dict[str, int] = {}

        for tid in range(self._tokenizer.vocab_size):
            token = self._tokenizer.convert_ids_to_tokens(tid)
            token_str = str(token)
            if tid in special_ids:
                preserved_vocab[token_str] = tid
            elif freq.get(tid, 0) >= min_frequency:
                preserved_vocab[token_str] = tid
            else:
                removed_tokens.append(token_str)

        return preserved_vocab, removed_tokens

    def apply_pruning(
        self,
        texts: Sequence[str],
        min_frequency: int = 5,
        preserve_special: bool = True,
        new_unk_token: str = "<unk>",
    ) -> BaseTokenizer:
        preserved, removed = self.prune_rare_tokens(
            texts, min_frequency, preserve_special
        )
        return self._rebuild_tokenizer(preserved, new_unk_token)

    def find_similar_tokens(
        self,
        similarity_threshold: float = 0.7,
        max_pairs: int = 100,
    ) -> List[Tuple[str, str, float]]:
        tokens: List[str] = []
        for tid in range(self._tokenizer.vocab_size):
            token = self._tokenizer.convert_ids_to_tokens(tid)
            token_str = str(token)
            if not token_str.startswith("<") and not token_str.startswith("##"):
                tokens.append(token_str)

        similar_pairs: List[Tuple[str, str, float]] = []
        for i in range(len(tokens)):
            for j in range(i + 1, len(tokens)):
                sim = self._levenshtein_similarity(tokens[i], tokens[j])
                if sim >= similarity_threshold:
                    similar_pairs.append((tokens[i], tokens[j], sim))
                    if len(similar_pairs) >= max_pairs:
                        break
            if len(similar_pairs) >= max_pairs:
                break

        similar_pairs.sort(key=lambda x: x[2], reverse=True)
        return similar_pairs

    def _levenshtein_similarity(self, a: str, b: str) -> float:
        if not a and not b:
            return 1.0
        if len(a) < len(b):
            a, b = b, a
        m, n = len(a), len(b)
        prev = list(range(n + 1))
        for i in range(1, m + 1):
            curr = [i] + [0] * n
            for j in range(1, n + 1):
                cost = 0 if a[i - 1] == b[j - 1] else 1
                curr[j] = min(
                    prev[j] + 1,
                    curr[j - 1] + 1,
                    prev[j - 1] + cost,
                )
            prev = curr
        distance = prev[n]
        max_len = max(len(a), len(b))
        if max_len == 0:
            return 1.0
        return 1.0 - (distance / max_len)

    def merge_similar_tokens(
        self,
        texts: Sequence[str],
        similarity_threshold: float = 0.85,
        preserve_special: bool = True,
    ) -> BaseTokenizer:
        freq = self.analyze_token_frequencies(texts)
        similar_pairs = self.find_similar_tokens(
            similarity_threshold=similarity_threshold
        )

        special_ids = set(self._tokenizer.all_special_ids()) if preserve_special else set()
        special_tokens = {
            str(self._tokenizer.convert_ids_to_tokens(sid)): sid
            for sid in special_ids
        }

        new_vocab: Dict[str, int] = dict(special_tokens)
        removed_tokens: Set[str] = set()

        for token_a, token_b, _ in similar_pairs:
            tid_a = self._tokenizer.convert_tokens_to_ids(token_a)
            tid_b = self._tokenizer.convert_tokens_to_ids(token_b)
            if isinstance(tid_a, list):
                tid_a = tid_a[0] if tid_a else 0
            if isinstance(tid_b, list):
                tid_b = tid_b[0] if tid_b else 0

            freq_a = freq.get(int(tid_a), 0)
            freq_b = freq.get(int(tid_b), 0)

            if token_a in removed_tokens or token_b in removed_tokens:
                continue

            if freq_a >= freq_b:
                new_vocab[token_a] = len(new_vocab)
                removed_tokens.add(token_b)
            else:
                new_vocab[token_b] = len(new_vocab)
                removed_tokens.add(token_a)

        for tid in range(self._tokenizer.vocab_size):
            token = self._tokenizer.convert_ids_to_tokens(tid)
            token_str = str(token)
            if token_str not in new_vocab and token_str not in removed_tokens and token_str not in special_tokens:
                new_vocab[token_str] = len(new_vocab)

        if len(new_vocab) == 0:
            return self._rebuild_tokenizer({unk_token: 0}, "<unk>")

        return self._rebuild_tokenizer(new_vocab, "<unk>")

    def _rebuild_tokenizer(
        self, vocab: Dict[str, int], unk_token: str = "<unk>"
    ) -> BaseTokenizer:
        original_class = type(self._tokenizer)
        import copy

        new_tokenizer = copy.copy(self._tokenizer)
        new_tokenizer._vocab = dict(vocab)
        new_tokenizer._decoder = {v: k for k, v in vocab.items()}
        new_tokenizer._added_tokens = {}
        new_tokenizer._added_tokens_decoder = {}

        if unk_token not in vocab:
            idx = len(vocab)
            new_tokenizer._vocab[unk_token] = idx
            new_tokenizer._decoder[idx] = unk_token

        return new_tokenizer

    def lossless_compress_vocab(
        self,
        texts: Sequence[str],
    ) -> Tuple[Dict[str, int], Dict[str, str]]:
        freq = self.analyze_token_frequencies(texts)

        token_replacement: Dict[str, str] = {}
        new_vocab: Dict[str, int] = {}

        special_ids = set(self._tokenizer.all_special_ids())
        for sid in special_ids:
            st = str(self._tokenizer.convert_ids_to_tokens(sid))
            new_vocab[st] = len(new_vocab)

        for tid, count in sorted(freq.items(), key=lambda x: -x[1]):
            token = self._tokenizer.convert_ids_to_tokens(tid)
            token_str = str(token)
            if len(token_str) <= 3:
                if token_str not in new_vocab:
                    new_vocab[token_str] = len(new_vocab)
                continue

            if token_str not in new_vocab:
                new_vocab[token_str] = len(new_vocab)

        for tid in range(self._tokenizer.vocab_size):
            token = self._tokenizer.convert_ids_to_tokens(tid)
            token_str = str(token)
            if token_str not in new_vocab and token_str not in token_replacement:
                token_replacement[token_str] = "<unk>"

        return new_vocab, token_replacement

    def optimize_vocab_size(
        self,
        texts: Sequence[str],
        target_size: int,
        pruning_ratio: float = 0.3,
    ) -> BaseTokenizer:
        freq = self.analyze_token_frequencies(texts)
        current_size = self._tokenizer.vocab_size

        if current_size <= target_size:
            return self._tokenizer

        sorted_by_freq = sorted(freq.items(), key=lambda x: -x[1])
        num_to_prune = current_size - target_size
        num_to_keep = current_size - num_to_prune

        if len(sorted_by_freq) >= num_to_keep:
            kept_ids = {tid for tid, _ in sorted_by_freq[:num_to_keep]}
        else:
            kept_ids = {tid for tid, _ in sorted_by_freq}
            remaining = current_size - len(kept_ids)
            extra_needed = min(remaining, num_to_keep - len(kept_ids))
            all_ids = set(range(current_size))
            unused = all_ids - kept_ids
            for tid in list(unused)[:extra_needed]:
                kept_ids.add(tid)

        special_ids = set(self._tokenizer.all_special_ids())
        for sid in special_ids:
            kept_ids.add(sid)

        new_vocab: Dict[str, int] = {}
        for tid in sorted(kept_ids):
            token = self._tokenizer.convert_ids_to_tokens(tid)
            new_vocab[str(token)] = len(new_vocab)

        unk = str(self._tokenizer._special_tokens.unk_token or "<unk>")
        if unk not in new_vocab:
            new_vocab[unk] = len(new_vocab)

        return self._rebuild_tokenizer(new_vocab, unk)

    def compress_report(
        self, texts: Sequence[str]
    ) -> Dict[str, object]:
        preserved, removed = self.prune_rare_tokens(texts, min_frequency=1)
        freq = self.analyze_token_frequencies(texts)

        total_tokens_used = sum(freq.values())
        zero_freq_tokens = self._tokenizer.vocab_size - len(freq)

        sizes: List[int] = []
        for tid in range(self._tokenizer.vocab_size):
            token = self._tokenizer.convert_ids_to_tokens(tid)
            sizes.append(len(str(token)))

        avg_token_len = sum(sizes) / len(sizes) if sizes else 0

        return {
            "original_vocab_size": self._tokenizer.vocab_size,
            "tokens_with_usage": len(freq),
            "tokens_with_zero_freq": zero_freq_tokens,
            "removable_rare_tokens": len(removed),
            "total_token_occurrences": total_tokens_used,
            "average_token_length": avg_token_len,
            "max_token_length": max(sizes) if sizes else 0,
            "min_token_length": min(sizes) if sizes else 0,
            "savings_from_rare_pruning": len(removed),
            "savings_percentage": (
                (len(removed) / self._tokenizer.vocab_size) * 100
                if self._tokenizer.vocab_size > 0
                else 0.0
            ),
        }
