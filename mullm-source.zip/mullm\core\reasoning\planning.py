"""Planning system for step-by-step plan generation and execution."""

from __future__ import annotations

import json
import time
import uuid
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any, Callable, Dict, List, Optional, Set, Tuple


class PlanStepStatus(Enum):
    PENDING = "pending"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    FAILED = "failed"
    SKIPPED = "skipped"
    BLOCKED = "blocked"


@dataclass
class PlanStep:
    id: str = field(default_factory=lambda: str(uuid.uuid4())[:8])
    description: str = ""
    action: str = ""
    dependencies: List[str] = field(default_factory=list)
    status: PlanStepStatus = PlanStepStatus.PENDING
    result: Optional[Any] = None
    error: Optional[str] = None
    execution_time: Optional[float] = None
    metadata: Dict[str, Any] = field(default_factory=list)

    def __post_init__(self) -> None:
        if isinstance(self.metadata, list):
            self.metadata = {}

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "description": self.description,
            "action": self.action,
            "dependencies": self.dependencies,
            "status": self.status.value,
            "result": self.result,
            "error": self.error,
            "execution_time": self.execution_time,
            "metadata": self.metadata,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "PlanStep":
        status = PlanStepStatus(data.get("status", "pending"))
        return cls(
            id=data.get("id", ""),
            description=data.get("description", ""),
            action=data.get("action", ""),
            dependencies=data.get("dependencies", []),
            status=status,
            result=data.get("result"),
            error=data.get("error"),
            execution_time=data.get("execution_time"),
            metadata=data.get("metadata", {}),
        )


@dataclass
class Plan:
    id: str = field(default_factory=lambda: str(uuid.uuid4())[:8])
    goal: str = ""
    steps: List[PlanStep] = field(default_factory=list)
    status: PlanStepStatus = PlanStepStatus.PENDING
    created_at: datetime = field(default_factory=datetime.utcnow)
    updated_at: datetime = field(default_factory=datetime.utcnow)
    metadata: Dict[str, Any] = field(default_factory=dict)

    @property
    def completed(self) -> bool:
        return self.status == PlanStepStatus.COMPLETED

    @property
    def progress(self) -> float:
        if not self.steps:
            return 0.0
        completed = sum(1 for s in self.steps if s.status == PlanStepStatus.COMPLETED)
        return completed / len(self.steps)

    @property
    def current_step(self) -> Optional[PlanStep]:
        for step in self.steps:
            if step.status in (PlanStepStatus.PENDING, PlanStepStatus.IN_PROGRESS):
                return step
        return None

    @property
    def failed_steps(self) -> List[PlanStep]:
        return [s for s in self.steps if s.status == PlanStepStatus.FAILED]

    def get_ready_steps(self) -> List[PlanStep]:
        ready: List[PlanStep] = []
        step_map = {s.id: s for s in self.steps}
        for step in self.steps:
            if step.status != PlanStepStatus.PENDING:
                continue
            deps_met = True
            for dep_id in step.dependencies:
                dep = step_map.get(dep_id)
                if dep and dep.status != PlanStepStatus.COMPLETED:
                    deps_met = False
                    break
            if deps_met:
                ready.append(step)
        return ready

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "goal": self.goal,
            "steps": [s.to_dict() for s in self.steps],
            "status": self.status.value,
            "created_at": self.created_at.isoformat(),
            "updated_at": self.updated_at.isoformat(),
            "metadata": self.metadata,
            "progress": self.progress,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Plan":
        return cls(
            id=data.get("id", ""),
            goal=data.get("goal", ""),
            steps=[PlanStep.from_dict(s) for s in data.get("steps", [])],
            status=PlanStepStatus(data.get("status", "pending")),
            created_at=datetime.fromisoformat(data["created_at"]) if "created_at" in data else datetime.utcnow(),
            updated_at=datetime.fromisoformat(data["updated_at"]) if "updated_at" in data else datetime.utcnow(),
            metadata=data.get("metadata", {}),
        )


class Planner:
    def __init__(
        self,
        llm_generate: Optional[Callable[[str], str]] = None,
        decomposition_prompt: str = "",
    ) -> None:
        self.llm_generate = llm_generate
        self.decomposition_prompt = decomposition_prompt or (
            "You are a planning assistant. Break down the following goal into "
            "a step-by-step plan. For each step, provide:\n"
            "- id: a short unique identifier\n"
            "- description: what this step does\n"
            "- action: the specific action to take\n"
            "- dependencies: list of step ids that must be completed first\n\n"
            "Output a JSON list of steps:\n"
            '```json\n[{"id": "step1", "description": "...", "action": "...", "dependencies": []}]\n```'
        )

    def create_plan(self, goal: str, context: Optional[Dict[str, Any]] = None) -> Plan:
        plan = Plan(goal=goal)
        if self.llm_generate:
            prompt = f"{self.decomposition_prompt}\n\nGoal: {goal}\n"
            if context:
                prompt += f"\nContext: {json.dumps(context, indent=2)}\n"
            response = self.llm_generate(prompt)
            steps = self._parse_steps_from_response(response)
            plan.steps = steps
        else:
            plan.steps = self._default_decomposition(goal)
        plan.status = PlanStepStatus.PENDING
        return plan

    def _parse_steps_from_response(self, response: str) -> List[PlanStep]:
        json_match = None
        for pattern in (r'```json\s*(.*?)\s*```', r'```\s*(.*?)\s*```', r'(\[.*\])'):
            import re
            match = re.search(pattern, response, re.DOTALL)
            if match:
                json_match = match.group(1)
                break

        if json_match is None:
            json_match = response.strip()

        try:
            data = json.loads(json_match)
            if isinstance(data, list):
                return [PlanStep(**item) for item in data]
        except (json.JSONDecodeError, TypeError, ValueError):
            pass

        return self._default_decomposition(response[:100])

    def _default_decomposition(self, goal: str) -> List[PlanStep]:
        return [
            PlanStep(
                id="step1",
                description=f"Analyze goal: {goal}",
                action="analyze",
                dependencies=[],
            ),
            PlanStep(
                id="step2",
                description="Gather required information",
                action="gather",
                dependencies=["step1"],
            ),
            PlanStep(
                id="step3",
                description="Execute primary actions",
                action="execute",
                dependencies=["step2"],
            ),
            PlanStep(
                id="step4",
                description="Verify and finalize results",
                action="verify",
                dependencies=["step3"],
            ),
        ]


class PlanExecutor:
    def __init__(
        self,
        step_executor: Optional[Callable[[PlanStep, Plan], PlanStep]] = None,
        max_concurrent: int = 1,
    ) -> None:
        self.step_executor = step_executor
        self.max_concurrent = max_concurrent

    def execute(self, plan: Plan, context: Optional[Dict[str, Any]] = None) -> Plan:
        plan.status = PlanStepStatus.IN_PROGRESS
        plan.updated_at = datetime.utcnow()

        completed_steps: Set[str] = set()
        max_iterations = len(plan.steps) * 2
        iterations = 0

        while len(completed_steps) < len(plan.steps) and iterations < max_iterations:
            iterations += 1
            ready = plan.get_ready_steps()

            if not ready:
                all_blocked = all(
                    s.status == PlanStepStatus.BLOCKED or s.status == PlanStepStatus.FAILED
                    for s in plan.steps
                )
                if all_blocked:
                    break
                if not any(s.status == PlanStepStatus.PENDING for s in plan.steps):
                    break

            for step in ready[:self.max_concurrent]:
                step.status = PlanStepStatus.IN_PROGRESS
                start = time.monotonic()
                try:
                    if self.step_executor:
                        result = self.step_executor(step, plan)
                        step.status = result.status
                        step.result = result.result
                        step.error = result.error
                    else:
                        step.status = PlanStepStatus.COMPLETED
                        step.result = f"Executed: {step.action}"
                except Exception as e:
                    step.status = PlanStepStatus.FAILED
                    step.error = str(e)
                step.execution_time = time.monotonic() - start

                if step.status == PlanStepStatus.COMPLETED:
                    completed_steps.add(step.id)
                elif step.status == PlanStepStatus.FAILED:
                    for other in plan.steps:
                        if step.id in other.dependencies:
                            other.status = PlanStepStatus.BLOCKED

        plan.updated_at = datetime.utcnow()

        all_completed = all(
            s.status == PlanStepStatus.COMPLETED for s in plan.steps
        )
        plan.status = PlanStepStatus.COMPLETED if all_completed else PlanStepStatus.FAILED
        return plan

    def execute_step(self, step: PlanStep, plan: Plan) -> PlanStep:
        if self.step_executor:
            return self.step_executor(step, plan)
        step.status = PlanStepStatus.COMPLETED
        return step


class PlanVerifier:
    def __init__(
        self,
        verify_fn: Optional[Callable[[Plan], Tuple[bool, List[str]]]] = None,
    ) -> None:
        self.verify_fn = verify_fn

    def verify(self, plan: Plan) -> Tuple[bool, List[str]]:
        if self.verify_fn:
            return self.verify_fn(plan)
        return self._default_verify(plan)

    def _default_verify(self, plan: Plan) -> Tuple[bool, List[str]]:
        issues: List[str] = []
        if not plan.goal:
            issues.append("Plan has no goal")
        if not plan.steps:
            issues.append("Plan has no steps")

        step_ids: Set[str] = set()
        for step in plan.steps:
            if step.id in step_ids:
                issues.append(f"Duplicate step id: {step.id}")
            step_ids.add(step.id)
            for dep in step.dependencies:
                if dep not in step_ids and dep not in [s.id for s in plan.steps]:
                    issues.append(f"Step '{step.id}' depends on unknown step '{dep}'")

        if plan.status == PlanStepStatus.COMPLETED:
            failed = [s for s in plan.steps if s.status == PlanStepStatus.FAILED]
            if failed:
                issues.append(f"{len(failed)} step(s) failed but plan marked completed")
        elif plan.status == PlanStepStatus.FAILED:
            non_failed = [s for s in plan.steps if s.status == PlanStepStatus.COMPLETED]
            if len(non_failed) == len(plan.steps):
                issues.append("All steps completed but plan marked failed")

        return len(issues) == 0, issues


class ReplanningHandler:
    def __init__(
        self,
        planner: Planner,
        max_replans: int = 3,
    ) -> None:
        self.planner = planner
        self.max_replans = max_replans
        self.replan_count = 0

    def handle_failure(
        self,
        plan: Plan,
        failed_step: PlanStep,
        context: Optional[Dict[str, Any]] = None,
    ) -> Optional[Plan]:
        if self.replan_count >= self.max_replans:
            return None

        self.replan_count += 1
        new_goal = (
            f"Continue from step '{failed_step.id}' which failed with "
            f"error: {failed_step.error}. Original goal: {plan.goal}"
        )
        if context:
            new_goal += f"\nContext: {json.dumps(context, indent=2)}"

        new_plan = self.planner.create_plan(new_goal)

        completed = [s for s in plan.steps if s.status == PlanStepStatus.COMPLETED]
        new_plan.steps = completed + new_plan.steps

        for step in new_plan.steps:
            step.dependencies = [
                d for d in step.dependencies if d in {s.id for s in completed}
            ]

        return new_plan


class ChainOfThoughtPlanner(Planner):
    def __init__(
        self,
        llm_generate: Optional[Callable[[str], str]] = None,
    ) -> None:
        cot_prompt = (
            "You are a step-by-step reasoner. Think through the following problem "
            "carefully, breaking it down into logical steps. For each step, explain "
            "your reasoning, then specify the action.\n\n"
            "Format your response as a JSON list:\n"
            '```json\n[{"id": "step1", "description": "Step description with reasoning", "action": "action_to_take", "dependencies": []}]\n```'
        )
        super().__init__(llm_generate=llm_generate, decomposition_prompt=cot_prompt)

    def reason(self, prompt: str, context: Optional[Dict[str, Any]] = None) -> str:
        plan = self.create_plan(prompt, context)
        reasoning_parts: List[str] = []
        for step in plan.steps:
            reasoning_parts.append(f"Step {step.id}: {step.description}")
            reasoning_parts.append(f"  Action: {step.action}")
        return "\n".join(reasoning_parts)


class ReActPlanner:
    def __init__(
        self,
        llm_generate: Callable[[str], str],
        max_steps: int = 10,
    ) -> None:
        self.llm_generate = llm_generate
        self.max_steps = max_steps

    def run(self, task: str, tools: Optional[List[Dict[str, Any]]] = None) -> List[Dict[str, str]]:
        trajectory: List[Dict[str, str]] = []
        thought_history: List[str] = []
        step = 0

        while step < self.max_steps:
            prompt = self._build_react_prompt(task, trajectory, tools)
            response = self.llm_generate(prompt)

            thought = self._extract_thought(response)
            action = self._extract_action(response)
            observation = self._extract_observation(response)

            trajectory.append({
                "step": str(step),
                "thought": thought or "",
                "action": action or "",
                "observation": observation or "",
            })

            if self._is_finished(response) or (action is None and observation is None):
                break
            step += 1

        return trajectory

    def _build_react_prompt(
        self,
        task: str,
        trajectory: List[Dict[str, str]],
        tools: Optional[List[Dict[str, Any]]] = None,
    ) -> str:
        parts = ["You are in a reasoning and acting loop.", f"Task: {task}", ""]
        if tools:
            parts.append("Available actions:")
            for tool in tools:
                parts.append(f"- {tool.get('name', 'unknown')}: {tool.get('description', '')}")
            parts.append("")

        parts.append("For each step, respond with:")
        parts.append("Thought: <your reasoning>")
        parts.append("Action: <action to take>")
        parts.append("Observation: <expected result>")
        parts.append("")

        if trajectory:
            parts.append("Previous steps:")
            for t in trajectory:
                if t.get("thought"):
                    parts.append(f"Thought: {t['thought']}")
                if t.get("action"):
                    parts.append(f"Action: {t['action']}")
                if t.get("observation"):
                    parts.append(f"Observation: {t['observation']}")
            parts.append("")

        parts.append("Continue the reasoning loop. If task is complete, respond with 'FINISHED'.")
        return "\n".join(parts)

    def _extract_thought(self, response: str) -> Optional[str]:
        import re
        match = re.search(r"Thought:\s*(.+?)(?:\n|$)", response)
        return match.group(1).strip() if match else None

    def _extract_action(self, response: str) -> Optional[str]:
        import re
        match = re.search(r"Action:\s*(.+?)(?:\n|$)", response)
        return match.group(1).strip() if match else None

    def _extract_observation(self, response: str) -> Optional[str]:
        import re
        match = re.search(r"Observation:\s*(.+?)(?:\n|$)", response)
        return match.group(1).strip() if match else None

    def _is_finished(self, response: str) -> bool:
        return "FINISHED" in response.upper() and "THOUGHT" not in response.upper()
