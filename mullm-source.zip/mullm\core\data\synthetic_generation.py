"""Synthetic data generation for LLM training using templates, rule-based expansion, and prompt-based generation."""

from __future__ import annotations

import json
import logging
import random
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Optional

logger = logging.getLogger(__name__)


@dataclass
class SynthGenConfig:
    num_samples: int = 100
    max_length: int = 512
    seed: int = 42
    output_format: str = "jsonl"


@dataclass
class SynthSample:
    text: str
    metadata: dict[str, Any] = field(default_factory=dict)
    label: Optional[str] = None


class TemplateGenerator:
    def __init__(self, templates: Optional[list[str]] = None) -> None:
        self.templates = templates or self._default_templates()

    def _default_templates(self) -> list[str]:
        return [
            "What is {concept}?",
            "Explain how {process} works.",
            "What is the difference between {concept_a} and {concept_b}?",
            "Can you describe {topic} in simple terms?",
            "What are the benefits of {concept}?",
            "How does {process} compare to {alternative}?",
            "What are the key features of {concept}?",
            "Give me an example of {concept}.",
            "Why is {concept} important in {domain}?",
            "What are common misconceptions about {concept}?",
        ]

    def generate(self, fillers: dict[str, list[str]], num: int = 100) -> list[SynthSample]:
        samples = []
        for _ in range(num):
            template = random.choice(self.templates)
            text = template
            for key, values in fillers.items():
                placeholder = "{" + key + "}"
                if placeholder in text:
                    text = text.replace(placeholder, random.choice(values), 1)
            text = re.sub(r"\{[^}]+\}", "something", text)
            samples.append(SynthSample(text=text, metadata={"template": template, "source": "template"}))
        return samples


class PatternExpander:
    def __init__(self) -> None:
        self._patterns = [
            (r"(?P<subject>\w+) is (?P<adj>\w+)", ["{subject} can be described as {adj}.", "One might say {subject} is {adj}.", "The {adj} nature of {subject} is well-known."]),
        ]

    def expand(self, seed_texts: list[str], expansions_per_seed: int = 3) -> list[SynthSample]:
        samples = []
        for seed in seed_texts:
            samples.append(SynthSample(text=seed, metadata={"source": "original"}))
            for _ in range(expansions_per_seed):
                expanded = self._simple_expand(seed)
                if expanded != seed:
                    samples.append(SynthSample(text=expanded, metadata={"source": "expanded"}))
        return samples

    def _simple_expand(self, text: str) -> str:
        prefixes = ["In my opinion, ", "From a technical perspective, ", "Generally speaking, ", "It is worth noting that ", "An interesting observation is that "]
        suffixes = [" This is particularly relevant in modern contexts.", " Many experts agree with this view.", " This has significant implications.", " Further research supports this conclusion."]
        choice = random.randint(0, 2)
        if choice == 0 and random.random() < 0.5:
            return random.choice(prefixes) + text[0].lower() + text[1:]
        elif choice == 1:
            return text + random.choice(suffixes)
        return text


class PromptBasedGenerator:
    def __init__(self, generator_fn: Optional[Callable[[str], str]] = None) -> None:
        self.generator_fn = generator_fn or self._dummy_generator

    def _dummy_generator(self, prompt: str) -> str:
        responses = [
            "The answer to your question involves several key considerations. First, we need to understand the fundamental principles at play. Second, we should examine the empirical evidence. Finally, we must consider practical implications.",
            "This is a complex topic with multiple perspectives. Research suggests that there are three main approaches: theoretical, practical, and hybrid. Each has its own advantages and limitations.",
            "Based on current understanding, the most relevant factors include context, methodology, and application. Each of these dimensions contributes to the overall picture in important ways.",
        ]
        return random.choice(responses)

    def generate(self, prompts: list[str]) -> list[SynthSample]:
        samples = []
        for prompt in prompts:
            response = self.generator_fn(prompt)
            text = f"Q: {prompt}\nA: {response}"
            samples.append(SynthSample(text=text, metadata={"prompt": prompt, "source": "prompt_generated"}))
        return samples


class QAGenerator:
    def __init__(self) -> None:
        self._topics = ["machine learning", "deep learning", "natural language processing", "computer vision", "reinforcement learning", "data science", "statistics", "linear algebra", "calculus", "probability"]
        self._question_stems = ["What is", "How does", "Why is", "Explain", "Describe", "Compare", "Define", "What are the applications of", "What are the limitations of", "What is the future of"]

    def generate_qa_pairs(self, num_pairs: int = 50) -> list[tuple[str, str]]:
        pairs = []
        for _ in range(num_pairs):
            topic = random.choice(self._topics)
            stem = random.choice(self._question_stems)
            question = f"{stem} {topic}?"
            answer = self._generate_answer(topic)
            pairs.append((question, answer))
        return pairs

    def _generate_answer(self, topic: str) -> str:
        templates = [
            f"{topic.capitalize()} is a fundamental concept that involves understanding core principles and applying them to real-world problems.",
            f"The study of {topic} has evolved significantly over the years, with major breakthroughs in both theory and practice.",
            f"When considering {topic}, it is important to focus on key methodologies and their practical implications.",
            f"{topic.capitalize()} plays a crucial role in modern technology, enabling advances across multiple domains.",
        ]
        return random.choice(templates)


class SyntheticDataPipeline:
    def __init__(self, config: Optional[SynthGenConfig] = None) -> None:
        self.config = config or SynthGenConfig()
        random.seed(self.config.seed)
        self.template_gen = TemplateGenerator()
        self.pattern_expander = PatternExpander()
        self.prompt_gen = PromptBasedGenerator()
        self.qa_gen = QAGenerator()

    def generate(self, fillers: Optional[dict[str, list[str]]] = None) -> list[SynthSample]:
        all_samples = []
        n = self.config.num_samples
        all_samples.extend(self.template_gen.generate(fillers or {}, n // 4))
        seed_texts = [s.text for s in all_samples[:10]]
        all_samples.extend(self.pattern_expander.expand(seed_texts, 2))
        prompts = ["What is artificial intelligence?", "How does machine learning work?", "Explain neural networks."]
        all_samples.extend(self.prompt_gen.generate(prompts))
        qa_pairs = self.qa_gen.generate_qa_pairs(n // 4)
        for q, a in qa_pairs:
            all_samples.append(SynthSample(text=f"Q: {q}\nA: {a}", metadata={"source": "qa_generated"}))
        return all_samples[:self.config.num_samples]

    def save(self, samples: list[SynthSample], output_path: str) -> None:
        ext = Path(output_path).suffix
        if ext == ".jsonl":
            with Path(output_path).open("w", encoding="utf-8") as f:
                for s in samples:
                    f.write(json.dumps({"text": s.text, "label": s.label, "metadata": s.metadata}) + "\n")
        elif ext == ".json":
            data = [{"text": s.text, "label": s.label, "metadata": s.metadata} for s in samples]
            Path(output_path).write_text(json.dumps(data, indent=2), encoding="utf-8")
        else:
            with Path(output_path).open("w", encoding="utf-8") as f:
                for s in samples:
                    f.write(s.text + "\n")
