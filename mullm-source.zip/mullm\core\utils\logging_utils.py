from __future__ import annotations

import json
import logging
import sys
import time
from functools import lru_cache
from logging import LogRecord
from pathlib import Path
from typing import Any, Dict, Optional, TextIO

_LOG_FORMATS = {
    "json": "json",
    "plain": "%(asctime)s | %(levelname)-8s | %(name)s:%(funcName)s:%(lineno)d | %(message)s",
}

DATETIME_FORMAT = "%Y-%m-%dT%H:%M:%S"


class JSONFormatter(logging.Formatter):
    """Logging formatter that outputs JSON-serialized log records."""

    def __init__(self, indent: Optional[int] = None) -> None:
        super().__init__()
        self._indent = indent

    def format(self, record: LogRecord) -> str:
        timestamp = time.strftime(DATETIME_FORMAT, time.gmtime(record.created))
        log_entry: Dict[str, Any] = {
            "timestamp": timestamp,
            "level": record.levelname,
            "name": record.name,
            "func": record.funcName,
            "line": record.lineno,
            "message": record.getMessage(),
        }
        if record.exc_info and record.exc_info[0] is not None:
            log_entry["exception"] = self.formatException(record.exc_info)
        if hasattr(record, "extra_fields"):
            log_entry.update(getattr(record, "extra_fields"))
        return json.dumps(log_entry, indent=self._indent, default=str)


class StructuredLogger(logging.Logger):
    """Logger subclass supporting structured extra fields in log calls."""

    def _log(
        self,
        level: int,
        msg: object,
        args: tuple[object, ...],
        exc_info: Optional[Any] = None,
        extra: Optional[Dict[str, Any]] = None,
        stack_info: bool = False,
        stacklevel: int = 1,
        **kwargs: Any,
    ) -> None:
        if extra is None:
            extra = {}
        if kwargs:
            extra["extra_fields"] = kwargs
        super()._log(level, msg, args, exc_info, extra, stack_info, stacklevel + 1)


logging.setLoggerClass(StructuredLogger)


def _create_console_handler(
    fmt: str,
    level: int,
    indent: int = 2,
) -> logging.Handler:
    """Create a console handler with the specified format and level."""
    handler = logging.StreamHandler(sys.stdout)
    handler.setLevel(level)
    if fmt == "json":
        formatter = JSONFormatter(indent=indent)
    else:
        formatter = logging.Formatter(
            _LOG_FORMATS.get(fmt, _LOG_FORMATS["plain"]),
            datefmt=DATETIME_FORMAT,
        )
    handler.setFormatter(formatter)
    return handler


def _create_file_handler(
    file_path: str,
    fmt: str,
    level: int,
    indent: int = 2,
) -> logging.Handler:
    """Create a file handler with rotation support via logging.handlers."""
    from logging.handlers import TimedRotatingFileHandler

    path = Path(file_path)
    path.parent.mkdir(parents=True, exist_ok=True)

    handler = TimedRotatingFileHandler(
        filename=str(path),
        when="midnight",
        interval=1,
        backupCount=30,
        encoding="utf-8",
    )
    handler.setLevel(level)
    if fmt == "json":
        formatter = JSONFormatter(indent=indent)
    else:
        formatter = logging.Formatter(
            _LOG_FORMATS.get(fmt, _LOG_FORMATS["plain"]),
            datefmt=DATETIME_FORMAT,
        )
    handler.setFormatter(formatter)
    return handler


def setup_logging(
    level: str = "INFO",
    fmt: str = "json",
    file_path: Optional[str] = None,
    json_indent: int = 2,
    enable_structlog: bool = True,
) -> None:
    """Configure the root logger with console and optional file handlers.

    Args:
        level: Log level string (DEBUG, INFO, WARNING, ERROR, CRITICAL).
        fmt: Output format ('json' or 'plain').
        file_path: Optional path to write log file.
        json_indent: Indentation for JSON output (0 = no indent).
        enable_structlog: If True, register StructuredLogger as the logger class.
    """
    root_logger = logging.getLogger()
    root_logger.setLevel(getattr(logging, level.upper(), logging.INFO))

    for handler in root_logger.handlers[:]:
        root_logger.removeHandler(handler)

    if enable_structlog:
        logging.setLoggerClass(StructuredLogger)

    console_handler = _create_console_handler(fmt, root_logger.level, json_indent)
    root_logger.addHandler(console_handler)

    if file_path:
        file_handler = _create_file_handler(file_path, fmt, root_logger.level, json_indent)
        root_logger.addHandler(file_handler)

    # Suppress noisy third-party loggers
    for logger_name in (
        "urllib3",
        "httpx",
        "httpcore",
        "PIL",
        "matplotlib",
        "numba",
        "s3transfer",
    ):
        logging.getLogger(logger_name).setLevel(logging.WARNING)


@lru_cache(maxsize=None)
def get_logger(name: str) -> StructuredLogger:
    """Get a structured logger instance for the given name.

    Args:
        name: The logger name, typically ``__name__``.

    Returns:
        A StructuredLogger instance.
    """
    logger = logging.getLogger(name)
    if not isinstance(logger, StructuredLogger):
        logging.setLoggerClass(StructuredLogger)
        logger = logging.getLogger(name)
    return logger  # type: ignore[return-value]
