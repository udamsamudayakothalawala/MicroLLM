import math
from typing import Any, Dict, List, Optional, Tuple

import torch
import torch.nn as nn
import torch.nn.functional as F
from torchvision import models, ops


class AttentionPool2d(nn.Module):
    def __init__(self, embed_dim: int, num_heads: int = 8):
        super().__init__()
        self.num_heads = num_heads
        head_dim = embed_dim // num_heads
        self.scale = head_dim ** -0.5
        self.q = nn.Linear(embed_dim, embed_dim)
        self.k = nn.Linear(embed_dim, embed_dim)
        self.v = nn.Linear(embed_dim, embed_dim)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        B, C, H, W = x.shape
        x_flat = x.flatten(2).transpose(1, 2)
        q = self.q(x_flat).reshape(B, -1, self.num_heads, C // self.num_heads).permute(0, 2, 1, 3)
        k = self.k(x_flat).reshape(B, -1, self.num_heads, C // self.num_heads).permute(0, 2, 1, 3)
        v = self.v(x_flat).reshape(B, -1, self.num_heads, C // self.num_heads).permute(0, 2, 1, 3)
        attn = (q @ k.transpose(-2, -1)) * self.scale
        attn = attn.softmax(dim=-1)
        pooled = (attn @ v).transpose(1, 2).reshape(B, -1, C)
        pooled = pooled.mean(dim=1)
        return pooled


class ImageCaptioner(nn.Module):
    def __init__(
        self,
        vocab_size: int = 30000,
        embed_dim: int = 512,
        num_heads: int = 8,
        num_encoder_layers: int = 6,
        num_decoder_layers: int = 6,
        max_len: int = 128,
        dropout: float = 0.1,
    ):
        super().__init__()
        self.embed_dim = embed_dim
        self.max_len = max_len

        resnet = models.resnet101(weights="DEFAULT")
        self.visual_encoder = nn.Sequential(*list(resnet.children())[:-2])
        self.visual_proj = nn.Sequential(
            nn.Conv2d(2048, embed_dim, 1),
            nn.BatchNorm2d(embed_dim),
            nn.ReLU(inplace=True),
        )

        encoder_layer = nn.TransformerEncoderLayer(d_model=embed_dim, nhead=num_heads, dim_feedforward=embed_dim * 4, dropout=dropout, batch_first=True)
        self.transformer_encoder = nn.TransformerEncoder(encoder_layer, num_encoder_layers)

        self.word_embedding = nn.Embedding(vocab_size, embed_dim)
        self.pos_embedding = nn.Parameter(torch.zeros(1, max_len, embed_dim))
        decoder_layer = nn.TransformerDecoderLayer(d_model=embed_dim, nhead=num_heads, dim_feedforward=embed_dim * 4, dropout=dropout, batch_first=True)
        self.transformer_decoder = nn.TransformerDecoder(decoder_layer, num_decoder_layers)

        self.output_proj = nn.Linear(embed_dim, vocab_size)
        self.dropout = nn.Dropout(dropout)

        nn.init.normal_(self.pos_embedding, std=0.02)

    def forward(self, images: torch.Tensor, captions: Optional[torch.Tensor] = None) -> torch.Tensor:
        visual_features = self.visual_encoder(images)
        visual_features = self.visual_proj(visual_features)
        B, C, H, W = visual_features.shape
        visual_tokens = visual_features.flatten(2).transpose(1, 2)
        memory = self.transformer_encoder(visual_tokens)

        if captions is not None:
            seq_len = captions.shape[1]
            embed = self.word_embedding(captions)
            pos = self.pos_embedding[:, :seq_len, :]
            embed = embed + pos
            embed = self.dropout(embed)
            causal_mask = nn.Transformer.generate_square_subsequent_mask(seq_len, device=images.device)
            output = self.transformer_decoder(embed, memory, tgt_mask=causal_mask)
            logits = self.output_proj(output)
            return logits
        return memory

    def generate(self, images: torch.Tensor, start_token: int = 0, end_token: int = 2, max_len: Optional[int] = None) -> torch.Tensor:
        max_len = max_len or self.max_len
        memory = self.forward(images)
        B = images.shape[0]
        generated = torch.full((B, 1), start_token, dtype=torch.long, device=images.device)

        for _ in range(max_len - 1):
            seq_len = generated.shape[1]
            embed = self.word_embedding(generated)
            pos = self.pos_embedding[:, :seq_len, :]
            embed = embed + pos
            embed = self.dropout(embed)
            causal_mask = nn.Transformer.generate_square_subsequent_mask(seq_len, device=images.device)
            output = self.transformer_decoder(embed, memory, tgt_mask=causal_mask)
            logits = self.output_proj(output[:, -1:, :])
            next_token = logits.argmax(dim=-1)
            generated = torch.cat([generated, next_token], dim=1)
            if (next_token == end_token).all():
                break
        return generated


class VisualQuestionAnswering(nn.Module):
    def __init__(
        self,
        vocab_size: int = 30000,
        answer_size: int = 5000,
        embed_dim: int = 512,
        num_heads: int = 8,
        num_layers: int = 6,
        dropout: float = 0.1,
    ):
        super().__init__()
        resnet = models.resnet50(weights="DEFAULT")
        self.visual_encoder = nn.Sequential(*list(resnet.children())[:-2])
        self.visual_proj = nn.Conv2d(2048, embed_dim, 1)

        self.text_embedding = nn.Embedding(vocab_size, embed_dim)
        encoder_layer = nn.TransformerEncoderLayer(d_model=embed_dim, nhead=num_heads, dim_feedforward=embed_dim * 4, dropout=dropout, batch_first=True)
        self.cross_modal_encoder = nn.TransformerEncoder(encoder_layer, num_layers)

        self.fusion = nn.Sequential(
            nn.Linear(embed_dim * 2, embed_dim * 4),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(embed_dim * 4, embed_dim),
            nn.GELU(),
            nn.Dropout(dropout),
        )

        self.answer_classifier = nn.Linear(embed_dim, answer_size)

    def forward(self, images: torch.Tensor, questions: torch.Tensor) -> torch.Tensor:
        visual_features = self.visual_encoder(images)
        visual_tokens = self.visual_proj(visual_features).flatten(2).transpose(1, 2)

        text_features = self.text_embedding(questions)
        cross_input = torch.cat([visual_tokens, text_features], dim=1)
        cross_features = self.cross_modal_encoder(cross_input)

        visual_len = visual_tokens.shape[1]
        visual_out = cross_features[:, :visual_len, :].mean(dim=1)
        text_out = cross_features[:, visual_len:, :].mean(dim=1)
        fused = self.fusion(torch.cat([visual_out, text_out], dim=-1))
        logits = self.answer_classifier(fused)
        return logits

    def answer(self, images: torch.Tensor, questions: torch.Tensor) -> torch.Tensor:
        logits = self.forward(images, questions)
        return logits.argmax(dim=-1)


class RegionProposalNetwork(nn.Module):
    def __init__(self, in_channels: int = 512, mid_channels: int = 256):
        super().__init__()
        self.conv = nn.Conv2d(in_channels, mid_channels, 3, padding=1)
        self.cls_logits = nn.Conv2d(mid_channels, 9 * 2, 1)
        self.bbox_pred = nn.Conv2d(mid_channels, 9 * 4, 1)

    def forward(self, x: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        x = F.relu(self.conv(x))
        cls_logits = self.cls_logits(x)
        bbox_pred = self.bbox_pred(x)
        return cls_logits, bbox_pred


class ImageFeatureExtractor(nn.Module):
    def __init__(self, backbone: str = "resnet50", output_dim: int = 2048):
        super().__init__()
        self.backbone_name = backbone
        self.output_dim = output_dim

        if backbone == "resnet50":
            resnet = models.resnet50(weights="DEFAULT")
            self.backbone = nn.Sequential(*list(resnet.children())[:-2])
            self.global_pool = nn.Sequential(
                nn.AdaptiveAvgPool2d(1),
                nn.Flatten(),
            )
        elif backbone == "resnet101":
            resnet = models.resnet101(weights="DEFAULT")
            self.backbone = nn.Sequential(*list(resnet.children())[:-2])
            self.global_pool = nn.Sequential(
                nn.AdaptiveAvgPool2d(1),
                nn.Flatten(),
            )
        else:
            raise ValueError(f"Unsupported backbone: {backbone}")

        self.attention_pool = AttentionPool2d(output_dim)

    def forward(self, x: torch.Tensor) -> Dict[str, torch.Tensor]:
        features = self.backbone(x)
        global_features = self.global_pool(features)
        attended_features = self.attention_pool(features)
        return {
            "global": global_features,
            "attended": attended_features,
            "feature_map": features,
        }

    def extract_region_features(self, x: torch.Tensor, boxes: List[torch.Tensor]) -> List[torch.Tensor]:
        features = self.backbone(x)
        region_features = []
        for b in range(x.shape[0]):
            H, W = features.shape[2:]
            scale_y = H / x.shape[2]
            scale_x = W / x.shape[3]
            scaled_boxes = boxes[b].clone()
            scaled_boxes[:, 0] *= scale_x
            scaled_boxes[:, 1] *= scale_y
            scaled_boxes[:, 2] *= scale_x
            scaled_boxes[:, 3] *= scale_y
            roi_features = ops.roi_align(features[b:b+1], [scaled_boxes], output_size=(7, 7), spatial_scale=1.0)
            roi_pooled = roi_features.mean(dim=[-1, -2])
            region_features.append(roi_pooled)
        return region_features

    def get_output_dim(self) -> int:
        return self.output_dim


class ObjectDetectionIntegration(nn.Module):
    def __init__(self, num_classes: int = 91, backbone: str = "resnet50_fpn"):
        super().__init__()
        self.num_classes = num_classes
        self.backbone = models.detection.fasterrcnn_resnet50_fpn(weights="DEFAULT")
        in_features = self.backbone.roi_heads.box_predictor.cls_score.in_features
        self.backbone.roi_heads.box_predictor = models.detection.faster_rcnn.FastRCNNPredictor(in_features, num_classes)

    def forward(self, x: torch.Tensor) -> List[Dict[str, torch.Tensor]]:
        if self.training:
            return self.backbone(x)
        return self.backbone(x)

    def detect(self, x: torch.Tensor, confidence_threshold: float = 0.5) -> List[Dict[str, Any]]:
        self.eval()
        with torch.no_grad():
            predictions = self.backbone(x)
        results = []
        for pred in predictions:
            mask = pred["scores"] > confidence_threshold
            results.append({
                "boxes": pred["boxes"][mask],
                "labels": pred["labels"][mask],
                "scores": pred["scores"][mask],
            })
        return results


class SceneUnderstanding(nn.Module):
    def __init__(self, num_scene_classes: int = 365, num_object_classes: int = 91, embed_dim: int = 1024):
        super().__init__()
        self.scene_classifier = models.resnet50(weights="DEFAULT")
        in_features = self.scene_classifier.fc.in_features
        self.scene_classifier.fc = nn.Linear(in_features, num_scene_classes)

        self.object_detector = ObjectDetectionIntegration(num_object_classes)

        self.attribute_encoder = nn.Sequential(
            nn.Linear(num_scene_classes + embed_dim, embed_dim),
            nn.GELU(),
            nn.Linear(embed_dim, embed_dim),
        )

    def forward(self, x: torch.Tensor) -> Dict[str, torch.Tensor]:
        scene_logits = self.scene_classifier(x)
        scene_probs = F.softmax(scene_logits, dim=-1)
        detections = self.object_detector.detect(x)
        return {
            "scene_logits": scene_logits,
            "scene_probs": scene_probs,
            "detections": detections,
        }

    def understand(self, x: torch.Tensor) -> Dict[str, Any]:
        output = self.forward(x)
        scene_ids = output["scene_probs"].argmax(dim=-1)
        scene_confidences = output["scene_probs"].max(dim=-1).values
        return {
            "scene_ids": scene_ids,
            "scene_confidences": scene_confidences,
            "scene_probs": output["scene_probs"],
            "objects": output["detections"],
        }


class VisualReasoning(nn.Module):
    def __init__(
        self,
        vocab_size: int = 30000,
        embed_dim: int = 512,
        num_heads: int = 8,
        num_layers: int = 8,
        num_answers: int = 5000,
        dropout: float = 0.1,
    ):
        super().__init__()
        self.embed_dim = embed_dim

        resnet = models.resnet50(weights="DEFAULT")
        self.visual_encoder = nn.Sequential(*list(resnet.children())[:-2])
        self.visual_proj = nn.Sequential(
            nn.Conv2d(2048, embed_dim, 1),
            nn.BatchNorm2d(embed_dim),
            nn.ReLU(inplace=True),
        )

        self.text_embedding = nn.Embedding(vocab_size, embed_dim)

        encoder_layer = nn.TransformerEncoderLayer(d_model=embed_dim, nhead=num_heads, dim_feedforward=embed_dim * 4, dropout=dropout, batch_first=True)
        self.reasoning_encoder = nn.TransformerEncoder(encoder_layer, num_layers)

        self.fusion = nn.Sequential(
            nn.Linear(embed_dim * 2, embed_dim * 4),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(embed_dim * 4, embed_dim * 2),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(embed_dim * 2, embed_dim),
        )

        self.reasoning_head = nn.Sequential(
            nn.Linear(embed_dim, embed_dim),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(embed_dim, num_answers),
        )

        self.relation_net = nn.Sequential(
            nn.Linear(embed_dim * 2, embed_dim),
            nn.GELU(),
            nn.Linear(embed_dim, 1),
        )

    def forward(self, images: torch.Tensor, questions: torch.Tensor) -> torch.Tensor:
        visual_features = self.visual_encoder(images)
        visual_tokens = self.visual_proj(visual_features).flatten(2).transpose(1, 2)

        text_features = self.text_embedding(questions)

        combined = torch.cat([visual_tokens, text_features], dim=1)
        encoded = self.reasoning_encoder(combined)

        visual_len = visual_tokens.shape[1]
        v_out = encoded[:, :visual_len, :]
        t_out = encoded[:, visual_len:, :]

        v_global = v_out.mean(dim=1)
        t_global = t_out.mean(dim=1)

        fused = self.fusion(torch.cat([v_global, t_global], dim=-1))
        logits = self.reasoning_head(fused)

        B, N, D = v_out.shape
        v_expand = v_out.unsqueeze(2).expand(-1, -1, N, -1)
        v_expand_other = v_out.unsqueeze(1).expand(-1, N, -1, -1)
        relation_pairs = torch.cat([v_expand, v_expand_other], dim=-1)
        relation_scores = self.relation_net(relation_pairs).squeeze(-1)

        return logits, relation_scores

    def reason(self, images: torch.Tensor, questions: torch.Tensor) -> Dict[str, torch.Tensor]:
        logits, relations = self.forward(images, questions)
        return {
            "answer_logits": logits,
            "predicted_answer": logits.argmax(dim=-1),
            "relation_scores": relations,
        }
