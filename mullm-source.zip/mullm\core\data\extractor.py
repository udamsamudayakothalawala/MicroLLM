"""Multi-format text extractor for PDF, HTML, Markdown, Jupyter notebooks, and more."""

from __future__ import annotations

import json
import logging
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional

try:
    import fitz  # PyMuPDF
except ImportError:
    fitz = None  # type: ignore

try:
    from bs4 import BeautifulSoup
except ImportError:
    BeautifulSoup = None  # type: ignore

try:
    from markdown_it import MarkdownIt
except ImportError:
    MarkdownIt = None  # type: ignore

logger = logging.getLogger(__name__)


@dataclass
class ExtractionConfig:
    """Configuration for text extraction."""

    extract_metadata: bool = True
    extract_images: bool = False
    preserve_structure: bool = True
    max_pages: int = 1000
    page_separator: str = "\n\n---\n\n"
    code_cell_separator: str = "\n\n"
    html_parser: str = "lxml"
    markdown_parser: str = "commonmark"


@dataclass
class ExtractedContent:
    """Result of text extraction."""

    text: str
    metadata: dict[str, Any] = field(default_factory=dict)
    source_format: str = ""
    page_count: int = 0
    char_count: int = 0
    word_count: int = 0
    error: Optional[str] = None


class PDFExtractor:
    """Extracts text from PDF documents using PyMuPDF."""

    def __init__(self, config: ExtractionConfig) -> None:
        self.config = config

    def extract(self, file_path: str) -> ExtractedContent:
        if fitz is None:
            return ExtractedContent(
                text="",
                source_format="pdf",
                error="PyMuPDF not installed. Install with: pip install pymupdf",
            )

        try:
            doc = fitz.open(file_path)
        except Exception as e:
            return ExtractedContent(
                text="",
                source_format="pdf",
                error=f"Failed to open PDF: {e}",
            )

        pages_text: list[str] = []
        metadata: dict[str, Any] = {}

        try:
            if self.config.extract_metadata:
                metadata = {
                    "title": doc.metadata.get("title", ""),
                    "author": doc.metadata.get("author", ""),
                    "subject": doc.metadata.get("subject", ""),
                    "creator": doc.metadata.get("creator", ""),
                    "producer": doc.metadata.get("producer", ""),
                    "page_count": len(doc),
                }

            max_pages = min(len(doc), self.config.max_pages)
            for page_num in range(max_pages):
                page = doc[page_num]
                text = page.get_text("text")
                if self.config.preserve_structure:
                    blocks = page.get_text("blocks")
                    sorted_blocks = sorted(blocks, key=lambda b: (b[1], b[0]))
                    text = "\n".join(
                        b[4] for b in sorted_blocks if b[4].strip()
                    )
                pages_text.append(text)

        finally:
            doc.close()

        full_text = self.config.page_separator.join(pages_text)
        return ExtractedContent(
            text=full_text,
            metadata=metadata,
            source_format="pdf",
            page_count=len(pages_text),
            char_count=len(full_text),
            word_count=len(full_text.split()),
        )

    def extract_from_bytes(self, data: bytes) -> ExtractedContent:
        if fitz is None:
            return ExtractedContent(
                text="",
                source_format="pdf",
                error="PyMuPDF not installed",
            )
        try:
            doc = fitz.open(stream=data, filetype="pdf")
        except Exception as e:
            return ExtractedContent(text="", source_format="pdf", error=str(e))

        pages_text: list[str] = []
        try:
            max_pages = min(len(doc), self.config.max_pages)
            for page_num in range(max_pages):
                page = doc[page_num]
                pages_text.append(page.get_text("text"))
        finally:
            doc.close()

        full_text = self.config.page_separator.join(pages_text)
        return ExtractedContent(
            text=full_text,
            source_format="pdf",
            page_count=len(pages_text),
            char_count=len(full_text),
            word_count=len(full_text.split()),
        )


class HTMLTextExtractor:
    """Extracts text from HTML documents."""

    def __init__(self, config: ExtractionConfig) -> None:
        self.config = config

    def extract(self, html_content: str) -> ExtractedContent:
        if BeautifulSoup is None:
            return self._simple_extract(html_content)

        try:
            soup = BeautifulSoup(html_content, self.config.html_parser)
        except Exception:
            soup = BeautifulSoup(html_content, "html.parser")

        for tag in soup(["script", "style", "noscript", "iframe", "svg", "nav", "footer", "header"]):
            tag.decompose()

        title = ""
        title_tag = soup.find("title")
        if title_tag:
            title = title_tag.get_text(strip=True)

        meta: dict[str, Any] = {}
        if title:
            meta["title"] = title

        for tag in soup.find_all("meta"):
            name = tag.get("name", "").lower()
            if name and tag.get("content"):
                meta[name] = tag["content"]

        text = soup.get_text(separator="\n", strip=True)
        text = re.sub(r"\n{3,}", "\n\n", text)

        return ExtractedContent(
            text=text,
            metadata=meta,
            source_format="html",
            char_count=len(text),
            word_count=len(text.split()),
        )

    def _simple_extract(self, html_content: str) -> ExtractedContent:
        from html.parser import HTMLParser

        class SimpleExtractor(HTMLParser):
            def __init__(self) -> None:
                super().__init__()
                self._skip = False
                self._parts: list[str] = []

            def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
                if tag in ("script", "style", "noscript"):
                    self._skip = True

            def handle_endtag(self, tag: str) -> None:
                if tag in ("script", "style", "noscript"):
                    self._skip = False

            def handle_data(self, data: str) -> None:
                if not self._skip:
                    self._parts.append(data)

        extractor = SimpleExtractor()
        extractor.feed(html_content)
        text = " ".join(extractor._parts)
        text = re.sub(r"\s+", " ", text).strip()
        return ExtractedContent(
            text=text, source_format="html", char_count=len(text), word_count=len(text.split())
        )


class MarkdownExtractor:
    """Extracts text from Markdown documents."""

    def __init__(self, config: ExtractionConfig) -> None:
        self.config = config

    def extract(self, md_content: str) -> ExtractedContent:
        text = self._strip_markdown(md_content)

        metadata = self._extract_frontmatter(md_content)

        return ExtractedContent(
            text=text,
            metadata=metadata,
            source_format="markdown",
            char_count=len(text),
            word_count=len(text.split()),
        )

    def _strip_markdown(self, text: str) -> str:
        text = re.sub(r"^#{1,6}\s+", "", text, flags=re.MULTILINE)
        text = re.sub(r"\*\*(.+?)\*\*", r"\1", text)
        text = re.sub(r"\*(.+?)\*", r"\1", text)
        text = re.sub(r"__(.+?)__", r"\1", text)
        text = re.sub(r"_(.+?)_", r"\1", text)
        text = re.sub(r"~~(.+?)~~", r"\1", text)
        text = re.sub(r"`(.+?)`", r"\1", text)
        text = re.sub(r"```[\s\S]*?```", lambda m: m.group(0).split("\n", 1)[-1].rsplit("\n", 1)[0] if "\n" in m.group(0) else "", text)
        text = re.sub(r"!\[([^\]]*)\]\([^)]*\)", r"\1", text)
        text = re.sub(r"\[([^\]]+)\]\([^)]*\)", r"\1", text)
        text = re.sub(r"^[\s]*[-*+]\s+", "", text, flags=re.MULTILINE)
        text = re.sub(r"^[\s]*\d+\.\s+", "", text, flags=re.MULTILINE)
        text = re.sub(r"^>\s*", "", text, flags=re.MULTILINE)
        text = re.sub(r"^[-*_]{3,}\s*$", "", text, flags=re.MULTILINE)
        text = re.sub(r"\n{3,}", "\n\n", text)
        return text.strip()

    def _extract_frontmatter(self, text: str) -> dict[str, Any]:
        metadata: dict[str, Any] = {}
        match = re.match(r"^---\s*\n(.*?)\n---\s*\n", text, re.DOTALL)
        if match:
            for line in match.group(1).split("\n"):
                if ":" in line:
                    key, _, value = line.partition(":")
                    metadata[key.strip()] = value.strip().strip("\"'")
        return metadata


class NotebookExtractor:
    """Extracts code and text from Jupyter notebooks."""

    def __init__(self, config: ExtractionConfig) -> None:
        self.config = config

    def extract(self, notebook_json: str) -> ExtractedContent:
        try:
            notebook = json.loads(notebook_json)
        except json.JSONDecodeError as e:
            return ExtractedContent(
                text="", source_format="notebook", error=f"Invalid JSON: {e}"
            )

        metadata: dict[str, Any] = {}
        nb_metadata = notebook.get("metadata", {})
        if "kernelspec" in nb_metadata:
            metadata["kernel"] = nb_metadata["kernelspec"].get("display_name", "")
        if "language_info" in nb_metadata:
            metadata["language"] = nb_metadata["language_info"].get("name", "")

        cells = notebook.get("cells", [])
        parts: list[str] = []
        code_cells = 0
        markdown_cells = 0

        for cell in cells:
            cell_type = cell.get("cell_type", "")
            source = "".join(cell.get("source", []))

            if cell_type == "markdown":
                markdown_cells += 1
                parts.append(f"# [Markdown Cell]\n{source}")
            elif cell_type == "code":
                code_cells += 1
                parts.append(f"# [Code Cell]\n{source}")
                outputs = cell.get("outputs", [])
                for output in outputs:
                    if output.get("output_type") == "stream":
                        output_text = "".join(output.get("text", []))
                        if output_text.strip():
                            parts.append(f"# [Output]\n{output_text.strip()}")
                    elif output.get("output_type") == "execute_result":
                        data = output.get("data", {})
                        if "text/plain" in data:
                            output_text = "".join(data["text/plain"])
                            parts.append(f"# [Result]\n{output_text.strip()}")
            elif cell_type == "raw":
                parts.append(f"# [Raw Cell]\n{source}")

        full_text = self.config.code_cell_separator.join(parts)

        metadata["code_cells"] = code_cells
        metadata["markdown_cells"] = markdown_cells
        metadata["total_cells"] = len(cells)

        return ExtractedContent(
            text=full_text,
            metadata=metadata,
            source_format="notebook",
            char_count=len(full_text),
            word_count=len(full_text.split()),
        )


class TextExtractor:
    """Unified multi-format text extractor."""

    def __init__(self, config: Optional[ExtractionConfig] = None) -> None:
        self.config = config or ExtractionConfig()
        self._pdf = PDFExtractor(self.config)
        self._html = HTMLTextExtractor(self.config)
        self._markdown = MarkdownExtractor(self.config)
        self._notebook = NotebookExtractor(self.config)

    def extract_from_file(self, file_path: str) -> ExtractedContent:
        path = Path(file_path)
        if not path.exists():
            return ExtractedContent(
                text="", error=f"File not found: {file_path}"
            )

        suffix = path.suffix.lower()
        try:
            content = path.read_text(encoding="utf-8", errors="replace")
        except Exception:
            try:
                raw = path.read_bytes()
                from mullm.core.data.cleaner import EncodingDetector
                content = EncodingDetector.convert(raw)
            except Exception as e:
                return ExtractedContent(text="", error=str(e))

        return self.extract_by_type(content, suffix)

    def extract_by_type(self, content: str, file_type: str) -> ExtractedContent:
        file_type = file_type.lower().lstrip(".")
        if file_type == "pdf":
            return self._pdf.extract(content)
        elif file_type in ("html", "htm"):
            return self._html.extract(content)
        elif file_type in ("md", "markdown", "mdown"):
            return self._markdown.extract(content)
        elif file_type in ("ipynb", "notebook"):
            return self._notebook.extract(content)
        elif file_type in ("txt", "text", "log"):
            return ExtractedContent(
                text=content,
                source_format="text",
                char_count=len(content),
                word_count=len(content.split()),
            )
        elif file_type == "json":
            return self._extract_json(content)
        elif file_type == "xml":
            return self._extract_xml(content)
        else:
            return ExtractedContent(
                text=content,
                source_format=file_type,
                char_count=len(content),
                word_count=len(content.split()),
            )

    def extract_json(self, json_content: str) -> ExtractedContent:
        return self._extract_json(json_content)

    def _extract_json(self, json_content: str) -> ExtractedContent:
        try:
            data = json.loads(json_content)
        except json.JSONDecodeError as e:
            return ExtractedContent(
                text=json_content,
                source_format="json",
                error=f"Invalid JSON: {e}",
            )
        text = self._flatten_json(data)
        return ExtractedContent(
            text=text,
            metadata={"type": type(data).__name__},
            source_format="json",
            char_count=len(text),
            word_count=len(text.split()),
        )

    def _flatten_json(self, obj: Any, prefix: str = "") -> str:
        parts: list[str] = []
        if isinstance(obj, dict):
            for k, v in obj.items():
                parts.append(self._flatten_json(v, f"{prefix}.{k}" if prefix else k))
        elif isinstance(obj, list):
            for i, item in enumerate(obj):
                parts.append(self._flatten_json(item, f"{prefix}[{i}]"))
        else:
            text = str(obj)
            if text:
                parts.append(text)
        return "\n".join(p for p in parts if p)

    def _extract_xml(self, xml_content: str) -> ExtractedContent:
        try:
            import lxml.etree as etree
            tree = etree.fromstring(xml_content.encode())
            text = etree.tostring(tree, encoding="unicode", method="text")
        except Exception:
            text = re.sub(r"<[^>]+>", " ", xml_content)
            text = re.sub(r"\s+", " ", text).strip()

        return ExtractedContent(
            text=text,
            source_format="xml",
            char_count=len(text),
            word_count=len(text.split()),
        )

    def extract_batch(
        self, contents: list[tuple[str, str]]
    ) -> list[ExtractedContent]:
        return [self.extract_by_type(c, t) for c, t in contents]
