import math
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Set, Tuple, Union

import torch
import torch.nn as nn
import torch.nn.functional as F


@dataclass
class LoRAConfig:
    r: int = 8
    alpha: int = 16
    dropout: float = 0.05
    target_modules: Optional[Set[str]] = None
    bias: str = "none"
    fan_in_fan_out: bool = False
    modules_to_save: Optional[List[str]] = None
    init_lora_weights: bool = True
    layers_to_transform: Optional[List[int]] = None
    layers_pattern: Optional[str] = None
    use_rslora: bool = False
    use_dora: bool = False
    dtype: torch.dtype = torch.float32


class LoRALayer(nn.Module):
    def __init__(
        self,
        in_features: int,
        out_features: int,
        r: int = 8,
        alpha: int = 16,
        dropout: float = 0.05,
        fan_in_fan_out: bool = False,
        use_rslora: bool = False,
        use_dora: bool = False,
        dtype: torch.dtype = torch.float32,
    ):
        super().__init__()
        self.r = r
        self.alpha = alpha
        self.dropout = dropout
        self.fan_in_fan_out = fan_in_fan_out
        self.use_rslora = use_rslora
        self.use_dora = use_dora
        self.in_features = in_features
        self.out_features = out_features
        self.scaling = alpha / r
        self.merged = False
        self.dora_scale = None

        if r > 0:
            self.lora_A = nn.Parameter(torch.empty(r, in_features, dtype=dtype))
            self.lora_B = nn.Parameter(torch.empty(out_features, r, dtype=dtype))
            self.dropout_layer = nn.Dropout(p=dropout) if dropout > 0 else nn.Identity()
            self._init_weights()
        else:
            self.lora_A = None
            self.lora_B = None
            self.dropout_layer = nn.Identity()

        self.weight: Optional[torch.Tensor] = None

    def _init_weights(self):
        nn.init.kaiming_uniform_(self.lora_A, a=math.sqrt(5))
        nn.init.zeros_(self.lora_B)

    def merge(self, weight: torch.Tensor) -> torch.Tensor:
        if self.merged or self.lora_A is None:
            return weight
        delta_w = self._compute_delta_w()
        if self.fan_in_fan_out:
            weight = weight + delta_w.T
        else:
            weight = weight + delta_w
        self.merged = True
        return weight

    def unmerge(self, weight: torch.Tensor) -> torch.Tensor:
        if not self.merged or self.lora_A is None:
            return weight
        delta_w = self._compute_delta_w()
        if self.fan_in_fan_out:
            weight = weight - delta_w.T
        else:
            weight = weight - delta_w
        self.merged = False
        return weight

    def _compute_delta_w(self) -> torch.Tensor:
        if self.lora_A is None or self.lora_B is None:
            return 0
        delta_w = self.lora_B @ self.lora_A
        if self.use_dora:
            weight_norm = delta_w.norm(p=2, dim=1, keepdim=True)
            delta_w = delta_w / (weight_norm + 1e-8)
        if self.use_rslora:
            scaling = (self.alpha / math.sqrt(self.r))
        else:
            scaling = self.scaling
        return delta_w * scaling

    def forward(self, x: torch.Tensor, weight: torch.Tensor) -> torch.Tensor:
        result = F.linear(x, weight)
        if self.lora_A is not None and not self.merged:
            if self.fan_in_fan_out:
                result += (self.lora_A @ x.T).T @ self.lora_B.T * self.scaling
            else:
                lora_out = self.dropout_layer(x) @ self.lora_A.T @ self.lora_B.T * self.scaling
                result = result + lora_out
        return result

    def set_scale(self, scale: float):
        if self.use_rslora:
            self.scaling = scale / math.sqrt(self.r)
        else:
            self.scaling = scale / self.r

    def extra_repr(self) -> str:
        return f"r={self.r}, alpha={self.alpha}, dropout={self.dropout}, fan_in_fan_out={self.fan_in_fan_out}, merged={self.merged}"


class LoRALinear(nn.Module):
    def __init__(
        self,
        in_features: int,
        out_features: int,
        bias: bool = True,
        r: int = 8,
        alpha: int = 16,
        dropout: float = 0.05,
        fan_in_fan_out: bool = False,
        use_rslora: bool = False,
        use_dora: bool = False,
        dtype: torch.dtype = torch.float32,
    ):
        super().__init__()
        self.in_features = in_features
        self.out_features = out_features
        self.weight = nn.Parameter(torch.empty(out_features, in_features, dtype=dtype))
        if bias:
            self.bias = nn.Parameter(torch.empty(out_features, dtype=dtype))
        else:
            self.register_parameter("bias", None)

        self.lora = LoRALayer(
            in_features=in_features,
            out_features=out_features,
            r=r,
            alpha=alpha,
            dropout=dropout,
            fan_in_fan_out=fan_in_fan_out,
            use_rslora=use_rslora,
            use_dora=use_dora,
            dtype=dtype,
        )
        self._init_weights()

    def _init_weights(self):
        nn.init.kaiming_uniform_(self.weight, a=math.sqrt(5))
        if self.bias is not None:
            fan_in, _ = nn.init._calculate_fan_in_and_fan_out(self.weight)
            bound = 1 / math.sqrt(fan_in) if fan_in > 0 else 0
            nn.init.uniform_(self.bias, -bound, bound)

    def merge(self):
        with torch.no_grad():
            self.weight.data = self.lora.merge(self.weight.data)

    def unmerge(self):
        with torch.no_grad():
            self.weight.data = self.lora.unmerge(self.weight.data)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.lora(x, self.weight) + (self.bias if self.bias is not None else 0)


class LoRAEmbedding(nn.Module):
    def __init__(
        self,
        num_embeddings: int,
        embedding_dim: int,
        r: int = 8,
        alpha: int = 16,
        dropout: float = 0.05,
        dtype: torch.dtype = torch.float32,
    ):
        super().__init__()
        self.num_embeddings = num_embeddings
        self.embedding_dim = embedding_dim
        self.weight = nn.Parameter(torch.empty(num_embeddings, embedding_dim, dtype=dtype))
        self.lora = LoRALayer(
            in_features=embedding_dim,
            out_features=embedding_dim,
            r=r,
            alpha=alpha,
            dropout=dropout,
            fan_in_fan_out=False,
            dtype=dtype,
        )
        nn.init.normal_(self.weight, mean=0, std=0.02)

    def merge(self):
        with torch.no_grad():
            self.weight.data = self.lora.merge(self.weight.data)

    def unmerge(self):
        with torch.no_grad():
            self.weight.data = self.lora.unmerge(self.weight.data)

    def forward(self, input_ids: torch.Tensor) -> torch.Tensor:
        emb = F.embedding(input_ids, self.weight)
        lora_emb = self.lora(emb, self.weight.T).T
        return emb + lora_emb


class MultiAdapterLoRALayer(nn.Module):
    def __init__(self, config: LoRAConfig, in_features: int, out_features: int):
        super().__init__()
        self.config = config
        self.in_features = in_features
        self.out_features = out_features
        self.adapters: nn.ParameterDict = nn.ParameterDict()
        self.active_adapter: Optional[str] = None

    def add_adapter(self, name: str, r: Optional[int] = None, alpha: Optional[int] = None):
        r = r if r is not None else self.config.r
        alpha = alpha if alpha is not None else self.config.alpha
        lora_a = nn.Parameter(torch.empty(r, self.in_features, dtype=self.config.dtype))
        lora_b = nn.Parameter(torch.empty(self.out_features, r, dtype=self.config.dtype))
        nn.init.kaiming_uniform_(lora_a, a=math.sqrt(5))
        nn.init.zeros_(lora_b)
        self.adapters[f"{name}_A"] = lora_a
        self.adapters[f"{name}_B"] = lora_b

    def set_active_adapter(self, name: str):
        self.active_adapter = name

    def remove_adapter(self, name: str):
        keys = [k for k in self.adapters if k.startswith(name)]
        for k in keys:
            del self.adapters[k]
        if self.active_adapter == name:
            self.active_adapter = None

    def get_delta_w(self, name: str) -> torch.Tensor:
        if f"{name}_A" not in self.adapters:
            return 0
        lora_a = self.adapters[f"{name}_A"]
        lora_b = self.adapters[f"{name}_B"]
        delta_w = lora_b @ lora_a
        scaling = self.config.alpha / self.config.r
        return delta_w * scaling

    def forward(self, x: torch.Tensor, weight: torch.Tensor) -> torch.Tensor:
        result = F.linear(x, weight)
        if self.active_adapter and f"{self.active_adapter}_A" in self.adapters:
            lora_a = self.adapters[f"{self.active_adapter}_A"]
            lora_b = self.adapters[f"{self.active_adapter}_B"]
            scaling = self.config.alpha / self.config.r
            lora_out = x @ lora_a.T @ lora_b.T * scaling
            result = result + lora_out
        return result


LORA_TYPE_MAP = {
    "linear": LoRALinear,
    "embedding": LoRAEmbedding,
    "multi_adapter": MultiAdapterLoRALayer,
}


def inject_lora(
    model: nn.Module,
    config: LoRAConfig,
    adapter_name: str = "default",
) -> nn.Module:
    target_modules = config.target_modules
    if target_modules is None:
        target_modules = {"q_proj", "k_proj", "v_proj", "o_proj", "gate_proj", "up_proj", "down_proj"}

    for name, module in model.named_modules():
        if not any(t in name for t in target_modules):
            continue
        parent_name, child_name = name.rsplit(".", 1) if "." in name else ("", name)
        parent = model if parent_name == "" else None
        current = model
        if parent_name:
            parts = parent_name.split(".")
            for p in parts:
                current = getattr(current, p)
            parent = current

        if isinstance(module, nn.Linear):
            lora_layer = LoRALinear(
                in_features=module.in_features,
                out_features=module.out_features,
                bias=module.bias is not None,
                r=config.r,
                alpha=config.alpha,
                dropout=config.dropout,
                fan_in_fan_out=config.fan_in_fan_out,
                use_rslora=config.use_rslora,
                use_dora=config.use_dora,
                dtype=module.weight.dtype,
            )
            lora_layer.weight.data = module.weight.data.clone()
            if module.bias is not None:
                lora_layer.bias.data = module.bias.data.clone()
            setattr(parent, child_name, lora_layer)

    return model


def get_lora_state_dict(model: nn.Module, adapter_name: str = "default") -> Dict[str, torch.Tensor]:
    lora_params = {}
    for name, param in model.named_parameters():
        if "lora_" in name:
            lora_params[name] = param.data.clone()
    return lora_params


def set_lora_scale(model: nn.Module, scale: float):
    for module in model.modules():
        if hasattr(module, "lora") and isinstance(module.lora, LoRALayer):
            module.lora.set_scale(scale)


def merge_lora_weights(model: nn.Module):
    for module in model.modules():
        if isinstance(module, (LoRALinear, LoRAEmbedding)):
            module.merge()


def unmerge_lora_weights(model: nn.Module):
    for module in model.modules():
        if isinstance(module, (LoRALinear, LoRAEmbedding)):
            module.unmerge()
