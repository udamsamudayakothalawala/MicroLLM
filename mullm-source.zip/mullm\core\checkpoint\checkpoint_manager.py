from __future__ import annotations

import atexit
import datetime
import hashlib
import json
import logging
import os
import shutil
import tempfile
import threading
import time
from concurrent.futures import Future, ThreadPoolExecutor
from dataclasses import asdict, dataclass, field
from enum import Enum
from pathlib import Path
from typing import (
    Any,
    Callable,
    Dict,
    List,
    Optional,
    Set,
    Tuple,
    Union,
)

import torch
import torch.distributed as dist
import torch.nn as nn

logger = logging.getLogger(__name__)


class CheckpointFormat(Enum):
    PYTORCH = "pytorch"
    SAFETENSORS = "safetensors"
    PICKLE = "pickle"


class VersionPolicy(Enum):
    KEEP_LAST_N = "keep_last_n"
    KEEP_BEST_N = "keep_best_n"
    KEEP_EVERY_K_STEPS = "keep_every_k_steps"


@dataclass
class CheckpointMetadata:
    step: int = 0
    epoch: int = 0
    loss: float = float("inf")
    metrics: Dict[str, float] = field(default_factory=dict)
    timestamp: str = ""
    version: str = "1.0.0"
    git_commit: Optional[str] = None
    experiment_tag: Optional[str] = None
    rng_states: Optional[Dict[str, Any]] = None
    extra: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> CheckpointMetadata:
        valid_fields = {f.name for f in cls.__dataclass_fields__.values()}
        filtered = {k: v for k, v in data.items() if k in valid_fields}
        return cls(**filtered)


@dataclass
class CheckpointInfo:
    path: Path
    metadata: CheckpointMetadata
    format: CheckpointFormat = CheckpointFormat.PYTORCH
    size_bytes: int = 0
    sha256: Optional[str] = None
    is_sharded: bool = False
    shard_count: int = 0
    parent_checkpoint: Optional[Path] = None


class IntegrityError(Exception):
    pass


class CheckpointManager:
    def __init__(
        self,
        base_dir: Union[str, Path],
        config: Optional[CheckpointConfig] = None,
    ) -> None:
        self.base_dir = Path(base_dir)
        self.base_dir.mkdir(parents=True, exist_ok=True)
        self.config = config or CheckpointConfig()
        self._executor: Optional[ThreadPoolExecutor] = None
        self._futures: List[Future] = []
        self._lock = threading.Lock()
        self._checkpoint_index: Dict[str, CheckpointInfo] = {}
        self._load_index()
        self._register_cleanup()
        self._pending_writes: Set[Path] = set()
        if self.config.async_saving:
            self._executor = ThreadPoolExecutor(max_workers=self.config.async_workers)

    def _register_cleanup(self) -> None:
        def _cleanup() -> None:
            if self._executor is not None:
                for future in self._futures:
                    try:
                        future.result(timeout=5)
                    except Exception:
                        pass
                self._executor.shutdown(wait=False)
            for tmp_dir in self._pending_writes:
                if tmp_dir.exists():
                    shutil.rmtree(tmp_dir, ignore_errors=True)

        atexit.register(_cleanup)

    def _load_index(self) -> None:
        index_path = self.base_dir / "checkpoint_index.json"
        if index_path.exists():
            try:
                with open(index_path, "r", encoding="utf-8") as f:
                    data = json.load(f)
                for key, info_dict in data.items():
                    info_dict["path"] = Path(info_dict["path"])
                    metadata = CheckpointMetadata.from_dict(info_dict.get("metadata", {}))
                    fmt = CheckpointFormat(info_dict.get("format", "pytorch"))
                    self._checkpoint_index[key] = CheckpointInfo(
                        path=info_dict["path"],
                        metadata=metadata,
                        format=fmt,
                        size_bytes=info_dict.get("size_bytes", 0),
                        sha256=info_dict.get("sha256"),
                        is_sharded=info_dict.get("is_sharded", False),
                        shard_count=info_dict.get("shard_count", 0),
                        parent_checkpoint=Path(info_dict["parent_checkpoint"]) if info_dict.get("parent_checkpoint") else None,
                    )
            except Exception as e:
                logger.warning("Failed to load checkpoint index: %s", e)

    def _save_index(self) -> None:
        index_path = self.base_dir / "checkpoint_index.json"
        data: Dict[str, Any] = {}
        for key, info in self._checkpoint_index.items():
            entry = {
                "path": str(info.path),
                "metadata": info.metadata.to_dict(),
                "format": info.format.value,
                "size_bytes": info.size_bytes,
                "sha256": info.sha256,
                "is_sharded": info.is_sharded,
                "shard_count": info.shard_count,
                "parent_checkpoint": str(info.parent_checkpoint) if info.parent_checkpoint else None,
            }
            data[key] = entry
        tmp = index_path.with_suffix(".tmp")
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)
        shutil.move(str(tmp), str(index_path))

    def _compute_sha256(self, file_path: Path) -> str:
        sha256 = hashlib.sha256()
        with open(file_path, "rb") as f:
            while True:
                chunk = f.read(8192)
                if not chunk:
                    break
                sha256.update(chunk)
        return sha256.hexdigest()

    def _directory_size(self, path: Path) -> int:
        if path.is_file():
            return path.stat().st_size
        total = 0
        for entry in path.rglob("*"):
            if entry.is_file():
                total += entry.stat().st_size
        return total

    def _atomic_write(self, target: Path, write_fn: Callable[[Path], None]) -> None:
        tmp_dir = Path(tempfile.mkdtemp(dir=self.base_dir, prefix=".tmp_"))
        self._pending_writes.add(tmp_dir)
        try:
            write_fn(tmp_dir)
            if target.exists():
                if target.is_dir():
                    shutil.rmtree(target)
                else:
                    target.unlink()
            shutil.move(str(tmp_dir), str(target))
            self._pending_writes.discard(tmp_dir)
        except Exception:
            if tmp_dir.exists():
                shutil.rmtree(tmp_dir, ignore_errors=True)
            self._pending_writes.discard(tmp_dir)
            raise

    def _collect_rng_states(self) -> Dict[str, Any]:
        states: Dict[str, Any] = {}
        states["cpu"] = torch.random.get_rng_state()
        if torch.cuda.is_available():
            states["cuda"] = torch.cuda.get_rng_state_all()
        import random
        import numpy as np
        states["python_random"] = random.getstate()
        states["numpy"] = np.random.get_state()[1].tolist()
        return states

    def _restore_rng_states(self, rng_states: Dict[str, Any]) -> None:
        if "cpu" in rng_states:
            torch.random.set_rng_state(rng_states["cpu"])
        if "cuda" in rng_states and torch.cuda.is_available():
            torch.cuda.set_rng_state_all(rng_states["cuda"])
        import random
        import numpy as np
        if "python_random" in rng_states:
            random.setstate(rng_states["python_random"])
        if "numpy" in rng_states:
            arr = np.array(rng_states["numpy"], dtype=np.uint32)
            state_tuple = ("MT19937", arr, 0, 0, 0.0)
            np.random.set_state(state_tuple)

    def _save_sharded_state_dict(
        self,
        state_dict: Dict[str, Any],
        save_dir: Path,
        num_shards: int,
    ) -> None:
        save_dir.mkdir(parents=True, exist_ok=True)
        items = list(state_dict.items())
        shard_size = max(1, (len(items) + num_shards - 1) // num_shards)
        shard_files: List[str] = []
        for i in range(num_shards):
            start_idx = i * shard_size
            end_idx = min(start_idx + shard_size, len(items))
            if start_idx >= len(items):
                break
            shard_dict = {k: v for k, v in items[start_idx:end_idx]}
            shard_name = f"shard_{i:05d}.pt"
            shard_files.append(shard_name)
            torch.save(shard_dict, save_dir / shard_name)
        manifest = {"shards": shard_files, "total_shards": len(shard_files)}
        with open(save_dir / "manifest.json", "w") as f:
            json.dump(manifest, f)

    def _load_sharded_state_dict(self, load_dir: Path) -> Dict[str, Any]:
        manifest_path = load_dir / "manifest.json"
        if not manifest_path.exists():
            raise FileNotFoundError(f"No manifest found in {load_dir}")
        with open(manifest_path, "r") as f:
            manifest = json.load(f)
        combined: Dict[str, Any] = {}
        for shard_name in manifest["shards"]:
            shard_data = torch.load(load_dir / shard_name, map_location="cpu", weights_only=False)
            combined.update(shard_data)
        return combined

    def _cleanup_old_checkpoints(self, tag: str = "default") -> None:
        tag_checkpoints = sorted(
            [(k, v) for k, v in self._checkpoint_index.items() if k.startswith(f"{tag}/")],
            key=lambda x: x[1].metadata.step,
        )
        if not tag_checkpoints:
            return
        kept: Set[str] = set()
        if self.config.version_policy == VersionPolicy.KEEP_LAST_N:
            keep_count = min(self.config.keep_last_n, len(tag_checkpoints))
            for key, _ in tag_checkpoints[-keep_count:]:
                kept.add(key)
        elif self.config.version_policy == VersionPolicy.KEEP_BEST_N:
            sorted_by_loss = sorted(tag_checkpoints, key=lambda x: x[1].metadata.loss)
            keep_count = min(self.config.keep_best_n, len(sorted_by_loss))
            for key, _ in sorted_by_loss[:keep_count]:
                kept.add(key)
        elif self.config.version_policy == VersionPolicy.KEEP_EVERY_K_STEPS:
            for key, info in tag_checkpoints:
                if info.metadata.step % self.config.keep_every_k_steps == 0:
                    kept.add(key)
            if tag_checkpoints:
                kept.add(tag_checkpoints[-1][0])
        else:
            return
        for key, info in tag_checkpoints:
            if key not in kept:
                self._delete_checkpoint(info.path)
                del self._checkpoint_index[key]
                logger.info("Removed old checkpoint: %s", key)

    def _delete_checkpoint(self, path: Path) -> None:
        try:
            if path.is_dir():
                shutil.rmtree(path)
            elif path.exists():
                path.unlink()
        except Exception as e:
            logger.warning("Failed to delete checkpoint at %s: %s", path, e)

    def _generate_key(self, tag: str, step: int) -> str:
        return f"{tag}/step_{step:08d}"

    def _is_distributed(self) -> bool:
        return dist.is_available() and dist.is_initialized()

    def _is_main_process(self) -> bool:
        if not self._is_distributed():
            return True
        return dist.get_rank() == 0

    def _get_world_size(self) -> int:
        if not self._is_distributed():
            return 1
        return dist.get_world_size()

    def _distributed_barrier(self) -> None:
        if self._is_distributed():
            dist.barrier()

    def _distributed_broadcast_object(self, obj: Any, src: int = 0) -> Any:
        if not self._is_distributed():
            return obj
        object_list = [obj]
        dist.broadcast_object_list(object_list, src=src)
        return object_list[0]

    def _distributed_save_state_dict(
        self,
        state_dict: Dict[str, Any],
        save_dir: Path,
    ) -> None:
        rank = dist.get_rank()
        world_size = dist.get_world_size()
        rank_dir = save_dir / f"rank_{rank:04d}"
        rank_dir.mkdir(parents=True, exist_ok=True)
        torch.save(state_dict, rank_dir / "model.pt")
        self._distributed_barrier()
        if rank == 0:
            manifest = {"rank_dirs": [f"rank_{i:04d}" for i in range(world_size)]}
            with open(save_dir / "manifest.json", "w") as f:
                json.dump(manifest, f)

    def _distributed_load_state_dict(
        self,
        load_dir: Path,
    ) -> Dict[str, Any]:
        manifest_path = load_dir / "manifest.json"
        if not manifest_path.exists():
            rank_dir = load_dir / f"rank_{dist.get_rank():04d}"
            return torch.load(rank_dir / "model.pt", map_location="cpu", weights_only=False)
        with open(manifest_path, "r") as f:
            manifest = json.load(f)
        combined: Dict[str, Any] = {}
        for rank_dir_name in manifest["rank_dirs"]:
            rank_data = torch.load(load_dir / rank_dir_name / "model.pt", map_location="cpu", weights_only=False)
            combined.update(rank_data)
        return combined

    def save_checkpoint(
        self,
        model: nn.Module,
        optimizer: Optional[torch.optim.Optimizer] = None,
        scheduler: Optional[Any] = None,
        step: int = 0,
        epoch: int = 0,
        loss: float = float("inf"),
        metrics: Optional[Dict[str, float]] = None,
        tag: str = "default",
        format: CheckpointFormat = CheckpointFormat.PYTORCH,
        num_shards: int = 0,
        extra_data: Optional[Dict[str, Any]] = None,
    ) -> CheckpointInfo:
        metadata = CheckpointMetadata(
            step=step,
            epoch=epoch,
            loss=loss,
            metrics=metrics or {},
            timestamp=datetime.datetime.now(datetime.timezone.utc).isoformat(),
            extra=extra_data or {},
        )
        if self.config.save_rng:
            metadata.rng_states = self._collect_rng_states()
        if self.config.git_tracking:
            metadata.git_commit = self._get_git_commit()
        key = self._generate_key(tag, step)
        save_dir = self.base_dir / key.replace("/", "_")

        def _write_checkpoint(target_dir: Path) -> None:
            target_dir.mkdir(parents=True, exist_ok=True)
            if self._is_distributed():
                if self.config.fsdp_sharded:
                    model_state = model.state_dict()
                    self._distributed_save_state_dict(model_state, target_dir / "model")
                else:
                    if self._is_main_process():
                        model_state = model.state_dict()
                        torch.save(model_state, target_dir / "model.pt")
            else:
                model_state = model.state_dict()
                if num_shards > 1:
                    self._save_sharded_state_dict(model_state, target_dir / "model", num_shards)
                else:
                    torch.save(model_state, target_dir / "model.pt")
            if optimizer is not None:
                opt_state = optimizer.state_dict()
                torch.save(opt_state, target_dir / "optimizer.pt")
            if scheduler is not None:
                sched_state = scheduler.state_dict()
                torch.save(sched_state, target_dir / "scheduler.pt")
            with open(target_dir / "metadata.json", "w", encoding="utf-8") as f:
                json.dump(metadata.to_dict(), f, indent=2, default=str)

        if self.config.async_saving and self._executor is not None:
            future = self._executor.submit(self._atomic_write, save_dir, _write_checkpoint)
            self._futures.append(future)
        else:
            self._atomic_write(save_dir, _write_checkpoint)

        self._distributed_barrier()
        self._checkpoint_index[key] = CheckpointInfo(
            path=save_dir,
            metadata=metadata,
            format=format,
            size_bytes=self._directory_size(save_dir),
            is_sharded=num_shards > 1,
            shard_count=num_shards,
        )
        if self._is_main_process():
            info = self._checkpoint_index[key]
            sha256_path = save_dir / "model.pt" if not num_shards else save_dir
            if sha256_path.is_file():
                info.sha256 = self._compute_sha256(sha256_path)
            self._save_index()
            self._cleanup_old_checkpoints(tag)
        self._distributed_broadcast_object(self._checkpoint_index, src=0)
        logger.info("Saved checkpoint: %s (step=%d, loss=%.4f)", key, step, loss)
        return self._checkpoint_index[key]

    def load_checkpoint(
        self,
        model: nn.Module,
        optimizer: Optional[torch.optim.Optimizer] = None,
        scheduler: Optional[Any] = None,
        tag: str = "default",
        step: Optional[int] = None,
        load_best: bool = False,
        load_rng: bool = True,
        strict: bool = True,
    ) -> Tuple[CheckpointMetadata, int]:
        key: Optional[str] = None
        if step is not None:
            key = self._generate_key(tag, step)
        elif load_best:
            tag_items = [(k, v) for k, v in self._checkpoint_index.items() if k.startswith(f"{tag}/")]
            if not tag_items:
                raise FileNotFoundError(f"No checkpoints found for tag '{tag}'")
            key, _ = min(tag_items, item=lambda x: x[1].metadata.loss)
        else:
            tag_items = [(k, v) for k, v in self._checkpoint_index.items() if k.startswith(f"{tag}/")]
            if not tag_items:
                raise FileNotFoundError(f"No checkpoints found for tag '{tag}'")
            key, _ = max(tag_items, item=lambda x: x[1].metadata.step)
        if key is None or key not in self._checkpoint_index:
            raise FileNotFoundError(f"Checkpoint not found: {key}")
        info = self._checkpoint_index[key]
        load_dir = info.path
        self._distributed_barrier()
        if info.is_sharded or self.config.fsdp_sharded:
            model_state = self._distributed_load_state_dict(load_dir / "model") if self.config.fsdp_sharded else self._load_sharded_state_dict(load_dir / "model")
        else:
            model_state = torch.load(load_dir / "model.pt", map_location="cpu", weights_only=False)
        model.load_state_dict(model_state, strict=strict)
        if optimizer is not None:
            opt_path = load_dir / "optimizer.pt"
            if opt_path.exists():
                opt_state = torch.load(opt_path, map_location="cpu", weights_only=False)
                optimizer.load_state_dict(opt_state)
        if scheduler is not None:
            sched_path = load_dir / "scheduler.pt"
            if sched_path.exists():
                sched_state = torch.load(sched_path, map_location="cpu", weights_only=False)
                scheduler.load_state_dict(sched_state)
        metadata_path = load_dir / "metadata.json"
        metadata = CheckpointMetadata()
        if metadata_path.exists():
            with open(metadata_path, "r", encoding="utf-8") as f:
                metadata = CheckpointMetadata.from_dict(json.load(f))
        if load_rng and metadata.rng_states is not None:
            self._restore_rng_states(metadata.rng_states)
        logger.info("Loaded checkpoint: %s (step=%d, loss=%.4f)", key, metadata.step, metadata.loss)
        return metadata, metadata.step

    def load_latest(self, model: nn.Module, tag: str = "default", **kwargs: Any) -> Tuple[CheckpointMetadata, int]:
        return self.load_checkpoint(model, tag=tag, step=None, **kwargs)

    def verify_integrity(self, key: str) -> bool:
        if key not in self._checkpoint_index:
            raise KeyError(f"Checkpoint not found: {key}")
        info = self._checkpoint_index[key]
        if info.sha256 is None:
            return True
        target = info.path / "model.pt"
        if not target.exists():
            return False
        actual_hash = self._compute_sha256(target)
        return actual_hash == info.sha256

    def verify_all_integrity(self) -> Dict[str, bool]:
        results: Dict[str, bool] = {}
        for key in self._checkpoint_index:
            try:
                results[key] = self.verify_integrity(key)
            except Exception:
                results[key] = False
        return results

    def list_checkpoints(
        self,
        tag: Optional[str] = None,
        sort_by: str = "step",
    ) -> List[CheckpointInfo]:
        checkpoints = list(self._checkpoint_index.values())
        if tag is not None:
            checkpoints = [c for c in checkpoints if c.path.name.startswith(tag)]
        if sort_by == "step":
            checkpoints.sort(key=lambda c: c.metadata.step)
        elif sort_by == "loss":
            checkpoints.sort(key=lambda c: c.metadata.loss)
        elif sort_by == "timestamp":
            checkpoints.sort(key=lambda c: c.metadata.timestamp)
        return checkpoints

    def delete_checkpoint(self, key: str) -> None:
        if key not in self._checkpoint_index:
            raise KeyError(f"Checkpoint not found: {key}")
        info = self._checkpoint_index[key]
        self._delete_checkpoint(info.path)
        del self._checkpoint_index[key]
        self._save_index()
        logger.info("Deleted checkpoint: %s", key)

    def get_recovery_checkpoint(self) -> Optional[CheckpointInfo]:
        latest = None
        for info in self._checkpoint_index.values():
            if latest is None or info.metadata.step > latest.metadata.step:
                latest = info
        if latest is not None and latest.path.exists():
            metadata_path = latest.path / "metadata.json"
            if metadata_path.exists():
                with open(metadata_path, "r") as f:
                    data = json.load(f)
                data["extra"]["recovered"] = True
                with open(metadata_path, "w") as f:
                    json.dump(data, f, indent=2, default=str)
        return latest

    def create_recovery_handler(self, model: nn.Module, tag: str = "default") -> Callable[[], None]:
        def _auto_recover() -> None:
            logger.info("Attempting automatic recovery...")
            try:
                recovery = self.get_recovery_checkpoint()
                if recovery is not None:
                    logger.info("Recovering from checkpoint: %s", recovery.path)
                    self.load_checkpoint(model, tag=tag, step=recovery.metadata.step)
                    logger.info("Recovery successful at step %d", recovery.metadata.step)
                else:
                    logger.info("No checkpoint available for recovery")
            except Exception as e:
                logger.error("Recovery failed: %s", e)

        return _auto_recover

    def _get_git_commit(self) -> Optional[str]:
        try:
            import subprocess
            result = subprocess.run(
                ["git", "rev-parse", "HEAD"],
                capture_output=True,
                text=True,
                timeout=5,
            )
            if result.returncode == 0:
                return result.stdout.strip()
        except Exception:
            pass
        return None

    def get_disk_usage(self) -> Dict[str, int]:
        usage: Dict[str, int] = {}
        for key, info in self._checkpoint_index.items():
            usage[key] = self._directory_size(info.path)
        return usage

    def prune(self, max_total_size_bytes: Optional[int] = None) -> List[str]:
        removed: List[str] = []
        if max_total_size_bytes is None:
            return removed
        sorted_checkpoints = sorted(
            self._checkpoint_index.items(),
            key=lambda x: x[1].metadata.step,
        )
        total = sum(self._directory_size(v.path) for _, v in sorted_checkpoints)
        while total > max_total_size_bytes and sorted_checkpoints:
            key, info = sorted_checkpoints.pop(0)
            size = self._directory_size(info.path)
            self._delete_checkpoint(info.path)
            del self._checkpoint_index[key]
            total -= size
            removed.append(key)
        if removed:
            self._save_index()
        return removed


@dataclass
class CheckpointConfig:
    base_dir: str = "./checkpoints"
    version_policy: VersionPolicy = VersionPolicy.KEEP_LAST_N
    keep_last_n: int = 5
    keep_best_n: int = 3
    keep_every_k_steps: int = 1000
    save_rng: bool = True
    async_saving: bool = False
    async_workers: int = 2
    git_tracking: bool = True
    fsdp_sharded: bool = False
    deepspeed_enabled: bool = False
    integrity_check: bool = True
    auto_recovery: bool = True
    max_total_size_bytes: Optional[int] = None
    format: CheckpointFormat = CheckpointFormat.PYTORCH
