"""Agent framework with specialized agents and orchestration."""

from __future__ import annotations

import json
import time
import traceback
import uuid
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any, Callable, Dict, List, Optional, Set, Tuple, Type


class AgentStatus(Enum):
    IDLE = "idle"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    BLOCKED = "blocked"


@dataclass
class AgentConfig:
    name: str = "agent"
    model: str = "gpt-4"
    max_steps: int = 20
    temperature: float = 0.7
    tools: List[Dict[str, Any]] = field(default_factory=list)
    system_prompt: str = "You are a helpful AI assistant."
    memory_enabled: bool = True
    max_retries: int = 2
    timeout: float = 60.0
    verbose: bool = False

    def to_dict(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "model": self.model,
            "max_steps": self.max_steps,
            "temperature": self.temperature,
            "system_prompt": self.system_prompt,
            "memory_enabled": self.memory_enabled,
            "max_retries": self.max_retries,
            "timeout": self.timeout,
            "verbose": self.verbose,
        }


@dataclass
class AgentStep:
    step_number: int = 0
    input: str = ""
    thought: str = ""
    action: str = ""
    action_input: Dict[str, Any] = field(default_factory=dict)
    observation: str = ""
    output: str = ""
    execution_time: float = 0.0
    error: Optional[str] = None
    timestamp: datetime = field(default_factory=datetime.utcnow)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "step_number": self.step_number,
            "input": self.input,
            "thought": self.thought,
            "action": self.action,
            "action_input": self.action_input,
            "observation": self.observation,
            "output": self.output,
            "execution_time": self.execution_time,
            "error": self.error,
            "timestamp": self.timestamp.isoformat(),
        }


@dataclass
class Trajectory:
    steps: List[AgentStep] = field(default_factory=list)
    start_time: datetime = field(default_factory=datetime.utcnow)
    end_time: Optional[datetime] = None

    def add_step(self, step: AgentStep) -> None:
        self.steps.append(step)

    @property
    def total_time(self) -> float:
        end = self.end_time or datetime.utcnow()
        return (end - self.start_time).total_seconds()

    @property
    def last_step(self) -> Optional[AgentStep]:
        return self.steps[-1] if self.steps else None

    def to_dict(self) -> Dict[str, Any]:
        return {
            "steps": [s.to_dict() for s in self.steps],
            "start_time": self.start_time.isoformat(),
            "end_time": self.end_time.isoformat() if self.end_time else None,
            "total_time": self.total_time,
        }


class Agent:
    def __init__(
        self,
        config: AgentConfig,
        llm_generate: Optional[Callable[[str], str]] = None,
        tool_executor: Optional[Callable[[str, Dict[str, Any]], str]] = None,
    ) -> None:
        self.config = config
        self.llm_generate = llm_generate
        self.tool_executor = tool_executor
        self.status = AgentStatus.IDLE
        self.trajectory = Trajectory()
        self._step_count = 0
        self._memory: List[str] = []
        self._error_count = 0

    def run(self, task: str, context: Optional[Dict[str, Any]] = None) -> str:
        self.status = AgentStatus.RUNNING
        self.trajectory = Trajectory()
        self._step_count = 0
        self._error_count = 0

        final_output = ""
        while self._step_count < self.config.max_steps:
            self._step_count += 1
            step = AgentStep(step_number=self._step_count, input=task)
            start = time.monotonic()

            try:
                prompt = self._build_prompt(task, context)
                response = self.llm_generate(prompt) if self.llm_generate else self._default_generate(prompt)

                thought = self._extract_thought(response)
                action = self._extract_action(response)
                action_input = self._extract_action_input(response)

                step.thought = thought or ""
                step.action = action or ""
                step.action_input = action_input

                if action and action_input and self.tool_executor:
                    observation = self.tool_executor(action, action_input)
                    step.observation = observation
                    if self.config.memory_enabled:
                        self._memory.append(f"Action: {action}({action_input}) -> {observation}")
                else:
                    step.observation = response

                step.output = response
                step.execution_time = time.monotonic() - start

                if self._is_finished(response):
                    final_output = self._extract_final(response) or response
                    step.output = final_output
                    self.trajectory.add_step(step)
                    break

            except Exception as e:
                step.error = str(e)
                step.execution_time = time.monotonic() - start
                self._error_count += 1
                if self._error_count > self.config.max_retries:
                    self.status = AgentStatus.FAILED
                    self.trajectory.add_step(step)
                    return f"Error: {e}"

            self.trajectory.add_step(step)

        self.status = AgentStatus.COMPLETED
        self.trajectory.end_time = datetime.utcnow()
        return final_output or self.trajectory.last_step.output if self.trajectory.last_step else ""

    def _build_prompt(self, task: str, context: Optional[Dict[str, Any]] = None) -> str:
        parts = [self.config.system_prompt]
        if context:
            parts.append(f"\nContext: {json.dumps(context, indent=2)}")
        if self.config.tools:
            tools_str = json.dumps(self.config.tools, indent=2)
            parts.append(f"\nAvailable tools:\n{tools_str}")
        if self.config.memory_enabled and self._memory:
            memory_str = "\n".join(self._memory[-5:])
            parts.append(f"\nRecent history:\n{memory_str}")
        parts.append(f"\nTask: {task}")
        parts.append("\nRespond with:\nThought: <your reasoning>\nAction: <tool name or 'final'>\nActionInput: <json arguments>\nObservation: <expected result>")
        return "\n".join(parts)

    def _extract_thought(self, response: str) -> Optional[str]:
        import re
        m = re.search(r"Thought:\s*(.*?)(?=\nAction|\nObservation|\Z)", response, re.DOTALL)
        return m.group(1).strip() if m else None

    def _extract_action(self, response: str) -> Optional[str]:
        import re
        m = re.search(r"Action:\s*(.*?)(?:\n|$)", response)
        return m.group(1).strip() if m else None

    def _extract_action_input(self, response: str) -> Dict[str, Any]:
        import re
        m = re.search(r"ActionInput:\s*(\{.*?\})", response, re.DOTALL)
        if m:
            try:
                return json.loads(m.group(1))
            except json.JSONDecodeError:
                pass
        m = re.search(r"ActionInput:\s*(.*?)(?=\nThought|\nAction|\nObservation|\Z)", response, re.DOTALL)
        if m:
            try:
                return json.loads(m.group(1).strip())
            except (json.JSONDecodeError, TypeError):
                return {"input": m.group(1).strip()}
        return {}

    def _is_finished(self, response: str) -> bool:
        return "Action: final" in response.lower() or "FINAL:" in response

    def _extract_final(self, response: str) -> Optional[str]:
        import re
        m = re.search(r"(?:Final Answer|FINAL):\s*(.*)", response, re.DOTALL)
        return m.group(1).strip() if m else None

    def _default_generate(self, prompt: str) -> str:
        return f"Thought: I need to process this task.\nAction: final\nObservation: Task received: {prompt[:100]}..."

    def reset(self) -> None:
        self.status = AgentStatus.IDLE
        self.trajectory = Trajectory()
        self._step_count = 0
        self._memory.clear()
        self._error_count = 0


class ChatAgent(Agent):
    def __init__(
        self,
        config: AgentConfig,
        llm_generate: Optional[Callable[[str], str]] = None,
    ) -> None:
        config.system_prompt = (
            "You are a conversational AI assistant. Respond naturally and helpfully. "
            "Keep responses concise and engaging."
        )
        super().__init__(config, llm_generate)

    def chat(self, message: str, history: Optional[List[Dict[str, str]]] = None) -> str:
        context: Dict[str, Any] = {}
        if history:
            context["conversation_history"] = history
        return self.run(message, context)


class TaskAgent(Agent):
    def __init__(
        self,
        config: AgentConfig,
        llm_generate: Optional[Callable[[str], str]] = None,
        tool_executor: Optional[Callable[[str, Dict[str, Any]], str]] = None,
    ) -> None:
        config.system_prompt = (
            "You are a goal-oriented task agent. Break down complex tasks into steps. "
            "Use tools when needed. Track progress toward the goal."
        )
        super().__init__(config, llm_generate, tool_executor)
        self._goal: Optional[str] = None
        self._subtasks: List[str] = []

    def run_with_goal(self, goal: str, tools: Optional[List[Dict[str, Any]]] = None) -> str:
        self._goal = goal
        if tools:
            self.config.tools = tools
        return self.run(goal)

    @property
    def progress(self) -> float:
        if not self._subtasks:
            return 0.0
        completed = sum(
            1 for step in self.trajectory.steps
            if step.error is None and step.output
        )
        return min(completed / max(len(self._subtasks), 1), 1.0)

    @property
    def goal(self) -> Optional[str]:
        return self._goal


class CodeAgent(Agent):
    def __init__(
        self,
        config: AgentConfig,
        llm_generate: Optional[Callable[[str], str]] = None,
        code_executor: Optional[Callable[[str, str], str]] = None,
    ) -> None:
        config.system_prompt = (
            "You are a code generation agent. Write clean, well-structured code. "
            "Explain your approach and test your code when possible."
        )
        super().__init__(config, llm_generate)
        self.code_executor = code_executor
        self._generated_code: Dict[str, str] = {}

    def generate_code(self, specification: str, language: str = "python") -> str:
        prompt = (
            f"Write {language} code for the following specification:\n{specification}\n\n"
            "Return the code in a code block."
        )
        result = self.run(prompt)
        self._generated_code[specification[:50]] = result
        return result

    def execute_code(self, code: str, language: str = "python") -> str:
        if self.code_executor:
            return self.code_executor(code, language)
        return "Code execution not available"

    def review_code(self, code: str) -> str:
        prompt = (
            f"Review the following code for bugs, security issues, and improvements:\n\n"
            f"```\n{code}\n```"
        )
        return self.run(prompt)


class ResearchAgent(Agent):
    def __init__(
        self,
        config: AgentConfig,
        llm_generate: Optional[Callable[[str], str]] = None,
        search_tool: Optional[Callable[[str], str]] = None,
    ) -> None:
        config.system_prompt = (
            "You are a research agent. Conduct thorough multi-step research on topics. "
            "Gather information from multiple angles, synthesize findings, and provide "
            "well-referenced conclusions."
        )
        config.max_steps = 30
        super().__init__(config, llm_generate)
        self.search_tool = search_tool
        self._findings: List[Dict[str, str]] = []

    def research(self, topic: str, depth: int = 3) -> str:
        plan_prompt = (
            f"Research topic: {topic}\n\n"
            f"Create a research plan with {depth} phases. "
            "For each phase, specify what to investigate."
        )
        plan = self.run(plan_prompt)

        for phase in range(1, depth + 1):
            if self.search_tool:
                search_query = f"{topic} - phase {phase}"
                result = self.search_tool(search_query)
                self._findings.append({"phase": str(phase), "query": search_query, "result": result})

        synthesis_prompt = (
            f"Synthesize all research findings on '{topic}' into a comprehensive report.\n"
            f"Findings:\n{json.dumps(self._findings, indent=2)}"
        )
        return self.run(synthesis_prompt)

    @property
    def findings(self) -> List[Dict[str, str]]:
        return self._findings


class AgentOrchestrator:
    def __init__(self) -> None:
        self._agents: Dict[str, Agent] = {}

    def register_agent(self, name: str, agent: Agent) -> None:
        self._agents[name] = agent

    def get_agent(self, name: str) -> Optional[Agent]:
        return self._agents.get(name)

    def run_pipeline(
        self,
        pipeline: List[Tuple[str, str]],
        shared_context: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, str]:
        results: Dict[str, str] = {}
        context = dict(shared_context or {})

        for agent_name, task in pipeline:
            agent = self._agents.get(agent_name)
            if agent is None:
                results[agent_name] = f"Agent '{agent_name}' not found"
                continue
            result = agent.run(task, context)
            results[agent_name] = result
            context[f"{agent_name}_output"] = result

        return results

    def run_parallel(
        self,
        assignments: List[Tuple[str, str]],
    ) -> Dict[str, str]:
        import concurrent.futures
        results: Dict[str, str] = {}

        with concurrent.futures.ThreadPoolExecutor(max_workers=len(assignments)) as executor:
            future_to_name = {}
            for agent_name, task in assignments:
                agent = self._agents.get(agent_name)
                if agent:
                    future = executor.submit(agent.run, task)
                    future_to_name[future] = agent_name
                else:
                    results[agent_name] = f"Agent '{agent_name}' not found"

            for future in concurrent.futures.as_completed(future_to_name):
                name = future_to_name[future]
                try:
                    results[name] = future.result()
                except Exception as e:
                    results[name] = f"Error: {e}"

        return results

    @property
    def agent_names(self) -> List[str]:
        return list(self._agents.keys())


class AgentLogger:
    def __init__(self, log_file: Optional[str] = None) -> None:
        self.log_file = log_file
        self._logs: List[Dict[str, Any]] = []

    def log(self, agent_name: str, event: str, details: Optional[Dict[str, Any]] = None) -> None:
        entry = {
            "timestamp": datetime.utcnow().isoformat(),
            "agent": agent_name,
            "event": event,
            "details": details or {},
        }
        self._logs.append(entry)
        if self.log_file:
            try:
                with open(self.log_file, "a") as f:
                    f.write(json.dumps(entry) + "\n")
            except (IOError, OSError):
                pass

    def get_logs(self, agent_name: Optional[str] = None) -> List[Dict[str, Any]]:
        if agent_name:
            return [log for log in self._logs if log["agent"] == agent_name]
        return self._logs

    def clear(self) -> None:
        self._logs.clear()

    def export(self, filepath: str) -> None:
        with open(filepath, "w") as f:
            json.dump(self._logs, f, indent=2, default=str)

    @property
    def count(self) -> int:
        return len(self._logs)
