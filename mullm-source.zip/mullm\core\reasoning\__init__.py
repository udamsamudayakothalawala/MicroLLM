"""muLLM Reasoning & Agent Features Module.

Complete reasoning, planning, memory, and agent orchestration for LLM pipelines.
"""

from mullm.core.reasoning.function_calling import (
    FunctionCallExecutor,
    FunctionCallParser,
    FunctionCallResult,
    FunctionRegistry,
    FunctionSpec,
)
from mullm.core.reasoning.tool_calling import (
    ToolCallExecutor,
    ToolCallFormatter,
    ToolCallParser,
    ToolExecutionError,
    ToolRegistry,
    ToolResultFormatter,
    ToolSpec,
)
from mullm.core.reasoning.json_output import (
    ConstrainedGenerator,
    JSONParser,
    JSONRepairer,
    JSONValidator,
    SchemaGenerator,
    StructuredOutputWrapper,
)
from mullm.core.reasoning.planning import (
    ChainOfThoughtPlanner,
    Plan,
    PlanExecutor,
    PlanStep,
    PlanStepStatus,
    PlanVerifier,
    Planner,
    ReActPlanner,
    ReplanningHandler,
)
from mullm.core.reasoning.memory import (
    EmbeddingConfig,
    EpisodicMemory,
    MemoryConsolidator,
    MemoryItem,
    MemoryQuery,
    MemoryResult,
    MemoryStore,
    SemanticMemory,
    VectorMemory,
    WorkingMemory,
)
from mullm.core.reasoning.rag import (
    Chunk,
    ChunkingStrategy,
    Citation,
    ContextBuilder,
    ContextWindow,
    Document,
    DocumentChunker,
    EmbeddingProvider,
    HybridRetriever,
    RAGConfig,
    RAGEngine,
    RAGEvaluator,
    RetrievalResult,
    SparseRetriever,
)
from mullm.core.reasoning.agent import (
    Agent,
    AgentConfig,
    AgentLogger,
    AgentOrchestrator,
    ChatAgent,
    CodeAgent,
    ResearchAgent,
    TaskAgent,
)
from mullm.core.reasoning.self_reflection import (
    ConfidenceScorer,
    RefinementLoop,
    SelfConsistency,
    SelfReflectionEngine,
    UncertaintyEstimator,
    VerificationQuestionGenerator,
)
from mullm.core.reasoning.task_decomposition import (
    DependencyGraph,
    DecompositionNode,
    DecompositionResult,
    ParallelTaskIdentifier,
    ProgressTracker,
    RecursiveDecomposer,
    TaskAssigner,
    TaskDecomposer,
)

__all__ = [
    # Function Calling
    "FunctionSpec",
    "FunctionRegistry",
    "FunctionCallParser",
    "FunctionCallExecutor",
    "FunctionCallResult",
    # Tool Calling
    "ToolSpec",
    "ToolRegistry",
    "ToolCallFormatter",
    "ToolCallParser",
    "ToolCallExecutor",
    "ToolResultFormatter",
    "ToolExecutionError",
    # JSON Output
    "JSONValidator",
    "JSONParser",
    "SchemaGenerator",
    "ConstrainedGenerator",
    "JSONRepairer",
    "StructuredOutputWrapper",
    # Planning
    "Planner",
    "Plan",
    "PlanStep",
    "PlanStepStatus",
    "PlanExecutor",
    "PlanVerifier",
    "ReplanningHandler",
    "ChainOfThoughtPlanner",
    "ReActPlanner",
    # Memory
    "MemoryStore",
    "EpisodicMemory",
    "SemanticMemory",
    "WorkingMemory",
    "VectorMemory",
    "MemoryConsolidator",
    "MemoryItem",
    "MemoryQuery",
    "MemoryResult",
    "EmbeddingConfig",
    # RAG
    "RAGConfig",
    "RAGEngine",
    "Document",
    "Chunk",
    "DocumentChunker",
    "ChunkingStrategy",
    "EmbeddingProvider",
    "HybridRetriever",
    "SparseRetriever",
    "ContextBuilder",
    "ContextWindow",
    "Citation",
    "RetrievalResult",
    "RAGEvaluator",
    # Agent
    "AgentConfig",
    "Agent",
    "ChatAgent",
    "TaskAgent",
    "CodeAgent",
    "ResearchAgent",
    "AgentOrchestrator",
    "AgentLogger",
    # Self Reflection
    "SelfReflectionEngine",
    "ConfidenceScorer",
    "RefinementLoop",
    "UncertaintyEstimator",
    "VerificationQuestionGenerator",
    "SelfConsistency",
    # Task Decomposition
    "TaskDecomposer",
    "RecursiveDecomposer",
    "DecompositionNode",
    "DecompositionResult",
    "DependencyGraph",
    "ParallelTaskIdentifier",
    "TaskAssigner",
    "ProgressTracker",
]

__version__ = "1.0.0"
