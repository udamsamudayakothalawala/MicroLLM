import abc
import json
import os
from dataclasses import dataclass, field
from typing import Dict, Iterator, List, Optional, Sequence, Set, Tuple, Union


@dataclass
class SpecialTokens:
    bos_token: Optional[str] = None
    eos_token: Optional[str] = None
    unk_token: Optional[str] = "<unk>"
    pad_token: Optional[str] = "<pad>"
    sep_token: Optional[str] = None
    cls_token: Optional[str] = None
    mask_token: Optional[str] = "<mask>"
    additional_tokens: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Optional[str]]:
        return {
            "bos_token": self.bos_token,
            "eos_token": self.eos_token,
            "unk_token": self.unk_token,
            "pad_token": self.pad_token,
            "sep_token": self.sep_token,
            "cls_token": self.cls_token,
            "mask_token": self.mask_token,
        }

    @classmethod
    def from_dict(cls, d: Dict[str, Optional[str]]) -> "SpecialTokens":
        return cls(
            bos_token=d.get("bos_token"),
            eos_token=d.get("eos_token"),
            unk_token=d.get("unk_token", "<unk>"),
            pad_token=d.get("pad_token", "<pad>"),
            sep_token=d.get("sep_token"),
            cls_token=d.get("cls_token"),
            mask_token=d.get("mask_token", "<mask>"),
            additional_tokens=d.get("additional_tokens", []),
        )

    @property
    def all_special_tokens(self) -> List[str]:
        tokens: List[str] = []
        for t in [self.bos_token, self.eos_token, self.unk_token, self.pad_token, self.sep_token, self.cls_token, self.mask_token]:
            if t is not None:
                tokens.append(t)
        tokens.extend(self.additional_tokens)
        return tokens


class BaseTokenizer(abc.ABC):
    def __init__(self, special_tokens: Optional[SpecialTokens] = None) -> None:
        self._special_tokens = special_tokens or SpecialTokens()
        self._added_tokens: Dict[str, int] = {}
        self._added_tokens_decoder: Dict[int, str] = {}

    @property
    def special_tokens(self) -> SpecialTokens:
        return self._special_tokens

    @abc.abstractmethod
    def encode(self, text: str, add_special_tokens: bool = True) -> List[int]:
        ...

    @abc.abstractmethod
    def decode(self, ids: Sequence[int], skip_special_tokens: bool = True) -> str:
        ...

    @property
    @abc.abstractmethod
    def vocab_size(self) -> int:
        ...

    def __len__(self) -> int:
        return self.vocab_size

    def add_special_tokens(self, special_tokens_dict: Dict[str, Optional[str]]) -> int:
        num_added = 0
        for name, token in special_tokens_dict.items():
            if token is not None and token not in self._special_tokens.all_special_tokens:
                setattr(self._special_tokens, f"{name}_token", token)
                if token not in self._added_tokens:
                    idx = self.vocab_size + len(self._added_tokens)
                    self._added_tokens[token] = idx
                    self._added_tokens_decoder[idx] = token
                    num_added += 1
        return num_added

    def add_tokens(self, tokens: List[str]) -> int:
        num_added = 0
        for token in tokens:
            if token not in self._added_tokens:
                idx = self.vocab_size + len(self._added_tokens)
                self._added_tokens[token] = idx
                self._added_tokens_decoder[idx] = token
                num_added += 1
        return num_added

    def convert_tokens_to_ids(self, tokens: Union[str, List[str]]) -> Union[int, List[int]]:
        if isinstance(tokens, str):
            return self._token_to_id(tokens)
        return [self._token_to_id(t) for t in tokens]

    def convert_ids_to_tokens(self, ids: Union[int, List[int]]) -> Union[str, List[str]]:
        if isinstance(ids, int):
            return self._id_to_token(ids)
        return [self._id_to_token(i) for i in ids]

    @abc.abstractmethod
    def _token_to_id(self, token: str) -> int:
        ...

    @abc.abstractmethod
    def _id_to_token(self, idx: int) -> str:
        ...

    def all_special_ids(self) -> List[int]:
        return [self._token_to_id(t) for t in self._special_tokens.all_special_tokens if t in self._added_tokens or self._token_to_id(t) != self.vocab_size]

    def bos_token_id(self) -> Optional[int]:
        if self._special_tokens.bos_token is not None:
            return self._token_to_id(self._special_tokens.bos_token)
        return None

    def eos_token_id(self) -> Optional[int]:
        if self._special_tokens.eos_token is not None:
            return self._token_to_id(self._special_tokens.eos_token)
        return None

    def unk_token_id(self) -> Optional[int]:
        if self._special_tokens.unk_token is not None:
            return self._token_to_id(self._special_tokens.unk_token)
        return None

    def pad_token_id(self) -> Optional[int]:
        if self._special_tokens.pad_token is not None:
            return self._token_to_id(self._special_tokens.pad_token)
        return None

    def save_vocabulary(self, path: str) -> None:
        os.makedirs(os.path.dirname(path) if os.path.dirname(path) else ".", exist_ok=True)
        vocab = self._get_vocab()
        data = {
            "vocab": vocab,
            "special_tokens": self._special_tokens.to_dict(),
            "added_tokens": self._added_tokens,
        }
        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)

    def load_vocabulary(self, path: str) -> None:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        self._set_vocab(data["vocab"])
        self._special_tokens = SpecialTokens.from_dict(data.get("special_tokens", {}))
        self._added_tokens = data.get("added_tokens", {})
        self._added_tokens_decoder = {v: k for k, v in self._added_tokens.items()}

    @abc.abstractmethod
    def _get_vocab(self) -> Dict[str, int]:
        ...

    @abc.abstractmethod
    def _set_vocab(self, vocab: Dict[str, int]) -> None:
        ...

    def train_from_iterator(
        self,
        texts: Iterator[str],
        vocab_size: int,
        show_progress: bool = True,
    ) -> None:
        raise NotImplementedError(
            f"{self.__class__.__name__} does not support training from iterator"
        )

    def encode_batch(
        self, texts: Sequence[str], add_special_tokens: bool = True
    ) -> List[List[int]]:
        return [self.encode(t, add_special_tokens=add_special_tokens) for t in texts]

    def decode_batch(
        self, batch: Sequence[Sequence[int]], skip_special_tokens: bool = True
    ) -> List[str]:
        return [self.decode(ids, skip_special_tokens=skip_special_tokens) for ids in batch]

    def num_special_tokens_to_add(self, pair: bool = False) -> int:
        count = 0
        if self._special_tokens.bos_token is not None:
            count += 1
        if self._special_tokens.eos_token is not None:
            count += 1
        if pair and self._special_tokens.sep_token is not None:
            count += 1
        return count

    def build_inputs_with_special_tokens(
        self, token_ids_0: List[int], token_ids_1: Optional[List[int]] = None
    ) -> List[int]:
        bos = self.bos_token_id()
        eos = self.eos_token_id()
        ids: List[int] = []
        if bos is not None:
            ids.append(bos)
        ids.extend(token_ids_0)
        if eos is not None:
            ids.append(eos)
        if token_ids_1 is not None:
            sep = self._special_tokens.sep_token
            sep_id = self._token_to_id(sep) if sep is not None else None
            if sep_id is not None:
                ids.append(sep_id)
            ids.extend(token_ids_1)
            if eos is not None:
                ids.append(eos)
        return ids

    def __repr__(self) -> str:
        return f"{self.__class__.__name__}(vocab_size={self.vocab_size})"
