"""muLLM GUI - Main window with tabs."""

import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))

import torch  # noqa: E402  (must load before PyQt5 to avoid DLL conflicts on Windows)

from PyQt5.QtWidgets import (
    QMainWindow, QTabWidget, QStatusBar, QMessageBox,
    QVBoxLayout, QWidget, QLabel, QHBoxLayout
)
from PyQt5.QtGui import QIcon

from .theme import DARK_STYLE
from .dataset_tab import DatasetTab
from .train_tab import TrainTab
from .eval_tab import EvalTab
from .export_tab import ExportTab


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("muLLM - Train / Test / Export GGUF")
        self.setMinimumSize(1200, 800)
        self.setStyleSheet(DARK_STYLE)
        _ico = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "assets", "MULLMICON.png")
        if os.path.exists(_ico):
            self.setWindowIcon(QIcon(_ico))

        central = QWidget()
        self.setCentralWidget(central)
        layout = QVBoxLayout(central)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        title_bar = QWidget()
        title_bar.setStyleSheet("background: #161926; border-bottom: 1px solid #2d2d4e;")
        tb = QHBoxLayout(title_bar)
        tb.setContentsMargins(16, 8, 16, 8)
        logo = QLabel("muLLM")
        logo.setStyleSheet("font-size: 16px; font-weight: 700; color: #6366f1;")
        tb.addWidget(logo)
        tb.addStretch()
        v = QLabel("Train a small LLM with as little as 1M tokens")
        v.setStyleSheet("font-size: 11px; color: #666;")
        tb.addWidget(v)
        layout.addWidget(title_bar)

        self.tabs = QTabWidget()
        self.tabs.setDocumentMode(True)
        layout.addWidget(self.tabs)

        self.dataset_tab = DatasetTab()
        self.train_tab = TrainTab(dataset_tab=self.dataset_tab)
        self.eval_tab = EvalTab()
        self.export_tab = ExportTab()

        self.tabs.addTab(self.dataset_tab, "1. Feed Data")
        self.tabs.addTab(self.train_tab, "2. Train")
        self.tabs.addTab(self.eval_tab, "3. Test Model")
        self.tabs.addTab(self.export_tab, "4. Export GGUF")

        self.tabs.setTabToolTip(0, "Load training data (.txt, .json, .jsonl, .csv)")
        self.tabs.setTabToolTip(1, "Configure and run training with live loss monitoring")
        self.tabs.setTabToolTip(2, "Evaluate and test generation before exporting")
        self.tabs.setTabToolTip(3, "Export the trained model to GGUF for llama.cpp")

        self.tabs.currentChanged.connect(self._on_tab)
        self.status_bar = QStatusBar()
        self.status_bar.showMessage("Ready")
        self.setStatusBar(self.status_bar)

    def _on_tab(self, idx):
        names = ["Dataset", "Training", "Testing", "Export GGUF"]
        if idx < len(names):
            self.status_bar.showMessage(f"Tab: {names[idx]}")

    def closeEvent(self, event):
        if hasattr(self.train_tab, "trainer") and self.train_tab.trainer:
            self.train_tab.trainer.stop()
        event.accept()