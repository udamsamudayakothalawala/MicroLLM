import json
import re
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional, Sequence, Tuple, Union


CHATML_TEMPLATE = (
    "{% for message in messages %}"
    "{% if message.role == 'system' %}<|im_start|>system\n{{ message.content }}<|im_end|>\n"
    "{% elif message.role == 'user' %}<|im_start|>user\n{{ message.content }}<|im_end|>\n"
    "{% elif message.role == 'assistant' %}<|im_start|>assistant\n{{ message.content }}<|im_end|>\n"
    "{% endif %}"
    "{% endfor %}"
    "{% if add_generation_prompt %}<|im_start|>assistant\n{% endif %}"
)

LLAMA_TEMPLATE = (
    "{% if messages[0].role == 'system' %}"
    "<<SYS>>\n{{ messages[0].content }}\n<</SYS>>\n\n"
    "{% endif %}"
    "{% for message in messages %}"
    "{% if message.role == 'system' %}{% continue %}{% endif %}"
    "{% if message.role == 'user' %}[INST] {{ message.content }} [/INST]"
    "{% elif message.role == 'assistant' %}{{ message.content }}</s>"
    "{% endif %}"
    "{% endfor %}"
)

MISTRAL_TEMPLATE = (
    "{% for message in messages %}"
    "{% if message.role == 'user' %}[INST] {{ message.content }} [/INST]"
    "{% elif message.role == 'assistant' %}{{ message.content }}</s>"
    "{% endif %}"
    "{% endfor %}"
)

GEMMA_TEMPLATE = (
    "{% for message in messages %}"
    "{% if message.role == 'user' %}<start_of_turn>user\n{{ message.content }}<end_of_turn>\n"
    "{% elif message.role == 'assistant' %}<start_of_turn>model\n{{ message.content }}<end_of_turn>\n"
    "{% endif %}"
    "{% endfor %}"
    "{% if add_generation_prompt %}<start_of_turn>model\n{% endif %}"
)

DEEPSEEK_TEMPLATE = (
    "{% for message in messages %}"
    "{% if message.role == 'user' %}User: {{ message.content }}\n\n"
    "{% elif message.role == 'assistant' %}Assistant: {{ message.content }}\n\n"
    "{% elif message.role == 'system' %}{{ message.content }}\n\n"
    "{% endif %}"
    "{% endfor %}"
    "{% if add_generation_prompt %}Assistant: {% endif %}"
)

BUILTIN_TEMPLATES: Dict[str, str] = {
    "chatml": CHATML_TEMPLATE,
    "llama": LLAMA_TEMPLATE,
    "mistral": MISTRAL_TEMPLATE,
    "gemma": GEMMA_TEMPLATE,
    "deepseek": DEEPSEEK_TEMPLATE,
}


class TemplateParseError(Exception):
    pass


class TemplateSyntaxError(TemplateParseError):
    pass


@dataclass
class Message:
    role: str
    content: str
    name: Optional[str] = None
    tool_calls: Optional[List[Dict[str, Any]]] = None
    tool_call_id: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        d: Dict[str, Any] = {"role": self.role, "content": self.content}
        if self.name is not None:
            d["name"] = self.name
        if self.tool_calls is not None:
            d["tool_calls"] = self.tool_calls
        if self.tool_call_id is not None:
            d["tool_call_id"] = self.tool_call_id
        return d

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "Message":
        return cls(
            role=d.get("role", "user"),
            content=d.get("content", ""),
            name=d.get("name"),
            tool_calls=d.get("tool_calls"),
            tool_call_id=d.get("tool_call_id"),
        )


class TemplateEngine:
    def __init__(self, template: str) -> None:
        self._template = template
        self._parsed = self._parse(template)

    def _parse(self, template: str) -> List[Tuple[str, str]]:
        tokens: List[Tuple[str, str]] = []
        i = 0
        while i < len(template):
            if template[i : i + 2] == "{{":
                j = template.find("}}", i + 2)
                if j == -1:
                    raise TemplateSyntaxError("Unmatched {{")
                expr = template[i + 2 : j].strip()
                tokens.append(("var", expr))
                i = j + 2
            elif template[i : i + 2] == "{%":
                j = template.find("%}", i + 2)
                if j == -1:
                    raise TemplateSyntaxError("Unmatched {%")
                expr = template[i + 2 : j].strip()
                tokens.append(("tag", expr))
                i = j + 2
            else:
                j = i
                while j < len(template):
                    if template[j : j + 2] in ("{{", "{%"):
                        break
                    j += 1
                if j > i:
                    tokens.append(("text", template[i:j]))
                i = j
        return tokens

    def _evaluate_expression(
        self, expr: str, context: Dict[str, Any]
    ) -> Any:
        parts = expr.split("|")
        var_expr = parts[0].strip()
        filters = [f.strip() for f in parts[1:]] if len(parts) > 1 else []

        value = self._resolve_var(var_expr, context)

        for filter_name in filters:
            value = self._apply_filter(value, filter_name)

        return value

    def _resolve_var(self, var_expr: str, context: Dict[str, Any]) -> Any:
        var_expr = var_expr.strip()

        if var_expr.startswith("'") and var_expr.endswith("'"):
            return var_expr[1:-1]
        if var_expr.startswith('"') and var_expr.endswith('"'):
            return var_expr[1:-1]
        if var_expr in ("True", "False"):
            return var_expr == "True"
        if var_expr in ("None", "none", "null"):
            return None
        try:
            if "." in var_expr or "_" in var_expr or var_expr.isalpha():
                pass
            else:
                return int(var_expr)
        except (ValueError, TypeError):
            try:
                return float(var_expr)
            except (ValueError, TypeError):
                pass

        parts = var_expr.split(".")
        current: Any = context
        for part in parts:
            part = part.strip()
            if not part:
                continue
            bracket_match = re.match(r"^(\w+)\[(\d+)\]$", part)
            if bracket_match:
                var_name = bracket_match.group(1)
                index = int(bracket_match.group(2))
                if isinstance(current, dict):
                    current = current.get(var_name, {})
                else:
                    current = getattr(current, var_name, {})
                try:
                    current = current[int(index)]
                except (IndexError, KeyError, TypeError):
                    return None
            elif part in ("True", "False"):
                current = part == "True"
            elif part in ("None", "none"):
                current = None
            elif part.isdigit():
                current = int(part)
            elif isinstance(current, dict):
                current = current.get(part, None)
            elif isinstance(current, (list, tuple)):
                try:
                    idx = int(part)
                    current = current[idx]
                except (ValueError, IndexError, TypeError):
                    return None
            else:
                try:
                    current = getattr(current, part, None)
                except (AttributeError, TypeError):
                    return None
        return current

    def _apply_filter(self, value: Any, filter_name: str) -> Any:
        if filter_name == "trim":
            return str(value).strip() if value is not None else ""
        elif filter_name == "lower":
            return str(value).lower() if value is not None else ""
        elif filter_name == "upper":
            return str(value).upper() if value is not None else ""
        elif filter_name == "title":
            return str(value).title() if value is not None else ""
        elif filter_name.startswith("default("):
            default_val = filter_name[len("default(") : -1]
            if value is None or value == "":
                return default_val.strip('"').strip("'")
            return value
        elif filter_name == "length":
            return len(value) if value is not None else 0
        elif filter_name == "reverse":
            if isinstance(value, list):
                return list(reversed(value))
            if isinstance(value, str):
                return value[::-1]
            return value
        else:
            return value

    def _evaluate_condition(self, expr: str, context: Dict[str, Any]) -> bool:
        expr = expr.strip()
        if " not in " in expr:
            parts = expr.split(" not in ")
            var = self._evaluate_expression(parts[0].strip(), context)
            container = self._evaluate_expression(parts[1].strip(), context)
            if container is None:
                return True
            if hasattr(container, "__contains__"):
                return var not in container
            return str(var) not in str(container)
        elif " in " in expr:
            parts = expr.split(" in ")
            var = self._evaluate_expression(parts[0].strip(), context)
            container = self._evaluate_expression(parts[1].strip(), context)
            if container is None:
                return False
            if hasattr(container, "__contains__"):
                return var in container
            return str(var) in str(container)
        elif "!=" in expr:
            parts = expr.split("!=")
            left = self._evaluate_expression(parts[0].strip(), context)
            right = self._evaluate_expression(parts[1].strip(), context)
            return str(left) != str(right)
        elif "==" in expr:
            parts = expr.split("==")
            left = self._evaluate_expression(parts[0].strip(), context)
            right = self._evaluate_expression(parts[1].strip(), context)
            return str(left) == str(right)
        elif ">=" in expr:
            parts = expr.split(">=")
            left = self._evaluate_expression(parts[0].strip(), context)
            right = self._evaluate_expression(parts[1].strip(), context)
            try:
                return float(left) >= float(right)
            except (TypeError, ValueError):
                return False
        elif "<=" in expr:
            parts = expr.split("<=")
            left = self._evaluate_expression(parts[0].strip(), context)
            right = self._evaluate_expression(parts[1].strip(), context)
            try:
                return float(left) <= float(right)
            except (TypeError, ValueError):
                return False
        elif ">" in expr:
            parts = expr.split(">")
            left = self._evaluate_expression(parts[0].strip(), context)
            right = self._evaluate_expression(parts[1].strip(), context)
            try:
                return float(left) > float(right)
            except (TypeError, ValueError):
                return False
        elif "<" in expr:
            parts = expr.split("<")
            left = self._evaluate_expression(parts[0].strip(), context)
            right = self._evaluate_expression(parts[1].strip(), context)
            try:
                return float(left) < float(right)
            except (TypeError, ValueError):
                return False
        else:
            val = self._evaluate_expression(expr, context)
            if val is None or val is False:
                return False
            if isinstance(val, str):
                return len(val) > 0
            if isinstance(val, (list, tuple, dict, set)):
                return len(val) > 0
            if isinstance(val, (int, float)):
                return val != 0
            return bool(val)

    def render(self, **kwargs: Any) -> str:
        return self._render_tokens(self._parsed, kwargs)

    def _render_tokens(
        self, tokens: List[Tuple[str, str]], context: Dict[str, Any]
    ) -> str:
        output: List[str] = []
        i = 0
        while i < len(tokens):
            tok_type, expr = tokens[i]
            if tok_type == "text":
                output.append(expr)
            elif tok_type == "var":
                value = self._evaluate_expression(expr, context)
                if value is not None:
                    output.append(str(value))
            elif tok_type == "tag":
                parts = expr.split()
                if not parts:
                    raise TemplateSyntaxError("Empty tag")
                tag = parts[0]
                if tag == "for":
                    var_name = parts[1]
                    if "in" not in parts[2:]:
                        raise TemplateSyntaxError("for tag missing 'in'")
                    in_idx = parts.index("in", 2)
                    iter_expr = " ".join(parts[in_idx + 1 :])
                    iterable = self._evaluate_expression(iter_expr, context)
                    if iterable is None:
                        iterable = []
                    end_idx = self._find_matching_end(tokens, i + 1, "endfor")
                    body_tokens = tokens[i + 1 : end_idx]
                    inner_output: List[str] = []
                    for item in iterable:
                        sub_context = dict(context)
                        sub_context[var_name] = item
                        inner_output.append(
                            self._render_tokens(body_tokens, sub_context)
                        )
                    output.append("".join(inner_output))
                    i = end_idx
                elif tag == "if":
                    condition = " ".join(parts[1:])
                    branches, endif_idx = self._collect_if_branches(
                        tokens, i + 1, condition
                    )
                    for branch_cond, branch_body in branches:
                        if branch_cond is None:
                            output.append(
                                self._render_tokens(branch_body, context)
                            )
                            break
                        elif self._evaluate_condition(branch_cond, context):
                            output.append(
                                self._render_tokens(branch_body, context)
                            )
                            break
                    i = endif_idx
                elif tag == "continue":
                    return ""
                elif tag == "set":
                    var_name = parts[1]
                    if "=" in parts:
                        eq_idx = parts.index("=")
                        val_expr = " ".join(parts[eq_idx + 1 :])
                        context[var_name] = self._evaluate_expression(
                            val_expr, context
                        )
                    else:
                        context[var_name] = ""
            i += 1
        return "".join(output)

    def _find_matching_end(
        self, tokens: List[Tuple[str, str]], start: int, end_tag: str
    ) -> int:
        depth = 1
        for i in range(start, len(tokens)):
            if tokens[i][0] == "tag":
                tag = tokens[i][1].split()[0]
                if tag in ("for", "if"):
                    depth += 1
                elif tag in ("endfor", "endif"):
                    depth -= 1
                    if depth == 0:
                        return i
        raise TemplateSyntaxError(f"Unmatched tag, expected '{end_tag}'")

    def _collect_if_branches(
        self, tokens: List[Tuple[str, str]], start: int, initial_cond: str
    ) -> Tuple[List[Tuple[Optional[str], List[Tuple[str, str]]]], int]:
        branches: List[Tuple[Optional[str], List[Tuple[str, str]]]] = []
        depth = 1
        branch_start = start
        current_cond: Optional[str] = initial_cond

        for i in range(start, len(tokens)):
            if tokens[i][0] != "tag":
                continue

            tag = tokens[i][1].split()[0]
            if tag == "if":
                depth += 1
            elif tag == "endif":
                depth -= 1
                if depth == 0:
                    body = tokens[branch_start:i]
                    branches.append((current_cond, body))
                    return branches, i
            elif tag == "elif":
                if depth == 1:
                    body = tokens[branch_start:i]
                    branches.append((current_cond, body))
                    cond = tokens[i][1][4:].strip()
                    current_cond = cond if cond else None
                    branch_start = i + 1
            elif tag == "else":
                if depth == 1:
                    body = tokens[branch_start:i]
                    branches.append((current_cond, body))
                    current_cond = None
                    branch_start = i + 1

        raise TemplateSyntaxError("Unmatched if tag")


class ChatTemplate:
    def __init__(
        self,
        template: Union[str, TemplateEngine],
        builtin_name: Optional[str] = None,
    ) -> None:
        if isinstance(template, TemplateEngine):
            self._engine = template
        else:
            self._engine = TemplateEngine(template)
        self._builtin_name = builtin_name

    @classmethod
    def from_builtin(cls, name: str) -> "ChatTemplate":
        name = name.lower()
        if name not in BUILTIN_TEMPLATES:
            available = ", ".join(BUILTIN_TEMPLATES.keys())
            raise ValueError(
                f"Unknown builtin template '{name}'. Available: {available}"
            )
        return cls(BUILTIN_TEMPLATES[name], builtin_name=name)

    @classmethod
    def from_file(cls, path: str) -> "ChatTemplate":
        with open(path, "r", encoding="utf-8") as f:
            template_str = f.read()
        return cls(template_str)

    @classmethod
    def from_huggingface(cls, repo_id: str, revision: str = "main") -> "ChatTemplate":
        try:
            from huggingface_hub import hf_hub_download
            import json

            config_path = hf_hub_download(
                repo_id=repo_id, filename="tokenizer_config.json", revision=revision
            )
            with open(config_path, "r", encoding="utf-8") as f:
                config = json.load(f)
            chat_template_str = config.get("chat_template")
            if chat_template_str is None:
                raise ValueError(
                    f"No chat_template found in tokenizer_config.json for {repo_id}"
                )
            return cls(chat_template_str)
        except ImportError:
            raise ImportError(
                "huggingface_hub is required to load templates from HuggingFace"
            )

    @property
    def engine(self) -> TemplateEngine:
        return self._engine

    @property
    def builtin_name(self) -> Optional[str]:
        return self._builtin_name

    def apply(
        self,
        messages: Sequence[Union[Dict[str, Any], Message]],
        add_generation_prompt: bool = True,
        tools: Optional[List[Dict[str, Any]]] = None,
        **kwargs: Any,
    ) -> str:
        converted: List[Dict[str, Any]] = []
        for m in messages:
            if isinstance(m, Message):
                converted.append(m.to_dict())
            elif isinstance(m, dict):
                converted.append(dict(m))
            else:
                converted.append({"role": "user", "content": str(m)})

        context: Dict[str, Any] = {
            "messages": converted,
            "add_generation_prompt": add_generation_prompt,
        }
        if tools is not None:
            context["tools"] = tools
        context.update(kwargs)

        return self._engine.render(**context)

    def render_tools(
        self, tools: List[Dict[str, Any]]
    ) -> str:
        rendered: List[str] = []
        for tool in tools:
            name = tool.get("name", "unknown")
            description = tool.get("description", "")
            parameters = tool.get("parameters", {})

            rendered.append(f"Tool: {name}")
            if description:
                rendered.append(f"Description: {description}")

            if parameters:
                props = parameters.get("properties", {})
                required = parameters.get("required", [])
                if props:
                    rendered.append("Parameters:")
                    for param_name, param_info in props.items():
                        param_type = param_info.get("type", "any")
                        param_desc = param_info.get("description", "")
                        req = "required" if param_name in required else "optional"
                        rendered.append(
                            f"  - {param_name}: {param_type} ({req})"
                        )
                        if param_desc:
                            rendered.append(f"      {param_desc}")
            rendered.append("")

        return "\n".join(rendered).strip()

    def __repr__(self) -> str:
        if self._builtin_name:
            return f"ChatTemplate(builtin='{self._builtin_name}')"
        return f"ChatTemplate(template='{str(self._engine._template[:50])}...')"
