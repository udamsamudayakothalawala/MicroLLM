"""Function calling system for LLM function execution."""

from __future__ import annotations

import inspect
import json
import re
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Callable, Dict, List, Optional, Tuple, Type, Union


@dataclass
class FunctionSpec:
    name: str
    description: str
    parameters: Dict[str, Any]
    required: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "type": "function",
            "function": {
                "name": self.name,
                "description": self.description,
                "parameters": {
                    "type": "object",
                    "properties": self.parameters,
                    "required": self.required,
                },
            },
        }

    def validate_arguments(self, arguments: Dict[str, Any]) -> Tuple[bool, Optional[str]]:
        for req in self.required:
            if req not in arguments:
                return False, f"Missing required parameter: '{req}'"
        for key in arguments:
            if key not in self.parameters:
                return False, f"Unknown parameter: '{key}'"
        return True, None


@dataclass
class FunctionCallResult:
    function_name: str
    arguments: Dict[str, Any]
    result: Any
    success: bool
    error: Optional[str] = None
    execution_time: Optional[float] = None
    timestamp: datetime = field(default_factory=datetime.utcnow)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "function_name": self.function_name,
            "arguments": self.arguments,
            "result": self.result,
            "success": self.success,
            "error": self.error,
            "execution_time": self.execution_time,
            "timestamp": self.timestamp.isoformat(),
        }


TypeCoercionMap = {
    "string": str,
    "integer": int,
    "number": float,
    "boolean": bool,
    "array": list,
    "object": dict,
}


def _coerce_value(value: Any, expected_type: str, param_name: str) -> Any:
    if value is None:
        return None
    coercer = TypeCoercionMap.get(expected_type)
    if coercer is None:
        return value
    if expected_type == "boolean":
        if isinstance(value, bool):
            return value
        if isinstance(value, str):
            if value.lower() in ("true", "1", "yes"):
                return True
            if value.lower() in ("false", "0", "no"):
                return False
        if isinstance(value, (int, float)):
            return bool(value)
        raise ValueError(f"Cannot coerce '{param_name}' (value={value!r}) to boolean")
    if expected_type == "integer":
        if isinstance(value, float):
            return int(value)
        if isinstance(value, str):
            return int(value.strip())
        if isinstance(value, int):
            return value
        raise ValueError(f"Cannot coerce '{param_name}' (value={value!r}) to integer")
    if expected_type == "number":
        if isinstance(value, (int, float)):
            return float(value)
        if isinstance(value, str):
            return float(value.strip())
        raise ValueError(f"Cannot coerce '{param_name}' (value={value!r}) to number")
    if expected_type == "string":
        if isinstance(value, (int, float, bool)):
            return str(value)
        if isinstance(value, str):
            return value
        raise ValueError(f"Cannot coerce '{param_name}' (value={value!r}) to string")
    if expected_type == "array":
        if isinstance(value, list):
            return value
        if isinstance(value, str):
            parsed = json.loads(value)
            if isinstance(parsed, list):
                return parsed
        raise ValueError(f"Cannot coerce '{param_name}' (value={value!r}) to array")
    if expected_type == "object":
        if isinstance(value, dict):
            return value
        if isinstance(value, str):
            parsed = json.loads(value)
            if isinstance(parsed, dict):
                return parsed
        raise ValueError(f"Cannot coerce '{param_name}' (value={value!r}) to object")
    return value


class FunctionRegistry:
    def __init__(self) -> None:
        self._functions: Dict[str, FunctionSpec] = {}
        self._callables: Dict[str, Callable[..., Any]] = {}

    def register(
        self,
        fn: Optional[Callable[..., Any]] = None,
        *,
        name: Optional[str] = None,
        description: Optional[str] = None,
        parameters: Optional[Dict[str, Any]] = None,
        required: Optional[List[str]] = None,
        spec: Optional[FunctionSpec] = None,
    ) -> FunctionSpec:
        if spec is not None:
            self._functions[spec.name] = spec
            return spec

        actual_name = name or (fn.__name__ if fn else "unnamed")
        actual_description = description or (fn.__doc__ or "") if fn else ""
        if parameters is None and fn is not None:
            parameters = self._infer_parameters(fn)
        if parameters is None:
            parameters = {}
        actual_required = required or list(parameters.keys() if parameters else [])

        func_spec = FunctionSpec(
            name=actual_name,
            description=actual_description,
            parameters=parameters,
            required=actual_required,
        )
        self._functions[func_spec.name] = func_spec
        if fn is not None:
            self._callables[func_spec.name] = fn
        return func_spec

    def _infer_parameters(self, fn: Callable[..., Any]) -> Dict[str, Any]:
        sig = inspect.signature(fn)
        params: Dict[str, Any] = {}
        for param_name, param in sig.parameters.items():
            if param_name in ("self", "cls"):
                continue
            type_str = "string"
            if param.annotation is not inspect.Parameter.empty:
                ann = param.annotation
                if ann is int:
                    type_str = "integer"
                elif ann is float:
                    type_str = "number"
                elif ann is bool:
                    type_str = "boolean"
                elif ann is list or getattr(ann, "__origin__", None) is list:
                    type_str = "array"
                elif ann is dict or getattr(ann, "__origin__", None) is dict:
                    type_str = "object"
                elif ann is str:
                    type_str = "string"
            params[param_name] = {"type": type_str, "description": ""}
        return params

    def list_functions(self) -> List[FunctionSpec]:
        return list(self._functions.values())

    def get(self, name: str) -> Optional[FunctionSpec]:
        return self._functions.get(name)

    def get_callable(self, name: str) -> Optional[Callable[..., Any]]:
        return self._callables.get(name)

    def remove(self, name: str) -> None:
        self._functions.pop(name, None)
        self._callables.pop(name, None)

    def clear(self) -> None:
        self._functions.clear()
        self._callables.clear()

    @property
    def count(self) -> int:
        return len(self._functions)


class FunctionCallParser:
    FUNCTION_CALL_RE = re.compile(
        r'(?:<functioncall>|```function)\s*'
        r'(?P<json_body>\{.*?\})\s*(?:</functioncall>|```)',
        re.DOTALL,
    )

    OPENAI_TOOL_CALL_RE = re.compile(
        r'\{\s*"name"\s*:\s*"(?P<name>[^"]+)"\s*,'
        r'\s*"arguments"\s*:\s*(?P<args>\{.*?\})\s*\}',
        re.DOTALL,
    )

    FUNCTION_MARKER_RE = re.compile(
        r'(?P<name>[a-zA-Z_]\w*)\s*\((?P<args>[^)]*)\)\s*',
    )

    def __init__(self, registry: Optional[FunctionRegistry] = None) -> None:
        self.registry = registry or FunctionRegistry()

    def parse(self, text: str) -> List[Dict[str, Any]]:
        calls: List[Dict[str, Any]] = []

        for match in self.FUNCTION_CALL_RE.finditer(text):
            try:
                body = json.loads(match.group("json_body"))
                if isinstance(body, list):
                    calls.extend(body)
                elif isinstance(body, dict):
                    calls.append(body)
            except json.JSONDecodeError:
                continue

        for match in self.OPENAI_TOOL_CALL_RE.finditer(text):
            try:
                args = json.loads(match.group("args"))
                calls.append({
                    "name": match.group("name"),
                    "arguments": args,
                })
            except json.JSONDecodeError:
                continue

        return self._deduplicate(calls)

    def _deduplicate(self, calls: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        seen: List[str] = []
        result: List[Dict[str, Any]] = []
        for call in calls:
            key = json.dumps(call, sort_keys=True)
            if key not in seen:
                seen.append(key)
                result.append(call)
        return result

    def extract_single_call(self, text: str) -> Optional[Dict[str, Any]]:
        calls = self.parse(text)
        return calls[0] if calls else None


class FunctionCallExecutor:
    def __init__(
        self,
        registry: Optional[FunctionRegistry] = None,
        allow_coercion: bool = True,
        max_retries: int = 0,
    ) -> None:
        self.registry = registry or FunctionRegistry()
        self.allow_coercion = allow_coercion
        self.max_retries = max_retries

    def execute(
        self,
        function_name: str,
        arguments: Dict[str, Any],
        timeout: Optional[float] = None,
    ) -> FunctionCallResult:
        start = datetime.utcnow()
        spec = self.registry.get(function_name)
        if spec is None:
            return FunctionCallResult(
                function_name=function_name,
                arguments=arguments,
                result=None,
                success=False,
                error=f"Function '{function_name}' is not registered",
                execution_time=(datetime.utcnow() - start).total_seconds(),
            )

        valid, error_msg = spec.validate_arguments(arguments)
        if not valid:
            if self.allow_coercion:
                try:
                    arguments = self._coerce_arguments(arguments, spec)
                except (ValueError, TypeError) as e:
                    return FunctionCallResult(
                        function_name=function_name,
                        arguments=arguments,
                        result=None,
                        success=False,
                        error=str(e),
                        execution_time=(datetime.utcnow() - start).total_seconds(),
                    )
            else:
                return FunctionCallResult(
                    function_name=function_name,
                    arguments=arguments,
                    result=None,
                    success=False,
                    error=error_msg,
                    execution_time=(datetime.utcnow() - start).total_seconds(),
                )

        callable_fn = self.registry.get_callable(function_name)
        if callable_fn is None:
            return FunctionCallResult(
                function_name=function_name,
                arguments=arguments,
                result=None,
                success=False,
                error=f"No callable registered for '{function_name}'",
                execution_time=(datetime.utcnow() - start).total_seconds(),
            )

        last_error: Optional[str] = None
        for attempt in range(self.max_retries + 1):
            try:
                result = callable_fn(**arguments)
                return FunctionCallResult(
                    function_name=function_name,
                    arguments=arguments,
                    result=result,
                    success=True,
                    execution_time=(datetime.utcnow() - start).total_seconds(),
                )
            except Exception as e:
                last_error = str(e)
                if attempt < self.max_retries:
                    continue

        return FunctionCallResult(
            function_name=function_name,
            arguments=arguments,
            result=None,
            success=False,
            error=last_error or "Unknown error",
            execution_time=(datetime.utcnow() - start).total_seconds(),
        )

    def execute_parsed(
        self,
        calls: List[Dict[str, Any]],
    ) -> List[FunctionCallResult]:
        results: List[FunctionCallResult] = []
        for call in calls:
            name = call.get("name", call.get("function", ""))
            args = call.get("arguments", call.get("parameters", {}))
            if isinstance(args, str):
                try:
                    args = json.loads(args)
                except json.JSONDecodeError:
                    args = {}
            result = self.execute(name, args)
            results.append(result)
        return results

    def _coerce_arguments(
        self,
        arguments: Dict[str, Any],
        spec: FunctionSpec,
    ) -> Dict[str, Any]:
        coerced = {}
        for key, value in arguments.items():
            if key in spec.parameters:
                param_schema = spec.parameters[key]
                expected_type = param_schema.get("type", "string")
                try:
                    coerced[key] = _coerce_value(value, expected_type, key)
                except (ValueError, TypeError) as e:
                    require_std = key in spec.required
                    if require_std:
                        raise
                    coerced[key] = value
            else:
                require_std = key in getattr(spec, "required", [])
                if require_std:
                    coerced[key] = value
        for req in spec.required:
            if req not in coerced and req in spec.parameters:
                default = spec.parameters[req].get("default")
                if default is not None:
                    coerced[req] = default
        return coerced
