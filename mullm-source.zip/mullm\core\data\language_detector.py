"""Language detection using FastText with confidence scoring and batch processing."""

from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field
from typing import Optional

logger = logging.getLogger(__name__)

# ISO 639-1 to language name mapping (subset of most common)
LANGUAGE_NAMES: dict[str, str] = {
    "af": "Afrikaans", "am": "Amharic", "ar": "Arabic", "az": "Azerbaijani",
    "be": "Belarusian", "bg": "Bulgarian", "bn": "Bengali", "bs": "Bosnian",
    "ca": "Catalan", "cs": "Czech", "cy": "Welsh", "da": "Danish",
    "de": "German", "el": "Greek", "en": "English", "eo": "Esperanto",
    "es": "Spanish", "et": "Estonian", "eu": "Basque", "fa": "Persian",
    "fi": "Finnish", "fr": "French", "ga": "Irish", "gl": "Galician",
    "gu": "Gujarati", "ha": "Hausa", "he": "Hebrew", "hi": "Hindi",
    "hr": "Croatian", "ht": "Haitian", "hu": "Hungarian", "hy": "Armenian",
    "id": "Indonesian", "ig": "Igbo", "is": "Icelandic", "it": "Italian",
    "ja": "Japanese", "jv": "Javanese", "ka": "Georgian", "kk": "Kazakh",
    "km": "Khmer", "kn": "Kannada", "ko": "Korean", "ku": "Kurdish",
    "ky": "Kyrgyz", "lo": "Lao", "lt": "Lithuanian", "lv": "Latvian",
    "mg": "Malagasy", "mk": "Macedonian", "ml": "Malayalam", "mn": "Mongolian",
    "mr": "Marathi", "ms": "Malay", "mt": "Maltese", "my": "Burmese",
    "ne": "Nepali", "nl": "Dutch", "no": "Norwegian", "ny": "Chichewa",
    "or": "Odia", "pa": "Punjabi", "pl": "Polish", "ps": "Pashto",
    "pt": "Portuguese", "ro": "Romanian", "ru": "Russian", "rw": "Kinyarwanda",
    "sd": "Sindhi", "si": "Sinhala", "sk": "Slovak", "sl": "Slovenian",
    "sm": "Samoan", "sn": "Shona", "so": "Somali", "sq": "Albanian",
    "sr": "Serbian", "ss": "Swati", "su": "Sundanese", "sv": "Swedish",
    "sw": "Swahili", "ta": "Tamil", "te": "Telugu", "tg": "Tajik",
    "th": "Thai", "tk": "Turkmen", "tl": "Tagalog", "tn": "Tswana",
    "tr": "Turkish", "ts": "Tsonga", "tt": "Tatar", "tw": "Twi",
    "ug": "Uyghur", "uk": "Ukrainian", "ur": "Urdu", "uz": "Uzbek",
    "ve": "Venda", "vi": "Vietnamese", "wo": "Wolof", "xh": "Xhosa",
    "yi": "Yiddish", "yo": "Yoruba", "zh": "Chinese", "zu": "Zulu",
}


@dataclass
class LanguageDetectionConfig:
    """Configuration for language detection."""

    model_path: Optional[str] = None
    min_confidence: float = 0.5
    top_k: int = 3
    fallback_language: str = "en"
    allowed_languages: Optional[set[str]] = None
    blocked_languages: Optional[set[str]] = None
    min_text_length: int = 10
    max_text_length: int = 10000
    use_heuristic: bool = True


@dataclass
class LanguageResult:
    """Result of language detection for a single text."""

    language: str
    language_name: str
    confidence: float
    top_languages: list[tuple[str, float]]
    is_allowed: bool = True
    text_length: int = 0
    method: str = "fasttext"


@dataclass
class LanguageFilterConfig:
    """Configuration for language filtering."""

    allowed_languages: set[str] = field(default_factory=lambda: {"en"})
    min_confidence: float = 0.7
    remove_unsupported: bool = True


class HeuristicLanguageDetector:
    """Rule-based language detection as fallback."""

    SCRIPT_PATTERNS: dict[str, str] = {
        "ja": r"[\u3040-\u309f\u30a0-\u30ff\u4e00-\u9faf]",
        "zh": r"[\u4e00-\u9fff]",
        "ko": r"[\uac00-\ud7af\u1100-\u11ff]",
        "ar": r"[\u0600-\u06ff\u0750-\u077f]",
        "he": r"[\u0590-\u05ff]",
        "th": r"[\u0e00-\u0e7f]",
        "hi": r"[\u0900-\u097f]",
        "bn": r"[\u0980-\u09ff]",
        "ru": r"[\u0400-\u04ff]",
        "el": r"[\u0370-\u03ff]",
    }

    COMMON_WORDS: dict[str, list[str]] = {
        "en": ["the", "is", "and", "to", "of", "in", "it", "that", "was", "for", "on", "are", "with", "this", "have"],
        "es": ["el", "la", "de", "que", "y", "en", "los", "del", "se", "las", "por", "un", "para", "con", "no"],
        "fr": ["le", "la", "de", "les", "des", "un", "une", "et", "est", "en", "que", "qui", "dans", "du", "ce"],
        "de": ["der", "die", "und", "in", "den", "von", "zu", "das", "mit", "sich", "des", "auf", "ist", "ein", "eine"],
        "it": ["il", "di", "che", "la", "in", "un", "del", "per", "una", "con", "sono", "non", "da", "dei", "al"],
        "pt": ["de", "que", "do", "da", "em", "um", "para", "com", "uma", "os", "no", "se", "na", "por", "mais"],
        "nl": ["de", "het", "van", "een", "en", "in", "is", "dat", "op", "te", "zijn", "voor", "met", "niet", "aan"],
        "ru": ["и", "в", "не", "на", "я", "что", "он", "как", "это", "но", "она", "все", "так", "его", "мне"],
    }

    @classmethod
    def detect(cls, text: str) -> tuple[str, float]:
        if not text:
            return "unknown", 0.0

        for lang, pattern in cls.SCRIPT_PATTERNS.items():
            matches = len(re.findall(pattern, text))
            if matches > 0:
                ratio = matches / max(len(text), 1)
                if ratio > 0.1:
                    return lang, min(0.5 + ratio, 0.95)

        words = text.lower().split()
        if not words:
            return "unknown", 0.0

        best_lang = "en"
        best_score = 0.0

        for lang, common_words in cls.COMMON_WORDS.items():
            matches = sum(1 for w in words[:100] if w in common_words)
            score = matches / min(len(words), 100)
            if score > best_score:
                best_score = score
                best_lang = lang

        return best_lang, min(best_score, 0.9)


class LanguageDetector:
    """Language detection using FastText with heuristic fallback."""

    def __init__(self, config: Optional[LanguageDetectionConfig] = None) -> None:
        self.config = config or LanguageDetectionConfig()
        self._model = None
        self._heuristic = HeuristicLanguageDetector()
        self._load_model()

    def _load_model(self) -> None:
        try:
            import fasttext

            model_path = self.config.model_path
            if not model_path:
                model_path = "lid.176.bin"
            self._model = fasttext.load_model(model_path)
            logger.info("FastText language model loaded from %s", model_path)
        except Exception as e:
            logger.warning(
                "FastText model not available (%s), using heuristic detection", e
            )
            self._model = None

    def detect(self, text: str) -> LanguageResult:
        if not text or len(text) < self.config.min_text_length:
            return LanguageResult(
                language=self.config.fallback_language,
                language_name=LANGUAGE_NAMES.get(
                    self.config.fallback_language, "Unknown"
                ),
                confidence=0.0,
                top_languages=[],
                text_length=len(text),
                method="fallback",
            )

        truncated = text[: self.config.max_text_length]

        if self._model:
            return self._detect_fasttext(truncated)

        if self.config.use_heuristic:
            return self._detect_heuristic(truncated)

        return LanguageResult(
            language=self.config.fallback_language,
            language_name=LANGUAGE_NAMES.get(self.config.fallback_language, "Unknown"),
            confidence=0.0,
            top_languages=[],
            text_length=len(text),
            method="fallback",
        )

    def _detect_fasttext(self, text: str) -> LanguageResult:
        clean_text = text.replace("\n", " ").strip()
        predictions = self._model.predict(clean_text, k=self.config.top_k)  # type: ignore

        top_languages: list[tuple[str, float]] = []
        if predictions and predictions[0] and predictions[1]:
            for label, score in zip(predictions[0], predictions[1]):
                lang = label.replace("__label__", "")
                top_languages.append((lang, float(score)))

        if top_languages:
            best_lang, best_conf = top_languages[0]
        else:
            best_lang, best_conf = self.config.fallback_language, 0.0

        lang_name = LANGUAGE_NAMES.get(best_lang, best_lang)
        is_allowed = self._check_allowed(best_lang)

        return LanguageResult(
            language=best_lang,
            language_name=lang_name,
            confidence=best_conf,
            top_languages=top_languages,
            is_allowed=is_allowed,
            text_length=len(text),
            method="fasttext",
        )

    def _detect_heuristic(self, text: str) -> LanguageResult:
        lang, confidence = self._heuristic.detect(text)
        lang_name = LANGUAGE_NAMES.get(lang, lang)
        is_allowed = self._check_allowed(lang)
        return LanguageResult(
            language=lang,
            language_name=lang_name,
            confidence=confidence,
            top_languages=[(lang, confidence)],
            is_allowed=is_allowed,
            text_length=len(text),
            method="heuristic",
        )

    def _check_allowed(self, lang_code: str) -> bool:
        if self.config.blocked_languages and lang_code in self.config.blocked_languages:
            return False
        if self.config.allowed_languages and lang_code not in self.config.allowed_languages:
            return False
        return True

    def detect_batch(self, texts: list[str]) -> list[LanguageResult]:
        results: list[LanguageResult] = []
        for text in texts:
            results.append(self.detect(text))
        return results

    def filter_by_language(
        self,
        texts: list[str],
        allowed_languages: Optional[set[str]] = None,
        min_confidence: Optional[float] = None,
    ) -> list[tuple[str, LanguageResult]]:
        allowed = allowed_languages or self.config.allowed_languages or set()
        threshold = min_confidence or self.config.min_confidence

        filtered: list[tuple[str, LanguageResult]] = []
        for text in texts:
            result = self.detect(text)
            if result.language in allowed and result.confidence >= threshold:
                filtered.append((text, result))
        return filtered

    def get_supported_languages(self) -> list[str]:
        return sorted(LANGUAGE_NAMES.keys())

    def get_language_name(self, code: str) -> str:
        return LANGUAGE_NAMES.get(code, code)
