from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Union

import torch
import torch.nn as nn
import torch.nn.functional as F


@dataclass
class PromptTuningConfig:
    num_virtual_tokens: int = 8
    init_type: str = "random"
    init_text: Optional[str] = None
    init_token_ids: Optional[List[int]] = None
    tokenizer: Optional[Any] = None
    hidden_size: int = 768
    dropout: float = 0.0
    pad_token_id: int = 0


class PromptEmbedding(nn.Module):
    def __init__(
        self,
        config: PromptTuningConfig,
        embed_tokens: Optional[nn.Embedding] = None,
    ):
        super().__init__()
        self.config = config
        self.num_virtual_tokens = config.num_virtual_tokens
        self.hidden_size = config.hidden_size

        self.embedding = nn.Parameter(
            torch.empty(config.num_virtual_tokens, config.hidden_size)
        )
        nn.init.normal_(self.embedding, mean=0.0, std=0.02)

        if embed_tokens is not None:
            self._init_from_vocab(embed_tokens)
        elif config.init_type == "random":
            pass
        elif config.init_type == "text" and config.init_text is not None:
            self._init_from_text()
        elif config.init_type == "vocab" and config.init_token_ids is not None:
            if embed_tokens is None:
                raise ValueError("embed_tokens required for vocab init")
            self._init_from_ids(config.init_token_ids, embed_tokens)

        self.dropout = nn.Dropout(config.dropout) if config.dropout > 0 else nn.Identity()

    def _init_from_vocab(self, embed_tokens: nn.Embedding) -> None:
        vocab_size = embed_tokens.weight.size(0)
        random_indices = torch.randint(0, vocab_size, (self.num_virtual_tokens,))
        with torch.no_grad():
            self.embedding.data.copy_(embed_tokens.weight[random_indices])

    def _init_from_text(self) -> None:
        if self.config.tokenizer is None:
            raise ValueError("tokenizer required for text-based init")
        tokenizer = self.config.tokenizer
        text = self.config.init_text
        if text is None:
            raise ValueError("init_text must be provided for text init")
        input_ids = tokenizer.encode(text, add_special_tokens=False)
        input_ids = input_ids[:self.num_virtual_tokens]
        if len(input_ids) < self.num_virtual_tokens:
            input_ids = input_ids + [self.config.pad_token_id] * (self.num_virtual_tokens - len(input_ids))
        with torch.no_grad():
            if hasattr(tokenizer, "get_input_embeddings"):
                embed = tokenizer.get_input_embeddings()
            elif hasattr(tokenizer, "embed_tokens"):
                embed = tokenizer.embed_tokens
            elif hasattr(tokenizer, "weight"):
                embed = tokenizer
            else:
                return
            ids_tensor = torch.tensor(input_ids[:self.num_virtual_tokens])
            self.embedding.data.copy_(embed(ids_tensor))

    def _init_from_ids(self, token_ids: List[int], embed_tokens: nn.Embedding) -> None:
        ids = token_ids[:self.num_virtual_tokens]
        if len(ids) < self.num_virtual_tokens:
            ids = ids + [self.config.pad_token_id] * (self.num_virtual_tokens - len(ids))
        ids_tensor = torch.tensor(ids, dtype=torch.long)
        with torch.no_grad():
            self.embedding.data.copy_(embed_tokens(ids_tensor))

    def forward(self, batch_size: int, device: torch.device, dtype: torch.dtype) -> torch.Tensor:
        emb = self.embedding.to(device=device, dtype=dtype)
        emb = emb.unsqueeze(0).expand(batch_size, -1, -1)
        emb = self.dropout(emb)
        return emb

    def get_prompt_parameters(self) -> List[nn.Parameter]:
        return [self.embedding]

    def extra_repr(self) -> str:
        return f"num_virtual_tokens={self.num_virtual_tokens}, hidden_size={self.hidden_size}, init_type={self.config.init_type}"


class PromptTuningWrapper(nn.Module):
    def __init__(
        self,
        model: nn.Module,
        config: PromptTuningConfig,
        embed_tokens: Optional[nn.Embedding] = None,
    ):
        super().__init__()
        self.model = model
        self.config = config

        hidden_size = config.hidden_size
        if hasattr(model, "config") and hasattr(model.config, "hidden_size"):
            hidden_size = model.config.hidden_size
        elif hasattr(model, "hidden_size"):
            hidden_size = model.hidden_size
        elif hasattr(model, "in_features"):
            hidden_size = model.in_features

        config.hidden_size = hidden_size
        self.prompt_embeddings = PromptEmbedding(config, embed_tokens)

        self._model_device = next(model.parameters()).device
        self._model_dtype = next(model.parameters()).dtype

    def forward(
        self,
        input_ids: Optional[torch.Tensor] = None,
        attention_mask: Optional[torch.Tensor] = None,
        labels: Optional[torch.Tensor] = None,
        inputs_embeds: Optional[torch.Tensor] = None,
        **kwargs,
    ) -> Any:
        batch_size = input_ids.size(0) if input_ids is not None else inputs_embeds.size(0)
        device = input_ids.device if input_ids is not None else inputs_embeds.device
        dtype = self._model_dtype

        prompt_embeds = self.prompt_embeddings(batch_size, device, dtype)

        if inputs_embeds is None and input_ids is not None:
            if hasattr(self.model, "get_input_embeddings"):
                embed_fn = self.model.get_input_embeddings()
                inputs_embeds = embed_fn(input_ids)
            elif hasattr(self.model, "embed_tokens"):
                inputs_embeds = self.model.embed_tokens(input_ids)
            elif hasattr(self.model, "transformer") and hasattr(self.model.transformer, "wte"):
                inputs_embeds = self.model.transformer.wte(input_ids)
            else:
                raise ValueError("Cannot determine input embeddings")

        combined_embeds = torch.cat([prompt_embeds, inputs_embeds], dim=1)

        if attention_mask is not None:
            prefix_mask = torch.ones(
                batch_size, self.config.num_virtual_tokens,
                dtype=attention_mask.dtype, device=attention_mask.device,
            )
            attention_mask = torch.cat([prefix_mask, attention_mask], dim=1)

        if labels is not None:
            prefix_labels = torch.full(
                (batch_size, self.config.num_virtual_tokens),
                -100,
                dtype=labels.dtype,
                device=labels.device,
            )
            labels = torch.cat([prefix_labels, labels], dim=1)

        return self.model(
            input_ids=None,
            attention_mask=attention_mask,
            labels=labels,
            inputs_embeds=combined_embeds,
            **kwargs,
        )

    def get_prompt_embeddings(self) -> torch.Tensor:
        return self.prompt_embeddings.embedding.data.clone()

    def set_prompt_embeddings(self, embeddings: torch.Tensor) -> None:
        if embeddings.shape != self.prompt_embeddings.embedding.shape:
            raise ValueError(
                f"Shape mismatch: expected {self.prompt_embeddings.embedding.shape}, got {embeddings.shape}"
            )
        self.prompt_embeddings.embedding.data.copy_(embeddings)


PROMPT_INIT_MAP = {
    "random": lambda config, embed: PromptEmbedding(config, embed),
    "vocab": lambda config, embed: PromptEmbedding(config, embed),
    "text": lambda config, embed: PromptEmbedding(config, embed),
}


def initialize_prompt_embeddings(
    prompt_embedding: PromptEmbedding,
    init_type: str = "random",
    tokenizer: Optional[Any] = None,
    text: Optional[str] = None,
    token_ids: Optional[List[int]] = None,
    embed_tokens: Optional[nn.Embedding] = None,
) -> PromptEmbedding:
    if init_type == "random":
        nn.init.normal_(prompt_embedding.embedding, mean=0.0, std=0.02)
    elif init_type == "vocab":
        if embed_tokens is None:
            raise ValueError("embed_tokens required for vocab init")
        prompt_embedding._init_from_vocab(embed_tokens)
    elif init_type == "text":
        if tokenizer is None or text is None:
            raise ValueError("tokenizer and text required for text init")
        prompt_embedding.config.tokenizer = tokenizer
        prompt_embedding.config.init_text = text
        prompt_embedding._init_from_text()
    elif init_type == "ids":
        if token_ids is None or embed_tokens is None:
            raise ValueError("token_ids and embed_tokens required for ids init")
        prompt_embedding._init_from_ids(token_ids, embed_tokens)
    return prompt_embedding
