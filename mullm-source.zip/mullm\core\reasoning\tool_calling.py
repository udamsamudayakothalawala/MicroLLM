"""Tool calling system for LLM tool execution."""

from __future__ import annotations

import asyncio
import concurrent.futures
import copy
import json
import re
import time
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Awaitable, Callable, Dict, List, Optional, Set, Tuple, Type, Union


class ToolExecutionError(Exception):
    def __init__(
        self,
        tool_name: str,
        message: str,
        arguments: Optional[Dict[str, Any]] = None,
        original_exception: Optional[Exception] = None,
    ) -> None:
        self.tool_name = tool_name
        self.arguments = arguments
        self.original_exception = original_exception
        super().__init__(f"Tool '{tool_name}' execution failed: {message}")


@dataclass
class ToolSpec:
    name: str
    description: str
    input_schema: Dict[str, Any]
    output_schema: Dict[str, Any]
    function: Optional[Callable[..., Any]] = None
    async_function: Optional[Callable[..., Awaitable[Any]]] = None
    required: List[str] = field(default_factory=list)
    tags: List[str] = field(default_factory=list)
    timeout: Optional[float] = None

    def to_openai_format(self) -> Dict[str, Any]:
        return {
            "type": "function",
            "function": {
                "name": self.name,
                "description": self.description,
                "parameters": {
                    "type": "object",
                    "properties": self.input_schema,
                    "required": self.required,
                },
            },
        }

    def validate_input(self, arguments: Dict[str, Any]) -> Tuple[bool, Optional[str]]:
        for req in self.required:
            if req not in arguments:
                return False, f"Missing required input: '{req}'"
        for key in arguments:
            if key not in self.input_schema:
                return False, f"Unknown input parameter: '{key}'"
        return True, None


@dataclass
class ToolCallResult:
    tool_name: str
    arguments: Dict[str, Any]
    result: Any
    success: bool
    error: Optional[str] = None
    execution_time: float = 0.0
    timestamp: datetime = field(default_factory=datetime.utcnow)
    formatted_result: Optional[str] = None

    def format_for_model(self) -> str:
        if self.formatted_result is not None:
            return self.formatted_result
        if self.success:
            result_str = json.dumps(self.result, default=str, ensure_ascii=False)
            return f"Tool '{self.tool_name}' returned: {result_str}"
        return f"Tool '{self.tool_name}' error: {self.error}"

    def to_dict(self) -> Dict[str, Any]:
        return {
            "tool_name": self.tool_name,
            "arguments": self.arguments,
            "result": self.result,
            "success": self.success,
            "error": self.error,
            "execution_time": self.execution_time,
            "timestamp": self.timestamp.isoformat(),
        }


class ToolRegistry:
    def __init__(self) -> None:
        self._tools: Dict[str, ToolSpec] = {}
        self._tag_index: Dict[str, Set[str]] = {}

    def register(self, spec: ToolSpec) -> ToolSpec:
        self._tools[spec.name] = spec
        for tag in spec.tags:
            if tag not in self._tag_index:
                self._tag_index[tag] = set()
            self._tag_index[tag].add(spec.name)
        return spec

    def register_from_callable(
        self,
        name: str,
        description: str,
        function: Callable[..., Any],
        *,
        input_schema: Optional[Dict[str, Any]] = None,
        required: Optional[List[str]] = None,
        tags: Optional[List[str]] = None,
    ) -> ToolSpec:
        import inspect
        if input_schema is None:
            sig = inspect.signature(function)
            input_schema = {}
            for param_name, param in sig.parameters.items():
                if param_name in ("self", "cls"):
                    continue
                type_str = "string"
                if param.annotation is not inspect.Parameter.empty:
                    ann = param.annotation
                    if ann is int:
                        type_str = "integer"
                    elif ann is float:
                        type_str = "number"
                    elif ann is bool:
                        type_str = "boolean"
                    elif ann is list or getattr(ann, "__origin__", None) is list:
                        type_str = "array"
                    elif ann is dict or getattr(ann, "__origin__", None) is dict:
                        type_str = "object"
                input_schema[param_name] = {"type": type_str, "description": ""}
        if required is None:
            required = list(input_schema.keys())
        spec = ToolSpec(
            name=name,
            description=description,
            input_schema=input_schema,
            output_schema={},
            function=function,
            required=required,
            tags=tags or [],
        )
        return self.register(spec)

    def get(self, name: str) -> Optional[ToolSpec]:
        return self._tools.get(name)

    def list_tools(self) -> List[ToolSpec]:
        return list(self._tools.values())

    def discover_by_tag(self, tag: str) -> List[ToolSpec]:
        names = self._tag_index.get(tag, set())
        return [self._tools[n] for n in names if n in self._tools]

    def remove(self, name: str) -> None:
        spec = self._tools.pop(name, None)
        if spec:
            for tag in spec.tags:
                if tag in self._tag_index:
                    self._tag_index[tag].discard(name)
                    if not self._tag_index[tag]:
                        del self._tag_index[tag]

    def clear(self) -> None:
        self._tools.clear()
        self._tag_index.clear()

    @property
    def count(self) -> int:
        return len(self._tools)

    def to_openai_tools(self) -> List[Dict[str, Any]]:
        return [t.to_openai_format() for t in self._tools.values()]


class ToolCallFormatter:
    def __init__(
        self,
        registry: ToolRegistry,
        include_tags: Optional[List[str]] = None,
        exclude_tags: Optional[List[str]] = None,
    ) -> None:
        self.registry = registry
        self.include_tags = include_tags
        self.exclude_tags = exclude_tags or []

    def format_for_prompt(self) -> str:
        tools = self._get_filtered_tools()
        if not tools:
            return ""
        lines = ["You have access to the following tools:", ""]
        for tool in tools:
            lines.append(f"### {tool.name}")
            lines.append(f"Description: {tool.description}")
            lines.append("Input schema:")
            lines.append(json.dumps(tool.input_schema, indent=2))
            lines.append("")
        lines.append("To use a tool, respond with:")
        lines.append('```tool\n{"name": "tool_name", "arguments": {...}}\n```')
        return "\n".join(lines)

    def format_as_system_message(self) -> Dict[str, str]:
        tools = self._get_filtered_tools()
        tool_descs = []
        for tool in tools:
            params = ", ".join(
                f"{p}: {s.get('type', 'string')}"
                for p, s in tool.input_schema.items()
            )
            tool_descs.append(f"- {tool.name}({params}): {tool.description}")
        content = "Available tools:\n" + "\n".join(tool_descs)
        return {"role": "system", "content": content}

    def _get_filtered_tools(self) -> List[ToolSpec]:
        all_tools = self.registry.list_tools()
        if self.include_tags:
            included: Set[str] = set()
            for tag in self.include_tags:
                included.update(self.registry._tag_index.get(tag, set()))
            all_tools = [t for t in all_tools if t.name in included]
        if self.exclude_tags:
            excluded: Set[str] = set()
            for tag in self.exclude_tags:
                excluded.update(self.registry._tag_index.get(tag, set()))
            all_tools = [t for t in all_tools if t.name not in excluded]
        return all_tools


class ToolCallParser:
    TOOL_CALL_RE = re.compile(
        r'(?:```tool|```json)\s*\n?'
        r'\{[^}]*"name"\s*:\s*"[^"]*"[^}]*"arguments"\s*:\s*\{[^}]*\}\s*\}'
        r'\s*(?:```|</tool>)',
        re.DOTALL,
    )

    JSON_TOOL_CALL_RE = re.compile(
        r'\{\s*"name"\s*:\s*"(?P<name>[^"]+)"\s*,'
        r'\s*"arguments"\s*:\s*(?P<args>\{.*?\})\s*\}',
        re.DOTALL,
    )

    def __init__(self, registry: ToolRegistry) -> None:
        self.registry = registry

    def parse(self, text: str) -> List[Dict[str, Any]]:
        calls: List[Dict[str, Any]] = []

        bracket_depth = 0
        json_start = -1
        for i, ch in enumerate(text):
            if ch == '{':
                if bracket_depth == 0:
                    json_start = i
                bracket_depth += 1
            elif ch == '}':
                bracket_depth -= 1
                if bracket_depth == 0 and json_start >= 0:
                    candidate = text[json_start:i + 1]
                    json_start = -1
                    try:
                        parsed = json.loads(candidate)
                        if isinstance(parsed, dict) and "name" in parsed:
                            calls.append(parsed)
                        elif isinstance(parsed, list):
                            for item in parsed:
                                if isinstance(item, dict) and "name" in item:
                                    calls.append(item)
                    except json.JSONDecodeError:
                        continue

        return self._deduplicate(calls)

    def _deduplicate(self, calls: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        seen: List[str] = []
        result: List[Dict[str, Any]] = []
        for call in calls:
            key = json.dumps(call, sort_keys=True)
            if key not in seen:
                seen.append(key)
                result.append(call)
        return result

    def validate_calls(self, calls: List[Dict[str, Any]]) -> List[Tuple[Dict[str, Any], bool, Optional[str]]]:
        results: List[Tuple[Dict[str, Any], bool, Optional[str]]] = []
        for call in calls:
            name = call.get("name", "")
            args = call.get("arguments", {})
            if isinstance(args, str):
                try:
                    args = json.loads(args)
                except json.JSONDecodeError:
                    results.append((call, False, "Arguments is invalid JSON string"))
                    continue
            spec = self.registry.get(name)
            if spec is None:
                results.append((call, False, f"Tool '{name}' not found"))
            else:
                valid, error = spec.validate_input(args)
                results.append((call, valid, error))
        return results


class ToolResultFormatter:
    def format(self, results: List[ToolCallResult]) -> str:
        parts = []
        for r in results:
            parts.append(r.format_for_model())
        return "\n".join(parts)

    def format_as_tool_response(self, results: List[ToolCallResult]) -> List[Dict[str, Any]]:
        messages: List[Dict[str, Any]] = []
        for r in results:
            if r.success:
                content = json.dumps(r.result, default=str, ensure_ascii=False)
            else:
                content = f"Error: {r.error}"
            messages.append({
                "role": "tool",
                "name": r.tool_name,
                "content": content,
            })
        return messages


class ToolCallExecutor:
    def __init__(
        self,
        registry: ToolRegistry,
        max_parallel: int = 5,
        default_timeout: float = 30.0,
    ) -> None:
        self.registry = registry
        self.max_parallel = max_parallel
        self.default_timeout = default_timeout

    def execute(
        self,
        name: str,
        arguments: Dict[str, Any],
        timeout: Optional[float] = None,
    ) -> ToolCallResult:
        start = time.monotonic()
        spec = self.registry.get(name)
        if spec is None:
            return ToolCallResult(
                tool_name=name,
                arguments=arguments,
                result=None,
                success=False,
                error=f"Tool '{name}' not found in registry",
            )

        valid, error = spec.validate_input(arguments)
        if not valid:
            return ToolCallResult(
                tool_name=name,
                arguments=arguments,
                result=None,
                success=False,
                error=error,
            )

        effective_timeout = timeout or spec.timeout or self.default_timeout
        fn = spec.function

        if fn is None:
            return ToolCallResult(
                tool_name=name,
                arguments=arguments,
                result=None,
                success=False,
                error=f"Tool '{name}' has no implementation",
            )

        try:
            with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
                future = pool.submit(fn, **arguments)
                result = future.result(timeout=effective_timeout)
            elapsed = time.monotonic() - start
            return ToolCallResult(
                tool_name=name,
                arguments=arguments,
                result=result,
                success=True,
                execution_time=elapsed,
            )
        except concurrent.futures.TimeoutError:
            elapsed = time.monotonic() - start
            return ToolCallResult(
                tool_name=name,
                arguments=arguments,
                result=None,
                success=False,
                error=f"Tool execution timed out after {effective_timeout}s",
                execution_time=elapsed,
            )
        except Exception as e:
            elapsed = time.monotonic() - start
            return ToolCallResult(
                tool_name=name,
                arguments=arguments,
                result=None,
                success=False,
                error=str(e),
                execution_time=elapsed,
            )

    def execute_parallel(
        self,
        calls: List[Dict[str, Any]],
    ) -> List[ToolCallResult]:
        results: List[ToolCallResult] = []
        with concurrent.futures.ThreadPoolExecutor(
            max_workers=min(self.max_parallel, len(calls))
        ) as executor:
            futures = []
            for call in calls:
                name = call.get("name", "")
                args = call.get("arguments", {})
                if isinstance(args, str):
                    try:
                        args = json.loads(args)
                    except json.JSONDecodeError:
                        results.append(ToolCallResult(
                            tool_name=name,
                            arguments={},
                            result=None,
                            success=False,
                            error="Arguments is invalid JSON",
                        ))
                        continue
                futures.append(executor.submit(self.execute, name, args))

            for future in concurrent.futures.as_completed(futures):
                results.append(future.result())

        return results

    def execute_parsed(
        self,
        text: str,
        parser: ToolCallParser,
    ) -> List[ToolCallResult]:
        calls = parser.parse(text)
        return self.execute_parallel(calls)
