import pytest


class TestBPE:
    def test_bpe_train_encode_decode(self, small_corpus):
        from mullm.core.tokenizer.bpe import BPETokenizer
        tokenizer = BPETokenizer()
        tokenizer.train(small_corpus, vocab_size=50)
        assert tokenizer.vocab_size == 50
        text = "hello world"
        ids = tokenizer.encode(text)
        assert isinstance(ids, list)
        assert len(ids) > 0
        decoded = tokenizer.decode(ids)
        assert isinstance(decoded, str)

    def test_special_tokens(self):
        from mullm.core.tokenizer.bpe import BPETokenizer
        tokenizer = BPETokenizer()
        tokenizer.add_special_tokens({"bos": "<s>", "eos": "</s>", "pad": "<pad>"})
        assert tokenizer.bos_token_id is not None
        assert tokenizer.eos_token_id is not None
        ids = tokenizer.encode("<s>hello</s>")
        assert isinstance(ids, list)


class TestChatTemplate:
    def test_apply_template(self):
        from mullm.core.tokenizer.chat_template import ChatTemplateEngine
        engine = ChatTemplateEngine()
        engine.add_template("test", "{% for msg in messages %}{{ msg.role }}: {{ msg.content }}\n{% endfor %}")
        messages = [
            {"role": "user", "content": "Hello"},
            {"role": "assistant", "content": "Hi there"},
        ]
        result = engine.apply("test", messages)
        assert "user: Hello" in result
        assert "assistant: Hi there" in result


class TestStatistics:
    def test_vocab_statistics(self):
        from mullm.core.tokenizer.statistics import TokenStatistics
        stats = TokenStatistics({"hello": 10, "world": 5, "test": 3})
        freq = stats.token_frequencies()
        assert freq["hello"] == 10
        total = stats.total_tokens()
        assert total == 18

    def test_compression_ratio(self):
        from mullm.core.tokenizer.statistics import TokenStatistics
        stats = TokenStatistics({"a": 10, "b": 5})
        ratio = stats.compression_ratio()
        assert ratio > 0
