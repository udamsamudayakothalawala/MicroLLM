@echo off
REM ============================================================
REM muLLM Installer (Option A - no extra tools required)
REM Creates a venv, installs muLLM + GUI, adds shortcuts.
REM ============================================================
setlocal
cd /d "%~dp0"

set PY=python
where %PY% >nul 2>nul
if errorlevel 1 (
    echo [ERROR] Python not found in PATH. Install Python 3.10+ from python.org first.
    pause
    exit /b 1
)

echo [1/4] Creating virtual environment...
if not exist "venv" %PY% -m venv venv
if errorlevel 1 goto :err
call "venv\Scripts\activate.bat"

echo [2/4] Upgrading pip...
python -m pip install --upgrade pip >nul 2>nul

echo [3/4] Installing muLLM (this downloads torch, ~200MB first time)...
pip install "dist\mullm-0.1.0-py3-none-any.whl" --quiet
if errorlevel 1 goto :err

echo [4/4] Installing GUI dependencies (PyQt5)...
pip install PyQt5 --quiet
if errorlevel 1 goto :err

REM ---- create shortcuts ----
set SHORTCUTS=%APPDATA%\Microsoft\Windows\Start Menu\Programs\muLLM
if not exist "%SHORTCUTS%" mkdir "%SHORTCUTS%"
set "EXE=%CD%\venv\Scripts\mullm.exe"
set "ICON=%CD%\assets\mullm.ico"

REM GUI shortcut
call :mklnk "%SHORTCUTS%\muLLM GUI.lnk" "%EXE%" "gui" "%ICON%"
REM CLI shortcut (console)
call :mklnk "%SHORTCUTS%\muLLM CLI.lnk" "%EXE%" "" "%ICON%"

echo.
echo ============================================================
echo   muLLM installed successfully!
echo
echo   Run GUI:  %EXE% gui
echo   Train:    %EXE% train --dataset data.txt --size tiny
echo   Export:   %EXE% export --checkpoint outputs
echo   Chat:     %EXE% chat --checkpoint outputs --tokenizer outputs\tokenizer.json
echo ============================================================
pause
exit /b 0

:mklnk
powershell -NoProfile -Command ^
  "$s=(New-Object -ComObject WScript.Shell).CreateShortcut('%1');" ^
  "$s.TargetPath='%2';" ^
  "$s.Arguments='%3';" ^
  "$s.IconLocation='%4,0';" ^
  "$s.WorkingDirectory='%CD%';" ^
  "$s.Save()" >nul 2>nul
exit /b 0

:err
echo [ERROR] Installation failed. See messages above.
pause
exit /b 1