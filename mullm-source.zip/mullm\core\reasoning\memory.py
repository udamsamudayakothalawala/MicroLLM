"""Memory system for LLM agents with episodic, semantic, and working memory."""

from __future__ import annotations

import json
import math
import time
import uuid
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Callable, Dict, List, Optional, Set, Tuple


@dataclass
class MemoryItem:
    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    content: str = ""
    metadata: Dict[str, Any] = field(default_factory=dict)
    timestamp: datetime = field(default_factory=datetime.utcnow)
    access_count: int = 0
    importance: float = 0.5
    embedding: Optional[List[float]] = None
    source: str = ""

    @property
    def age_hours(self) -> float:
        delta = datetime.utcnow() - self.timestamp
        return delta.total_seconds() / 3600.0

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "content": self.content,
            "metadata": self.metadata,
            "timestamp": self.timestamp.isoformat(),
            "access_count": self.access_count,
            "importance": self.importance,
            "embedding": self.embedding,
            "source": self.source,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "MemoryItem":
        return cls(
            id=data.get("id", ""),
            content=data.get("content", ""),
            metadata=data.get("metadata", {}),
            timestamp=datetime.fromisoformat(data["timestamp"]) if "timestamp" in data else datetime.utcnow(),
            access_count=data.get("access_count", 0),
            importance=data.get("importance", 0.5),
            embedding=data.get("embedding"),
            source=data.get("source", ""),
        )


@dataclass
class MemoryQuery:
    query: str = ""
    top_k: int = 5
    threshold: float = 0.0
    filters: Dict[str, Any] = field(default_factory=dict)
    embedding: Optional[List[float]] = None

    def to_dict(self) -> Dict[str, Any]:
        return {
            "query": self.query,
            "top_k": self.top_k,
            "threshold": self.threshold,
            "filters": self.filters,
        }


@dataclass
class MemoryResult:
    items: List[MemoryItem] = field(default_factory=list)
    query: MemoryQuery = field(default_factory=MemoryQuery)
    total_found: int = 0
    execution_time: float = 0.0

    @property
    def top_item(self) -> Optional[MemoryItem]:
        return self.items[0] if self.items else None

    @property
    def contents(self) -> List[str]:
        return [item.content for item in self.items]


class MemoryStore(ABC):
    @abstractmethod
    def add(self, item: MemoryItem) -> str: ...

    @abstractmethod
    def get(self, item_id: str) -> Optional[MemoryItem]: ...

    @abstractmethod
    def search(self, query: MemoryQuery) -> MemoryResult: ...

    @abstractmethod
    def update(self, item_id: str, **updates: Any) -> bool: ...

    @abstractmethod
    def delete(self, item_id: str) -> bool: ...

    @abstractmethod
    def clear(self) -> None: ...

    @abstractmethod
    def count(self) -> int: ...

    @abstractmethod
    def get_all(self) -> List[MemoryItem]: ...


class EpisodicMemory(MemoryStore):
    def __init__(self, max_size: int = 1000, decay_hours: float = 24.0) -> None:
        self._items: Dict[str, MemoryItem] = {}
        self._max_size = max_size
        self._decay_hours = decay_hours

    def add(self, item: MemoryItem) -> str:
        if len(self._items) >= self._max_size:
            self._evict()
        self._items[item.id] = item
        return item.id

    def get(self, item_id: str) -> Optional[MemoryItem]:
        item = self._items.get(item_id)
        if item:
            item.access_count += 1
        return item

    def search(self, query: MemoryQuery) -> MemoryResult:
        start = time.monotonic()
        scored: List[Tuple[float, MemoryItem]] = []

        for item in self._items.values():
            score = self._compute_relevance(item, query)
            if score >= query.threshold:
                scored.append((score, item))

        scored.sort(key=lambda x: x[0], reverse=True)
        items = [item for _, item in scored[:query.top_k]]

        return MemoryResult(
            items=items,
            query=query,
            total_found=len(scored),
            execution_time=time.monotonic() - start,
        )

    def update(self, item_id: str, **updates: Any) -> bool:
        item = self._items.get(item_id)
        if item is None:
            return False
        for key, value in updates.items():
            if hasattr(item, key):
                setattr(item, key, value)
        return True

    def delete(self, item_id: str) -> bool:
        return self._items.pop(item_id, None) is not None

    def clear(self) -> None:
        self._items.clear()

    def count(self) -> int:
        return len(self._items)

    def get_all(self) -> List[MemoryItem]:
        return list(self._items.values())

    def _compute_relevance(self, item: MemoryItem, query: MemoryQuery) -> float:
        score = 0.0
        query_lower = query.query.lower()
        content_lower = item.content.lower()

        if query.query and query.query in item.content:
            score += 0.3
        query_words = set(query_lower.split())
        content_words = set(content_lower.split())
        if query_words and content_words:
            overlap = len(query_words & content_words)
            score += 0.4 * (overlap / max(len(query_words), 1))

        recency = math.exp(-item.age_hours / self._decay_hours)
        score += 0.2 * recency

        score += 0.1 * item.importance

        for filter_key, filter_value in query.filters.items():
            meta_val = item.metadata.get(filter_key)
            if meta_val != filter_value:
                score *= 0.5

        return score

    def _evict(self) -> None:
        if not self._items:
            return
        oldest = min(self._items.values(), key=lambda x: x.timestamp)
        del self._items[oldest.id]


class SemanticMemory(MemoryStore):
    def __init__(self, max_size: int = 100000) -> None:
        self._items: Dict[str, MemoryItem] = {}
        self._max_size = max_size
        self._embeddings_matrix: Optional[List[float]] = None

    def add(self, item: MemoryItem) -> str:
        if len(self._items) >= self._max_size:
            oldest = min(self._items.values(), key=lambda x: x.timestamp)
            del self._items[oldest.id]
        self._items[item.id] = item
        return item.id

    def get(self, item_id: str) -> Optional[MemoryItem]:
        return self._items.get(item_id)

    def search(self, query: MemoryQuery) -> MemoryResult:
        start = time.monotonic()
        scored: List[Tuple[float, MemoryItem]] = []

        for item in self._items.values():
            score = self._semantic_score(item, query)
            if score >= query.threshold:
                scored.append((score, item))

        scored.sort(key=lambda x: x[0], reverse=True)
        items = [item for _, item in scored[:query.top_k]]

        return MemoryResult(
            items=items,
            query=query,
            total_found=len(scored),
            execution_time=time.monotonic() - start,
        )

    def update(self, item_id: str, **updates: Any) -> bool:
        item = self._items.get(item_id)
        if item is None:
            return False
        for key, value in updates.items():
            if hasattr(item, key):
                setattr(item, key, value)
        return True

    def delete(self, item_id: str) -> bool:
        return self._items.pop(item_id, None) is not None

    def clear(self) -> None:
        self._items.clear()

    def count(self) -> int:
        return len(self._items)

    def get_all(self) -> List[MemoryItem]:
        return list(self._items.values())

    def _semantic_score(self, item: MemoryItem, query: MemoryQuery) -> float:
        score = 0.0

        q_words = set(query.query.lower().split())
        c_words = set(item.content.lower().split())
        overlap = len(q_words & c_words)
        if q_words:
            score += 0.6 * (overlap / len(q_words))

        if item.embedding is not None and query.embedding is not None:
            sim = self._cosine_similarity(item.embedding, query.embedding)
            score += 0.4 * sim

        score *= item.importance

        for filter_key, filter_value in query.filters.items():
            meta_val = item.metadata.get(filter_key)
            if meta_val != filter_value:
                score *= 0.3

        return score

    def _cosine_similarity(self, a: List[float], b: List[float]) -> float:
        if len(a) != len(b) or not a:
            return 0.0
        dot = sum(x * y for x, y in zip(a, b))
        norm_a = math.sqrt(sum(x * x for x in a))
        norm_b = math.sqrt(sum(y * y for y in b))
        if norm_a == 0 or norm_b == 0:
            return 0.0
        return dot / (norm_a * norm_b)


class WorkingMemory(MemoryStore):
    def __init__(self, max_size: int = 100, default_ttl: float = 3600.0) -> None:
        self._items: Dict[str, MemoryItem] = {}
        self._max_size = max_size
        self._default_ttl = default_ttl

    def add(self, item: MemoryItem) -> str:
        if len(self._items) >= self._max_size:
            self._evict_lru()
        self._items[item.id] = item
        return item.id

    def set(self, key: str, value: Any, ttl: Optional[float] = None) -> str:
        item = MemoryItem(
            content=json.dumps(value) if not isinstance(value, str) else value,
            metadata={"key": key, "ttl": ttl or self._default_ttl},
            source="working_memory",
        )
        return self.add(item)

    def get_value(self, key: str) -> Optional[Any]:
        for item in self._items.values():
            if item.metadata.get("key") == key:
                if self._is_expired(item):
                    self.delete(item.id)
                    return None
                item.access_count += 1
                try:
                    return json.loads(item.content)
                except (json.JSONDecodeError, TypeError):
                    return item.content
        return None

    def get(self, item_id: str) -> Optional[MemoryItem]:
        item = self._items.get(item_id)
        if item and self._is_expired(item):
            self.delete(item_id)
            return None
        return item

    def search(self, query: MemoryQuery) -> MemoryResult:
        start = time.monotonic()
        results: List[MemoryItem] = []
        for item in self._items.values():
            if self._is_expired(item):
                continue
            if query.query and query.query.lower() in item.content.lower():
                results.append(item)
            elif not query.query:
                results.append(item)
        return MemoryResult(
            items=results[:query.top_k],
            query=query,
            total_found=len(results),
            execution_time=time.monotonic() - start,
        )

    def update(self, item_id: str, **updates: Any) -> bool:
        item = self._items.get(item_id)
        if item is None:
            return False
        for key, value in updates.items():
            if hasattr(item, key):
                setattr(item, key, value)
        return True

    def delete(self, item_id: str) -> bool:
        return self._items.pop(item_id, None) is not None

    def clear(self) -> None:
        self._items.clear()

    def count(self) -> int:
        return len(self._items)

    def get_all(self) -> List[MemoryItem]:
        return [v for v in self._items.values() if not self._is_expired(v)]

    def keys(self) -> List[str]:
        return [
            item.metadata.get("key", item.id)
            for item in self._items.values()
            if not self._is_expired(item)
        ]

    def _is_expired(self, item: MemoryItem) -> bool:
        ttl = item.metadata.get("ttl", self._default_ttl)
        age = (datetime.utcnow() - item.timestamp).total_seconds()
        return age > ttl

    def _evict_lru(self) -> None:
        if not self._items:
            return
        lru = min(self._items.values(), key=lambda x: x.access_count)
        del self._items[lru.id]


@dataclass
class EmbeddingConfig:
    model_name: str = "text-embedding-ada-002"
    dimension: int = 768
    batch_size: int = 32
    normalize: bool = True


class VectorMemory(MemoryStore):
    def __init__(
        self,
        embedding_fn: Optional[Callable[[str], List[float]]] = None,
        dimension: int = 768,
        similarity_metric: str = "cosine",
    ) -> None:
        self._items: Dict[str, MemoryItem] = {}
        self._embedding_fn = embedding_fn
        self._dimension = dimension
        self._similarity_metric = similarity_metric

    def add(self, item: MemoryItem) -> str:
        if self._embedding_fn and item.embedding is None:
            try:
                item.embedding = self._embedding_fn(item.content)
            except Exception:
                pass
        self._items[item.id] = item
        return item.id

    def get(self, item_id: str) -> Optional[MemoryItem]:
        return self._items.get(item_id)

    def search(self, query: MemoryQuery) -> MemoryResult:
        start = time.monotonic()
        query_embedding = query.embedding
        if query_embedding is None and self._embedding_fn and query.query:
            try:
                query_embedding = self._embedding_fn(query.query)
            except Exception:
                pass

        scored: List[Tuple[float, MemoryItem]] = []
        for item in self._items.values():
            score = self._compute_vector_score(item, query, query_embedding)
            if score >= query.threshold:
                scored.append((score, item))

        scored.sort(key=lambda x: x[0], reverse=True)
        items = [item for _, item in scored[:query.top_k]]

        return MemoryResult(
            items=items,
            query=query,
            total_found=len(scored),
            execution_time=time.monotonic() - start,
        )

    def update(self, item_id: str, **updates: Any) -> bool:
        item = self._items.get(item_id)
        if item is None:
            return False
        for key, value in updates.items():
            if hasattr(item, key):
                setattr(item, key, value)
        if "embedding" not in updates and self._embedding_fn:
            try:
                item.embedding = self._embedding_fn(item.content)
            except Exception:
                pass
        return True

    def delete(self, item_id: str) -> bool:
        return self._items.pop(item_id, None) is not None

    def clear(self) -> None:
        self._items.clear()

    def count(self) -> int:
        return len(self._items)

    def get_all(self) -> List[MemoryItem]:
        return list(self._items.values())

    def _compute_vector_score(
        self,
        item: MemoryItem,
        query: MemoryQuery,
        query_embedding: Optional[List[float]],
    ) -> float:
        score = 0.0

        if item.embedding is not None and query_embedding is not None:
            if self._similarity_metric == "cosine":
                sim = self._cosine_similarity(item.embedding, query_embedding)
            elif self._similarity_metric == "dot":
                sim = sum(a * b for a, b in zip(item.embedding, query_embedding))
            elif self._similarity_metric == "euclidean":
                dist = math.sqrt(sum((a - b) ** 2 for a, b in zip(item.embedding, query_embedding)))
                sim = 1.0 / (1.0 + dist)
            else:
                sim = self._cosine_similarity(item.embedding, query_embedding)
            score = sim

        q_words = set(query.query.lower().split())
        c_words = set(item.content.lower().split())
        overlap = len(q_words & c_words)
        if q_words:
            score += 0.2 * (overlap / len(q_words))

        for filter_key, filter_value in query.filters.items():
            meta_val = item.metadata.get(filter_key)
            if meta_val != filter_value:
                score *= 0.3

        return score

    def _cosine_similarity(self, a: List[float], b: List[float]) -> float:
        if len(a) != len(b) or not a:
            return 0.0
        dot = sum(x * y for x, y in zip(a, b))
        norm_a = math.sqrt(sum(x * x for x in a))
        norm_b = math.sqrt(sum(y * y for y in b))
        if norm_a == 0 or norm_b == 0:
            return 0.0
        return dot / (norm_a * norm_b)


class MemoryConsolidator:
    def __init__(
        self,
        llm_summarize: Optional[Callable[[str], str]] = None,
        consolidation_interval: int = 100,
    ) -> None:
        self.llm_summarize = llm_summarize
        self.consolidation_interval = consolidation_interval

    def consolidate(self, store: MemoryStore) -> List[MemoryItem]:
        all_items = store.get_all()
        if len(all_items) < self.consolidation_interval:
            return all_items

        summaries: List[MemoryItem] = []
        for i in range(0, len(all_items), self.consolidation_interval):
            batch = all_items[i:i + self.consolidation_interval]
            summary_item = self._summarize_batch(batch)
            if summary_item:
                summaries.append(summary_item)

        for item in all_items:
            store.delete(item.id)

        for summary in summaries:
            store.add(summary)

        return store.get_all()

    def _summarize_batch(self, items: List[MemoryItem]) -> Optional[MemoryItem]:
        if self.llm_summarize:
            texts = [item.content for item in items if item.content]
            if not texts:
                return None
            combined = "\n".join(texts)
            try:
                summary = self.llm_summarize(combined[:4000])
                avg_importance = sum(item.importance for item in items) / len(items)
                return MemoryItem(
                    content=summary,
                    metadata={"consolidated": True, "source_count": len(items)},
                    importance=avg_importance,
                    source="consolidation",
                )
            except Exception:
                pass

        combined_text = " ".join(item.content for item in items if item.content)
        truncated = combined_text[:2000]
        avg_importance = sum(item.importance for item in items) / len(items)
        return MemoryItem(
            content=truncated,
            metadata={"consolidated": True, "source_count": len(items)},
            importance=avg_importance,
            source="consolidation",
        )

    def forget_old(
        self,
        store: MemoryStore,
        max_age_hours: float = 72.0,
        importance_threshold: float = 0.3,
    ) -> int:
        forgotten = 0
        for item in store.get_all():
            if item.age_hours > max_age_hours and item.importance < importance_threshold:
                store.delete(item.id)
                forgotten += 1
        return forgotten

    def reweigh_by_recency(self, store: MemoryStore, half_life_hours: float = 24.0) -> None:
        for item in store.get_all():
            decay = math.exp(-item.age_hours / half_life_hours)
            item.importance = item.importance * 0.7 + decay * 0.3
