"""HTML cleaner with content extraction, boilerplate removal, and encoding detection."""

from __future__ import annotations

import re
import unicodedata
from dataclasses import dataclass, field
from html.parser import HTMLParser
from typing import Optional

try:
    from readability import Document as ReadabilityDocument
except ImportError:
    ReadabilityDocument = None  # type: ignore

try:
    import chardet
except ImportError:
    chardet = None  # type: ignore

import lxml.etree as etree
import lxml.html as html_parser


@dataclass
class CleanConfig:
    """Configuration for HTML cleaning."""

    strip_tags: bool = True
    remove_scripts: bool = True
    remove_styles: bool = True
    remove_navigation: bool = True
    remove_boilerplate: bool = True
    use_readability: bool = True
    normalize_whitespace: bool = True
    fix_encoding: bool = True
    min_content_length: int = 50
    remove_empty_elements: bool = True
    allowed_tags: set[str] = field(
        default_factory=lambda: {"p", "h1", "h2", "h3", "h4", "h5", "h6", "li", "pre", "code", "blockquote", "tr", "td", "th"}
    )
    navigation_patterns: tuple[str, ...] = (
        r"\bnav\b",
        r"\bmenu\b",
        r"\bheader\b",
        r"\bfooter\b",
        r"\bsidebar\b",
        r"\bbreadcrumb\b",
        r"\bpagination\b",
    )


class ContentExtractor(HTMLParser):
    """Extracts main text content from HTML, ignoring scripts/styles."""

    def __init__(self) -> None:
        super().__init__()
        self._skip = False
        self._skip_tags = {"script", "style", "noscript", "iframe", "svg"}
        self._skip_depth = 0
        self._text_parts: list[str] = []
        self._links: list[str] = []

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        if tag in self._skip_tags:
            self._skip = True
            self._skip_depth += 1
        if tag == "a":
            for name, value in attrs:
                if name == "href" and value:
                    self._links.append(value)

    def handle_endtag(self, tag: str) -> None:
        if tag in self._skip_tags and self._skip:
            self._skip_depth -= 1
            if self._skip_depth <= 0:
                self._skip = False
                self._skip_depth = 0
        if tag in ("p", "br", "div", "h1", "h2", "h3", "h4", "h5", "h6", "li", "tr"):
            self._text_parts.append("\n")

    def handle_data(self, data: str) -> None:
        if not self._skip:
            self._text_parts.append(data)

    def get_text(self) -> str:
        return "".join(self._text_parts)

    def get_links(self) -> list[str]:
        return self._links


class EncodingDetector:
    """Detects and converts character encoding."""

    @staticmethod
    def detect(raw_bytes: bytes) -> str:
        if chardet:
            result = chardet.detect(raw_bytes)
            return result.get("encoding", "utf-8") or "utf-8"
        return EncodingDetector._simple_detect(raw_bytes)

    @staticmethod
    def _simple_detect(raw_bytes: bytes) -> str:
        if raw_bytes.startswith(b"\xef\xbb\xbf"):
            return "utf-8-sig"
        if raw_bytes.startswith(b"\xff\xfe"):
            return "utf-16-le"
        if raw_bytes.startswith(b"\xfe\xff"):
            return "utf-16-be"
        if raw_bytes[:4] == b"\x00\x00\xfe\xff":
            return "utf-32-be"
        try:
            raw_bytes.decode("utf-8")
            return "utf-8"
        except UnicodeDecodeError:
            pass
        try:
            raw_bytes.decode("ascii")
            return "ascii"
        except UnicodeDecodeError:
            pass
        return "latin-1"

    @staticmethod
    def convert(raw_bytes: bytes, encoding: Optional[str] = None) -> str:
        if encoding is None:
            encoding = EncodingDetector.detect(raw_bytes)
        try:
            return raw_bytes.decode(encoding, errors="replace")
        except (LookupError, UnicodeDecodeError):
            return raw_bytes.decode("utf-8", errors="replace")


class BoilerplateRemover:
    """Removes boilerplate content from HTML."""

    BOILERPLATE_SIGNATURES: tuple[str, ...] = (
        "all rights reserved",
        "copyright",
        "terms of service",
        "privacy policy",
        "cookie policy",
        "sign up",
        "log in",
        "subscribe",
        "newsletter",
        "follow us",
        "share this",
        "advertisement",
        "sponsored",
    )

    @classmethod
    def is_boilerplate(cls, text: str) -> bool:
        lower = text.lower()
        matches = sum(1 for s in cls.BOILERPLATE_SIGNATURES if s in lower)
        return matches >= 2

    @classmethod
    def remove_boilerplate(cls, text: str) -> str:
        lines = text.split("\n")
        cleaned = []
        for line in lines:
            stripped = line.strip()
            if stripped and cls.is_boilerplate(stripped):
                continue
            cleaned.append(line)
        return "\n".join(cleaned)


class HTMLCleaner:
    """Comprehensive HTML cleaner and content extractor."""

    def __init__(self, config: Optional[CleanConfig] = None) -> None:
        self.config = config or CleanConfig()
        self._nav_pattern = re.compile(
            "|".join(self.config.navigation_patterns), re.IGNORECASE
        )

    def _remove_by_xpath(self, tree: html_parser.HtmlElement, expressions: list[str]) -> None:
        for expr in expressions:
            try:
                for elem in tree.xpath(expr):
                    elem.getparent().remove(elem)
            except etree.XPathSyntaxError:
                continue

    def _remove_scripts_styles(self, tree: html_parser.HtmlElement) -> None:
        if self.config.remove_scripts:
            self._remove_by_xpath(tree, ["//script", "//noscript"])
        if self.config.remove_styles:
            self._remove_by_xpath(tree, ["//style", "//link[@rel='stylesheet']"])

    def _remove_navigation(self, tree: html_parser.HtmlElement) -> None:
        if not self.config.remove_navigation:
            return
        for elem in tree.iter():
            tag = elem.tag if isinstance(elem.tag, str) else ""
            classes = " ".join(elem.get("class", "").split())
            id_attr = elem.get("id", "")
            if self._nav_pattern.search(tag) or self._nav_pattern.search(
                classes
            ) or self._nav_pattern.search(id_attr):
                parent = elem.getparent()
                if parent is not None:
                    parent.remove(elem)

    def _remove_boilerplate_elements(self, tree: html_parser.HtmlElement) -> None:
        if not self.config.remove_boilerplate:
            return
        self._remove_by_xpath(
            tree,
            [
                "//footer",
                "//header",
                "//nav",
                "//*[contains(@class, 'footer')]",
                "//*[contains(@class, 'header')]",
                "//*[contains(@class, 'sidebar')]",
                "//*[contains(@class, 'widget')]",
                "//*[contains(@class, 'cookie')]",
                "//*[contains(@class, 'popup')]",
                "//*[contains(@class, 'modal')]",
                "//*[contains(@class, 'overlay')]",
            ],
        )

    def _remove_empty_elements(self, tree: html_parser.HtmlElement) -> None:
        if not self.config.remove_empty_elements:
            return
        for elem in reversed(list(tree.iter())):
            if isinstance(elem.tag, str) and elem.tag not in ("br", "hr", "img", "input"):
                if elem.text is None and elem.tail is None and len(elem) == 0:
                    parent = elem.getparent()
                    if parent is not None:
                        parent.remove(elem)

    def _readability_extract(self, html_content: str) -> Optional[str]:
        if not self.config.use_readability or ReadabilityDocument is None:
            return None
        try:
            doc = ReadabilityDocument(html_content)
            summary_html = doc.summary()
            extractor = ContentExtractor()
            extractor.feed(summary_html)
            return extractor.get_text().strip()
        except Exception:
            return None

    def _lxml_extract(self, html_content: str) -> str:
        try:
            tree = html_parser.fromstring(html_content)
        except Exception:
            extractor = ContentExtractor()
            extractor.feed(html_content)
            return extractor.get_text().strip()

        self._remove_scripts_styles(tree)
        self._remove_navigation(tree)
        self._remove_boilerplate_elements(tree)
        self._remove_empty_elements(tree)

        extractor = ContentExtractor()
        extractor.feed(etree.tostring(tree, encoding="unicode"))
        return extractor.get_text().strip()

    def _normalize_whitespace(self, text: str) -> str:
        text = re.sub(r"[ \t]+", " ", text)
        text = re.sub(r"\n{3,}", "\n\n", text)
        return text.strip()

    def _normalize_unicode(self, text: str) -> str:
        return unicodedata.normalize("NFKC", text)

    def clean(self, html_content: str) -> str:
        text = self._readability_extract(html_content)
        if text and len(text) >= self.config.min_content_length:
            if self.config.normalize_whitespace:
                text = self._normalize_whitespace(text)
            if self.config.fix_encoding:
                text = self._normalize_unicode(text)
            return text

        text = self._lxml_extract(html_content)
        if self.config.normalize_whitespace:
            text = self._normalize_whitespace(text)
        if self.config.fix_encoding:
            text = self._normalize_unicode(text)
        return text

    def clean_raw(self, raw_bytes: bytes, encoding: Optional[str] = None) -> str:
        if self.config.fix_encoding:
            text = EncodingDetector.convert(raw_bytes, encoding)
        else:
            text = raw_bytes.decode("utf-8", errors="replace")
        return self.clean(text)

    def clean_batch(self, html_documents: list[str]) -> list[str]:
        return [self.clean(doc) for doc in html_documents]
