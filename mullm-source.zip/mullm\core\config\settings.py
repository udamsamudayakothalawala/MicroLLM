from __future__ import annotations

import os
from enum import Enum
from typing import Any, Dict, List, Optional, Union

from pydantic import BaseModel, Field, field_validator, model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class AttentionType(str, Enum):
    flash_attention_2 = "flash_attention_2"
    sdpa = "sdpa"
    eager = "eager"
    xformers = "xformers"


class NormalizationType(str, Enum):
    rms_norm = "rms_norm"
    layer_norm = "layer_norm"
    l2_norm = "l2_norm"


class ActivationType(str, Enum):
    silu = "silu"
    gelu = "gelu"
    gelu_tanh = "gelu_tanh"
    relu = "relu"
    relu2 = "relu2"
    swiglu = "swiglu"


class MoEConfig(BaseModel):
    num_experts: int = Field(default=8, ge=1, description="Number of MoE experts")
    top_k: int = Field(default=2, ge=1, description="Number of top experts to route to")
    expert_capacity: Optional[int] = Field(default=None, description="Per-expert capacity")
    shared_expert_count: int = Field(default=1, ge=0, description="Number of shared experts")
    shared_expert_gate: bool = Field(default=False, description="Whether to use gating for shared experts")
    router_aux_loss_coef: float = Field(default=0.001, ge=0.0, description="Auxiliary loss coefficient for load balancing")
    router_jitter_noise: float = Field(default=0.0, ge=0.0, description="Jitter noise for routing")
    router_dtype: str = Field(default="float32", description="Data type for router weights")
    num_shared_experts: int = Field(default=1, ge=0, description="DEPRECATED: use shared_expert_count")


class RopeScalingConfig(BaseModel):
    scaling_type: str = Field(default="linear", pattern="^(linear|dynamic|yarn|su|none)$")
    scaling_factor: float = Field(default=1.0, ge=1.0)
    original_max_position_embeddings: int = Field(default=4096, ge=1)
    attention_factor: Optional[float] = Field(default=None)
    beta_fast: Optional[float] = Field(default=None)
    beta_slow: Optional[float] = Field(default=None)
    mscale: Optional[float] = Field(default=None)
    mscale_all_dim: Optional[float] = Field(default=None)


class ModelConfig(BaseModel):
    vocab_size: int = Field(default=32000, ge=1, description="Vocabulary size")
    hidden_size: int = Field(default=4096, ge=1, description="Hidden dimension size")
    num_layers: int = Field(default=32, ge=1, description="Number of transformer layers")
    num_attention_heads: int = Field(default=32, ge=1, description="Number of attention heads")
    num_kv_heads: Optional[int] = Field(default=None, ge=1, description="Number of key/value heads for GQA")
    intermediate_size: int = Field(default=11008, ge=1, description="FFN intermediate size")
    max_position_embeddings: int = Field(default=4096, ge=1, description="Maximum sequence length")
    rope_theta: float = Field(default=10000.0, gt=0.0, description="RoPE base frequency")
    rope_scaling: Optional[RopeScalingConfig] = Field(default=None, description="RoPE scaling configuration")
    attention_type: AttentionType = Field(default=AttentionType.sdpa, description="Attention implementation type")
    normalization_type: NormalizationType = Field(default=NormalizationType.rms_norm, description="Normalization type")
    activation_type: ActivationType = Field(default=ActivationType.silu, description="Activation function type")
    use_flash_attn: bool = Field(default=False, description="Whether to use Flash Attention v2")
    sliding_window: Optional[int] = Field(default=None, ge=1, description="Sliding window attention size")
    moe_config: Optional[MoEConfig] = Field(default=None, description="MoE configuration")

    # Dropout & regularization
    attention_dropout: float = Field(default=0.0, ge=0.0, le=1.0)
    hidden_dropout: float = Field(default=0.0, ge=0.0, le=1.0)
    embedding_dropout: float = Field(default=0.0, ge=0.0, le=1.0)

    # Initialization
    initializer_range: float = Field(default=0.02, ge=0.0)
    rms_norm_eps: float = Field(default=1e-6, gt=0.0)
    layer_norm_eps: float = Field(default=1e-5, gt=0.0)

    # Tie embeddings
    tie_word_embeddings: bool = Field(default=False, description="Tie input and output embeddings")

    # Model parallelism
    num_key_value_heads: Optional[int] = Field(default=None, ge=1)
    head_dim: Optional[int] = Field(default=None, ge=1)

    @field_validator("num_kv_heads", "num_key_value_heads", mode="before")
    @classmethod
    def set_kv_heads(cls, v: Optional[int], info: Any) -> Optional[int]:
        if v is not None:
            return v
        return None

    @model_validator(mode="after")
    def set_default_kv_heads(self) -> "ModelConfig":
        if self.num_kv_heads is None:
            self.num_kv_heads = self.num_attention_heads
        if self.num_key_value_heads is None:
            self.num_key_value_heads = self.num_kv_heads
        if self.head_dim is None:
            self.head_dim = self.hidden_size // self.num_attention_heads
        if self.use_flash_attn:
            self.attention_type = AttentionType.flash_attention_2
        return self

    def to_hf_config(self) -> Dict[str, Any]:
        """Convert to Hugging Face AutoConfig kwargs."""
        config: Dict[str, Any] = {
            "vocab_size": self.vocab_size,
            "hidden_size": self.hidden_size,
            "num_hidden_layers": self.num_layers,
            "num_attention_heads": self.num_attention_heads,
            "num_key_value_heads": self.num_kv_heads,
            "intermediate_size": self.intermediate_size,
            "max_position_embeddings": self.max_position_embeddings,
            "rope_theta": self.rope_theta,
            "attention_dropout": self.attention_dropout,
            "hidden_dropout": self.hidden_dropout,
            "rms_norm_eps": self.rms_norm_eps,
            "initializer_range": self.initializer_range,
            "tie_word_embeddings": self.tie_word_embeddings,
            "head_dim": self.head_dim,
            "sliding_window": self.sliding_window,
        }
        if self.rope_scaling is not None:
            config["rope_scaling"] = self.rope_scaling.model_dump(exclude_none=True)
        if self.moe_config is not None:
            config["moe"] = self.moe_config.model_dump(exclude_none=True)
            config["num_experts"] = self.moe_config.num_experts
            config["num_experts_per_tok"] = self.moe_config.top_k
        return config


class OptimizerType(str, Enum):
    adamw = "adamw"
    adam = "adam"
    sgd = "sgd"
    adagrad = "adagrad"
    rmsprop = "rmsprop"


class SchedulerType(str, Enum):
    cosine = "cosine"
    linear = "linear"
    constant = "constant"
    constant_with_warmup = "constant_with_warmup"
    cosine_with_restarts = "cosine_with_restarts"
    polynomial = "polynomial"
    inverse_sqrt = "inverse_sqrt"
    warmup_stable_decay = "warmup_stable_decay"


class LoRAConfig(BaseModel):
    r: int = Field(default=8, ge=1, description="LoRA rank")
    alpha: int = Field(default=16, ge=1, description="LoRA alpha scaling")
    dropout: float = Field(default=0.05, ge=0.0, le=1.0, description="LoRA dropout rate")
    target_modules: Optional[List[str]] = Field(default=None, description="Modules to apply LoRA to")
    bias: str = Field(default="none", pattern="^(none|all|lora_only)$")
    task_type: str = Field(default="CAUSAL_LM", description="Task type for PEFT")
    modules_to_save: Optional[List[str]] = Field(default=None)
    init_lora_weights: bool = Field(default=True)
    use_rslora: bool = Field(default=False)
    use_dora: bool = Field(default=False)


class DeepSpeedConfig(BaseModel):
    zero_stage: int = Field(default=2, ge=0, le=3, description="ZeRO optimization stage")
    offload_optimizer: bool = Field(default=False, description="Offload optimizer states to CPU/NVMe")
    offload_params: bool = Field(default=False, description="Offload parameters to CPU/NVMe")
    offload_device: str = Field(default="cpu", pattern="^(cpu|nvme)$")
    gradient_accumulation_steps: int = Field(default=1, ge=1)
    gradient_clipping: float = Field(default=1.0, gt=0.0)
    train_batch_size: Optional[int] = Field(default=None, ge=1)
    train_micro_batch_size_per_gpu: Optional[int] = Field(default=None, ge=1)
    wall_clock_breakdown: bool = Field(default=False)
    flush_l2: bool = Field(default=False)
    allgather_bucket_size: int = Field(default=500000000, ge=1)
    reduce_bucket_size: int = Field(default=500000000, ge=1)

    def to_ds_config(self) -> Dict[str, Any]:
        return {
            "zero_optimization": {
                "stage": self.zero_stage,
                "offload_optimizer": {"device": self.offload_device} if self.offload_optimizer else None,
                "offload_param": {"device": self.offload_device} if self.offload_params else None,
                "allgather_bucket_size": self.allgather_bucket_size,
                "reduce_bucket_size": self.reduce_bucket_size,
            },
            "gradient_accumulation_steps": self.gradient_accumulation_steps,
            "gradient_clipping": self.gradient_clipping,
            "train_batch_size": self.train_batch_size,
            "train_micro_batch_size_per_gpu": self.train_micro_batch_size_per_gpu,
            "wall_clock_breakdown": self.wall_clock_breakdown,
            "flush_l2": self.flush_l2,
        }


class TrainingConfig(BaseModel):
    batch_size: int = Field(default=8, ge=1, description="Training batch size per device")
    gradient_accumulation_steps: int = Field(default=1, ge=1)
    learning_rate: float = Field(default=5e-5, gt=0.0, description="Peak learning rate")
    min_learning_rate: float = Field(default=0.0, ge=0.0, description="Minimum learning rate for schedules")
    warmup_steps: int = Field(default=0, ge=0, description="Number of warmup steps")
    warmup_ratio: float = Field(default=0.0, ge=0.0, le=1.0, description="Fraction of total steps for warmup")
    num_epochs: int = Field(default=3, ge=1, description="Number of training epochs")
    max_steps: int = Field(default=-1, description="Maximum training steps (-1 = auto)")
    optimizer: OptimizerType = Field(default=OptimizerType.adamw)
    scheduler: SchedulerType = Field(default=SchedulerType.cosine)
    weight_decay: float = Field(default=0.01, ge=0.0)
    adam_beta1: float = Field(default=0.9, ge=0.0, le=1.0)
    adam_beta2: float = Field(default=0.999, ge=0.0, le=1.0)
    adam_epsilon: float = Field(default=1e-8, gt=0.0)
    max_grad_norm: float = Field(default=1.0, gt=0.0, description="Maximum gradient norm for clipping")

    # Precision
    fp16: bool = Field(default=False, description="Enable FP16 training")
    bf16: bool = Field(default=True, description="Enable BF16 training")
    tf32: bool = Field(default=True, description="Enable TF32 precision on Ampere GPUs")

    # Checkpointing
    save_steps: int = Field(default=500, ge=1, description="Save checkpoint every N steps")
    save_total_limit: int = Field(default=3, ge=1, description="Maximum number of checkpoints to keep")
    eval_steps: int = Field(default=500, ge=1, description="Evaluate every N steps")
    logging_steps: int = Field(default=10, ge=1, description="Log every N steps")

    # Distributed
    deepspeed: Optional[DeepSpeedConfig] = Field(default=None, description="DeepSpeed configuration")
    lora_config: Optional[LoRAConfig] = Field(default=None, description="LoRA/PEFT configuration")
    ddp_find_unused_parameters: bool = Field(default=False)
    ddp_bucket_cap_mb: int = Field(default=25, ge=1)
    local_rank: int = Field(default=-1, description="Local rank for distributed training")
    world_size: int = Field(default=1, ge=1, description="Number of processes for distributed training")

    # FSDP
    fsdp: bool = Field(default=False, description="Enable FSDP")
    fsdp_transformer_layer_cls_to_wrap: Optional[List[str]] = Field(default=None)
    fsdp_backward_prefetch: str = Field(default="backward_pre", pattern="^(backward_pre|backward_post|no_prefetch)$")

    # Profiling
    profile: bool = Field(default=False)
    skip_first_n_steps_for_profile: int = Field(default=0, ge=0)

    @model_validator(mode="after")
    def validate_precision(self) -> "TrainingConfig":
        if self.fp16 and self.bf16:
            raise ValueError("fp16 and bf16 cannot both be enabled simultaneously")
        return self

    @model_validator(mode="after")
    def validate_warmup(self) -> "TrainingConfig":
        if self.warmup_steps > 0 and self.warmup_ratio > 0:
            raise ValueError("Specify either warmup_steps or warmup_ratio, not both")
        return self


class DataSourceType(str, Enum):
    huggingface = "huggingface"
    json = "json"
    jsonl = "jsonl"
    csv = "csv"
    parquet = "parquet"
    arrow = "arrow"
    text = "text"
    custom = "custom"


class DataConfig(BaseModel):
    dataset_name_or_path: str = Field(default="", description="HuggingFace dataset name or local path")
    source_type: DataSourceType = Field(default=DataSourceType.huggingface)
    split: str = Field(default="train", description="Dataset split to use")
    train_split: str = Field(default="train", description="Training split")
    eval_split: str = Field(default="validation", description="Evaluation split")
    tokenizer_name_or_path: str = Field(default="", description="Tokenizer name or path")
    max_seq_length: int = Field(default=2048, ge=1, description="Maximum sequence length for tokenization")
    padding: Union[bool, str] = Field(default=False, description="Padding strategy")
    truncation: bool = Field(default=True, description="Whether to truncate sequences")
    preprocessing_num_workers: int = Field(default=4, ge=1, description="Number of workers for data preprocessing")
    cache_dir: Optional[str] = Field(default=None, description="Directory for caching datasets")
    stream: bool = Field(default=False, description="Stream dataset instead of downloading")
    shuffle_buffer_size: int = Field(default=10000, ge=1, description="Buffer size for shuffling streaming data")

    # Data loading
    num_proc: int = Field(default=1, ge=1, description="Number of processes for data loading")
    batch_size: int = Field(default=1024, ge=1, description="Batch size for data loading")
    prefetch_factor: int = Field(default=2, ge=1, description="Prefetch factor for data loading")
    persistent_workers: bool = Field(default=True)

    # Filtering
    min_text_length: int = Field(default=0, ge=0)
    max_text_length: int = Field(default=0, ge=0, description="0 = no limit")
    remove_duplicates: bool = Field(default=False)
    filter_empty: bool = Field(default=True)

    # Columns
    text_column: str = Field(default="text", description="Input text column name")
    label_column: str = Field(default="label", description="Label column name")
    prompt_column: str = Field(default="prompt", description="Prompt column for instruction tuning")
    response_column: str = Field(default="response", description="Response column for instruction tuning")
    remove_columns: Optional[List[str]] = Field(default=None, description="Columns to remove after processing")

    @model_validator(mode="after")
    def set_default_tokenizer(self) -> "DataConfig":
        if not self.tokenizer_name_or_path:
            self.tokenizer_name_or_path = self.dataset_name_or_path
        return self


class LoggingConfig(BaseModel):
    level: str = Field(default="INFO", pattern="^(DEBUG|INFO|WARNING|ERROR|CRITICAL)$")
    format: str = Field(default="json", pattern="^(json|plain)$")
    file_path: Optional[str] = Field(default=None)
    rotation: str = Field(default="1 day", description="Log rotation interval")
    retention: str = Field(default="30 days", description="Log retention period")
    json_indent: int = Field(default=2, ge=0)
    enable_structlog: bool = Field(default=True)


class DeviceConfig(str, Enum):
    auto = "auto"
    cpu = "cpu"
    cuda = "cuda"
    mps = "mps"
    xpu = "xpu"
    npu = "npu"


class ServingConfig(BaseModel):
    host: str = Field(default="0.0.0.0")
    port: int = Field(default=8000, ge=1, le=65535)
    workers: int = Field(default=1, ge=1)
    max_concurrent_requests: int = Field(default=64, ge=1)
    request_timeout: int = Field(default=60, ge=1)
    max_batch_size: int = Field(default=32, ge=1)
    batch_wait_timeout_ms: int = Field(default=100, ge=0)
    enable_websockets: bool = Field(default=True)
    cors_origins: List[str] = Field(default=["*"])
    api_keys: Optional[List[str]] = Field(default=None)
    rate_limit_requests_per_minute: int = Field(default=60, ge=1)
    enable_request_logging: bool = Field(default=True)
    max_request_length: int = Field(default=100000, ge=1)


class SystemConfig(BaseSettings):
    model_config = SettingsConfigDict(
        env_prefix="MULLM_",
        env_nested_delimiter="__",
        case_sensitive=False,
        extra="ignore",
    )

    model: ModelConfig = Field(default_factory=ModelConfig)
    training: TrainingConfig = Field(default_factory=TrainingConfig)
    data: DataConfig = Field(default_factory=DataConfig)
    serving: ServingConfig = Field(default_factory=ServingConfig)
    logging: LoggingConfig = Field(default_factory=LoggingConfig)

    device: DeviceConfig = Field(default=DeviceConfig.auto)
    seed: int = Field(default=42, ge=0)
    debug: bool = Field(default=False)
    output_dir: str = Field(default="./output")
    cache_dir: str = Field(default="./cache")
    experiment_name: str = Field(default="default")
    project_name: str = Field(default="mullm")
    use_wandb: bool = Field(default=False)
    use_tensorboard: bool = Field(default=True)
    wandb_project: Optional[str] = Field(default=None)
    wandb_entity: Optional[str] = Field(default=None)
    tensorboard_dir: Optional[str] = Field(default=None)

    # Distributed
    distributed_backend: str = Field(default="nccl", pattern="^(nccl|gloo|mpi)$")
    main_process_port: int = Field(default=29500, ge=1024, le=65535)

    # Memory & Performance
    tokenizer_parallelism: bool = Field(default=False)
    dataloader_num_workers: int = Field(default=2, ge=0)
    disable_tqdm: bool = Field(default=False)
    compile_model: bool = Field(default=False, description="Use torch.compile")

    @model_validator(mode="after")
    def resolve_device(self) -> "SystemConfig":
        if self.device == DeviceConfig.auto:
            import torch
            if torch.cuda.is_available():
                self.device = DeviceConfig.cuda
            elif hasattr(torch.backends, "mps") and torch.backends.mps.is_available():
                self.device = DeviceConfig.mps
            else:
                self.device = DeviceConfig.cpu
        return self

    @model_validator(mode="after")
    def set_default_paths(self) -> "SystemConfig":
        if self.tensorboard_dir is None:
            self.tensorboard_dir = os.path.join(self.output_dir, "tensorboard")
        return self

