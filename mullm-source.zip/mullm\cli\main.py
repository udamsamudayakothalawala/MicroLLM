#!/usr/bin/env python3
"""muLLM CLI - Train a small LLM from scratch with as little as 1M tokens."""

from __future__ import annotations

import argparse
import os
import sys
from typing import Optional, Sequence


def _get_version() -> str:
    try:
        from mullm import __version__

        return __version__
    except ImportError:
        return "0.1.0"


# ---------------------------------------------------------------------------
# train
# ---------------------------------------------------------------------------
def cmd_train(args: argparse.Namespace) -> int:
    """Train a small LLM from scratch."""
    from mullm.core.model.tiny_transformer import TinyTransformer, TINY_CONFIGS
    from mullm.core.trainer.simple_trainer import SimpleTrainer, SimpleConfig, set_seed
    from mullm.core.tokenizer.simple_tokenizer import SimpleTokenizer
    from mullm.core.data.text_dataset import TextDataset, load_text_file

    print(f"Loading dataset: {args.dataset}")
    texts = load_text_file(args.dataset)
    if not texts:
        print(f"Error: no text found in {args.dataset}", file=sys.stderr)
        return 1
    print(f"  {len(texts)} samples loaded")

    tokenizer = SimpleTokenizer(vocab_size=args.vocab_size)
    print("Training tokenizer (BPE)...")
    tokenizer.train(texts)
    os.makedirs(args.output_dir, exist_ok=True)
    tok_path = os.path.join(args.output_dir, "tokenizer.json")
    tokenizer.save(tok_path)
    print(f"  tokenizer saved to {tok_path} (vocab={len(tokenizer.vocab)})")

    model_cfg = TINY_CONFIGS.get(args.size, TINY_CONFIGS["small"])
    model_cfg.vocab_size = min(args.vocab_size, len(tokenizer.vocab))
    model_cfg.max_seq_len = args.max_seq_length
    model = TinyTransformer(model_cfg)
    print(f"Model: {args.size} config ({model.count_parameters():,} params)")

    train_ds = TextDataset(texts, tokenizer=tokenizer, max_len=args.max_seq_length)
    eval_ds = train_ds if args.eval_steps > 0 else None

    tcfg = SimpleConfig(
        output_dir=args.output_dir,
        num_epochs=args.epochs,
        batch_size=args.batch_size,
        learning_rate=args.learning_rate,
        weight_decay=args.weight_decay,
        warmup_steps=args.warmup_steps,
        max_grad_norm=args.max_grad_norm,
        bf16=args.bf16,
        fp16=args.fp16,
        seed=args.seed,
        log_steps=args.logging_steps,
        save_steps=args.save_steps,
        eval_steps=args.eval_steps,
        max_steps=args.max_steps,
        gradient_accumulation_steps=args.gradient_accumulation_steps,
        device=args.device,
    )

    set_seed(args.seed)
    trainer = SimpleTrainer(model=model, config=tcfg, train_dataset=train_ds, eval_dataset=eval_ds)
    result = trainer.train()
    print(f"Result: {result}")
    return 0


# ---------------------------------------------------------------------------
# export
# ---------------------------------------------------------------------------
def _load_model(checkpoint: str, size: str, vocab_size: Optional[int] = None, max_seq_len: Optional[int] = None):
    """Load a TinyTransformer from a checkpoint, using saved config when available."""
    import json
    import os
    import torch

    from mullm.core.model.tiny_transformer import TinyTransformer, TinyConfig, TINY_CONFIGS

    state_dict_path = None
    cfg_path = None

    if checkpoint.endswith(".pt"):
        state_dict_path = checkpoint
        cfg_path = checkpoint.replace("model.pt", "config.json")
    elif os.path.isdir(checkpoint):
        candidates = [
            os.path.join(checkpoint, "model.pt"),
            os.path.join(checkpoint, "checkpoint-final", "model.pt"),
        ]
        import glob

        candidates += glob.glob(os.path.join(checkpoint, "checkpoint-*/", "model.pt"))
        for c in candidates:
            if os.path.exists(c):
                state_dict_path = c
                alt_cfg = c.replace("model.pt", "config.json")
                if os.path.exists(alt_cfg):
                    cfg_path = alt_cfg
                break

    if not state_dict_path or not os.path.exists(state_dict_path):
        raise FileNotFoundError(checkpoint)

    model_cfg = TINY_CONFIGS.get(size, TINY_CONFIGS["small"])
    if cfg_path and os.path.exists(cfg_path):
        with open(cfg_path) as f:
            meta = json.load(f)
        saved = meta.get("model_config")
        if saved:
            allowed = set(TinyConfig.__dataclass_fields__)
            model_cfg = TinyConfig(**{k: v for k, v in saved.items() if k in allowed})

    if vocab_size:
        model_cfg.vocab_size = vocab_size
    if max_seq_len:
        model_cfg.max_seq_len = max_seq_len

    model = TinyTransformer(model_cfg)
    missing, unexpected = model.load_state_dict(torch.load(state_dict_path, map_location="cpu"), strict=False)
    if missing:
        print(f"  warning: {len(missing)} missing keys (buffers only)", file=sys.stderr)
    model.eval()
    return model


def cmd_export(args: argparse.Namespace) -> int:
    """Export a trained checkpoint to GGUF format."""
    from mullm.core.export.gguf_export import GGUFExporter

    if not args.checkpoint:
        print("Error: --checkpoint is required (path to model.pt)", file=sys.stderr)
        return 1

    print(f"Loading checkpoint: {args.checkpoint}")
    try:
        model = _load_model(args.checkpoint, args.size, args.vocab_size, args.max_seq_length)
    except FileNotFoundError:
        print(f"Error: checkpoint not found: {args.checkpoint}", file=sys.stderr)
        return 1
    print(f"Model loaded: {model.count_parameters():,} params")

    output = args.output_dir or f"model-{args.gguf_type}.gguf"
    exporter = GGUFExporter()
    path = exporter.export(model, output, dtype=args.gguf_type, architecture=args.architecture)
    print(f"GGUF exported to: {path}")
    return 0


# ---------------------------------------------------------------------------
# chat
# ---------------------------------------------------------------------------
def cmd_chat(args: argparse.Namespace) -> int:
    """Interactive generation with a trained model checkpoint."""
    import torch

    from mullm.core.tokenizer.simple_tokenizer import SimpleTokenizer

    if not args.checkpoint or not args.tokenizer:
        print("Error: --checkpoint and --tokenizer are required", file=sys.stderr)
        return 1

    print(f"Loading tokenizer: {args.tokenizer}")
    tokenizer = SimpleTokenizer.load(args.tokenizer)

    print(f"Loading model: {args.checkpoint}")
    model = _load_model(args.checkpoint, args.size)
    print("Ready. Type a prompt (Ctrl+C or /exit to quit).\n")

    try:
        while True:
            try:
                prompt = input("You: ").strip()
            except EOFError:
                break
            if prompt.lower() in ("/exit", "/quit", "/q"):
                break
            if not prompt:
                continue

            ids = tokenizer.encode(prompt, add_special_tokens=False)
            max_len = model.config.max_seq_len
            ids = ids[: max_len]
            input_ids = torch.tensor([ids], dtype=torch.long)
            max_gen = min(args.max_tokens, max_len - input_ids.shape[1])
            if max_gen <= 0:
                print("AI: (prompt exceeds model's max sequence length)\n")
                continue
            with torch.no_grad():
                for _ in range(max_gen):
                    outputs = model(input_ids=input_ids)
                    logits = outputs["logits"]
                    next_id = logits[0, -1].argmax().item()
                    if next_id in (tokenizer.eos_token_id, 0):
                        break
                    input_ids = torch.cat(
                        [input_ids, torch.tensor([[next_id]], dtype=torch.long)], dim=1
                    )

            response_tokens = input_ids[0].tolist()[len(ids):]
            response = tokenizer.decode(response_tokens)
            print(f"AI: {response}\n")
    except KeyboardInterrupt:
        print("\nGoodbye!")
    return 0


# ---------------------------------------------------------------------------
# gui
# ---------------------------------------------------------------------------
def cmd_gui(args: argparse.Namespace) -> int:
    """Launch the muLLM desktop GUI."""
    try:
        from gui.main import main
        main()
    except ImportError as e:
        print(f"Error: GUI dependencies not installed.\n  {e}\n\nInstall with: pip install PyQt5", file=sys.stderr)
        return 1
    return 0


# ---------------------------------------------------------------------------
# Argument parser
# ---------------------------------------------------------------------------
def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="mullm",
        description="muLLM - Train a small LLM from scratch with as little as 1M tokens",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument("--version", action="version", version=f"%(prog)s {_get_version()}")

    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    # ---- train ----
    train_parser = subparsers.add_parser("train", help="Train a small LLM from scratch")
    train_parser.add_argument("--dataset", required=True, help="Path to dataset (.txt, .json, .jsonl, .csv)")
    train_parser.add_argument("--size", default="small", choices=["tiny", "small", "base", "medium"],
                              help="Model size preset")
    train_parser.add_argument("--output-dir", default="./outputs", help="Output directory")
    train_parser.add_argument("--vocab-size", type=int, default=32000, help="Tokenizer vocabulary size")
    train_parser.add_argument("--max-seq-length", type=int, default=512, help="Maximum sequence length")
    train_parser.add_argument("--batch-size", type=int, default=8, help="Batch size")
    train_parser.add_argument("--learning-rate", type=float, default=3e-4, help="Learning rate")
    train_parser.add_argument("--epochs", type=int, default=3, help="Number of epochs")
    train_parser.add_argument("--max-steps", type=int, default=-1, help="Max training steps (-1 = auto)")
    train_parser.add_argument("--warmup-steps", type=int, default=100, help="Warmup steps")
    train_parser.add_argument("--save-steps", type=int, default=500, help="Save checkpoint every N steps")
    train_parser.add_argument("--eval-steps", type=int, default=0, help="Evaluate every N steps (0 = off)")
    train_parser.add_argument("--logging-steps", type=int, default=10, help="Log every N steps")
    train_parser.add_argument("--gradient-accumulation-steps", type=int, default=1, help="Grad accumulation steps")
    train_parser.add_argument("--weight-decay", type=float, default=0.01, help="Weight decay")
    train_parser.add_argument("--max-grad-norm", type=float, default=1.0, help="Max gradient norm")
    train_parser.add_argument("--bf16", action="store_true", default=True, help="Enable BF16 training")
    train_parser.add_argument("--fp16", action="store_true", help="Enable FP16 training")
    train_parser.add_argument("--seed", type=int, default=42, help="Random seed")
    train_parser.add_argument("--device", default="auto", choices=["auto", "cuda", "cpu", "mps"], help="Device")

    # ---- export ----
    exp_parser = subparsers.add_parser("export", help="Export checkpoint to GGUF")
    exp_parser.add_argument("--checkpoint", required=True, help="Path to model.pt checkpoint or checkpoint dir")
    exp_parser.add_argument("--size", default="small", choices=["tiny", "small", "base", "medium"],
                            help="Model size preset (used if checkpoint has no saved config)")
    exp_parser.add_argument("--output-dir", help="Output GGUF file path")
    exp_parser.add_argument("--gguf-type", default="f16", choices=["f32", "f16", "q4_0"], help="GGUF quantization type")
    exp_parser.add_argument("--architecture", default="llama", help="GGUF architecture name")
    exp_parser.add_argument("--vocab-size", type=int, help="Override vocab size")
    exp_parser.add_argument("--max-seq-length", type=int, help="Override max sequence length")

    # ---- chat ----
    chat_parser = subparsers.add_parser("chat", help="Interactive chat with a trained model")
    chat_parser.add_argument("--checkpoint", required=True, help="Path to model.pt checkpoint")
    chat_parser.add_argument("--tokenizer", required=True, help="Path to tokenizer.json")
    chat_parser.add_argument("--size", default="small", choices=["tiny", "small", "base", "medium"],
                             help="Model size preset")
    chat_parser.add_argument("--max-tokens", type=int, default=256, help="Max generation tokens")

    # ---- gui ----
    subparsers.add_parser("gui", help="Launch the muLLM desktop GUI")

    return parser


def main(argv: Optional[Sequence[str]] = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)

    if not args.command:
        parser.print_help()
        return 0

    command_map = {
        "train": cmd_train,
        "export": cmd_export,
        "chat": cmd_chat,
        "gui": cmd_gui,
    }

    handler = command_map.get(args.command)
    if handler is None:
        parser.print_help()
        return 1

    try:
        return handler(args)
    except KeyboardInterrupt:
        print("\nInterrupted.", file=sys.stderr)
        return 130
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
