"""
simple_tokenizer.py - BPE tokenizer trained from your data.
No HuggingFace dependency.
"""

import json
import os
import re
from collections import Counter, defaultdict
from typing import List, Optional


class SimpleTokenizer:
    def __init__(self, vocab_size: int = 32000):
        self.vocab_size = vocab_size
        self.merges: list[tuple[str, str]] = []
        self.vocab: dict[str, int] = {}
        self.inverse_vocab: dict[int, str] = {}
        self.special_tokens: dict[str, int] = {
            "<pad>": 0,
            "<bos>": 1,
            "<eos>": 2,
            "<unk>": 3,
        }

    @property
    def pad_token_id(self) -> int:
        return 0

    @property
    def bos_token_id(self) -> int:
        return 1

    @property
    def eos_token_id(self) -> int:
        return 2

    @property
    def unk_token_id(self) -> int:
        return 3

    def _get_stats(self, ids: list[list[int]]) -> dict[tuple[int, int], int]:
        counts = Counter()
        for word_ids in ids:
            for pair in zip(word_ids[:-1], word_ids[1:]):
                counts[pair] += 1
        return counts

    def _merge(self, ids: list[int], pair: tuple[int, int], new_id: int) -> list[int]:
        new_ids = []
        i = 0
        while i < len(ids):
            if i < len(ids) - 1 and ids[i] == pair[0] and ids[i + 1] == pair[1]:
                new_ids.append(new_id)
                i += 2
            else:
                new_ids.append(ids[i])
                i += 1
        return new_ids

    def train(self, texts: List[str], min_freq: int = 2) -> None:
        tokenized = []
        for text in texts:
            tokens = list(text.encode("utf-8"))
            tokenized.append(tokens)

        num_merges = self.vocab_size - 256 - len(self.special_tokens)
        self.merges = []
        self.vocab = {}

        for i in range(256):
            self.vocab[chr(i)] = i

        ids = [list(t) for t in tokenized]
        for i in range(num_merges):
            stats = self._get_stats(ids)
            if not stats:
                break
            best_pair = max(stats, key=stats.get)
            if stats[best_pair] < min_freq:
                break
            new_id = 256 + len(self.special_tokens) + i
            self.merges.append((chr(best_pair[0]), chr(best_pair[1])))
            ids = [self._merge(seq, best_pair, new_id) for seq in ids]

        self._build_vocab()

    def _build_vocab(self) -> None:
        self.vocab = {}
        for i in range(256):
            self.vocab[chr(i)] = i
        for i, (t, id_) in enumerate(self.special_tokens.items()):
            self.vocab[t] = id_

        base = 256 + len(self.special_tokens)
        for i, (a, b) in enumerate(self.merges):
            self.vocab[a + b] = base + i

        self.inverse_vocab = {v: k for k, v in self.vocab.items()}

    def encode(self, text: str, add_special_tokens: bool = True) -> list[int]:
        tokens = list(text.encode("utf-8"))
        for a, b in self.merges:
            i = 0
            while i < len(tokens) - 1:
                if chr(tokens[i]) == a and chr(tokens[i + 1]) == b:
                    merged_id = self.vocab.get(a + b, self.unk_token_id)
                    tokens[i] = merged_id
                    tokens.pop(i + 1)
                else:
                    i += 1

        if add_special_tokens:
            tokens = [self.bos_token_id] + tokens + [self.eos_token_id]
        return tokens

    def decode(self, ids: list[int]) -> str:
        tokens = []
        for id_ in ids:
            if id_ in self.inverse_vocab:
                tokens.append(self.inverse_vocab[id_])
            else:
                tokens.append("<unk>")
        return "".join(tokens).replace("<bos>", "").replace("<eos>", "").replace("<pad>", "")

    def save(self, path: str) -> None:
        os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
        data = {
            "vocab_size": self.vocab_size,
            "merges": self.merges,
            "vocab": self.vocab,
            "special_tokens": self.special_tokens,
        }
        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)

    @classmethod
    def load(cls, path: str) -> "SimpleTokenizer":
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        tok = cls(vocab_size=data["vocab_size"])
        tok.merges = [tuple(m) for m in data["merges"]]
        tok.vocab = data["vocab"]
        tok.special_tokens = data["special_tokens"]
        tok.inverse_vocab = {v: k for k, v in tok.vocab.items()}
        return tok
