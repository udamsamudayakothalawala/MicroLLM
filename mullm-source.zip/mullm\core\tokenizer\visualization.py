import math
from typing import Dict, List, Optional, Sequence, Tuple

from .base import BaseTokenizer


ANSI_RESET = "\033[0m"
ANSI_COLORS = [
    "\033[38;5;1m",
    "\033[38;5;2m",
    "\033[38;5;3m",
    "\033[38;5;4m",
    "\033[38;5;5m",
    "\033[38;5;6m",
    "\033[38;5;7m",
    "\033[38;5;9m",
    "\033[38;5;10m",
    "\033[38;5;11m",
    "\033[38;5;12m",
    "\033[38;5;13m",
    "\033[38;5;14m",
    "\033[38;5;69m",
    "\033[38;5;105m",
    "\033[38;5;141m",
    "\033[38;5;177m",
    "\033[38;5;213m",
    "\033[38;5;35m",
    "\033[38;5;41m",
    "\033[38;5;47m",
    "\033[38;5;53m",
    "\033[38;5;59m",
    "\033[38;5;65m",
    "\033[38;5;71m",
    "\033[38;5;77m",
    "\033[38;5;83m",
    "\033[38;5;89m",
    "\033[38;5;95m",
    "\033[38;5;101m",
    "\033[38;5;107m",
    "\033[38;5;113m",
    "\033[38;5;119m",
    "\033[38;5;125m",
    "\033[38;5;131m",
    "\033[38;5;137m",
    "\033[38;5;143m",
    "\033[38;5;149m",
    "\033[38;5;155m",
    "\033[38;5;161m",
    "\033[38;5;167m",
    "\033[38;5;173m",
    "\033[38;5;179m",
    "\033[38;5;185m",
    "\033[38;5;191m",
    "\033[38;5;197m",
    "\033[38;5;203m",
    "\033[38;5;209m",
    "\033[38;5;215m",
    "\033[38;5;221m",
    "\033[38;5;227m",
]

ANSI_BG_COLORS = [
    "\033[48;5;52m",
    "\033[48;5;53m",
    "\033[48;5;54m",
    "\033[48;5;55m",
    "\033[48;5;56m",
    "\033[48;5;57m",
    "\033[48;5;58m",
    "\033[48;5;59m",
    "\033[48;5;60m",
    "\033[48;5;61m",
    "\033[48;5;62m",
    "\033[48;5;63m",
    "\033[48;5;64m",
    "\033[48;5;65m",
    "\033[48;5;66m",
    "\033[48;5;67m",
    "\033[48;5;68m",
    "\033[48;5;69m",
    "\033[48;5;70m",
    "\033[48;5;71m",
    "\033[48;5;72m",
    "\033[48;5;73m",
    "\033[48;5;74m",
    "\033[48;5;75m",
    "\033[48;5;76m",
    "\033[48;5;77m",
    "\033[48;5;78m",
    "\033[48;5;79m",
    "\033[48;5;80m",
    "\033[48;5;81m",
    "\033[48;5;82m",
    "\033[48;5;83m",
    "\033[48;5;84m",
    "\033[48;5;85m",
    "\033[48;5;86m",
    "\033[48;5;87m",
    "\033[48;5;88m",
    "\033[48;5;89m",
    "\033[48;5;90m",
    "\033[48;5;91m",
    "\033[48;5;92m",
    "\033[48;5;93m",
    "\033[48;5;94m",
    "\033[48;5;95m",
    "\033[48;5;96m",
    "\033[48;5;97m",
    "\033[48;5;98m",
    "\033[48;5;99m",
    "\033[48;5;100m",
    "\033[48;5;101m",
]

HTML_COLORS = [
    "#e6194b",
    "#3cb44b",
    "#ffe119",
    "#4363d8",
    "#f58231",
    "#911eb4",
    "#42d4f4",
    "#f032e6",
    "#bfef45",
    "#fabed4",
    "#469990",
    "#dcbeff",
    "#9a6324",
    "#800000",
    "#aaffc3",
    "#808000",
    "#ffd8b1",
    "#000075",
    "#a9a9a9",
    "#e6beff",
    "#ff6f61",
    "#6b5b95",
    "#88b04b",
    "#f7cac9",
    "#92a8d1",
    "#f5d6c6",
    "#c9b1ff",
    "#ffb347",
    "#ff6961",
    "#77dd77",
    "#aec6cf",
    "#e2a1c4",
    "#b19cd9",
    "#ffccb3",
    "#b3d9ff",
    "#c4e0d9",
    "#ffd1dc",
    "#d4a5a5",
    "#9c89b8",
    "#f0e6ef",
    "#b8c6b8",
    "#f4d1d1",
    "#d1e0d1",
    "#b3b3cc",
    "#e6ccb3",
    "#d9b3b3",
    "#b3ccb3",
    "#d9d9f0",
    "#f0d9d9",
    "#d9f0d9",
]


class TokenVisualizer:
    def __init__(self, tokenizer: BaseTokenizer) -> None:
        self._tokenizer = tokenizer

    def tokenize_with_metadata(
        self, text: str
    ) -> List[Dict]:
        ids = self._tokenizer.encode(text, add_special_tokens=False)
        metadata: List[Dict] = []
        for tid in ids:
            token_str = self._tokenizer.convert_ids_to_tokens(tid)
            metadata.append(
                {
                    "id": tid,
                    "token": str(token_str),
                    "length": len(str(token_str)),
                }
            )
        return metadata

    def render_ansi(
        self, text: str, color_per_token: bool = True
    ) -> str:
        metadata = self.tokenize_with_metadata(text)
        parts: List[str] = []
        for i, meta in enumerate(metadata):
            token_str = meta["token"]
            display = token_str.replace("\n", "\\n").replace("\t", "\\t")
            if color_per_token:
                color = ANSI_COLORS[i % len(ANSI_COLORS)]
                parts.append(f"{color}{display}{ANSI_RESET}")
            elif i < len(ANSI_COLORS):
                parts.append(f"{ANSI_COLORS[i % len(ANSI_COLORS)]}{display}{ANSI_RESET}")
            else:
                parts.append(display)
        return "".join(parts)

    def render_ansi_detailed(
        self, text: str
    ) -> str:
        metadata = self.tokenize_with_metadata(text)
        lines: List[str] = []
        for i, meta in enumerate(metadata):
            token_str = meta["token"]
            display = token_str.replace("\n", "\\n").replace("\t", "\\t")
            color = ANSI_BG_COLORS[i % len(ANSI_BG_COLORS)]
            text_color = ANSI_COLORS[i % len(ANSI_COLORS)]
            lines.append(
                f"{color}{text_color}[{meta['id']:5d}] {display}{ANSI_RESET}"
            )
        return "\n".join(lines)

    def render_html(
        self,
        text: str,
        dark_mode: bool = False,
    ) -> str:
        metadata = self.tokenize_with_metadata(text)
        token_spans: List[str] = []
        for i, meta in enumerate(metadata):
            token_str = meta["token"]
            escaped = (
                token_str.replace("&", "&amp;")
                .replace("<", "&lt;")
                .replace(">", "&gt;")
                .replace('"', "&quot;")
                .replace("\n", "&#10;")
                .replace("\t", "&#9;")
            )
            color = HTML_COLORS[i % len(HTML_COLORS)]
            token_spans.append(
                f'<span style="color:{color}" title="{meta["id"]}">{escaped}</span>'
            )

        bg_color = "#1e1e1e" if dark_mode else "#ffffff"
        text_color = "#d4d4d4" if dark_mode else "#000000"
        html = (
            f'<div style="background:{bg_color};color:{text_color};'
            f'font-family:monospace;padding:10px;border-radius:5px;'
            f'white-space:pre-wrap;word-wrap:break-word;line-height:1.5;">'
            f'{"".join(token_spans)}</div>'
        )
        return html

    def render_token_table_html(self, text: str) -> str:
        metadata = self.tokenize_with_metadata(text)
        rows: List[str] = []
        for i, meta in enumerate(metadata):
            token_str = meta["token"]
            escaped = token_str.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
            color = HTML_COLORS[i % len(HTML_COLORS)]
            rows.append(
                f'<tr><td style="color:{color}">{meta["id"]}</td>'
                f'<td style="color:{color}">{i}</td>'
                f'<td style="color:{color}">{escaped}</td>'
                f'<td>{meta["length"]}</td></tr>'
            )
        table = (
            "<table border='1' style='border-collapse:collapse;font-family:monospace;'>"
            "<tr><th>ID</th><th>Position</th><th>Token</th><th>Length</th></tr>"
            + "".join(rows)
            + "</table>"
        )
        return table

    def render_heatmap(
        self,
        texts: Sequence[str],
        max_tokens: int = 100,
    ) -> List[str]:
        all_ids: List[List[int]] = []
        max_len = 0
        for text in texts:
            ids = self._tokenizer.encode(text, add_special_tokens=False)
            if len(ids) > max_tokens:
                ids = ids[:max_tokens]
            all_ids.append(ids)
            max_len = max(max_len, len(ids))

        heatmap: List[str] = []
        for row_idx, ids in enumerate(all_ids):
            row_parts: List[str] = []
            for col_idx in range(max_len):
                if col_idx < len(ids):
                    intensity = min(
                        255, int((ids[col_idx] / self._tokenizer.vocab_size) * 255)
                    )
                    r = intensity
                    g = 0
                    b = 255 - intensity
                    row_parts.append(
                        f"\033[48;2;{r};{g};{b}m \033[0m"
                    )
                else:
                    row_parts.append(" ")
            heatmap.append(f"Seq {row_idx:4d}: {''.join(row_parts)}")

        return heatmap

    def attention_heatmap(
        self,
        attention_matrix: List[List[float]],
        tokens: Optional[List[str]] = None,
        max_tokens: int = 50,
    ) -> str:
        n_rows = min(len(attention_matrix), max_tokens)
        n_cols = min(len(attention_matrix[0]) if attention_matrix else 0, max_tokens)

        if tokens and len(tokens) > max_tokens:
            tokens = tokens[:max_tokens]

        lines: List[str] = []
        header = "     "
        for j in range(n_cols):
            if tokens and j < len(tokens):
                label = tokens[j][:3]
            else:
                label = str(j)[:3]
            header += f"{label:>4}"
        lines.append(header)

        for i in range(n_rows):
            if tokens and i < len(tokens):
                label = tokens[i][:4]
            else:
                label = str(i)[:4]
            row = f"{label:>4} "
            for j in range(n_cols):
                val = attention_matrix[i][j]
                if val > 0.75:
                    row += "██ "
                elif val > 0.5:
                    row += "▓▓ "
                elif val > 0.25:
                    row += "▒▒ "
                elif val > 0.05:
                    row += "░░ "
                else:
                    row += "   "
            lines.append(row)

        return "\n".join(lines)

    def attention_heatmap_html(
        self,
        attention_matrix: List[List[float]],
        tokens: Optional[List[str]] = None,
    ) -> str:
        n = len(attention_matrix)
        if tokens and len(tokens) < n:
            n = len(tokens)

        cells: List[str] = []
        for i in range(n):
            for j in range(n):
                val = attention_matrix[i][j]
                r = int(255 * val)
                g = int(255 * (1 - val))
                b = 0
                tooltip = f"attn[{i},{j}] = {val:.4f}"
                if tokens:
                    tooltip = f"{tokens[i]} -> {tokens[j]}: {val:.4f}"
                cells.append(
                    f'<td style="background:rgb({r},{g},{b});width:20px;height:20px;" '
                    f'title="{tooltip}"></td>'
                )

        header = "<tr><td></td>"
        for j in range(n):
            label = tokens[j] if tokens and j < len(tokens) else str(j)
            header += f"<td style='font-size:10px;writing-mode:vertical-rl;'>{label}</td>"
        header += "</tr>"

        rows = [header]
        for i in range(n):
            row = "<tr>"
            label = tokens[i] if tokens and i < len(tokens) else str(i)
            row += f"<td style='font-size:10px;'>{label}</td>"
            row += "".join(cells[i * n : (i + 1) * n])
            row += "</tr>"
            rows.append(row)

        return (
            "<table style='border-collapse:collapse;font-family:monospace;'>"
            + "".join(rows)
            + "</table>"
        )

    def print_ansi(self, text: str) -> None:
        print(self.render_ansi(text))

    def print_ansi_detailed(self, text: str) -> None:
        print(self.render_ansi_detailed(text))
