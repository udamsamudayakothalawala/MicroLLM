# muLLM

**Train a small Language Model from scratch with as little as 1M tokens.**

> Built by **[Udam](https://github.com/anomalyco)** — everything is implemented from scratch in pure PyTorch. No HuggingFace `transformers`, no external training frameworks.

> **⚠️ WARNING: This codebase is UNTESTED.** Code was generated as a focused buildout and has **not** been run, tested, or validated. Expect bugs and runtime errors. Validate thoroughly before any use.

---

## Overview

muLLM is a minimal, self-contained toolkit to train a small transformer LLM from raw text — no HuggingFace, no pretrained checkpoints required. It's designed to work with small datasets (~1M tokens or less) and single machines.

Everything is custom:
- **TinyTransformer** — Llama-style decoder-only transformer (RMSNorm, RoPE, SwiGLU) built from scratch
- **SimpleTokenizer** — byte-level BPE tokenizer trained on your own data
- **SimpleTrainer** — lightweight training loop with warmup/cosine LR schedule, mixed precision, gradient clipping
- **GGUFExporter** — export to GGUF format for llama.cpp
- **SimpleEvaluator** — loss, perplexity, accuracy

---

## Architecture

```
mullm/
└── core/
    ├── model/          # TinyTransformer, configs (tiny/small/base/medium)
    ├── tokenizer/      # SimpleTokenizer (BPE trained on your data)
    ├── trainer/        # SimpleTrainer, SimpleConfig, warmup/cosine scheduler
    ├── data/           # TextDataset, load_text_file (txt/json/jsonl/csv)
    ├── export/         # GGUFExporter (f32/f16/q4_0)
    ├── evaluation/     # simple_eval (loss, perplexity, accuracy)
    ├── config/         # Settings
    ├── checkpoint/     # Checkpoint management
    ├── fine_tune/      # LoRA/QLoRA adapters
    ├── multimodal/     # Vision-language
    └── reasoning/      # Reasoning & tool calling
```

---

## Install

```bash
pip install .          # or: pip install -e .
```

Dependencies: `torch`, `numpy`, `tqdm`, `pyyaml` only.

---

## Usage

### Train from scratch (no pretrained model)

```bash
mullm train \
  --dataset data.txt \
  --size small \
  --epochs 3 \
  --batch-size 8 \
  --output-dir ./outputs
```

Supports `.txt`, `.json`, `.jsonl`, `.csv` datasets.

### Export to GGUF

```bash
mullm export \
  --checkpoint outputs/checkpoint-final/model.pt \
  --size small \
  --gguf-type q4_0 \
  --output-dir model.gguf
```

### Chat with your model

```bash
mullm chat \
  --checkpoint outputs/checkpoint-final/model.pt \
  --tokenizer outputs/tokenizer.json \
  --size small
```

---

## Model Sizes

| Preset | Params (approx) | Layers | Heads | d_model |
|--------|-----------------|--------|-------|---------|
| tiny   | ~4M             | 4      | 4     | 256     |
| small  | ~30M            | 6      | 8     | 512     |
| base   | ~180M           | 12     | 12    | 768     |
| medium | ~700M           | 24     | 16    | 1024    |

For 1M tokens, start with **tiny** or **small** — they can train on a single consumer GPU (or even CPU) in minutes to hours.

---

## License

Apache 2.0
