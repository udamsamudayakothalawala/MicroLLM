from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional, Tuple, Union

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader, Sampler


@dataclass
class DomainAdaptationConfig:
    domain_weights: Optional[Dict[str, float]] = None
    ewc_lambda: float = 0.0
    mas_lambda: float = 0.0
    ewc_strategy: str = "online"
    num_ewc_samples: int = 200
    vocab_extension_size: int = 1000
    mixed_training: bool = True
    domain_sampling_temperature: float = 1.0
    temperature: float = 1.0
    num_epochs: int = 3
    learning_rate: float = 5e-5
    max_length: int = 2048
    batch_size: int = 8
    gradient_accumulation_steps: int = 1
    max_grad_norm: float = 1.0
    warmup_ratio: float = 0.03
    weight_decay: float = 0.01


class DomainDataset(Dataset):
    def __init__(
        self,
        data: List[Dict[str, Any]],
        tokenizer: Any,
        domain_key: str = "domain",
        text_key: str = "text",
        max_length: int = 2048,
    ):
        self.tokenizer = tokenizer
        self.domain_key = domain_key
        self.text_key = text_key
        self.max_length = max_length

        self.examples: List[Dict[str, Any]] = []
        self.domain_counts: Dict[str, int] = {}
        self.domain_indices: Dict[str, List[int]] = {}

        for idx, item in enumerate(data):
            text = item.get(text_key, "")
            domain = item.get(domain_key, "general")

            tokenized = tokenizer(
                text,
                max_length=max_length,
                truncation=True,
                padding=False,
                return_tensors=None,
            )
            input_ids = tokenized["input_ids"]
            if isinstance(input_ids, list):
                input_ids = input_ids

            attention_mask = [1] * len(input_ids)

            self.examples.append({
                "input_ids": torch.tensor(input_ids, dtype=torch.long),
                "labels": torch.tensor(input_ids, dtype=torch.long),
                "attention_mask": torch.tensor(attention_mask, dtype=torch.long),
                "domain": domain,
            })

            self.domain_counts[domain] = self.domain_counts.get(domain, 0) + 1
            if domain not in self.domain_indices:
                self.domain_indices[domain] = []
            self.domain_indices[domain].append(idx)

    def __len__(self) -> int:
        return len(self.examples)

    def __getitem__(self, idx: int) -> Dict[str, Any]:
        return self.examples[idx]


class EWCLoss:
    def __init__(
        self,
        model: nn.Module,
        ewc_lambda: float = 1.0,
        strategy: str = "online",
    ):
        self.model = model
        self.ewc_lambda = ewc_lambda
        self.strategy = strategy
        self.fisher_dict: Dict[str, torch.Tensor] = {}
        self.opt_params_dict: Dict[str, torch.Tensor] = {}
        self._registered = False

    def register_model_params(self) -> None:
        self.opt_params_dict = {}
        for name, param in self.model.named_parameters():
            if param.requires_grad:
                self.opt_params_dict[name] = param.data.clone().detach()
        self._registered = True

    def estimate_fisher(
        self,
        dataloader: DataLoader,
        device: torch.device,
        num_samples: int = 200,
    ) -> None:
        if not self._registered:
            self.register_model_params()

        self.model.eval()
        fisher_dict: Dict[str, torch.Tensor] = {}
        for name, param in self.model.named_parameters():
            if param.requires_grad:
                fisher_dict[name] = torch.zeros_like(param.data)

        count = 0
        for batch in dataloader:
            if count >= num_samples:
                break
            batch = {k: v.to(device) if isinstance(v, torch.Tensor) else v for k, v in batch.items()}

            self.model.zero_grad()
            outputs = self.model(**batch)
            loss = outputs["loss"] if isinstance(outputs, dict) else outputs.loss

            loss.backward()

            for name, param in self.model.named_parameters():
                if param.requires_grad and param.grad is not None:
                    fisher_dict[name] += (param.grad.data ** 2) / num_samples
                elif param.requires_grad:
                    fisher_dict[name] += torch.zeros_like(param.data)

            count += 1

        if self.strategy == "online":
            for name in fisher_dict:
                if name in self.fisher_dict:
                    self.fisher_dict[name] = self.fisher_dict[name] * 0.9 + fisher_dict[name] * 0.1
                else:
                    self.fisher_dict[name] = fisher_dict[name]
        else:
            self.fisher_dict = fisher_dict

        self.model.train()

    def compute_loss(self) -> torch.Tensor:
        if not self.fisher_dict or not self.opt_params_dict:
            return torch.tensor(0.0, device=self._get_device())

        ewc_loss = 0.0
        for name, param in self.model.named_parameters():
            if param.requires_grad and name in self.fisher_dict and name in self.opt_params_dict:
                fisher = self.fisher_dict[name]
                opt_param = self.opt_params_dict[name].to(param.device)
                ewc_loss += (fisher * (param - opt_param) ** 2).sum()

        return self.ewc_lambda * ewc_loss

    def _get_device(self) -> torch.device:
        for param in self.model.parameters():
            return param.device
        return torch.device("cpu")


class MASLoss:
    def __init__(
        self,
        model: nn.Module,
        mas_lambda: float = 1.0,
    ):
        self.model = model
        self.mas_lambda = mas_lambda
        self.omega_dict: Dict[str, torch.Tensor] = {}
        self.opt_params_dict: Dict[str, torch.Tensor] = {}
        self._registered = False

    def register_model_params(self) -> None:
        self.opt_params_dict = {}
        for name, param in self.model.named_parameters():
            if param.requires_grad:
                self.opt_params_dict[name] = param.data.clone().detach()
        self._registered = True

    def estimate_importance(
        self,
        dataloader: DataLoader,
        device: torch.device,
        num_samples: int = 200,
    ) -> None:
        if not self._registered:
            self.register_model_params()

        self.model.eval()
        omega_dict: Dict[str, torch.Tensor] = {}
        for name, param in self.model.named_parameters():
            if param.requires_grad:
                omega_dict[name] = torch.zeros_like(param.data)

        count = 0
        for batch in dataloader:
            if count >= num_samples:
                break
            batch = {k: v.to(device) if isinstance(v, torch.Tensor) else v for k, v in batch.items()}

            self.model.zero_grad()
            batch.pop("labels", None)
            batch.pop("domain", None)

            outputs = self.model(**batch, labels=batch.get("input_ids"))
            loss = outputs["loss"] if isinstance(outputs, dict) else outputs.loss

            grad_outputs: Optional[torch.Tensor] = None
            gradients = torch.autograd.grad(
                loss,
                [p for p in self.model.parameters() if p.requires_grad],
                grad_outputs=grad_outputs,
                create_graph=False,
                retain_graph=False,
                allow_unused=True,
            )

            grad_idx = 0
            for name, param in self.model.named_parameters():
                if param.requires_grad and grad_idx < len(gradients) and gradients[grad_idx] is not None:
                    omega_dict[name] += gradients[grad_idx].abs() / num_samples
                grad_idx += 1

            count += 1

        self.omega_dict = omega_dict
        self.model.train()

    def compute_loss(self) -> torch.Tensor:
        if not self.omega_dict or not self.opt_params_dict:
            return torch.tensor(0.0, device=self._get_device())

        mas_loss = 0.0
        for name, param in self.model.named_parameters():
            if param.requires_grad and name in self.omega_dict and name in self.opt_params_dict:
                omega = self.omega_dict[name]
                opt_param = self.opt_params_dict[name].to(param.device)
                mas_loss += (omega * (param - opt_param) ** 2).sum()

        return self.mas_lambda * mas_loss

    def _get_device(self) -> torch.device:
        for param in self.model.parameters():
            return param.device
        return torch.device("cpu")


class DomainVocabularyExtension:
    def __init__(
        self,
        tokenizer: Any,
        model: nn.Module,
        extension_size: int = 1000,
    ):
        self.tokenizer = tokenizer
        self.model = model
        self.extension_size = extension_size
        self.new_token_ids: List[int] = []
        self.new_tokens: List[str] = []
        self._extended = False

    def build_vocab_extension(
        self,
        domain_texts: List[str],
        min_frequency: int = 3,
    ) -> Dict[str, int]:
        from collections import Counter
        word_counts: Counter = Counter()
        for text in domain_texts:
            words = text.split()
            word_counts.update(words)

        existing_vocab = set()
        if hasattr(self.tokenizer, "get_vocab"):
            existing_vocab = set(self.tokenizer.get_vocab().keys())
        elif hasattr(self.tokenizer, "vocab"):
            existing_vocab = set(self.tokenizer.vocab.keys())

        new_words = [w for w, c in word_counts.most_common(self.extension_size * 2)
                     if w not in existing_vocab and c >= min_frequency]
        new_words = new_words[:self.extension_size]

        self.new_tokens = new_words
        if hasattr(self.tokenizer, "add_tokens"):
            num_added = self.tokenizer.add_tokens(new_words)
            self.new_token_ids = list(range(
                self.tokenizer.vocab_size if hasattr(self.tokenizer, "vocab_size") else 0,
                (self.tokenizer.vocab_size if hasattr(self.tokenizer, "vocab_size") else 0) + num_added,
            ))
        else:
            self.new_token_ids = []

        if self.new_token_ids and hasattr(self.model, "get_input_embeddings"):
            embed = self.model.get_input_embeddings()
            old_vocab_size, embed_dim = embed.weight.shape
            new_embedding = nn.Embedding(
                old_vocab_size + len(self.new_token_ids),
                embed_dim,
                padding_idx=getattr(embed, "padding_idx", None),
            )
            nn.init.normal_(new_embedding.weight, mean=0.0, std=0.02)
            new_embedding.weight[:old_vocab_size].data.copy_(embed.weight.data)
            if hasattr(self.model, "set_input_embeddings"):
                self.model.set_input_embeddings(new_embedding)

            if hasattr(self.model, "get_output_embeddings") and self.model.get_output_embeddings() is not None:
                output_embed = self.model.get_output_embeddings()
                old_out_vocab, out_dim = output_embed.weight.shape
                new_output = nn.Linear(out_dim, old_out_vocab + len(self.new_token_ids), bias=False)
                nn.init.normal_(new_output.weight, mean=0.0, std=0.02)
                new_output.weight[:old_out_vocab].data.copy_(output_embed.weight.data)
                if hasattr(self.model, "set_output_embeddings"):
                    self.model.set_output_embeddings(new_output)
                elif hasattr(self.model, "lm_head"):
                    self.model.lm_head = new_output

        self._extended = True
        return dict(zip(self.new_tokens, self.new_token_ids))

    def get_new_token_embeddings(self) -> Optional[torch.Tensor]:
        if not self._extended or not self.new_token_ids:
            return None
        embed = self.model.get_input_embeddings() if hasattr(self.model, "get_input_embeddings") else None
        if embed is None:
            return None
        return embed.weight[self.new_token_ids].data.clone()


def mixed_domain_collator(
    batch: List[Dict[str, Any]],
    pad_token_id: int = 0,
    ignore_index: int = -100,
    max_length: int = 2048,
) -> Dict[str, torch.Tensor]:
    input_ids = [item["input_ids"] for item in batch]
    labels = [item["labels"] for item in batch]
    attention_masks = [item["attention_mask"] for item in batch]
    domains = [item.get("domain", "general") for item in batch]

    max_len = max(ids.size(0) for ids in input_ids)
    max_len = min(max_len, max_length)

    padded_input_ids = []
    padded_labels = []
    padded_attention_masks = []

    for i in range(len(input_ids)):
        ids = input_ids[i]
        lbls = labels[i]
        mask = attention_masks[i]

        seq_len = ids.size(0)
        if seq_len > max_len:
            padded_input_ids.append(ids[:max_len])
            padded_labels.append(lbls[:max_len])
            padded_attention_masks.append(mask[:max_len])
        else:
            pad_len = max_len - seq_len
            padded_input_ids.append(
                F.pad(ids, (0, pad_len), value=pad_token_id)
            )
            padded_labels.append(
                F.pad(lbls, (0, pad_len), value=ignore_index)
            )
            padded_attention_masks.append(
                F.pad(mask, (0, pad_len), value=0)
            )

    return {
        "input_ids": torch.stack(padded_input_ids, dim=0),
        "labels": torch.stack(padded_labels, dim=0),
        "attention_mask": torch.stack(padded_attention_masks, dim=0),
        "domains": domains,
    }


class DomainAdapter(nn.Module):
    def __init__(
        self,
        hidden_size: int,
        num_domains: int,
        adapter_dim: int = 64,
        dropout: float = 0.1,
    ):
        super().__init__()
        self.hidden_size = hidden_size
        self.num_domains = num_domains
        self.adapter_dim = adapter_dim

        self.domain_embeddings = nn.Embedding(num_domains, adapter_dim)
        self.down_proj = nn.Linear(hidden_size + adapter_dim, adapter_dim, bias=False)
        self.up_proj = nn.Linear(adapter_dim, hidden_size, bias=False)
        self.activation = nn.GELU()
        self.dropout = nn.Dropout(dropout)

        nn.init.normal_(self.domain_embeddings.weight, mean=0.0, std=0.02)
        nn.init.kaiming_uniform_(self.down_proj.weight, a=5 ** 0.5)
        nn.init.zeros_(self.up_proj.weight)

    def forward(self, x: torch.Tensor, domain_ids: torch.Tensor) -> torch.Tensor:
        domain_emb = self.domain_embeddings(domain_ids)
        if x.dim() == 3:
            domain_emb = domain_emb.unsqueeze(1).expand(-1, x.size(1), -1)
            combined = torch.cat([x, domain_emb], dim=-1)
        else:
            combined = torch.cat([x, domain_emb], dim=-1)
        out = self.down_proj(combined)
        out = self.activation(out)
        out = self.dropout(out)
        out = self.up_proj(out)
        return x + out


class DomainAdaptationTrainer:
    def __init__(
        self,
        model: nn.Module,
        tokenizer: Any,
        config: DomainAdaptationConfig,
        device: Optional[torch.device] = None,
    ):
        self.model = model
        self.tokenizer = tokenizer
        self.config = config
        self.device = device or torch.device("cuda" if torch.cuda.is_available() else "cpu")

        self.model.to(self.device)

        self.ewc = EWCLoss(
            model=model,
            ewc_lambda=config.ewc_lambda,
            strategy=config.ewc_strategy,
        ) if config.ewc_lambda > 0 else None

        self.mas = MASLoss(
            model=model,
            mas_lambda=config.mas_lambda,
        ) if config.mas_lambda > 0 else None

        self.vocab_extension: Optional[DomainVocabularyExtension] = None

        no_decay = ["bias", "LayerNorm", "layer_norm", "layernorm", "ln", "norm", "embed"]
        decay_params = []
        no_decay_params = []
        for name, param in self.model.named_parameters():
            if not param.requires_grad:
                continue
            if any(nd in name.lower() for nd in no_decay):
                no_decay_params.append(param)
            else:
                decay_params.append(param)

        param_groups = [
            {"params": decay_params, "weight_decay": config.weight_decay},
            {"params": no_decay_params, "weight_decay": 0.0},
        ]
        self.optimizer = torch.optim.AdamW(param_groups, lr=config.learning_rate)

    def _create_scheduler(self, num_training_steps: int) -> torch.optim.lr_scheduler.LambdaLR:
        warmup_steps = int(num_training_steps * self.config.warmup_ratio)

        def lr_lambda(current_step: int) -> float:
            if current_step < warmup_steps:
                return float(current_step) / float(max(1, warmup_steps))
            progress = float(current_step - warmup_steps) / float(
                max(1, num_training_steps - warmup_steps)
            )
            return 0.5 * (1.0 + torch.cos(torch.tensor(progress * torch.pi)).item())

        return torch.optim.lr_scheduler.LambdaLR(self.optimizer, lr_lambda)

    def extend_vocabulary(self, domain_texts: List[str]) -> Dict[str, int]:
        self.vocab_extension = DomainVocabularyExtension(
            tokenizer=self.tokenizer,
            model=self.model,
            extension_size=self.config.vocab_extension_size,
        )
        return self.vocab_extension.build_vocab_extension(domain_texts)

    def train(
        self,
        dataset: DomainDataset,
        eval_dataset: Optional[DomainDataset] = None,
        output_dir: str = "./domain_adaptation_output",
    ) -> Dict[str, float]:
        dataloader = DataLoader(
            dataset,
            batch_size=self.config.batch_size,
            shuffle=True,
            collate_fn=lambda batch: mixed_domain_collator(
                batch,
                pad_token_id=self.tokenizer.pad_token_id if hasattr(self.tokenizer, "pad_token_id") and self.tokenizer.pad_token_id is not None else 0,
            ),
        )

        num_training_steps = len(dataloader) * self.config.num_epochs // self.config.gradient_accumulation_steps
        scheduler = self._create_scheduler(num_training_steps)

        if self.ewc and not self.ewc._registered:
            self.ewc.register_model_params()
            self.ewc.estimate_fisher(dataloader, self.device, self.config.num_ewc_samples)

        if self.mas and not self.mas._registered:
            self.mas.register_model_params()
            self.mas.estimate_importance(dataloader, self.device, self.config.num_ewc_samples)

        self.model.train()
        global_step = 0
        best_loss = float("inf")
        accum_loss = 0.0

        for epoch in range(self.config.num_epochs):
            epoch_loss = 0.0
            num_batches = 0

            for batch_idx, batch in enumerate(dataloader):
                input_ids = batch["input_ids"].to(self.device)
                labels = batch["labels"].to(self.device)
                attention_mask = batch["attention_mask"].to(self.device)

                outputs = self.model(
                    input_ids=input_ids,
                    labels=labels,
                    attention_mask=attention_mask,
                )
                lm_loss = outputs["loss"] if isinstance(outputs, dict) else outputs.loss

                loss = lm_loss

                if self.ewc is not None:
                    loss = loss + self.ewc.compute_loss()

                if self.mas is not None:
                    loss = loss + self.mas.compute_loss()

                loss = loss / self.config.gradient_accumulation_steps
                loss.backward()

                epoch_loss += lm_loss.item()
                num_batches += 1
                global_step += 1

                if global_step % self.config.gradient_accumulation_steps == 0:
                    if self.config.max_grad_norm > 0.0:
                        torch.nn.utils.clip_grad_norm_(self.model.parameters(), self.config.max_grad_norm)
                    self.optimizer.step()
                    scheduler.step()
                    self.optimizer.zero_grad()

            avg_epoch_loss = epoch_loss / max(1, num_batches)

            if eval_dataset is not None:
                eval_loss = self.evaluate(eval_dataset)
                if eval_loss < best_loss:
                    best_loss = eval_loss
                    self.save_pretrained(output_dir)

        return {"loss": avg_epoch_loss, "best_eval_loss": best_loss}

    def evaluate(self, dataset: DomainDataset) -> float:
        dataloader = DataLoader(
            dataset,
            batch_size=self.config.batch_size,
            shuffle=False,
            collate_fn=lambda batch: mixed_domain_collator(
                batch,
                pad_token_id=self.tokenizer.pad_token_id if hasattr(self.tokenizer, "pad_token_id") and self.tokenizer.pad_token_id is not None else 0,
            ),
        )

        self.model.eval()
        total_loss = 0.0
        num_batches = 0

        with torch.no_grad():
            for batch in dataloader:
                input_ids = batch["input_ids"].to(self.device)
                labels = batch["labels"].to(self.device)
                attention_mask = batch["attention_mask"].to(self.device)

                outputs = self.model(
                    input_ids=input_ids,
                    labels=labels,
                    attention_mask=attention_mask,
                )
                loss = outputs["loss"] if isinstance(outputs, dict) else outputs.loss
                total_loss += loss.item()
                num_batches += 1

        self.model.train()
        return total_loss / max(1, num_batches)

    def continual_pretrain(
        self,
        dataset: DomainDataset,
        output_dir: str = "./continual_pretrain_output",
    ) -> Dict[str, float]:
        return self.train(dataset, None, output_dir)

    def save_pretrained(self, output_dir: str) -> None:
        import os
        os.makedirs(output_dir, exist_ok=True)
        torch.save(self.model.state_dict(), os.path.join(output_dir, "pytorch_model.bin"))

    def from_pretrained(self, model_path: str) -> None:
        state_dict = torch.load(model_path, map_location=self.device)
        self.model.load_state_dict(state_dict)
