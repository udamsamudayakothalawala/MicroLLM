"""muLLM GUI - Default dark theme."""

DARK_STYLE = """
QMainWindow, QWidget {
    background-color: #0f1117;
    color: #d4d4d8;
    font-size: 13px;
}

QTabWidget::pane {
    border: 1px solid #2d2d4e;
    background: #11131b;
    border-radius: 4px;
}

QTabBar::tab {
    background: #161926;
    color: #9a9aa6;
    padding: 10px 18px;
    border: 1px solid #2d2d4e;
    border-bottom: none;
    border-top-left-radius: 4px;
    border-top-right-radius: 4px;
    margin-right: 2px;
}

QTabBar::tab:selected {
    background: #252545;
    color: #ffffff;
}

QPushButton {
    background: #1f2333;
    border: 1px solid #3a3f5c;
    border-radius: 4px;
    padding: 7px 16px;
    color: #d4d4d8;
}

QPushButton:hover {
    background: #2a3050;
}

QPushButton:disabled {
    color: #555;
    background: #181b28;
    border-color: #2a2d3d;
}

QPushButton[class="btn-success"] {
    background: #16a34a;
    border-color: #16a34a;
    color: white;
}

QPushButton[class="btn-danger"] {
    background: #dc2626;
    border-color: #dc2626;
    color: white;
}

QPushButton[class="btn-secondary"] {
    background: #272b3d;
}

QLineEdit, QSpinBox, QDoubleSpinBox, QComboBox, QTextEdit {
    background: #161926;
    border: 1px solid #3a3f5c;
    border-radius: 4px;
    padding: 5px;
    color: #d4d4d8;
}

QLineEdit:focus, QComboBox:focus, QTextEdit:focus {
    border-color: #6366f1;
}

QGroupBox {
    border: 1px solid #2d2d4e;
    border-radius: 4px;
    margin-top: 12px;
    padding-top: 6px;
    color: #a1a1aa;
}

QGroupBox::title {
    subcontrol-origin: margin;
    left: 10px;
    padding: 0 4px;
}

QLabel[class="heading"] {
    font-size: 16px;
    font-weight: 700;
    color: #ffffff;
    padding: 6px 0;
}

QLabel[class="subheading"] {
    color: #9a9aa6;
    padding-bottom: 8px;
}

QLabel[class="metric-value"] {
    font-size: 15px;
    font-weight: 600;
    color: #8b5cf6;
}

QProgressBar {
    border: 1px solid #3a3f5c;
    border-radius: 4px;
    background: #161926;
    text-align: center;
    color: #d4d4d8;
    height: 18px;
}

QProgressBar::chunk {
    background: #6366f1;
    border-radius: 3px;
}

QTableWidget, QListWidget {
    background: #161926;
    border: 1px solid #2d2d4e;
    border-radius: 4px;
    color: #d4d4d8;
}

QHeaderView::section {
    background: #1f2333;
    color: #a1a1aa;
    border: 1px solid #2d2d4e;
    padding: 4px;
}

QStatusBar {
    background: #161926;
    color: #9a9aa6;
}

QSplitter::handle {
    background: #2d2d4e;
}

QCheckBox {
    color: #d4d4d8;
    spacing: 6px;
}
"""