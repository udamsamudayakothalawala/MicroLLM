#!/usr/bin/env bash
# muLLM API Server Launcher
# Usage: ./serve.sh [options]

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"

HOST="${MULLM_SERVE_HOST:-0.0.0.0}"
PORT="${MULLM_SERVE_PORT:-8000}"
WORKERS="${MULLM_SERVE_WORKERS:-1}"
LOG_LEVEL="${MULLM_LOG_LEVEL:-INFO}"
LOG_FORMAT="${MULLM_LOG_FORMAT:-plain}"
LOG_FILE="${MULLM_LOG_FILE:-}"
MODEL_PATH="${MULLM_MODEL_PATH:-}"
MODEL_PRECISION="${MULLM_MODEL_PRECISION:-fp16}"
DEVICE_MAP="${MULLM_DEVICE_MAP:-auto}"
MAX_SEQ_LEN="${MULLM_MAX_SEQ_LEN:-4096}"
MAX_BATCH_SIZE="${MULLM_MAX_BATCH_SIZE:-64}"
CORS_ORIGINS="${MULLM_CORS_ORIGINS:-*}"
RATE_LIMIT_RPM="${MULLM_RATE_LIMIT_RPM:-60}"
SSL_CERTFILE="${MULLM_SSL_CERTFILE:-}"
SSL_KEYFILE="${MULLM_SSL_KEYFILE:-}"
RELOAD="${MULLM_RELOAD:-false}"

while [[ $# -gt 0 ]]; do
    case $1 in
        --host) HOST="$2"; shift 2 ;;
        -p|--port) PORT="$2"; shift 2 ;;
        -w|--workers) WORKERS="$2"; shift 2 ;;
        --log-level) LOG_LEVEL="$2"; shift 2 ;;
        --log-format) LOG_FORMAT="$2"; shift 2 ;;
        --log-file) LOG_FILE="$2"; shift 2 ;;
        --model-path) MODEL_PATH="$2"; shift 2 ;;
        --model-precision) MODEL_PRECISION="$2"; shift 2 ;;
        --device-map) DEVICE_MAP="$2"; shift 2 ;;
        --max-seq-len) MAX_SEQ_LEN="$2"; shift 2 ;;
        --max-batch-size) MAX_BATCH_SIZE="$2"; shift 2 ;;
        --cors-origins) CORS_ORIGINS="$2"; shift 2 ;;
        --rate-limit-rpm) RATE_LIMIT_RPM="$2"; shift 2 ;;
        --ssl-certfile) SSL_CERTFILE="$2"; shift 2 ;;
        --ssl-keyfile) SSL_KEYFILE="$2"; shift 2 ;;
        --reload) RELOAD="true"; shift ;;
        -h|--help)
            echo "Usage: $0 [options]"
            echo ""
            echo "Server:"
            echo "  --host <addr>            Bind address (default: 0.0.0.0)"
            echo "  -p, --port <port>        Listen port (default: 8000)"
            echo "  -w, --workers <n>        Number of workers (default: 1)"
            echo "  --reload                 Enable hot reload"
            echo ""
            echo "Logging:"
            echo "  --log-level <level>      DEBUG/INFO/WARNING/ERROR/CRITICAL"
            echo "  --log-format <fmt>       json/plain"
            echo "  --log-file <path>        Log to file"
            echo ""
            echo "Model:"
            echo "  --model-path <path>      Model to load"
            echo "  --model-precision <p>    fp32/fp16/bf16/int8/int4"
            echo "  --device-map <map>       auto/cpu/gpu/balanced"
            echo "  --max-seq-len <n>        Max sequence length (default: 4096)"
            echo "  --max-batch-size <n>     Max batch size (default: 64)"
            echo ""
            echo "API:"
            echo "  --cors-origins <origins> Comma-separated CORS origins"
            echo "  --rate-limit-rpm <n>     Rate limit requests/min (default: 60)"
            echo "  --ssl-certfile <path>    SSL certificate file"
            echo "  --ssl-keyfile <path>     SSL key file"
            exit 0
            ;;
        *) echo "Unknown option: $1"; exit 1 ;;
    esac
done

echo "============================================"
echo "  muLLM API Server"
echo "============================================"
echo "Host:           $HOST"
echo "Port:           $PORT"
echo "Workers:        $WORKERS"
echo "Log level:      $LOG_LEVEL"
echo "Model path:     ${MODEL_PATH:-<not set>}"
echo "Precision:      $MODEL_PRECISION"
echo "Device map:     $DEVICE_MAP"
echo "Max seq len:    $MAX_SEQ_LEN"
echo "Max batch:      $MAX_BATCH_SIZE"
echo "Reload:         $RELOAD"
echo "============================================"

CMD=(python -m mullm.core.api.server)
CMD+=(--host "$HOST")
CMD+=(--port "$PORT")
CMD+=(--workers "$WORKERS")
CMD+=(--log-level "$LOG_LEVEL")
CMD+=(--log-format "$LOG_FORMAT")
CMD+=(--model-precision "$MODEL_PRECISION")
CMD+=(--device-map "$DEVICE_MAP")
CMD+=(--max-seq-len "$MAX_SEQ_LEN")
CMD+=(--max-batch-size "$MAX_BATCH_SIZE")
CMD+=(--cors-origins "$CORS_ORIGINS")
CMD+=(--rate-limit-rpm "$RATE_LIMIT_RPM")

[[ -n "$LOG_FILE" ]] && CMD+=(--log-file "$LOG_FILE")
[[ -n "$MODEL_PATH" ]] && CMD+=(--model-path "$MODEL_PATH")
[[ -n "$SSL_CERTFILE" ]] && CMD+=(--ssl-certfile "$SSL_CERTFILE")
[[ -n "$SSL_KEYFILE" ]] && CMD+=(--ssl-keyfile "$SSL_KEYFILE")
[[ "$RELOAD" == "true" ]] && CMD+=(--reload)

exec "${CMD[@]}"
