"""Dataset loaders for Wikipedia, Books, Code, Scientific papers, Conversations, and more."""

from __future__ import annotations

import json
import logging
import re
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any, AsyncIterator, Iterator, Optional

logger = logging.getLogger(__name__)


@dataclass
class DatasetConfig:
    """Configuration for dataset loading."""

    batch_size: int = 100
    max_samples: Optional[int] = None
    split: str = "train"
    language: str = "en"
    cache_dir: str = "./dataset_cache"
    use_streaming: bool = False
    filter_fn: Optional[Any] = None
    transform_fn: Optional[Any] = None
    shuffle: bool = False
    seed: int = 42


@dataclass
class DatasetItem:
    """A single item from a dataset."""

    text: str
    metadata: dict[str, Any] = field(default_factory=dict)
    source: str = ""
    language: str = ""
    id: Optional[str] = None

    def to_dict(self) -> dict[str, Any]:
        return {
            "text": self.text,
            "metadata": self.metadata,
            "source": self.source,
            "language": self.language,
            "id": self.id,
        }


class BaseDatasetLoader(ABC):
    """Abstract base class for dataset loaders."""

    def __init__(self, config: Optional[DatasetConfig] = None) -> None:
        self.config = config or DatasetConfig()

    @abstractmethod
    def load(self) -> list[DatasetItem]:
        pass

    @abstractmethod
    def stream(self) -> Iterator[DatasetItem]:
        pass

    async def load_async(self) -> list[DatasetItem]:
        return self.load()

    async def stream_async(self) -> AsyncIterator[DatasetItem]:
        for item in self.stream():
            yield item

    def _apply_filter(self, item: DatasetItem) -> bool:
        if self.config.filter_fn:
            return bool(self.config.filter_fn(item))
        return True

    def _apply_transform(self, item: DatasetItem) -> DatasetItem:
        if self.config.transform_fn:
            result = self.config.transform_fn(item)
            if isinstance(result, DatasetItem):
                return result
        return item

    def _limit(self, items: list[DatasetItem]) -> list[DatasetItem]:
        if self.config.max_samples:
            return items[: self.config.max_samples]
        return items

    def _shuffle(self, items: list[DatasetItem]) -> list[DatasetItem]:
        if self.config.shuffle:
            import random
            rng = random.Random(self.config.seed)
            shuffled = list(items)
            rng.shuffle(shuffled)
            return shuffled
        return items


class WikipediaLoader(BaseDatasetLoader):
    """Loader for Wikipedia datasets."""

    DUMPS_API = "https://dumps.wikimedia.org/{lang}wiki/latest/"

    def __init__(
        self,
        config: Optional[DatasetConfig] = None,
        article_limit: Optional[int] = None,
        min_length: int = 100,
    ) -> None:
        super().__init__(config)
        self.article_limit = article_limit or self.config.max_samples
        self.min_length = min_length

    def load(self) -> list[DatasetItem]:
        try:
            return self._load_from_datasets()
        except Exception:
            return self._load_from_api()

    def _load_from_datasets(self) -> list[DatasetItem]:
        from datasets import load_dataset

        dataset = load_dataset(
            "wikipedia",
            self.config.language + "wikisource" if self.config.language != "en" else "20231101.en",
            split=self.config.split,
            streaming=self.config.use_streaming,
            cache_dir=self.config.cache_dir,
        )

        items: list[DatasetItem] = []
        for i, row in enumerate(dataset):
            if self.article_limit and i >= self.article_limit:
                break
            text = row.get("text", "")
            if len(text) < self.min_length:
                continue

            item = DatasetItem(
                text=text,
                metadata={
                    "title": row.get("title", ""),
                    "url": row.get("url", ""),
                },
                source="wikipedia",
                language=self.config.language,
                id=row.get("id"),
            )
            if self._apply_filter(item):
                item = self._apply_transform(item)
                items.append(item)

        return self._limit(self._shuffle(items))

    def _load_from_api(self) -> list[DatasetItem]:
        import aiohttp
        import asyncio

        async def fetch_articles() -> list[DatasetItem]:
            url = f"https://en.wikipedia.org/api/rest_v1/page/random/summary"
            items: list[DatasetItem] = []
            async with aiohttp.ClientSession() as session:
                count = 0
                while not self.article_limit or count < self.article_limit:
                    try:
                        async with session.get(url) as resp:
                            if resp.status == 200:
                                data = await resp.json()
                                text = data.get("extract", "")
                                if len(text) >= self.min_length:
                                    items.append(DatasetItem(
                                        text=text,
                                        metadata={"title": data.get("title", "")},
                                        source="wikipedia_api",
                                        language=self.config.language,
                                    ))
                                    count += 1
                            break
                    except Exception:
                        break
            return items

        loop = asyncio.new_event_loop()
        try:
            return loop.run_until_complete(fetch_articles())
        finally:
            loop.close()

    def stream(self) -> Iterator[DatasetItem]:
        try:
            from datasets import load_dataset

            dataset = load_dataset(
                "wikipedia",
                "20231101.en",
                split=self.config.split,
                streaming=True,
                cache_dir=self.config.cache_dir,
            )
            count = 0
            for row in dataset:
                if self.article_limit and count >= self.article_limit:
                    break
                text = row.get("text", "")
                if len(text) < self.min_length:
                    continue
                item = DatasetItem(
                    text=text,
                    metadata={"title": row.get("title", "")},
                    source="wikipedia",
                    language=self.config.language,
                )
                if self._apply_filter(item):
                    yield self._apply_transform(item)
                    count += 1
        except ImportError:
            logger.warning("datasets library not available for streaming")


class BooksLoader(BaseDatasetLoader):
    """Loader for Project Gutenberg and book datasets."""

    GUTENBERG_URL = "https://www.gutenberg.org"

    def __init__(
        self,
        config: Optional[DatasetConfig] = None,
        book_ids: Optional[list[int]] = None,
        min_length: int = 500,
    ) -> None:
        super().__init__(config)
        self.book_ids = book_ids or []
        self.min_length = min_length

    def load(self) -> list[DatasetItem]:
        try:
            return self._load_from_datasets()
        except Exception:
            return self._load_from_gutenberg()

    def _load_from_datasets(self) -> list[DatasetItem]:
        from datasets import load_dataset

        dataset = load_dataset(
            "bookcorpusopen" if self.config.language == "en" else "pileOfBooks",
            split=self.config.split,
            streaming=self.config.use_streaming,
            cache_dir=self.config.cache_dir,
        )

        items: list[DatasetItem] = []
        for i, row in enumerate(dataset):
            if self.config.max_samples and i >= self.config.max_samples:
                break
            text = row.get("text", row.get("content", ""))
            if len(text) < self.min_length:
                continue

            item = DatasetItem(
                text=text,
                metadata={
                    "title": row.get("title", ""),
                    "author": row.get("author", ""),
                },
                source="books",
                language=self.config.language,
                id=row.get("id"),
            )
            if self._apply_filter(item):
                item = self._apply_transform(item)
                items.append(item)

        return self._limit(self._shuffle(items))

    def _load_from_gutenberg(self) -> list[DatasetItem]:
        import urllib.request
        import urllib.error

        items: list[DatasetItem] = []
        for book_id in self.book_ids:
            try:
                url = f"{self.GUTENBERG_URL}/files/{book_id}/{book_id}-0.txt"
                req = urllib.request.Request(url, headers={"User-Agent": "muLLM/1.0"})
                with urllib.request.urlopen(req, timeout=30) as resp:
                    text = resp.read().decode("utf-8", errors="replace")

                header_end = text.find("*** START OF THIS PROJECT GUTENBERG EBOOK")
                if header_end == -1:
                    header_end = 0
                else:
                    header_end = text.find("\n", header_end) + 1
                footer_start = text.find("*** END OF THIS PROJECT GUTENBERG EBOOK")
                if footer_start == -1:
                    footer_start = len(text)

                text = text[header_end:footer_start].strip()

                if len(text) >= self.min_length:
                    item = DatasetItem(
                        text=text,
                        metadata={"book_id": book_id, "source_url": url},
                        source="gutenberg",
                        language=self.config.language,
                        id=str(book_id),
                    )
                    if self._apply_filter(item):
                        items.append(self._apply_transform(item))
            except Exception as e:
                logger.warning("Failed to load Gutenberg book %d: %s", book_id, e)

        return self._limit(items)

    def stream(self) -> Iterator[DatasetItem]:
        items = self.load()
        for item in items:
            yield item


class CodeDatasetLoader(BaseDatasetLoader):
    """Loader for code datasets from GitHub and The Stack."""

    def __init__(
        self,
        config: Optional[DatasetConfig] = None,
        languages: Optional[list[str]] = None,
        min_length: int = 50,
    ) -> None:
        super().__init__(config)
        self.languages = languages or ["python", "javascript", "java", "cpp"]
        self.min_length = min_length

    def load(self) -> list[DatasetItem]:
        try:
            return self._load_the_stack()
        except Exception:
            return self._load_codeparrot()

    def _load_the_stack(self) -> list[DatasetItem]:
        from datasets import load_dataset

        items: list[DatasetItem] = []
        for lang in self.languages:
            try:
                dataset = load_dataset(
                    "bigcode/the-stack-dedup",
                    lang,
                    split=self.config.split,
                    streaming=self.config.use_streaming,
                    cache_dir=self.config.cache_dir,
                )

                count = 0
                for row in dataset:
                    if self.config.max_samples and count >= self.config.max_samples:
                        break
                    text = row.get("content", "")
                    if len(text) < self.min_length:
                        continue

                    item = DatasetItem(
                        text=text,
                        metadata={
                            "repo_name": row.get("repo_name", ""),
                            "path": row.get("path", ""),
                            "language": lang,
                            "size": row.get("size", 0),
                        },
                        source="the_stack",
                        language=lang,
                        id=row.get("hexsha"),
                    )
                    if self._apply_filter(item):
                        item = self._apply_transform(item)
                        items.append(item)
                        count += 1
            except Exception as e:
                logger.warning("Failed to load code for %s: %s", lang, e)

        return self._limit(self._shuffle(items))

    def _load_codeparrot(self) -> list[DatasetItem]:
        from datasets import load_dataset

        try:
            dataset = load_dataset(
                "codeparrot/github-code",
                split=self.config.split,
                streaming=self.config.use_streaming,
                cache_dir=self.config.cache_dir,
            )

            items: list[DatasetItem] = []
            for i, row in enumerate(dataset):
                if self.config.max_samples and i >= self.config.max_samples:
                    break
                text = row.get("code", row.get("content", ""))
                if len(text) < self.min_length:
                    continue
                item = DatasetItem(
                    text=text,
                    metadata={"language": row.get("language", "")},
                    source="codeparrot",
                    language=row.get("language", ""),
                )
                if self._apply_filter(item):
                    items.append(self._apply_transform(item))
            return self._limit(items)
        except Exception:
            return []

    def stream(self) -> Iterator[DatasetItem]:
        items = self.load()
        for item in items:
            yield item


class ArxivLoader(BaseDatasetLoader):
    """Loader for scientific papers from arXiv."""

    ARXIV_API = "http://export.arxiv.org/api/query"

    def __init__(
        self,
        config: Optional[DatasetConfig] = None,
        query: str = "cat:cs.AI",
        max_results: Optional[int] = None,
    ) -> None:
        super().__init__(config)
        self.query = query
        self.max_results = max_results or self.config.max_samples or 100

    def load(self) -> list[DatasetItem]:
        try:
            return self._load_from_datasets()
        except Exception:
            return self._load_from_api()

    def _load_from_datasets(self) -> list[DatasetItem]:
        from datasets import load_dataset

        dataset = load_dataset(
            "ccdv/arxiv-papers",
            split=self.config.split,
            streaming=self.config.use_streaming,
            cache_dir=self.config.cache_dir,
        )

        items: list[DatasetItem] = []
        for i, row in enumerate(dataset):
            if self.config.max_samples and i >= self.config.max_samples:
                break
            text = row.get("abstract", row.get("content", ""))
            if not text:
                continue

            item = DatasetItem(
                text=text,
                metadata={
                    "title": row.get("title", ""),
                    "authors": row.get("authors", ""),
                    "categories": row.get("categories", ""),
                },
                source="arxiv",
                language="en",
                id=row.get("id"),
            )
            if self._apply_filter(item):
                items.append(self._apply_transform(item))

        return self._limit(self._shuffle(items))

    def _load_from_api(self) -> list[DatasetItem]:
        import urllib.request
        import xml.etree.ElementTree as ET

        items: list[DatasetItem] = []
        start = 0
        batch_size = min(100, self.max_results)

        while start < self.max_results:
            count = min(batch_size, self.max_results - start)
            url = (
                f"{self.ARXIV_API}?search_query={self.query}"
                f"&start={start}&max_results={count}"
            )
            try:
                req = urllib.request.Request(url, headers={"User-Agent": "muLLM/1.0"})
                with urllib.request.urlopen(req, timeout=30) as resp:
                    xml_data = resp.read().decode("utf-8")

                ns = {"atom": "http://www.w3.org/2005/Atom"}
                root = ET.fromstring(xml_data)

                for entry in root.findall("atom:entry", ns):
                    title = entry.findtext("atom:title", "", ns).strip()
                    summary = entry.findtext("atom:summary", "", ns).strip()
                    published = entry.findtext("atom:published", "", ns)
                    arxiv_id = entry.findtext("atom:id", "", ns)
                    authors = [
                        a.findtext("atom:name", "", ns)
                        for a in entry.findall("atom:author", ns)
                    ]
                    categories = [
                        c.get("term", "")
                        for c in entry.findall("atom:category", ns)
                    ]

                    text = f"{title}\n\n{summary}"
                    if len(text) >= 50:
                        item = DatasetItem(
                            text=text,
                            metadata={
                                "title": title,
                                "authors": ", ".join(authors),
                                "published": published,
                                "categories": ", ".join(categories),
                            },
                            source="arxiv_api",
                            language="en",
                            id=arxiv_id,
                        )
                        if self._apply_filter(item):
                            items.append(self._apply_transform(item))

                start += count
            except Exception as e:
                logger.warning("Failed to fetch arXiv page at offset %d: %s", start, e)
                break

        return self._limit(items)

    def stream(self) -> Iterator[DatasetItem]:
        items = self.load()
        for item in items:
            yield item


class ConversationsLoader(BaseDatasetLoader):
    """Loader for conversation/chat datasets."""

    def __init__(
        self,
        config: Optional[DatasetConfig] = None,
        dataset_name: str = "daily_dialog",
        min_turns: int = 2,
    ) -> None:
        super().__init__(config)
        self.dataset_name = dataset_name
        self.min_turns = min_turns

    def load(self) -> list[DatasetItem]:
        from datasets import load_dataset

        dataset_map = {
            "daily_dialog": ("daily_dialog", "default"),
            "personachat": ("boids-card/persona-chat", None),
            "mutual": ("google-research-datasets/multi_woz", None),
        }

        ds_name, subset = dataset_map.get(self.dataset_name, (self.dataset_name, None))

        kwargs: dict[str, Any] = {
            "split": self.config.split,
            "streaming": self.config.use_streaming,
            "cache_dir": self.config.cache_dir,
        }
        if subset:
            kwargs["name"] = subset

        try:
            dataset = load_dataset(ds_name, **kwargs)
        except Exception:
            dataset = load_dataset(ds_name, split=self.config.split, cache_dir=self.config.cache_dir)

        items: list[DatasetItem] = []
        for i, row in enumerate(dataset):
            if self.config.max_samples and i >= self.config.max_samples:
                break

            dialog = row.get("dialog", row.get("context", row.get("conversations", [])))
            if isinstance(dialog, list) and len(dialog) >= self.min_turns:
                parts: list[str] = []
                for turn in dialog:
                    if isinstance(turn, dict):
                        role = turn.get("role", turn.get("from", "speaker"))
                        content = turn.get("content", turn.get("value", ""))
                        parts.append(f"{role}: {content}")
                    elif isinstance(turn, str):
                        parts.append(turn)
                text = "\n".join(parts)
            elif isinstance(dialog, str):
                text = dialog
            else:
                continue

            if not text:
                continue

            item = DatasetItem(
                text=text,
                metadata={"dialog_length": len(dialog) if isinstance(dialog, list) else 1},
                source=f"conversations_{self.dataset_name}",
                language=self.config.language,
                id=row.get("id"),
            )
            if self._apply_filter(item):
                items.append(self._apply_transform(item))

        return self._limit(self._shuffle(items))

    def stream(self) -> Iterator[DatasetItem]:
        items = self.load()
        for item in items:
            yield item


class MultilingualLoader(BaseDatasetLoader):
    """Loader for multilingual datasets."""

    def __init__(
        self,
        config: Optional[DatasetConfig] = None,
        dataset_name: str = "cc100",
        languages: Optional[list[str]] = None,
    ) -> None:
        super().__init__(config)
        self.dataset_name = dataset_name
        self.languages = languages or ["en", "de", "fr", "es", "zh", "ja"]

    def load(self) -> list[DatasetItem]:
        from datasets import load_dataset

        items: list[DatasetItem] = []

        dataset_configs = {
            "cc100": "cc100",
            "oscar": "oscar",
            "tatoeba": "tatoeba",
        }

        ds_name = dataset_configs.get(self.dataset_name, self.dataset_name)

        for lang in self.languages:
            try:
                kwargs: dict[str, Any] = {
                    "split": self.config.split,
                    "streaming": self.config.use_streaming,
                    "cache_dir": self.config.cache_dir,
                }
                if ds_name == "cc100":
                    kwargs["name"] = lang
                elif ds_name == "oscar":
                    kwargs["name"] = f"unshuffled_deduplicated_{lang}"

                dataset = load_dataset(ds_name, **kwargs)

                count = 0
                max_per_lang = (self.config.max_samples or 10000) // len(self.languages)

                for row in dataset:
                    if count >= max_per_lang:
                        break
                    text = row.get("text", row.get("content", ""))
                    if not text or len(text) < 50:
                        continue

                    item = DatasetItem(
                        text=text,
                        metadata={"language": lang, "dataset": ds_name},
                        source=f"multilingual_{ds_name}",
                        language=lang,
                        id=row.get("id"),
                    )
                    if self._apply_filter(item):
                        items.append(self._apply_transform(item))
                        count += 1
            except Exception as e:
                logger.warning("Failed to load %s for language %s: %s", ds_name, lang, e)

        return self._limit(self._shuffle(items))

    def stream(self) -> Iterator[DatasetItem]:
        items = self.load()
        for item in items:
            yield item


class CustomDatasetLoader(BaseDatasetLoader):
    """Loader for custom/local datasets from files."""

    SUPPORTED_FORMATS = {".json", ".jsonl", ".txt", ".csv", ".parquet"}

    def __init__(
        self,
        config: Optional[DatasetConfig] = None,
        file_path: str = "",
        text_key: str = "text",
        format: Optional[str] = None,
    ) -> None:
        super().__init__(config)
        self.file_path = file_path
        self.text_key = text_key
        self.format = format

    def load(self) -> list[DatasetItem]:
        from pathlib import Path

        path = Path(self.file_path)
        if not path.exists():
            logger.error("Dataset file not found: %s", self.file_path)
            return []

        ext = self.format or path.suffix.lower()

        if ext == ".json":
            return self._load_json(path)
        elif ext == ".jsonl":
            return self._load_jsonl(path)
        elif ext == ".txt":
            return self._load_text(path)
        elif ext == ".csv":
            return self._load_csv(path)
        elif ext == ".parquet":
            return self._load_parquet(path)
        else:
            logger.error("Unsupported format: %s", ext)
            return []

    def _load_json(self, path: Any) -> list[DatasetItem]:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)

        if isinstance(data, dict):
            if self.text_key in data:
                data = data[self.text_key]
            elif "data" in data:
                data = data["data"]
            elif "items" in data:
                data = data["items"]

        items: list[DatasetItem] = []
        if isinstance(data, list):
            for i, row in enumerate(data):
                if self.config.max_samples and i >= self.config.max_samples:
                    break
                if isinstance(row, str):
                    text = row
                    metadata = {}
                elif isinstance(row, dict):
                    text = row.get(self.text_key, row.get("text", row.get("content", "")))
                    metadata = {k: v for k, v in row.items() if k != self.text_key and k != "text"}
                else:
                    continue

                if not text:
                    continue

                item = DatasetItem(
                    text=str(text),
                    metadata=metadata,
                    source=f"custom_{path.name}",
                    language=self.config.language,
                )
                if self._apply_filter(item):
                    items.append(self._apply_transform(item))

        return self._limit(self._shuffle(items))

    def _load_jsonl(self, path: Any) -> list[DatasetItem]:
        items: list[DatasetItem] = []
        count = 0
        with open(path, "r", encoding="utf-8") as f:
            for line in f:
                if self.config.max_samples and count >= self.config.max_samples:
                    break
                line = line.strip()
                if not line:
                    continue
                try:
                    row = json.loads(line)
                except json.JSONDecodeError:
                    row = {"text": line}

                if isinstance(row, str):
                    text = row
                    metadata = {}
                elif isinstance(row, dict):
                    text = row.get(self.text_key, row.get("text", ""))
                    metadata = {k: v for k, v in row.items() if k not in (self.text_key, "text")}
                else:
                    continue

                if not text:
                    continue

                item = DatasetItem(
                    text=str(text),
                    metadata=metadata,
                    source=f"custom_{path.name}",
                    language=self.config.language,
                )
                if self._apply_filter(item):
                    items.append(self._apply_transform(item))
                    count += 1

        return self._limit(self._shuffle(items))

    def _load_text(self, path: Any) -> list[DatasetItem]:
        with open(path, "r", encoding="utf-8") as f:
            content = f.read()

        paragraphs = re.split(r"\n\s*\n", content)
        items: list[DatasetItem] = []
        for i, para in enumerate(paragraphs):
            if self.config.max_samples and i >= self.config.max_samples:
                break
            text = para.strip()
            if not text:
                continue
            item = DatasetItem(
                text=text,
                source=f"custom_{path.name}",
                language=self.config.language,
            )
            if self._apply_filter(item):
                items.append(self._apply_transform(item))

        return self._limit(self._shuffle(items))

    def _load_csv(self, path: Any) -> list[DatasetItem]:
        import csv

        items: list[DatasetItem] = []
        count = 0
        with open(path, "r", encoding="utf-8", newline="") as f:
            reader = csv.DictReader(f)
            for row in reader:
                if self.config.max_samples and count >= self.config.max_samples:
                    break
                text = row.get(self.text_key, row.get("text", ""))
                if not text:
                    continue
                metadata = {k: v for k, v in row.items() if k not in (self.text_key, "text")}
                item = DatasetItem(
                    text=text,
                    metadata=metadata,
                    source=f"custom_{path.name}",
                    language=self.config.language,
                )
                if self._apply_filter(item):
                    items.append(self._apply_transform(item))
                    count += 1

        return self._limit(self._shuffle(items))

    def _load_parquet(self, path: Any) -> list[DatasetItem]:
        try:
            import pandas as pd

            df = pd.read_parquet(path)
            items: list[DatasetItem] = []
            for i, row in df.iterrows():
                if self.config.max_samples and i >= self.config.max_samples:
                    break
                text = str(row.get(self.text_key, row.get("text", "")))
                if not text:
                    continue
                metadata = {k: str(v) for k, v in row.items() if k not in (self.text_key, "text")}
                item = DatasetItem(
                    text=text,
                    metadata=metadata,
                    source=f"custom_{path.name}",
                    language=self.config.language,
                )
                if self._apply_filter(item):
                    items.append(self._apply_transform(item))
            return self._limit(self._shuffle(items))
        except ImportError:
            logger.warning("pandas and pyarrow required for parquet loading")
            return []

    def stream(self) -> Iterator[DatasetItem]:
        items = self.load()
        for item in items:
            yield item


class DatasetFactory:
    """Factory for creating dataset loaders."""

    LOADERS: dict[str, type[BaseDatasetLoader]] = {
        "wikipedia": WikipediaLoader,
        "books": BooksLoader,
        "code": CodeDatasetLoader,
        "arxiv": ArxivLoader,
        "conversations": ConversationsLoader,
        "multilingual": MultilingualLoader,
        "custom": CustomDatasetLoader,
    }

    @classmethod
    def create(cls, dataset_type: str, config: Optional[DatasetConfig] = None, **kwargs) -> BaseDatasetLoader:
        if dataset_type not in cls.LOADERS:
            raise ValueError(
                f"Unknown dataset type: {dataset_type}. Available: {list(cls.LOADERS.keys())}"
            )
        return cls.LOADERS[dataset_type](config=config, **kwargs)

    @classmethod
    def register(cls, name: str, loader_class: type[BaseDatasetLoader]) -> None:
        cls.LOADERS[name] = loader_class

    @classmethod
    def available(cls) -> list[str]:
        return list(cls.LOADERS.keys())
