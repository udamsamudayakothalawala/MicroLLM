import pytest
import torch


@pytest.fixture
def model_config():
    from mullm.core.config.settings import ModelConfig
    return ModelConfig(
        vocab_size=1000,
        hidden_size=64,
        num_layers=2,
        num_attention_heads=4,
        num_kv_heads=2,
        intermediate_size=256,
        max_position_embeddings=128,
    )


@pytest.fixture
def llama_model(model_config):
    from mullm.core.model.model import LlamaModel
    return LlamaModel(model_config)


@pytest.fixture
def input_ids():
    return torch.randint(0, 100, (2, 16))


@pytest.fixture
def attention_mask():
    return torch.ones(2, 16, dtype=torch.bool)


@pytest.fixture
def position_ids():
    return torch.arange(16).unsqueeze(0).expand(2, -1)


@pytest.fixture
def tokenizer():
    from mullm.core.tokenizer.bpe import BPETokenizer
    tok = BPETokenizer()
    tok._vocab = {f"token_{i}": str(i) for i in range(100)}
    tok._reverse_vocab = {str(i): f"token_{i}" for i in range(100)}
    tok._vocab_size = 100
    return tok


@pytest.fixture
def small_corpus():
    return ["hello world", "this is a test", "the cat sat on the mat", "natural language processing"]
