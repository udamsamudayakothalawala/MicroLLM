from __future__ import annotations

import gc
import math
import os
import random
import signal
import sys
import time
import warnings
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Tuple, Union

import numpy as np
import torch
import torch.distributed as dist
import torch.nn as nn
from torch.cuda.amp import GradScaler, autocast
from torch.optim import Optimizer
from torch.optim.lr_scheduler import LRScheduler
from torch.utils.data import DataLoader, Dataset
from tqdm import tqdm

from mullm.core.trainer.dataloader import (
    DataCollatorForCausalLM,
    DistributedDataLoader,
    PackingCollator,
    StreamingDataset,
    create_dataloader,
)
from mullm.core.trainer.deepspeed_zoo import (
    build_deepspeed_config,
    deepspeed_available,
)
from mullm.core.trainer.fsdp import FSDPConfigBuilder
from mullm.core.trainer.loss import CombinedLoss, build_loss
from mullm.core.trainer.optimizer import build_optimizer
from mullm.core.trainer.parallelism import ParallelismManager
from mullm.core.trainer.scheduler import build_scheduler
from mullm.core.trainer.training_config import (
    BackendType,
    CheckpointConfig,
    EvaluationConfig,
    LoggingConfig,
    OptimizerConfig,
    PrecisionType,
    SchedulerConfig,
    TrainerConfig,
)


def set_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False
    os.environ["PYTHONHASHSEED"] = str(seed)


def get_device(local_rank: int = -1, device: str = "auto") -> torch.device:
    if device == "auto":
        if torch.cuda.is_available():
            if local_rank >= 0:
                return torch.device(f"cuda:{local_rank}")
            return torch.device("cuda")
        return torch.device("cpu")
    return torch.device(device)


def is_main_process(local_rank: int, world_size: int) -> bool:
    if world_size <= 1:
        return True
    return local_rank == 0


def initialize_distributed(
    backend: str = "nccl",
    init_method: str = "env://",
    world_size: int = 1,
    rank: int = 0,
    local_rank: int = -1,
    master_addr: str = "localhost",
    master_port: str = "29500",
) -> Tuple[int, int]:
    if not dist.is_initialized():
        if "RANK" in os.environ and "WORLD_SIZE" in os.environ:
            world_size = int(os.environ["WORLD_SIZE"])
            rank = int(os.environ["RANK"])
            local_rank = int(os.environ.get("LOCAL_RANK", 0))
        else:
            os.environ["MASTER_ADDR"] = os.environ.get("MASTER_ADDR", master_addr)
            os.environ["MASTER_PORT"] = os.environ.get("MASTER_PORT", master_port)
            if torch.cuda.is_available():
                local_rank = local_rank if local_rank >= 0 else 0
                world_size = world_size if world_size > 0 else 1
                rank = rank if rank >= 0 else 0

        if world_size > 1 and torch.cuda.is_available():
            torch.cuda.set_device(local_rank)
            dist.init_process_group(
                backend=backend,
                init_method=init_method,
                world_size=world_size,
                rank=rank,
            )

    return world_size, rank


class Trainer:
    def __init__(
        self,
        model: nn.Module,
        config: TrainerConfig,
        train_dataset: Optional[Dataset] = None,
        eval_dataset: Optional[Dataset] = None,
        tokenizer: Optional[Any] = None,
        optimizers: Tuple[Optional[Optimizer], Optional[LRScheduler]] = (None, None),
        collator: Optional[Any] = None,
        callbacks: Optional[List[Any]] = None,
    ) -> None:
        self.model = model
        self.config = config
        self.train_dataset = train_dataset
        self.eval_dataset = eval_dataset
        self.tokenizer = tokenizer
        self.callbacks = callbacks or []

        self.device = get_device(config.local_rank, config.device)
        self.world_size, self.rank = initialize_distributed(
            backend="nccl",
            world_size=config.world_size,
            rank=config.rank,
            local_rank=config.local_rank,
            master_addr=config.master_addr,
            master_port=config.master_port,
        )
        self.local_rank = config.local_rank if config.local_rank >= 0 else self.rank
        self.is_main = is_main_process(self.local_rank, self.world_size)

        self._setup_logging()

        self.optimizer: Optional[Optimizer] = None
        self.scheduler: Optional[LRScheduler] = None
        self.scaler: Optional[GradScaler] = None
        self.collator = collator

        self._setup_precision()
        self._setup_backend()
        self._setup_optimizers(optimizers)
        self._setup_misc()

        self.total_steps = 0
        self.epoch = 0
        self.best_metric = float("inf") if self.config.evaluation.metric_mode == "min" else float("-inf")
        self.best_step = 0
        self.early_stop_counter = 0
        self.global_step = 0

        self._train_dataloader: Optional[Any] = None
        self._eval_dataloader: Optional[Any] = None
        self._stop_training = False

    def _setup_logging(self) -> None:
        log_cfg = self.config.logging
        if self.is_main:
            import logging

            logging.basicConfig(
                level=getattr(logging, log_cfg.log_level.upper(), logging.INFO),
                format="%(asctime)s | %(levelname)-8s | %(message)s",
            )
            self.logger = logging.getLogger("mullm.trainer")
        else:
            self.logger = None

        self._wandb_run = None
        if self.is_main and log_cfg.wandb_enabled:
            try:
                import wandb

                wandb_kwargs = {
                    "project": log_cfg.wandb_project or "mullm",
                    "entity": log_cfg.wandb_entity,
                    "name": log_cfg.wandb_run_name,
                    "tags": log_cfg.wandb_tags,
                    "config": self.config.to_dict(),
                }
                wandb_kwargs = {k: v for k, v in wandb_kwargs.items() if v is not None}
                self._wandb_run = wandb.init(**wandb_kwargs)
            except Exception:
                pass

        self._tensorboard_writer = None
        if self.is_main and log_cfg.tensorboard_enabled:
            try:
                from torch.utils.tensorboard import SummaryWriter

                tb_dir = log_cfg.tensorboard_dir or os.path.join(self.config.output_dir, "tensorboard")
                os.makedirs(tb_dir, exist_ok=True)
                self._tensorboard_writer = SummaryWriter(tb_dir)
            except Exception:
                pass

    def _setup_precision(self) -> None:
        precision = self.config.precision
        if precision == PrecisionType.fp16:
            self.amp_dtype = torch.float16
            self.amp_enabled = True
            self.scaler = GradScaler(enabled=True)
        elif precision == PrecisionType.bf16:
            self.amp_dtype = torch.bfloat16
            self.amp_enabled = True
            self.scaler = None
        elif precision == PrecisionType.fp8:
            self.amp_dtype = torch.float8_e4m3fn
            self.amp_enabled = True
            self.scaler = None
        else:
            self.amp_dtype = torch.float32
            self.amp_enabled = False
            self.scaler = None

    def _setup_backend(self) -> None:
        self.parallelism_manager = ParallelismManager(self.config.parallelism)

        if self.world_size > 1:
            self.parallelism_manager.initialize_groups()

        if self.config.backend == BackendType.deepspeed or self.config.deepspeed_enabled:
            self._setup_deepspeed()
        elif self.config.backend == BackendType.fsdp or self.config.fsdp_enabled:
            self._setup_fsdp()
        elif self.config.backend == BackendType.ddp and self.world_size > 1:
            self._setup_ddp()

    def _setup_ddp(self) -> None:
        if self.world_size <= 1:
            return

        if self.rank == 0:
            self.log(f"Initializing DDP with {self.world_size} GPUs")

        self.model = self.model.to(self.device)
        self.model = nn.parallel.DistributedDataParallel(
            self.model,
            device_ids=[self.local_rank] if torch.cuda.is_available() else None,
            output_device=self.local_rank if torch.cuda.is_available() else None,
            find_unused_parameters=self.config.ddp_find_unused_parameters,
            bucket_cap_mb=self.config.ddp_bucket_cap_mb,
            static_graph=self.config.ddp_static_graph,
        )

    def _setup_fsdp(self) -> None:
        if not FSDPConfigBuilder.supports_fsdp():
            self.log("FSDP not available, falling back to DDP", level="warning")
            self._setup_ddp()
            return

        try:
            from torch.distributed.fsdp import FullyShardedDataParallel as FSDP

            if self.rank == 0:
                self.log("Initializing FSDP")

            fsdp_config = self.config.fsdp
            builder = FSDPConfigBuilder(fsdp_config)
            kwargs = builder.build_kwargs()

            self.model = self.model.to(self.device)
            self.model = FSDP(
                self.model,
                **kwargs,
                device_id=self.local_rank if torch.cuda.is_available() else None,
            )
        except Exception as e:
            self.log(f"FSDP initialization failed: {e}, falling back to DDP", level="warning")
            self._setup_ddp()

    def _setup_deepspeed(self) -> None:
        if not deepspeed_available():
            self.log("DeepSpeed not available, falling back to DDP", level="warning")
            self._setup_ddp()
            return

        try:
            import deepspeed

            if self.rank == 0:
                self.log("Initializing DeepSpeed")

            ds_config_path = self.config.deepspeed_config_path
            if ds_config_path:
                import json

                with open(ds_config_path) as f:
                    ds_config = json.load(f)
            else:
                ds_config = build_deepspeed_config(
                    config=self.config.deepspeed_zero,
                    train_batch_size=self.config.batch_size * self.world_size * self.config.gradient_accumulation_steps,
                    train_micro_batch_size_per_gpu=self.config.batch_size,
                    gradient_accumulation_steps=self.config.gradient_accumulation_steps,
                    gradient_clipping=self.config.max_grad_norm,
                    fp16_enabled=self.config.precision == PrecisionType.fp16,
                    bf16_enabled=self.config.precision == PrecisionType.bf16,
                )

            model_params = self._get_param_groups()
            self.model, self.optimizer, _, self.scheduler = deepspeed.initialize(
                model=self.model,
                model_parameters=model_params,
                config_params=ds_config,
            )
        except Exception as e:
            self.log(f"DeepSpeed initialization failed: {e}, falling back to DDP", level="warning")
            self._setup_ddp()

    def _setup_optimizers(
        self, optimizers: Tuple[Optional[Optimizer], Optional[LRScheduler]]
    ) -> None:
        if self.config.backend == BackendType.deepspeed or self.config.deepspeed_enabled:
            return

        if optimizers[0] is not None:
            self.optimizer = optimizers[0]
        else:
            self.optimizer = build_optimizer(self.model, self.config.optimizer)

        if optimizers[1] is not None:
            self.scheduler = optimizers[1]
        else:
            opt_config = self.config.optimizer
            sched_config = self.config.scheduler

            effective_lr = self.optimizer.param_groups[0]["lr"]
            step_count = self._estimate_training_steps()

            sched_config.num_training_steps = step_count
            self.scheduler = build_scheduler(self.optimizer, sched_config)

    def _setup_misc(self) -> None:
        if self.config.gradient_checkpointing:
            self.model.gradient_checkpointing_enable()

        if self.config.compile_model:
            try:
                self.model = torch.compile(self.model)
            except Exception:
                pass

        set_seed(self.config.seed)

    def _estimate_training_steps(self) -> int:
        if self.config.max_steps > 0:
            return self.config.max_steps

        if self.train_dataset is None:
            return 1000

        num_batches = max(1, len(self.train_dataset) // (self.config.batch_size * self.world_size))
        total_steps = (num_batches * self.config.num_epochs) // self.config.gradient_accumulation_steps
        return total_steps

    def _get_param_groups(self) -> List[Dict[str, Any]]:
        opt_config = self.config.optimizer
        if not opt_config.param_groups_decay:
            return self.model.parameters()

        no_decay = opt_config.no_decay_params
        decay = []
        no_decay_params = []

        for name, param in self.model.named_parameters():
            if not param.requires_grad:
                continue
            if any(nd in name.lower() for nd in no_decay):
                no_decay_params.append(param)
            else:
                decay.append(param)

        groups = []
        if decay:
            groups.append({"params": decay, "weight_decay": opt_config.adamw.weight_decay})
        if no_decay_params:
            groups.append({"params": no_decay_params, "weight_decay": 0.0})
        if not groups:
            groups = [{"params": self.model.parameters()}]

        return groups

    def log(self, msg: str, level: str = "info") -> None:
        if self.is_main and self.logger:
            log_fn = getattr(self.logger, level.lower(), self.logger.info)
            log_fn(f"[Step {self.global_step}] {msg}")

    def log_metrics(self, metrics: Dict[str, float], step: Optional[int] = None) -> None:
        step = step or self.global_step
        if not self.is_main:
            return

        prefix = ""
        log_str = f"Step {step}: "
        for k, v in metrics.items():
            log_str += f"{k}={v:.4f} "
        self.log(log_str.strip())

        if self._wandb_run is not None:
            import wandb

            wandb.log({f"{prefix}{k}": v for k, v in metrics.items()}, step=step)

        if self._tensorboard_writer is not None:
            for k, v in metrics.items():
                self._tensorboard_writer.add_scalar(f"{prefix}{k}", v, step)

    def _build_train_dataloader(self) -> Any:
        if self._train_dataloader is not None:
            return self._train_dataloader

        if self.train_dataset is None:
            raise ValueError("Training dataset is required")

        if self.collator is None:
            self.collator = DataCollatorForCausalLM(
                tokenizer=self.tokenizer,
                max_length=self.config.data.max_seq_length,
                pad_token_id=self.config.data.collator_pad_token_id,
                ignore_index=self.config.data.collator_ignore_index,
                padding=self.config.data.padding,
                truncation=self.config.data.truncation,
            )

        if self.config.data.packing:
            inner_collator = DataCollatorForCausalLM(
                tokenizer=self.tokenizer,
                max_length=self.config.data.max_seq_length,
                pad_token_id=self.config.data.collator_pad_token_id,
                ignore_index=self.config.data.collator_ignore_index,
            )
            from torch.utils.data import DataLoader as TorchDataLoader

            dl = TorchDataLoader(
                self.train_dataset,
                batch_size=1,
                shuffle=True,
                num_workers=self.config.dataloader_num_workers,
                collate_fn=lambda x: x[0] if isinstance(x, list) and len(x) == 1 else x,
                pin_memory=True,
            )
            self._train_dataloader = dl
            return self._train_dataloader

        if self.config.data.streaming:
            stream_dataset = StreamingDataset(
                source=self.train_dataset,
                tokenizer=self.tokenizer,
                max_length=self.config.data.max_seq_length,
                shuffle_buffer_size=self.config.data.shuffle_buffer_size,
                seed=self.config.seed,
            )
            self._train_dataloader = DistributedDataLoader(
                dataset=stream_dataset,
                batch_size=self.config.batch_size,
                shuffle=False,
                seed=self.config.seed,
                num_workers=0,
                collator=self.collator,
                world_size=self.world_size,
                rank=self.rank,
                distributed=self.world_size > 1,
            )
            return self._train_dataloader

        self._train_dataloader = create_dataloader(
            dataset=self.train_dataset,
            config=self.config.data,
            world_size=self.world_size,
            rank=self.rank,
            collator=self.collator,
        )
        return self._train_dataloader

    def _build_eval_dataloader(self) -> Any:
        if self._eval_dataloader is not None:
            return self._eval_dataloader

        if self.eval_dataset is None:
            return None

        eval_collator = DataCollatorForCausalLM(
            tokenizer=self.tokenizer,
            max_length=self.config.data.max_seq_length,
            pad_token_id=self.config.data.collator_pad_token_id,
            ignore_index=self.config.data.collator_ignore_index,
            padding=True,
            truncation=True,
        )

        self._eval_dataloader = create_dataloader(
            dataset=self.eval_dataset,
            config=self.config.data,
            world_size=1,
            rank=0,
            collator=eval_collator,
        )
        return self._eval_dataloader

    def train(self) -> Dict[str, Any]:
        self.log(f"Starting training with {self.config.backend.value} backend")
        self.log(f"Model parameters: {sum(p.numel() for p in self.model.parameters()):,}")
        self.log(f"Trainable parameters: {sum(p.numel() for p in self.model.parameters() if p.requires_grad):,}")

        train_dataloader = self._build_train_dataloader()
        eval_dataloader = self._build_eval_dataloader()

        self.model.train()
        self.total_steps = self._estimate_training_steps()
        self.global_step = 0
        epoch = 0
        total_loss = 0.0
        best_loss = float("inf")

        self._stop_training = False
        signal.signal(signal.SIGINT, self._signal_handler)
        signal.signal(signal.SIGTERM, self._signal_handler)

        log_cfg = self.config.logging
        eval_cfg = self.config.evaluation
        ckpt_cfg = self.config.checkpoint

        self._maybe_resume(ckpt_cfg)

        accum_steps = self.config.gradient_accumulation_steps

        while epoch < self.config.num_epochs and not self._stop_training:
            self.epoch = epoch
            if hasattr(train_dataloader, "set_epoch"):
                train_dataloader.set_epoch(epoch)

            epoch_loss = 0.0
            epoch_steps = 0
            optim_steps = 0
            batch_idx = 0

            progress_bar = tqdm(
                train_dataloader,
                desc=f"Epoch {epoch + 1}/{self.config.num_epochs}",
                disable=not self.is_main or self.config.disable_tqdm,
            )

            for batch in progress_bar:
                if self._stop_training:
                    break

                batch_idx += 1
                loss = self._training_step(batch)

                total_loss += loss
                epoch_loss += loss
                epoch_steps += 1

                if (batch_idx + 1) % accum_steps == 0 or (batch_idx + 1) == len(progress_bar) * accum_steps:
                    self._optimizer_step()
                    optim_steps += 1
                    self.global_step += 1

                    if self.global_step % log_cfg.log_steps == 0:
                        avg_loss = total_loss / max(1, log_cfg.log_steps)
                        lr = self._get_current_lr()
                        metrics = {
                            "loss": avg_loss,
                            "lr": lr,
                            "epoch": epoch,
                            "grad_norm": self._get_grad_norm(),
                        }
                        self.log_metrics(metrics)
                        total_loss = 0.0

                    if self.config.log_grad_norm:
                        grad_norms = {}
                        for name, param in self.model.named_parameters():
                            if param.grad is not None:
                                grad_norms[name] = param.grad.data.norm(2).item()
                        self.log_metrics({"grad_norms": grad_norms})

                    if self.global_step % ckpt_cfg.save_steps == 0:
                        self._save_checkpoint(ckpt_cfg, is_best=False)

                    if eval_dataloader is not None and self.global_step % eval_cfg.eval_steps == 0:
                        eval_metrics = self.evaluate(eval_dataloader)
                        self.log_metrics({f"eval_{k}": v for k, v in eval_metrics.items()})

                        if eval_cfg.metric_to_monitor in eval_metrics:
                            current = eval_metrics[eval_cfg.metric_to_monitor]
                            is_better = (
                                current < self.best_metric if eval_cfg.metric_mode == "min" else current > self.best_metric
                            )
                            if is_better:
                                self.best_metric = current
                                self.best_step = self.global_step
                                self._save_checkpoint(ckpt_cfg, is_best=True)
                                self.early_stop_counter = 0
                            else:
                                self.early_stop_counter += 1

                        self.model.train()

                        if eval_cfg.early_stopping_patience > 0 and self.early_stop_counter >= eval_cfg.early_stopping_patience:
                            self.log(f"Early stopping triggered after {self.early_stop_counter} evaluations without improvement")
                            self._stop_training = True
                            break

                    if self.config.max_steps > 0 and self.global_step >= self.config.max_steps:
                        self._stop_training = True
                        break

            if epoch_steps > 0:
                avg_epoch_loss = epoch_loss / epoch_steps
                self.log(f"Epoch {epoch + 1} completed. Average loss: {avg_epoch_loss:.4f}")
                self.log_metrics({"epoch_loss": avg_epoch_loss, "epoch": epoch})

            if self.global_step % accum_steps == 0 or epoch_steps % accum_steps == 0:
                self._optimizer_step()
                self.global_step += 1

            epoch += 1

            if self.config.max_steps > 0 and self.global_step >= self.config.max_steps:
                break

        self._save_checkpoint(ckpt_cfg, is_best=False, final=True)
        self._cleanup()

        final_metrics: Dict[str, Any] = {
            "best_metric": self.best_metric,
            "best_step": self.best_step,
            "total_steps": self.global_step,
            "total_epochs": epoch,
        }
        return final_metrics

    def _training_step(self, batch: Dict[str, torch.Tensor]) -> float:
        batch = {k: v.to(self.device) if isinstance(v, torch.Tensor) else v for k, v in batch.items()}

        if self.config.backend == BackendType.deepspeed or self.config.deepspeed_enabled:
            outputs = self.model(**batch)
            loss = outputs["loss"] if isinstance(outputs, dict) else outputs.loss
            if isinstance(loss, dict):
                loss = loss["loss"]
            self.model.backward(loss)
            return loss.item()

        with autocast(device_type="cuda" if torch.cuda.is_available() else "cpu", enabled=self.amp_enabled, dtype=self.amp_dtype):
            outputs = self.model(**batch)
            loss = outputs["loss"] if isinstance(outputs, dict) else outputs.loss
            if isinstance(loss, dict):
                loss = loss["loss"]

        loss = loss / self.config.gradient_accumulation_steps

        if self.scaler is not None:
            self.scaler.scale(loss).backward()
        else:
            loss.backward()

        return loss.item()

    def _optimizer_step(self) -> None:
        if self.config.backend == BackendType.deepspeed or self.config.deepspeed_enabled:
            self.model.step()
            return

        if self.config.max_grad_norm > 0.0:
            if self.scaler is not None:
                self.scaler.unscale_(self.optimizer)

            if isinstance(self.model, nn.parallel.DistributedDataParallel) or hasattr(self.model, "parameters"):
                torch.nn.utils.clip_grad_norm_(self.model.parameters(), self.config.max_grad_norm)

        if self.scaler is not None:
            self.scaler.step(self.optimizer)
            self.scaler.update()
        else:
            self.optimizer.step()

        self.scheduler.step()
        self.optimizer.zero_grad(set_to_none=True)

    def evaluate(self, eval_dataloader: Optional[Any] = None) -> Dict[str, float]:
        if eval_dataloader is None:
            eval_dataloader = self._build_eval_dataloader()

        if eval_dataloader is None:
            return {"loss": 0.0, "perplexity": 1.0}

        self.model.eval()
        total_loss = 0.0
        total_tokens = 0
        num_batches = 0

        eval_cfg = self.config.evaluation
        progress_bar = tqdm(
            eval_dataloader,
            desc="Evaluating",
            disable=not self.is_main or self.config.disable_tqdm,
        )

        with torch.no_grad():
            for batch_idx, batch in enumerate(progress_bar):
                if eval_cfg.eval_max_steps > 0 and batch_idx >= eval_cfg.eval_max_steps:
                    break

                batch = {
                    k: v.to(self.device) if isinstance(v, torch.Tensor) else v
                    for k, v in batch.items()
                }

                with autocast(
                    device_type="cuda" if torch.cuda.is_available() else "cpu",
                    enabled=self.amp_enabled,
                    dtype=self.amp_dtype,
                ):
                    outputs = self.model(**batch)
                    loss = outputs["loss"] if isinstance(outputs, dict) else outputs.loss
                    if isinstance(loss, dict):
                        loss = loss["loss"]

                total_loss += loss.item()
                num_batches += 1

                if "labels" in batch:
                    valid_tokens = (batch["labels"].view(-1) != -100).sum().item()
                    total_tokens += valid_tokens

        if self.world_size > 1 and dist.is_initialized():
            loss_tensor = torch.tensor(total_loss, device=self.device)
            dist.all_reduce(loss_tensor, op=dist.ReduceOp.SUM)
            total_loss = loss_tensor.item() / self.world_size

        avg_loss = total_loss / max(1, num_batches)
        perplexity = math.exp(min(avg_loss, 100.0))

        self.model.train()
        return {"loss": avg_loss, "perplexity": perplexity}

    def _get_current_lr(self) -> float:
        if self.scheduler is not None:
            return self.scheduler.get_last_lr()[0]
        if self.optimizer is not None:
            return self.optimizer.param_groups[0]["lr"]
        return 0.0

    def _get_grad_norm(self) -> float:
        total_norm = 0.0
        for p in self.model.parameters():
            if p.grad is not None:
                param_norm = p.grad.data.norm(2)
                total_norm += param_norm.item() ** 2
        return math.sqrt(total_norm)

    def _save_checkpoint(
        self,
        ckpt_cfg: CheckpointConfig,
        is_best: bool = False,
        final: bool = False,
    ) -> None:
        if not self.is_main:
            return

        if not os.path.exists(ckpt_cfg.checkpoint_dir):
            os.makedirs(ckpt_cfg.checkpoint_dir, exist_ok=True)

        if is_best:
            ckpt_path = os.path.join(ckpt_cfg.checkpoint_dir, "best_model.pt")
        elif final:
            ckpt_path = os.path.join(ckpt_cfg.checkpoint_dir, "final_model.pt")
        else:
            ckpt_path = os.path.join(ckpt_cfg.checkpoint_dir, f"checkpoint-{self.global_step}.pt")

        state_dict: Dict[str, Any] = {
            "global_step": self.global_step,
            "epoch": self.epoch,
            "best_metric": self.best_metric,
            "best_step": self.best_step,
            "model_state_dict": self.model.state_dict() if not hasattr(self.model, "module") else self.model.module.state_dict(),
            "config": self.config.to_dict(),
        }

        if ckpt_cfg.save_optimizer and self.optimizer is not None:
            state_dict["optimizer_state_dict"] = self.optimizer.state_dict()

        if ckpt_cfg.save_scheduler and self.scheduler is not None:
            state_dict["scheduler_state_dict"] = self.scheduler.state_dict()

        if ckpt_cfg.save_rng_state:
            state_dict["rng_state"] = {
                "python": random.getstate(),
                "numpy": np.random.get_state(),
                "torch": torch.get_rng_state(),
                "torch_cuda": torch.cuda.get_rng_state_all() if torch.cuda.is_available() else None,
            }

        if self.scaler is not None:
            state_dict["scaler_state_dict"] = self.scaler.state_dict()

        torch.save(state_dict, ckpt_path)
        self.log(f"Checkpoint saved to {ckpt_path}")

        if not is_best and not final:
            self._prune_checkpoints(ckpt_cfg.checkpoint_dir, ckpt_cfg.save_total_limit)

    def _prune_checkpoints(self, checkpoint_dir: str, save_total_limit: int) -> None:
        if save_total_limit <= 0:
            return

        checkpoints = sorted(
            [
                f
                for f in os.listdir(checkpoint_dir)
                if f.startswith("checkpoint-") and f.endswith(".pt")
            ],
            key=lambda x: int(x.split("-")[1].split(".")[0]),
        )

        while len(checkpoints) >= save_total_limit:
            old_ckpt = checkpoints.pop(0)
            os.remove(os.path.join(checkpoint_dir, old_ckpt))

    def _maybe_resume(self, ckpt_cfg: CheckpointConfig) -> None:
        resume_path = ckpt_cfg.resume_from_checkpoint
        if resume_path is None:
            return

        if not os.path.exists(resume_path):
            self.log(f"Resume checkpoint not found: {resume_path}", level="warning")
            return

        self.log(f"Resuming from checkpoint: {resume_path}")
        state_dict = torch.load(resume_path, map_location=self.device, weights_only=False)

        if "model_state_dict" in state_dict:
            if hasattr(self.model, "module"):
                self.model.module.load_state_dict(state_dict["model_state_dict"])
            else:
                self.model.load_state_dict(state_dict["model_state_dict"])

        if "optimizer_state_dict" in state_dict and self.optimizer is not None:
            self.optimizer.load_state_dict(state_dict["optimizer_state_dict"])

        if "scheduler_state_dict" in state_dict and self.scheduler is not None:
            self.scheduler.load_state_dict(state_dict["scheduler_state_dict"])

        if "scaler_state_dict" in state_dict and self.scaler is not None:
            self.scaler.load_state_dict(state_dict["scaler_state_dict"])

        self.global_step = state_dict.get("global_step", 0)
        self.epoch = state_dict.get("epoch", 0)
        self.best_metric = state_dict.get("best_metric", float("inf"))
        self.best_step = state_dict.get("best_step", 0)

        if "rng_state" in state_dict:
            rng_state = state_dict["rng_state"]
            random.setstate(rng_state["python"])
            np.random.set_state(rng_state["numpy"])
            torch.set_rng_state(rng_state["torch"])
            if rng_state.get("torch_cuda") is not None and torch.cuda.is_available():
                torch.cuda.set_rng_state_all(rng_state["torch_cuda"])

        self.log(f"Resumed at global step {self.global_step}, epoch {self.epoch}")

    def _signal_handler(self, signum: int, frame: Any) -> None:
        self.log(f"Received signal {signum}, stopping training...")
        self._stop_training = True

    def _cleanup(self) -> None:
        if self._wandb_run is not None:
            try:
                import wandb

                wandb.finish()
            except Exception:
                pass

        if self._tensorboard_writer is not None:
            self._tensorboard_writer.close()

        if dist.is_initialized():
            dist.barrier()
            dist.destroy_process_group()

        gc.collect()
        if torch.cuda.is_available():
            torch.cuda.empty_cache()

    def predict(self, dataloader: DataLoader) -> List[Dict[str, Any]]:
        self.model.eval()
        predictions: List[Dict[str, Any]] = []

        with torch.no_grad():
            for batch in tqdm(dataloader, desc="Predicting", disable=not self.is_main):
                batch = {
                    k: v.to(self.device) if isinstance(v, torch.Tensor) else v
                    for k, v in batch.items()
                }
                with autocast(device_type="cuda" if torch.cuda.is_available() else "cpu", enabled=self.amp_enabled, dtype=self.amp_dtype):
                    outputs = self.model(**batch)

                logits = outputs["logits"] if isinstance(outputs, dict) else outputs.logits
                preds = torch.argmax(logits, dim=-1)
                predictions.append({"predictions": preds.cpu(), **batch})

        return predictions

    def get_model_for_save(self) -> nn.Module:
        if hasattr(self.model, "module"):
            return self.model.module
        return self.model
