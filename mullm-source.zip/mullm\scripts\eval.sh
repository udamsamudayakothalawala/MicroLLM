#!/usr/bin/env bash
# muLLM Evaluation Launcher
# Usage: ./eval.sh --model-name <name> [--benchmarks mmlu,hellaswag,...]

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"

MODEL_NAME="${MULLM_EVAL_MODEL_NAME:-}"
BENCHMARKS="${MULLM_EVAL_BENCHMARKS:-hellaswag}"
MAX_SAMPLES="${MULLM_EVAL_MAX_SAMPLES:-}"
OUTPUT_DIR="${MULLM_EVAL_OUTPUT_DIR:-./eval_results}"
CACHE_DIR="${MULLM_EVAL_CACHE_DIR:-./eval_cache}"
NO_CACHE="${MULLM_EVAL_NO_CACHE:-false}"
NUM_GPUS="${MULLM_EVAL_NUM_GPUS:-1}"
BATCH_SIZE="${MULLM_EVAL_BATCH_SIZE:-1}"
TIMEOUT="${MULLM_EVAL_TIMEOUT:-300}"
MAX_TOKENS="${MULLM_EVAL_MAX_TOKENS:-256}"
SERVER_HOST="${MULLM_EVAL_SERVER_HOST:-localhost}"
SERVER_PORT="${MULLM_EVAL_SERVER_PORT:-8000}"
API_KEY="${MULLM_EVAL_API_KEY:-}"

while [[ $# -gt 0 ]]; do
    case $1 in
        --model-name) MODEL_NAME="$2"; shift 2 ;;
        --benchmarks) BENCHMARKS="$2"; shift 2 ;;
        --max-samples) MAX_SAMPLES="$2"; shift 2 ;;
        --output-dir) OUTPUT_DIR="$2"; shift 2 ;;
        --cache-dir) CACHE_DIR="$2"; shift 2 ;;
        --no-cache) NO_CACHE="true"; shift ;;
        --num-gpus) NUM_GPUS="$2"; shift 2 ;;
        --batch-size) BATCH_SIZE="$2"; shift 2 ;;
        --timeout) TIMEOUT="$2"; shift 2 ;;
        --max-tokens) MAX_TOKENS="$2"; shift 2 ;;
        --server-host) SERVER_HOST="$2"; shift 2 ;;
        --server-port) SERVER_PORT="$2"; shift 2 ;;
        --api-key) API_KEY="$2"; shift 2 ;;
        -h|--help)
            echo "Usage: $0 --model-name <name> [options]"
            echo ""
            echo "Required:"
            echo "  --model-name <name>       Model name for reporting"
            echo ""
            echo "Evaluation:"
            echo "  --benchmarks <list>       Comma-separated benchmarks (default: hellaswag)"
            echo "                            Available: mmlu, arc_easy, arc_challenge, gsm8k,"
            echo "                            humaneval, truthfulqa_mc, truthfulqa_gen, hellaswag,"
            echo "                            mt_bench"
            echo "  --max-samples <int>       Max samples per benchmark"
            echo "  --no-cache                Disable evaluation cache"
            echo "  --timeout <sec>           Timeout per request (default: 300)"
            echo "  --max-tokens <int>        Max generation tokens (default: 256)"
            echo ""
            echo "Infrastructure:"
            echo "  --num-gpus <int>          Number of GPUs (default: 1)"
            echo "  --batch-size <int>        Batch size (default: 1)"
            echo "  --output-dir <dir>        Output directory (default: ./eval_results)"
            echo "  --cache-dir <dir>         Cache directory (default: ./eval_cache)"
            echo ""
            echo "API Server (for remote inference):"
            echo "  --server-host <host>      Server host (default: localhost)"
            echo "  --server-port <port>      Server port (default: 8000)"
            echo "  --api-key <key>           API key for authentication"
            exit 0
            ;;
        *) echo "Unknown option: $1"; exit 1 ;;
    esac
done

if [[ -z "$MODEL_NAME" ]]; then
    echo "Error: --model-name is required" >&2
    exit 1
fi

echo "============================================"
echo "  muLLM Evaluation"
echo "============================================"
echo "Model:          $MODEL_NAME"
echo "Benchmarks:     $BENCHMARKS"
echo "Max samples:    ${MAX_SAMPLES:-auto}"
echo "Output:         $OUTPUT_DIR"
echo "Cache:          $CACHE_DIR"
echo "No cache:       $NO_CACHE"
echo "GPUs:           $NUM_GPUS"
echo "Server:         $SERVER_HOST:$SERVER_PORT"
echo "============================================"

mkdir -p "$OUTPUT_DIR" "$CACHE_DIR"

export MULLM_EVAL_MODEL_NAME="$MODEL_NAME"
export MULLM_EVAL_BENCHMARKS="$BENCHMARKS"
export MULLM_EVAL_OUTPUT_DIR="$OUTPUT_DIR"
export MULLM_EVAL_CACHE_DIR="$CACHE_DIR"
export MULLM_EVAL_NO_CACHE="$NO_CACHE"
export MULLM_EVAL_NUM_GPUS="$NUM_GPUS"
export MULLM_EVAL_BATCH_SIZE="$BATCH_SIZE"
export MULLM_EVAL_TIMEOUT="$TIMEOUT"
export MULLM_EVAL_MAX_TOKENS="$MAX_TOKENS"
export MULLM_EVAL_SERVER_HOST="$SERVER_HOST"
export MULLM_EVAL_SERVER_PORT="$SERVER_PORT"
[[ -n "$API_KEY" ]] && export MULLM_EVAL_API_KEY="$API_KEY"
[[ -n "$MAX_SAMPLES" ]] && export MULLM_EVAL_MAX_SAMPLES="$MAX_SAMPLES"

exec python -m mullm.cli.main eval \
    --model-name "$MODEL_NAME" \
    --benchmarks "$BENCHMARKS" \
    --output-dir "$OUTPUT_DIR" \
    --cache-dir "$CACHE_DIR" \
    --num-gpus "$NUM_GPUS" \
    --batch-size "$BATCH_SIZE" \
    --timeout "$TIMEOUT" \
    --max-tokens "$MAX_TOKENS" \
    --server-host "$SERVER_HOST" \
    --server-port "$SERVER_PORT" \
    $([[ -n "$MAX_SAMPLES" ]] && echo "--max-samples $MAX_SAMPLES") \
    $([[ "$NO_CACHE" == "true" ]] && echo "--no-cache") \
    $([[ -n "$API_KEY" ]] && echo "--api-key $API_KEY")
