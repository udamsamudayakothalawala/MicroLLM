; ============================================================
; muLLM Installer - Inno Setup script (Option B)
; Produces: mullm-setup.exe  (native Windows installer)
;
; Requirements:
;   1. Download & install Inno Setup: https://jrsoftware.org/isdl.php
;   2. Ensure Python 3.10+ is installed on the target machine.
;
; To compile:
;   ISCC.exe mullm.iss
; ============================================================

#define MyAppName "muLLM"
#define MyAppVersion "0.1.0"
#define MyAppPublisher "Udam"
#define MyAppExeName "mullm.exe"
#define ProjectDir ".."

[Setup]
AppId={{8F4E3B22-7A2C-4D16-9B1E-muLLM}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppPublisher={#MyAppPublisher}
DefaultDirName={autopf}\muLLM
DefaultGroupName=muLLM
DisableProgramGroupPage=yes
OutputDir=..\dist
OutputBaseFilename=mullm-setup
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
PrivilegesRequired=admin
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
SetupIconFile=..\assets\mullm.ico
UninstallDisplayIcon={app}\boot\Scripts\mullm.exe

[Languages]
Name: "english"; MessagesFile: "compiler:Default.isl"

[Tasks]
Name: "desktopicon"; Description: "{cm:CreateDesktopIcon}"; GroupDescription: "{cm:AdditionalIcons}"; Flags: unchecked
Name: "pythoncheck"; Description: "Check Python 3.10+ is installed"; GroupDescription: "Prerequisites:"; Flags: checkedonce

[Files]
Source: "{#ProjectDir}\dist\mullm-{#MyAppVersion}-py3-none-any.whl"; DestDir: "{app}\wheel"; Flags: ignoreversion
Source: "{#ProjectDir}\install.bat"; DestDir: "{app}"; Flags: ignoreversion
Source: "{#ProjectDir}\assets\mullm.ico"; DestDir: "{app}\assets"; Flags: ignoreversion
Source: "{#ProjectDir}\assets\MULLMICON.png"; DestDir: "{app}\assets"; Flags: ignoreversion

[Icons]
Name: "{group}\muLLM GUI"; Filename: "{app}\boot\Scripts\mullm.exe"; Parameters: "gui"; WorkingDir: "{app}"; IconFilename: "{app}\assets\mullm.ico"
Name: "{group}\muLLM CLI"; Filename: "{app}\boot\Scripts\mullm.exe"; WorkingDir: "{app}"; IconFilename: "{app}\assets\mullm.ico"
Name: "{autodesktop}\muLLM GUI"; Filename: "{app}\boot\Scripts\mullm.exe"; Parameters: "gui"; WorkingDir: "{app}"; Tasks: desktopicon; IconFilename: "{app}\assets\mullm.ico"

[Registry]
Root: HKA; Subkey: "Software\Microsoft\Windows\CurrentVersion\Uninstall\muLLM"; ValueType: dword; ValueName: "EstimatedSize"; ValueData: 250000; Flags: uninsdeletevalue

[Run]
Filename: "py"; Parameters: "-3 -m venv ""{app}\boot"""; StatusMsg: "Creating Python environment..."; Flags: runhidden
Filename: "{app}\boot\Scripts\python.exe"; Parameters: "-m pip install --upgrade pip"; StatusMsg: "Upgrading pip..."; Flags: runhidden; Check: PythonInstalled
Filename: "{app}\boot\Scripts\python.exe"; Parameters: "-m pip install ""{app}\wheel\{#MyAppName}-{#MyAppVersion}-py3-none-any.whl"""; StatusMsg: "Installing muLLM core..."; Flags: runhidden; Check: PythonInstalled
Filename: "{app}\boot\Scripts\python.exe"; Parameters: "-m pip install PyQt5"; StatusMsg: "Installing GUI (PyQt5)..."; Flags: runhidden; Check: PythonInstalled
Filename: "{app}\boot\Scripts\mullm.exe"; Parameters: "--version"; StatusMsg: "Verifying installation..."; Flags: runhidden; Check: PythonInstalled

[Code]
function PythonInstalled(): Boolean;
var
  ResultCode: Integer;
begin
  Result := True;
  if FileExists(ExpandConstant('{app}\boot\Scripts\python.exe')) then
    Exit;
  if ExecAsOriginalUser('py', '-3 -c pass', '', 0, ewWaitUntilTerminated, ResultCode) then
    Result := (ResultCode = 0)
  else
    Result := False;
  if not Result then
    MsgBox('Python 3.10+ was not found. Please install Python 3.10 or newer from python.org, then run this installer again.', mbCriticalError, MB_OK);
end;

[UninstallDelete]
Type: filesandordirs; Name: "{app}\boot"
Type: filesandordirs; Name: "{app}\wheel"