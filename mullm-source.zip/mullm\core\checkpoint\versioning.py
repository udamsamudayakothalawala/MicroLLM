from __future__ import annotations

import copy
import datetime
import hashlib
import json
import logging
import os
import subprocess
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple, Union

logger = logging.getLogger(__name__)


@dataclass
class VersionInfo:
    version: str = "0.0.0"
    major: int = 0
    minor: int = 0
    patch: int = 0
    pre_release: Optional[str] = None
    build_metadata: Optional[str] = None

    @classmethod
    def parse(cls, version_str: str) -> VersionInfo:
        version_str = version_str.strip().lstrip("v")
        build_metadata = None
        if "+" in version_str:
            version_str, build_metadata = version_str.split("+", 1)
        pre_release = None
        if "-" in version_str:
            parts = version_str.split("-", 1)
            version_str = parts[0]
            pre_release = parts[1]
        version_parts = version_str.split(".")
        if len(version_parts) != 3:
            raise ValueError(f"Invalid version format: {version_str}. Expected MAJOR.MINOR.PATCH")
        major, minor, patch = int(version_parts[0]), int(version_parts[1]), int(version_parts[2])
        return cls(
            version=version_str,
            major=major,
            minor=minor,
            patch=patch,
            pre_release=pre_release,
            build_metadata=build_metadata,
        )

    def bump_major(self) -> VersionInfo:
        return VersionInfo(major=self.major + 1, minor=0, patch=0)

    def bump_minor(self) -> VersionInfo:
        return VersionInfo(major=self.major, minor=self.minor + 1, patch=0)

    def bump_patch(self) -> VersionInfo:
        return VersionInfo(major=self.major, minor=self.minor, patch=self.patch + 1)

    def __str__(self) -> str:
        version_str = f"{self.major}.{self.minor}.{self.patch}"
        if self.pre_release:
            version_str += f"-{self.pre_release}"
        if self.build_metadata:
            version_str += f"+{self.build_metadata}"
        return version_str

    def __gt__(self, other: VersionInfo) -> bool:
        return (self.major, self.minor, self.patch) > (other.major, other.minor, other.patch)

    def __lt__(self, other: VersionInfo) -> bool:
        return (self.major, self.minor, self.patch) < (other.major, other.minor, other.patch)

    def __ge__(self, other: VersionInfo) -> bool:
        return self == other or self > other

    def __le__(self, other: VersionInfo) -> bool:
        return self == other or self < other

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, VersionInfo):
            return False
        return (
            self.major == other.major
            and self.minor == other.minor
            and self.patch == other.patch
        )


@dataclass
class ExperimentTag:
    name: str
    description: str = ""
    created_at: str = ""
    metadata: Dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if not self.created_at:
            self.created_at = datetime.datetime.now(datetime.timezone.utc).isoformat()

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> ExperimentTag:
        valid_fields = {f.name for f in cls.__dataclass_fields__.values()}
        filtered = {k: v for k, v in data.items() if k in valid_fields}
        return cls(**filtered)


@dataclass
class CheckpointLineage:
    parent_checkpoint: Optional[str] = None
    child_checkpoints: List[str] = field(default_factory=list)
    derivation_method: str = ""
    derived_from_checkpoints: List[str] = field(default_factory=list)
    merge_weights: Optional[List[float]] = None
    operation: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> CheckpointLineage:
        valid_fields = {f.name for f in cls.__dataclass_fields__.values()}
        filtered = {k: v for k, v in data.items() if k in valid_fields}
        return cls(**filtered)


@dataclass
class CheckpointDiff:
    checkpoint_a: str = ""
    checkpoint_b: str = ""
    added_keys: List[str] = field(default_factory=list)
    removed_keys: List[str] = field(default_factory=list)
    modified_keys: List[str] = field(default_factory=list)
    identical_keys: List[str] = field(default_factory=list)
    parameter_differences: Dict[str, Dict[str, float]] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    @property
    def total_changes(self) -> int:
        return len(self.added_keys) + len(self.removed_keys) + len(self.modified_keys)

    @property
    def summary(self) -> str:
        return (
            f"Added: {len(self.added_keys)}, "
            f"Removed: {len(self.removed_keys)}, "
            f"Modified: {len(self.modified_keys)}, "
            f"Identical: {len(self.identical_keys)}"
        )


@dataclass
class TrainingRunMetadata:
    run_id: str = ""
    experiment_name: str = ""
    dataset_name: str = ""
    dataset_hash: str = ""
    model_architecture: str = ""
    hyperparameters: Dict[str, Any] = field(default_factory=dict)
    environment: Dict[str, str] = field(default_factory=dict)
    git_repo: str = ""
    git_branch: str = ""
    git_commit: str = ""
    start_time: str = ""
    end_time: str = ""
    total_steps: int = 0
    final_loss: float = float("inf")
    final_metrics: Dict[str, float] = field(default_factory=dict)
    notes: str = ""

    def __post_init__(self) -> None:
        if not self.start_time:
            self.start_time = datetime.datetime.now(datetime.timezone.utc).isoformat()

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> TrainingRunMetadata:
        valid_fields = {f.name for f in cls.__dataclass_fields__.values()}
        filtered = {k: v for k, v in data.items() if k in valid_fields}
        return cls(**filtered)


class CheckpointVersionManager:
    def __init__(self, base_dir: Union[str, Path]) -> None:
        self.base_dir = Path(base_dir)
        self.base_dir.mkdir(parents=True, exist_ok=True)
        self._versions: Dict[str, VersionInfo] = {}
        self._lineage: Dict[str, CheckpointLineage] = {}
        self._tags: Dict[str, ExperimentTag] = {}
        self._training_runs: Dict[str, TrainingRunMetadata] = {}
        self._version_history: Dict[str, List[str]] = {}
        self._load_state()

    def _state_file(self) -> Path:
        return self.base_dir / "version_state.json"

    def _load_state(self) -> None:
        state_file = self._state_file()
        if state_file.exists():
            try:
                with open(state_file, "r", encoding="utf-8") as f:
                    data = json.load(f)
                self._versions = {
                    k: VersionInfo(**v) for k, v in data.get("versions", {}).items()
                }
                self._lineage = {
                    k: CheckpointLineage.from_dict(v)
                    for k, v in data.get("lineage", {}).items()
                }
                self._tags = {
                    k: ExperimentTag.from_dict(v)
                    for k, v in data.get("tags", {}).items()
                }
                self._training_runs = {
                    k: TrainingRunMetadata.from_dict(v)
                    for k, v in data.get("training_runs", {}).items()
                }
                self._version_history = data.get("version_history", {})
            except Exception as e:
                logger.warning("Failed to load version state: %s", e)

    def _save_state(self) -> None:
        state = {
            "versions": {k: {"version": str(v), "major": v.major, "minor": v.minor, "patch": v.patch} for k, v in self._versions.items()},
            "lineage": {k: v.to_dict() for k, v in self._lineage.items()},
            "tags": {k: v.to_dict() for k, v in self._tags.items()},
            "training_runs": {k: v.to_dict() for k, v in self._training_runs.items()},
            "version_history": self._version_history,
        }
        tmp_file = self._state_file().with_suffix(".tmp")
        with open(tmp_file, "w", encoding="utf-8") as f:
            json.dump(state, f, indent=2, default=str)
        import shutil
        shutil.move(str(tmp_file), str(self._state_file()))

    def register_checkpoint(
        self,
        checkpoint_id: str,
        version: str = "1.0.0",
        parent_checkpoint: Optional[str] = None,
        tags: Optional[List[str]] = None,
    ) -> VersionInfo:
        ver = VersionInfo.parse(version)
        self._versions[checkpoint_id] = ver
        if checkpoint_id not in self._lineage:
            self._lineage[checkpoint_id] = CheckpointLineage(
                parent_checkpoint=parent_checkpoint,
                derivation_method="initial" if parent_checkpoint is None else "derived",
            )
        if parent_checkpoint and parent_checkpoint in self._lineage:
            self._lineage[parent_checkpoint].child_checkpoints.append(checkpoint_id)
        if tags:
            for tag_name in tags:
                if tag_name not in self._tags:
                    self._tags[tag_name] = ExperimentTag(name=tag_name)
        self._version_history.setdefault(checkpoint_id, []).append(str(ver))
        self._save_state()
        return ver

    def create_version(
        self,
        checkpoint_id: str,
        bump: str = "patch",
    ) -> VersionInfo:
        if checkpoint_id not in self._versions:
            raise KeyError(f"Checkpoint not found: {checkpoint_id}")
        current = self._versions[checkpoint_id]
        if bump == "major":
            new_ver = current.bump_major()
        elif bump == "minor":
            new_ver = current.bump_minor()
        elif bump == "patch":
            new_ver = current.bump_patch()
        else:
            raise ValueError(f"Invalid bump type: {bump}. Must be 'major', 'minor', or 'patch'")
        self._versions[checkpoint_id] = new_ver
        self._version_history.setdefault(checkpoint_id, []).append(str(new_ver))
        self._save_state()
        return new_ver

    def get_version(self, checkpoint_id: str) -> VersionInfo:
        if checkpoint_id not in self._versions:
            raise KeyError(f"Checkpoint not found: {checkpoint_id}")
        return self._versions[checkpoint_id]

    def get_lineage(self, checkpoint_id: str) -> CheckpointLineage:
        if checkpoint_id not in self._lineage:
            raise KeyError(f"Checkpoint lineage not found: {checkpoint_id}")
        return self._lineage[checkpoint_id]

    def track_derivation(
        self,
        checkpoint_id: str,
        parent_checkpoints: List[str],
        method: str,
        weights: Optional[List[float]] = None,
    ) -> None:
        lineage = CheckpointLineage(
            parent_checkpoint=parent_checkpoints[0] if parent_checkpoints else None,
            derived_from_checkpoints=parent_checkpoints,
            derivation_method=method,
            merge_weights=weights,
        )
        self._lineage[checkpoint_id] = lineage
        for parent_id in parent_checkpoints:
            if parent_id in self._lineage:
                self._lineage[parent_id].child_checkpoints.append(checkpoint_id)
        self._save_state()

    def get_ancestors(
        self,
        checkpoint_id: str,
        max_depth: Optional[int] = None,
    ) -> List[str]:
        ancestors: List[str] = []
        visited: Set[str] = set()
        queue = [checkpoint_id]
        depth = 0
        while queue:
            if max_depth is not None and depth >= max_depth:
                break
            next_queue: List[str] = []
            for cid in queue:
                if cid in visited:
                    continue
                visited.add(cid)
                if cid in self._lineage:
                    lineage = self._lineage[cid]
                    if lineage.parent_checkpoint:
                        ancestors.append(lineage.parent_checkpoint)
                        next_queue.append(lineage.parent_checkpoint)
                    for parent in lineage.derived_from_checkpoints:
                        if parent not in visited:
                            ancestors.append(parent)
                            next_queue.append(parent)
            queue = next_queue
            depth += 1
        return ancestors

    def get_descendants(
        self,
        checkpoint_id: str,
        max_depth: Optional[int] = None,
    ) -> List[str]:
        descendants: List[str] = []
        visited: Set[str] = set()
        queue = [checkpoint_id]
        depth = 0
        while queue:
            if max_depth is not None and depth >= max_depth:
                break
            next_queue: List[str] = []
            for cid in queue:
                if cid in visited:
                    continue
                visited.add(cid)
                if cid in self._lineage:
                    for child in self._lineage[cid].child_checkpoints:
                        descendants.append(child)
                        next_queue.append(child)
            queue = next_queue
            depth += 1
        return descendants

    def add_tag(
        self,
        checkpoint_id: str,
        tag_name: str,
        description: str = "",
        metadata: Optional[Dict[str, Any]] = None,
    ) -> ExperimentTag:
        if tag_name not in self._tags:
            self._tags[tag_name] = ExperimentTag(
                name=tag_name,
                description=description,
                metadata=metadata or {},
            )
        return self._tags[tag_name]

    def get_checkpoints_by_tag(self, tag_name: str) -> List[str]:
        if tag_name not in self._tags:
            return []
        return [cid for cid, lineage in self._lineage.items()
                if tag_name in self._get_checkpoint_tags(cid)]

    def _get_checkpoint_tags(self, checkpoint_id: str) -> List[str]:
        tags: List[str] = []
        for tag_name in self._tags:
            tag_checkpoints = self.get_checkpoints_by_tag(tag_name)
            if checkpoint_id in tag_checkpoints:
                tags.append(tag_name)
        return tags

    def record_training_run(
        self,
        run_id: str,
        metadata: Optional[TrainingRunMetadata] = None,
    ) -> TrainingRunMetadata:
        if metadata is None:
            metadata = TrainingRunMetadata(run_id=run_id)
        metadata.run_id = run_id
        env_info = {
            "PYTHONPATH": os.environ.get("PYTHONPATH", ""),
            "CUDA_VISIBLE_DEVICES": os.environ.get("CUDA_VISIBLE_DEVICES", ""),
            "HOME": os.environ.get("HOME", ""),
        }
        metadata.environment = env_info
        git_info = self._get_git_info()
        metadata.git_repo = git_info.get("repo", "")
        metadata.git_branch = git_info.get("branch", "")
        metadata.git_commit = git_info.get("commit", "")
        self._training_runs[run_id] = metadata
        self._save_state()
        return metadata

    def get_training_run(self, run_id: str) -> TrainingRunMetadata:
        if run_id not in self._training_runs:
            raise KeyError(f"Training run not found: {run_id}")
        return self._training_runs[run_id]

    def _get_git_info(self) -> Dict[str, str]:
        info: Dict[str, str] = {}
        try:
            result = subprocess.run(
                ["git", "rev-parse", "--show-toplevel"],
                capture_output=True,
                text=True,
                timeout=5,
            )
            if result.returncode == 0:
                info["repo"] = result.stdout.strip()
            result = subprocess.run(
                ["git", "rev-parse", "--abbrev-ref", "HEAD"],
                capture_output=True,
                text=True,
                timeout=5,
            )
            if result.returncode == 0:
                info["branch"] = result.stdout.strip()
            result = subprocess.run(
                ["git", "rev-parse", "HEAD"],
                capture_output=True,
                text=True,
                timeout=5,
            )
            if result.returncode == 0:
                info["commit"] = result.stdout.strip()
        except Exception:
            pass
        return info

    def diff_checkpoints(
        self,
        checkpoint_a: Path,
        checkpoint_b: Path,
        param_name_filter: Optional[str] = None,
    ) -> CheckpointDiff:
        import torch
        sd_a = self._load_state_dict_from_path(checkpoint_a)
        sd_b = self._load_state_dict_from_path(checkpoint_b)
        diff = CheckpointDiff(
            checkpoint_a=str(checkpoint_a),
            checkpoint_b=str(checkpoint_b),
        )
        keys_a = set(sd_a.keys())
        keys_b = set(sd_b.keys())
        diff.added_keys = sorted(keys_b - keys_a)
        diff.removed_keys = sorted(keys_a - keys_b)
        common_keys = keys_a & keys_b
        for key in sorted(common_keys):
            if param_name_filter and param_name_filter not in key:
                continue
            tensor_a = sd_a[key]
            tensor_b = sd_b[key]
            if torch.equal(tensor_a, tensor_b):
                diff.identical_keys.append(key)
            else:
                diff.modified_keys.append(key)
                abs_diff = (tensor_a.float() - tensor_b.float()).abs()
                param_diff = {
                    "mean_abs_diff": float(abs_diff.mean()),
                    "max_abs_diff": float(abs_diff.max()),
                    "cosine_similarity": float(
                        torch.nn.functional.cosine_similarity(
                            tensor_a.float().flatten().unsqueeze(0),
                            tensor_b.float().flatten().unsqueeze(0),
                        )
                    ),
                    "l2_distance": float(torch.norm((tensor_a.float() - tensor_b.float()).flatten())),
                    "size_a": float(tensor_a.numel()),
                    "size_b": float(tensor_b.numel()),
                }
                diff.parameter_differences[key] = param_diff
        return diff

    def _load_state_dict_from_path(self, path: Path) -> Dict[str, Any]:
        import torch
        if path.is_file():
            return torch.load(str(path), map_location="cpu", weights_only=False)
        bin_file = path / "pytorch_model.bin"
        if bin_file.exists():
            return torch.load(str(bin_file), map_location="cpu", weights_only=False)
        safetensors_file = path / "model.safetensors"
        if safetensors_file.exists():
            try:
                from safetensors.torch import load_file
                return load_file(str(safetensors_file))
            except ImportError:
                pass
        checkpoint_file = path / "checkpoint.pt"
        if checkpoint_file.exists():
            data = torch.load(str(checkpoint_file), map_location="cpu", weights_only=False)
            if isinstance(data, dict) and "model" in data:
                return data["model"]
            return data
        raise FileNotFoundError(f"Could not load state dict from {path}")

    def rollback(
        self,
        checkpoint_id: str,
        to_version: Optional[str] = None,
    ) -> VersionInfo:
        if checkpoint_id not in self._versions:
            raise KeyError(f"Checkpoint not found: {checkpoint_id}")
        if to_version is not None:
            target_version = VersionInfo.parse(to_version)
            self._versions[checkpoint_id] = target_version
            self._version_history.setdefault(checkpoint_id, []).append(str(target_version))
        else:
            history = self._version_history.get(checkpoint_id, [])
            if len(history) < 2:
                raise ValueError(f"No previous version to rollback to for {checkpoint_id}")
            previous_version_str = history[-2]
            previous_version = VersionInfo.parse(previous_version_str)
            self._versions[checkpoint_id] = previous_version
            history.append(str(previous_version))
            self._version_history[checkpoint_id] = history
        self._save_state()
        return self._versions[checkpoint_id]

    def list_versions(self, checkpoint_id: str) -> List[VersionInfo]:
        history = self._version_history.get(checkpoint_id, [])
        return [VersionInfo.parse(v) for v in history]

    def compare_versions(
        self,
        checkpoint_id: str,
        version_a: str,
        version_b: str,
    ) -> Dict[str, bool]:
        a = VersionInfo.parse(version_a)
        b = VersionInfo.parse(version_b)
        return {
            "a_greater": a > b,
            "a_less": a < b,
            "equal": a == b,
            "a_greater_or_equal": a >= b,
            "a_less_or_equal": a <= b,
        }

    def list_all_checkpoints(self) -> List[Dict[str, Any]]:
        result: List[Dict[str, Any]] = []
        for cid, ver in self._versions.items():
            lineage = self._lineage.get(cid, CheckpointLineage())
            entry = {
                "checkpoint_id": cid,
                "version": str(ver),
                "parent": lineage.parent_checkpoint,
                "derivation_method": lineage.derivation_method,
                "derived_from": lineage.derived_from_checkpoints,
                "children": lineage.child_checkpoints,
                "tags": self._get_checkpoint_tags(cid),
            }
            result.append(entry)
        return result

    def get_checkpoint_tree(
        self,
        root_checkpoint: Optional[str] = None,
    ) -> Dict[str, Any]:
        if root_checkpoint is None:
            all_roots = [
                cid for cid, lineage in self._lineage.items()
                if lineage.parent_checkpoint is None and not lineage.derived_from_checkpoints
            ]
            if not all_roots:
                all_roots = list(self._versions.keys())
            if all_roots:
                root_checkpoint = all_roots[0]
            else:
                return {}
        tree: Dict[str, Any] = {
            "checkpoint_id": root_checkpoint,
            "version": str(self._versions.get(root_checkpoint, VersionInfo())),
            "children": [],
        }
        if root_checkpoint in self._lineage:
            for child_id in self._lineage[root_checkpoint].child_checkpoints:
                child_tree = self.get_checkpoint_tree(child_id)
                if child_tree:
                    tree["children"].append(child_tree)
        return tree

    def export_metadata(
        self,
        output_path: Union[str, Path],
    ) -> None:
        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        data = {
            "versions": {k: str(v) for k, v in self._versions.items()},
            "lineage": {k: v.to_dict() for k, v in self._lineage.items()},
            "tags": {k: v.to_dict() for k, v in self._tags.items()},
            "training_runs": {k: v.to_dict() for k, v in self._training_runs.items()},
            "version_history": self._version_history,
            "exported_at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        }
        with open(output_path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, default=str)

    def import_metadata(self, input_path: Union[str, Path]) -> None:
        input_path = Path(input_path)
        if not input_path.exists():
            raise FileNotFoundError(f"Metadata file not found: {input_path}")
        with open(input_path, "r", encoding="utf-8") as f:
            data = json.load(f)
        for k, v in data.get("versions", {}).items():
            self._versions[k] = VersionInfo.parse(v) if isinstance(v, str) else VersionInfo(**v)
        for k, v in data.get("lineage", {}).items():
            self._lineage[k] = CheckpointLineage.from_dict(v)
        for k, v in data.get("tags", {}).items():
            self._tags[k] = ExperimentTag.from_dict(v)
        for k, v in data.get("training_runs", {}).items():
            self._training_runs[k] = TrainingRunMetadata.from_dict(v)
        self._version_history.update(data.get("version_history", {}))
        self._save_state()

    def delete_checkpoint(self, checkpoint_id: str) -> None:
        if checkpoint_id in self._versions:
            del self._versions[checkpoint_id]
        if checkpoint_id in self._lineage:
            parent = self._lineage[checkpoint_id].parent_checkpoint
            if parent and parent in self._lineage:
                if checkpoint_id in self._lineage[parent].child_checkpoints:
                    self._lineage[parent].child_checkpoints.remove(checkpoint_id)
            del self._lineage[checkpoint_id]
        if checkpoint_id in self._version_history:
            del self._version_history[checkpoint_id]
        self._save_state()


__all__ = [
    "VersionInfo",
    "ExperimentTag",
    "CheckpointLineage",
    "CheckpointDiff",
    "TrainingRunMetadata",
    "CheckpointVersionManager",
]
