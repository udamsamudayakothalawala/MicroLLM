"""
simple_eval.py - Lightweight evaluation: loss, perplexity, accuracy.
No benchmark suite, just core metrics.
"""

import math
from typing import Optional

import torch
from torch.utils.data import DataLoader


def compute_loss(model, dataset, batch_size: int = 8, device: torch.device = None) -> float:
    if device is None:
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    loader = DataLoader(dataset, batch_size=batch_size, shuffle=False)
    model.eval()
    total_loss = 0.0
    total_batches = 0
    with torch.no_grad():
        for batch in loader:
            input_ids = batch["input_ids"].to(device)
            labels = batch["labels"].to(device)
            outputs = model(input_ids=input_ids, labels=labels)
            total_loss += outputs["loss"].item()
            total_batches += 1
    model.train()
    return total_loss / max(total_batches, 1)


def compute_perplexity(model, dataset, batch_size: int = 8, device: torch.device = None) -> float:
    loss = compute_loss(model, dataset, batch_size, device)
    return math.exp(min(loss, 20))


def compute_accuracy(model, dataset, batch_size: int = 8, device: torch.device = None) -> float:
    if device is None:
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    loader = DataLoader(dataset, batch_size=batch_size, shuffle=False)
    model.eval()
    correct = 0
    total = 0
    with torch.no_grad():
        for batch in loader:
            input_ids = batch["input_ids"].to(device)
            labels = batch["labels"].to(device)
            outputs = model(input_ids=input_ids)
            logits = outputs["logits"]
            preds = logits.argmax(dim=-1)
            mask = labels != 0
            correct += ((preds == labels) & mask).sum().item()
            total += mask.sum().item()
    model.train()
    return correct / max(total, 1)


def evaluate(model, dataset, batch_size: int = 8, device: torch.device = None) -> dict:
    loss = compute_loss(model, dataset, batch_size, device)
    perplexity = math.exp(min(loss, 20))
    accuracy = compute_accuracy(model, dataset, batch_size, device)
    return {
        "loss": round(loss, 4),
        "perplexity": round(perplexity, 2),
        "accuracy": round(accuracy, 4),
    }