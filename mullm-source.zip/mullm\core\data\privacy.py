"""PII detection and removal with regex-based patterns and redaction strategies."""

from __future__ import annotations

import hashlib
import logging
import re
from dataclasses import dataclass, field
from enum import Enum
from typing import Optional

logger = logging.getLogger(__name__)


class RedactionStrategy(Enum):
    MASK = "mask"
    REPLACE = "replace"
    REMOVE = "remove"
    HASH = "hash"
    PARTIAL = "partial"


class PIICategory(Enum):
    EMAIL = "email"
    PHONE = "phone"
    IP_ADDRESS = "ip_address"
    CREDIT_CARD = "credit_card"
    SSN = "ssn"
    PASSPORT = "passport"
    DRIVERS_LICENSE = "drivers_license"
    URL = "url"
    NAME = "name"
    ADDRESS = "address"
    DATE_OF_BIRTH = "date_of_birth"


@dataclass
class PIIDetection:
    """A detected PII instance."""

    category: PIICategory
    value: str
    start: int
    end: int
    confidence: float
    redacted_value: Optional[str] = None


@dataclass
class PrivacyConfig:
    """Configuration for PII detection and removal."""

    enabled_categories: tuple[PIICategory, ...] = tuple(PIICategory)
    redaction_strategy: RedactionStrategy = RedactionStrategy.MASK
    replacement_text: str = "[REDACTED]"
    mask_char: str = "*"
    mask_visible_chars: int = 0
    hash_algorithm: str = "sha256"
    min_confidence: float = 0.8
    preserve_format: bool = False
    custom_patterns: dict[str, str] = field(default_factory=dict)
    custom_replacements: dict[str, str] = field(default_factory=dict)
    differential_privacy_epsilon: Optional[float] = None


class PIIPatterns:
    """Regex patterns for PII detection."""

    EMAIL = re.compile(
        r"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b"
    )

    PHONE_US = re.compile(
        r"(?:\+?1[-.\s]?)?\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}\b"
    )
    PHONE_INTL = re.compile(
        r"\+\d{1,3}[-.\s]?\d{1,4}[-.\s]?\d{2,4}[-.\s]?\d{2,4}\b"
    )

    IPV4 = re.compile(
        r"\b(?:\d{1,3}\.){3}\d{1,3}\b"
    )
    IPV6 = re.compile(
        r"\b(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}\b"
    )

    CREDIT_CARD = re.compile(
        r"\b(?:\d{4}[-\s]?){3}\d{4}\b"
    )

    SSN = re.compile(
        r"\b\d{3}[-.\s]?\d{2}[-.\s]?\d{4}\b"
    )

    PASSPORT_US = re.compile(
        r"\b[A-Z]{1,2}\d{6,9}\b"
    )
    PASSPORTGeneric = re.compile(
        r"\b\d{8,9}\b"
    )

    DRIVERS_LICENSE_US = re.compile(
        r"\b[A-Z]\d{7,14}\b"
    )

    URL_PATTERN = re.compile(
        r"https?://[^\s<>\"']+|www\.[^\s<>\"']+"
    )


class PIIDetector:
    """Detects PII in text using regex patterns."""

    CREDIT_CARD_LUHN_WEIGHTS = [2, 1] * 8

    @staticmethod
    def _luhn_check(number: str) -> bool:
        digits = [int(d) for d in number if d.isdigit()]
        if len(digits) < 13 or len(digits) > 19:
            return False
        checksum = 0
        for i, digit in enumerate(reversed(digits)):
            weight = PIIDetector.CREDIT_CARD_LUHN_WEIGHTS[i % 2]
            product = digit * weight
            checksum += product // 10 + product % 10
        return checksum % 10 == 0

    @staticmethod
    def _is_valid_ip(text: str) -> bool:
        parts = text.split(".")
        if len(parts) != 4:
            return False
        return all(0 <= int(p) <= 255 for p in parts)

    @staticmethod
    def _ssn_is_valid(text: str) -> bool:
        digits = re.sub(r"\D", "", text)
        if len(digits) != 9:
            return False
        if digits[:3] == "000" or digits[3:5] == "00" or digits[5:] == "0000":
            return False
        if digits[:3] == "666" or digits[:3] >= "900":
            return False
        return True

    def detect(self, text: str, categories: tuple[PIICategory, ...] = tuple(PIICategory)) -> list[PIIDetection]:
        detections: list[PIIDetection] = []

        if PIICategory.EMAIL in categories:
            for match in PIIPatterns.EMAIL.finditer(text):
                detections.append(PIIDetection(
                    category=PIICategory.EMAIL,
                    value=match.group(),
                    start=match.start(),
                    end=match.end(),
                    confidence=0.95,
                ))

        if PIICategory.PHONE in categories:
            for match in PIIPatterns.PHONE_US.finditer(text):
                phone = match.group()
                digits = re.sub(r"\D", "", phone)
                if len(digits) >= 10:
                    detections.append(PIIDetection(
                        category=PIICategory.PHONE,
                        value=phone,
                        start=match.start(),
                        end=match.end(),
                        confidence=0.9,
                    ))
            for match in PIIPatterns.PHONE_INTL.finditer(text):
                if match.group() not in [d.value for d in detections]:
                    detections.append(PIIDetection(
                        category=PIICategory.PHONE,
                        value=match.group(),
                        start=match.start(),
                        end=match.end(),
                        confidence=0.85,
                    ))

        if PIICategory.IP_ADDRESS in categories:
            for match in PIIPatterns.IPV4.finditer(text):
                if self._is_valid_ip(match.group()):
                    detections.append(PIIDetection(
                        category=PIICategory.IP_ADDRESS,
                        value=match.group(),
                        start=match.start(),
                        end=match.end(),
                        confidence=0.9,
                    ))
            for match in PIIPatterns.IPV6.finditer(text):
                detections.append(PIIDetection(
                    category=PIICategory.IP_ADDRESS,
                    value=match.group(),
                    start=match.start(),
                    end=match.end(),
                    confidence=0.85,
                ))

        if PIICategory.CREDIT_CARD in categories:
            for match in PIIPatterns.CREDIT_CARD.finditer(text):
                card = match.group()
                digits_only = re.sub(r"\D", "", card)
                if self._luhn_check(digits_only):
                    detections.append(PIIDetection(
                        category=PIICategory.CREDIT_CARD,
                        value=card,
                        start=match.start(),
                        end=match.end(),
                        confidence=0.95,
                    ))

        if PIICategory.SSN in categories:
            for match in PIIPatterns.SSN.finditer(text):
                ssn = match.group()
                if self._ssn_is_valid(ssn):
                    detections.append(PIIDetection(
                        category=PIICategory.SSN,
                        value=ssn,
                        start=match.start(),
                        end=match.end(),
                        confidence=0.9,
                    ))

        if PIICategory.PASSPORT in categories:
            for match in PIIPatterns.PASSPORT_US.finditer(text):
                detections.append(PIIDetection(
                    category=PIICategory.PASSPORT,
                    value=match.group(),
                    start=match.start(),
                    end=match.end(),
                    confidence=0.7,
                ))

        if PIICategory.DRIVERS_LICENSE in categories:
            for match in PIIPatterns.DRIVERS_LICENSE_US.finditer(text):
                dl = match.group()
                if len(dl) >= 8:
                    detections.append(PIIDetection(
                        category=PIICategory.DRIVERS_LICENSE,
                        value=dl,
                        start=match.start(),
                        end=match.end(),
                        confidence=0.7,
                    ))

        if PIICategory.URL in categories:
            for match in PIIPatterns.URL_PATTERN.finditer(text):
                detections.append(PIIDetection(
                    category=PIICategory.URL,
                    value=match.group(),
                    start=match.start(),
                    end=match.end(),
                    confidence=0.95,
                ))

        detections.sort(key=lambda d: d.start)
        return detections


class PIIAnonymizer:
    """Redacts or anonymizes detected PII."""

    def __init__(self, config: Optional[PrivacyConfig] = None) -> None:
        self.config = config or PrivacyConfig()
        self._detector = PIIDetector()

    def _mask_value(self, value: str) -> str:
        if self.config.mask_visible_chars > 0:
            visible = value[: self.config.mask_visible_chars]
            masked = self.config.mask_char * max(0, len(value) - self.config.mask_visible_chars)
            return visible + masked
        return self.config.mask_char * len(value)

    def _partial_redact(self, value: str) -> str:
        if len(value) <= 4:
            return self.config.mask_char * len(value)
        visible = 2
        start = value[:visible]
        end = value[-visible:]
        middle = self.config.mask_char * (len(value) - visible * 2)
        return start + middle + end

    def _hash_value(self, value: str) -> str:
        h = hashlib.new(self.config.hash_algorithm)
        h.update(value.encode("utf-8"))
        return f"[HASH:{h.hexdigest()[:12]}]"

    def _replace_value(self, value: str, category: PIICategory) -> str:
        custom = self.config.custom_replacements.get(category.value)
        if custom:
            return custom
        return self.config.replacement_text

    def redact(self, text: str) -> tuple[str, list[PIIDetection]]:
        detections = self._detector.detect(text, self.config.enabled_categories)

        filtered = [d for d in detections if d.confidence >= self.config.min_confidence]

        redacted = text
        offset = 0
        for detection in filtered:
            strategy = self.config.redaction_strategy
            if strategy == RedactionStrategy.MASK:
                replacement = self._mask_value(detection.value)
            elif strategy == RedactionStrategy.PARTIAL:
                replacement = self._partial_redact(detection.value)
            elif strategy == RedactionStrategy.REPLACE:
                replacement = self._replace_value(detection.value, detection.category)
            elif strategy == RedactionStrategy.HASH:
                replacement = self._hash_value(detection.value)
            elif strategy == RedactionStrategy.REMOVE:
                replacement = ""
            else:
                replacement = self.config.replacement_text

            detection.redacted_value = replacement
            start = detection.start + offset
            end = detection.end + offset
            redacted = redacted[:start] + replacement + redacted[end:]
            offset += len(replacement) - (detection.end - detection.start)

        return redacted, filtered

    def redact_batch(self, texts: list[str]) -> list[tuple[str, list[PIIDetection]]]:
        return [self.redact(text) for text in texts]

    def get_pii_count(self, text: str) -> dict[str, int]:
        detections = self._detector.detect(text, self.config.enabled_categories)
        counts: dict[str, int] = {}
        for d in detections:
            cat = d.category.value
            counts[cat] = counts.get(cat, 0) + 1
        return counts

    def has_pii(self, text: str) -> bool:
        detections = self._detector.detect(text, self.config.enabled_categories)
        return any(d.confidence >= self.config.min_confidence for d in detections)
