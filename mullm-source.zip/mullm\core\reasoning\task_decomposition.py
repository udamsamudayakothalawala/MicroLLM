"""Task decomposition system for hierarchical task breakdown."""

from __future__ import annotations

import json
import time
import uuid
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any, Callable, Dict, List, Optional, Set, Tuple


class NodeStatus(Enum):
    PENDING = "pending"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    FAILED = "failed"
    BLOCKED = "blocked"


class DecompositionStrategy(Enum):
    TOP_DOWN = "top_down"
    BOTTOM_UP = "bottom_up"
    FUNCTIONAL = "functional"
    SEQUENTIAL = "sequential"


@dataclass
class DecompositionNode:
    id: str = field(default_factory=lambda: str(uuid.uuid4())[:8])
    title: str = ""
    description: str = ""
    parent_id: Optional[str] = None
    children: List[str] = field(default_factory=list)
    dependencies: List[str] = field(default_factory=list)
    status: NodeStatus = NodeStatus.PENDING
    depth: int = 0
    effort_estimate: Optional[float] = None
    assigned_to: Optional[str] = None
    result: Optional[Any] = None
    error: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "title": self.title,
            "description": self.description,
            "parent_id": self.parent_id,
            "children": self.children,
            "dependencies": self.dependencies,
            "status": self.status.value,
            "depth": self.depth,
            "effort_estimate": self.effort_estimate,
            "assigned_to": self.assigned_to,
            "result": self.result,
            "error": self.error,
            "metadata": self.metadata,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "DecompositionNode":
        return cls(
            id=data.get("id", ""),
            title=data.get("title", ""),
            description=data.get("description", ""),
            parent_id=data.get("parent_id"),
            children=data.get("children", []),
            dependencies=data.get("dependencies", []),
            status=NodeStatus(data.get("status", "pending")),
            depth=data.get("depth", 0),
            effort_estimate=data.get("effort_estimate"),
            assigned_to=data.get("assigned_to"),
            result=data.get("result"),
            error=data.get("error"),
            metadata=data.get("metadata", {}),
        )


@dataclass
class DecompositionResult:
    root_id: str = ""
    nodes: Dict[str, DecompositionNode] = field(default_factory=dict)
    goal: str = ""
    strategy: DecompositionStrategy = DecompositionStrategy.TOP_DOWN
    created_at: datetime = field(default_factory=datetime.utcnow)
    completed_at: Optional[datetime] = None

    @property
    def root(self) -> Optional[DecompositionNode]:
        return self.nodes.get(self.root_id)

    @property
    def leaf_nodes(self) -> List[DecompositionNode]:
        return [n for n in self.nodes.values() if not n.children]

    @property
    def completed_nodes(self) -> List[DecompositionNode]:
        return [n for n in self.nodes.values() if n.status == NodeStatus.COMPLETED]

    @property
    def failed_nodes(self) -> List[DecompositionNode]:
        return [n for n in self.nodes.values() if n.status == NodeStatus.FAILED]

    @property
    def progress(self) -> float:
        if not self.nodes:
            return 0.0
        completed = len(self.completed_nodes)
        return completed / len(self.nodes)

    @property
    def depth(self) -> int:
        if not self.nodes:
            return 0
        return max(n.depth for n in self.nodes.values())

    def get_children(self, node_id: str) -> List[DecompositionNode]:
        node = self.nodes.get(node_id)
        if not node:
            return []
        return [self.nodes[cid] for cid in node.children if cid in self.nodes]

    def get_ancestors(self, node_id: str) -> List[DecompositionNode]:
        ancestors: List[DecompositionNode] = []
        current = self.nodes.get(node_id)
        while current and current.parent_id:
            parent = self.nodes.get(current.parent_id)
            if parent:
                ancestors.append(parent)
                current = parent
            else:
                break
        return ancestors

    def to_dict(self) -> Dict[str, Any]:
        return {
            "root_id": self.root_id,
            "nodes": {k: v.to_dict() for k, v in self.nodes.items()},
            "goal": self.goal,
            "strategy": self.strategy.value,
            "created_at": self.created_at.isoformat(),
            "completed_at": self.completed_at.isoformat() if self.completed_at else None,
            "progress": self.progress,
            "depth": self.depth,
        }


class DependencyGraph:
    def __init__(self, nodes: Optional[Dict[str, DecompositionNode]] = None) -> None:
        self.nodes: Dict[str, DecompositionNode] = nodes or {}

    def add_node(self, node: DecompositionNode) -> None:
        self.nodes[node.id] = node

    def get_dependents(self, node_id: str) -> List[DecompositionNode]:
        return [
            n for n in self.nodes.values()
            if node_id in n.dependencies
        ]

    def get_dependencies(self, node_id: str) -> List[DecompositionNode]:
        node = self.nodes.get(node_id)
        if not node:
            return []
        return [self.nodes[d] for d in node.dependencies if d in self.nodes]

    def get_ready_nodes(self) -> List[DecompositionNode]:
        ready: List[DecompositionNode] = []
        for node in self.nodes.values():
            if node.status != NodeStatus.PENDING:
                continue
            deps_met = all(
                self.nodes.get(d) and self.nodes[d].status == NodeStatus.COMPLETED
                for d in node.dependencies
            )
            if deps_met:
                ready.append(node)
        return ready

    def get_parallel_groups(self) -> List[List[DecompositionNode]]:
        levels: Dict[int, List[DecompositionNode]] = {}
        for node in self.nodes.values():
            level = self._compute_level(node.id)
            if level not in levels:
                levels[level] = []
            levels[level].append(node)
        return [levels[l] for l in sorted(levels.keys())]

    def _compute_level(self, node_id: str) -> int:
        node = self.nodes.get(node_id)
        if not node or not node.dependencies:
            return 0
        max_dep_level = 0
        for dep_id in node.dependencies:
            dep_level = self._compute_level(dep_id)
            max_dep_level = max(max_dep_level, dep_level)
        return max_dep_level + 1

    def has_cycle(self) -> bool:
        visited: Set[str] = set()
        in_stack: Set[str] = set()

        def _dfs(node_id: str) -> bool:
            visited.add(node_id)
            in_stack.add(node_id)
            node = self.nodes.get(node_id)
            if node:
                for dep_id in node.dependencies:
                    if dep_id not in visited:
                        if _dfs(dep_id):
                            return True
                    elif dep_id in in_stack:
                        return True
            in_stack.discard(node_id)
            return False

        for node_id in self.nodes:
            if node_id not in visited:
                if _dfs(node_id):
                    return True
        return False

    def topological_sort(self) -> List[DecompositionNode]:
        visited: Set[str] = set()
        sorted_nodes: List[DecompositionNode] = []

        def _visit(node_id: str) -> None:
            if node_id in visited:
                return
            visited.add(node_id)
            node = self.nodes.get(node_id)
            if node:
                for dep_id in node.dependencies:
                    _visit(dep_id)
                sorted_nodes.append(node)

        for node_id in self.nodes:
            _visit(node_id)

        return sorted_nodes

    def to_dict(self) -> Dict[str, Any]:
        return {
            "nodes": {k: v.to_dict() for k, v in self.nodes.items()},
            "has_cycle": self.has_cycle(),
        }


class TaskDecomposer:
    def __init__(
        self,
        llm_generate: Optional[Callable[[str], str]] = None,
        strategy: DecompositionStrategy = DecompositionStrategy.TOP_DOWN,
        max_depth: int = 5,
        max_breadth: int = 10,
    ) -> None:
        self.llm_generate = llm_generate
        self.strategy = strategy
        self.max_depth = max_depth
        self.max_breadth = max_breadth

    def decompose(self, task: str, context: Optional[Dict[str, Any]] = None) -> DecompositionResult:
        result = DecompositionResult(goal=task, strategy=self.strategy)

        root = DecompositionNode(
            title=task,
            description=f"Overall goal: {task}",
            depth=0,
        )
        result.root_id = root.id
        result.nodes[root.id] = root

        self._expand_node(root, result, context, depth=1)
        return result

    def _expand_node(
        self,
        node: DecompositionNode,
        result: DecompositionResult,
        context: Optional[Dict[str, Any]] = None,
        depth: int = 1,
    ) -> None:
        if depth > self.max_depth:
            return

        children = self._generate_subtasks(node, result, context)

        for child_data in children[:self.max_breadth]:
            child = DecompositionNode(
                title=child_data.get("title", ""),
                description=child_data.get("description", ""),
                parent_id=node.id,
                dependencies=child_data.get("dependencies", []),
                depth=depth,
                effort_estimate=child_data.get("effort_estimate"),
                metadata=child_data.get("metadata", {}),
            )
            result.nodes[child.id] = child
            node.children.append(child.id)

            has_subtasks = child_data.get("has_subtasks", depth < self.max_depth)
            if has_subtasks:
                self._expand_node(child, result, context, depth + 1)

    def _generate_subtasks(
        self,
        node: DecompositionNode,
        result: DecompositionResult,
        context: Optional[Dict[str, Any]] = None,
    ) -> List[Dict[str, Any]]:
        if self.llm_generate:
            prompt = self._build_decomposition_prompt(node, result, context)
            try:
                response = self.llm_generate(prompt)
                return self._parse_subtasks(response)
            except Exception:
                pass
        return self._default_subtasks(node)

    def _build_decomposition_prompt(
        self,
        node: DecompositionNode,
        result: DecompositionResult,
        context: Optional[Dict[str, Any]] = None,
    ) -> str:
        ancestors = result.get_ancestors(node.id)
        hierarchy = " -> ".join([result.goal] + [a.title for a in reversed(ancestors)] + [node.title])

        existing_titles = [n.title for n in result.nodes.values()]
        prompt = (
            f"Decompose this task into subtasks:\n\n"
            f"Task hierarchy: {hierarchy}\n"
            f"Task description: {node.description}\n"
        )
        if context:
            prompt += f"Context: {json.dumps(context, indent=2)}\n"

        prompt += (
            "\nReturn a JSON list of subtasks. Each subtask must have:\n"
            '  - "title": short name\n'
            '  - "description": what to do\n'
            '  - "dependencies": list of sibling subtask titles this depends on (or [])\n'
            '  - "has_subtasks": true/false (whether this can be broken down further)\n'
            '  - "effort_estimate": estimated effort 1-10 (optional)\n'
            "\n"
            "Current sibling tasks: " + ", ".join(
                result.nodes[child].title
                for child in node.children
                if child in result.nodes
            ) + "\n\n"
            "Return valid JSON only:\n"
            "```json\n[{\"title\": \"...\", \"description\": \"...\", \"dependencies\": [], \"has_subtasks\": false}]\n```"
        )
        return prompt

    def _parse_subtasks(self, response: str) -> List[Dict[str, Any]]:
        import re
        json_match = None
        for pattern in (r'```json\s*(.*?)\s*```', r'```\s*(.*?)\s*```', r'(\[.*?\])'):
            match = re.search(pattern, response, re.DOTALL)
            if match:
                json_match = match.group(1)
                break

        if json_match is None:
            json_match = response.strip()

        try:
            data = json.loads(json_match)
            if isinstance(data, list):
                return data
        except (json.JSONDecodeError, TypeError):
            pass
        return []

    def _default_subtasks(self, node: DecompositionNode) -> List[Dict[str, Any]]:
        return [
            {
                "title": f"Analyze: {node.title}",
                "description": f"Analyze requirements for: {node.title}",
                "dependencies": [],
                "has_subtasks": False,
                "effort_estimate": 3,
            },
            {
                "title": f"Execute: {node.title}",
                "description": f"Execute the main work for: {node.title}",
                "dependencies": [f"Analyze: {node.title}"],
                "has_subtasks": True,
                "effort_estimate": 5,
            },
            {
                "title": f"Verify: {node.title}",
                "description": f"Verify the results of: {node.title}",
                "dependencies": [f"Execute: {node.title}"],
                "has_subtasks": False,
                "effort_estimate": 2,
            },
        ]


class RecursiveDecomposer(TaskDecomposer):
    def __init__(
        self,
        llm_generate: Optional[Callable[[str], str]] = None,
        max_depth: int = 5,
        min_task_size: int = 1,
    ) -> None:
        super().__init__(
            llm_generate=llm_generate,
            strategy=DecompositionStrategy.TOP_DOWN,
            max_depth=max_depth,
        )
        self.min_task_size = min_task_size

    def decompose_until_atomic(
        self,
        task: str,
        context: Optional[Dict[str, Any]] = None,
    ) -> DecompositionResult:
        result = self.decompose(task, context)
        self._ensure_atomic(result, context)
        return result

    def _ensure_atomic(
        self,
        result: DecompositionResult,
        context: Optional[Dict[str, Any]] = None,
    ) -> None:
        changed = True
        while changed:
            changed = False
            for node in list(result.leaf_nodes):
                if node.depth >= self.max_depth:
                    continue
                if not node.children and node.effort_estimate is not None and node.effort_estimate > self.min_task_size:
                    self._expand_node(node, result, context, node.depth + 1)
                    changed = True


class ParallelTaskIdentifier:
    def __init__(self, graph: DependencyGraph) -> None:
        self.graph = graph

    def identify_parallel_tasks(self) -> List[List[DecompositionNode]]:
        return self.graph.get_parallel_groups()

    def suggest_parallelism(self) -> Dict[str, List[str]]:
        groups = self.identify_parallel_tasks()
        suggestions: Dict[str, List[str]] = {}
        for i, group in enumerate(groups):
            if len(group) > 1:
                suggestions[f"parallel_group_{i}"] = [n.title for n in group]
        return suggestions

    def estimate_parallel_speedup(self) -> float:
        groups = self.identify_parallel_tasks()
        total_effort = sum(
            n.effort_estimate or 1
            for group in groups
            for n in group
        )
        if not groups:
            return 1.0
        max_group_effort = max(
            sum(n.effort_estimate or 1 for n in group)
            for group in groups
        )
        if max_group_effort == 0:
            return 1.0
        return total_effort / max_group_effort


class TaskAssigner:
    def __init__(self, agents: Optional[Dict[str, List[str]]] = None) -> None:
        self.agents: Dict[str, List[str]] = agents or {}

    def assign(self, node: DecompositionNode, agent: str) -> None:
        node.assigned_to = agent
        if agent not in self.agents:
            self.agents[agent] = []
        node_id = node.id
        if node_id not in self.agents[agent]:
            self.agents[agent].append(node_id)

    def assign_batch(self, assignments: Dict[str, List[DecompositionNode]]) -> None:
        for agent, nodes in assignments.items():
            for node in nodes:
                self.assign(node, agent)

    def get_agent_tasks(self, agent: str) -> List[str]:
        return self.agents.get(agent, [])

    def get_workload(self) -> Dict[str, int]:
        return {agent: len(tasks) for agent, tasks in self.agents.items()}

    def get_unassigned(self, nodes: Dict[str, DecompositionNode]) -> List[DecompositionNode]:
        return [n for n in nodes.values() if n.assigned_to is None]

    def balance_workload(self, nodes: List[DecompositionNode]) -> Dict[str, List[DecompositionNode]]:
        from collections import defaultdict
        assignments: Dict[str, List[DecompositionNode]] = defaultdict(list)
        sorted_nodes = sorted(
            nodes,
            key=lambda n: n.effort_estimate or 1,
            reverse=True,
        )

        for node in sorted_nodes:
            lightest_agent = min(
                self.agents.keys(),
                key=lambda a: sum(
                    n.effort_estimate or 1
                    for nid in self.agents[a]
                    for n in [{}]
                ) if self.agents[a] else 0,
            ) if self.agents else "default"

            if "default" not in assignments:
                assignments["default"] = []
            assignments[lightest_agent if lightest_agent != "default" else "default"].append(node)
            self.assign(node, lightest_agent if lightest_agent != "default" else "default")

        return dict(assignments)


class ProgressTracker:
    def __init__(self, result: DecompositionResult) -> None:
        self.result = result
        self._start_time = datetime.utcnow()

    def update_status(self, node_id: str, status: NodeStatus, result: Optional[Any] = None) -> None:
        node = self.result.nodes.get(node_id)
        if node is None:
            return
        node.status = status
        if result is not None:
            node.result = result

        if status == NodeStatus.FAILED:
            for child_id in node.children:
                child = self.result.nodes.get(child_id)
                if child and child.status == NodeStatus.PENDING:
                    child.status = NodeStatus.BLOCKED

        if self.result.progress == 1.0:
            self.result.completed_at = datetime.utcnow()

    def get_blockers(self, node_id: str) -> List[DecompositionNode]:
        node = self.result.nodes.get(node_id)
        if not node:
            return []
        blockers: List[DecompositionNode] = []
        for dep_id in node.dependencies:
            dep = self.result.nodes.get(dep_id)
            if dep and dep.status != NodeStatus.COMPLETED:
                blockers.append(dep)
        return blockers

    def get_critical_path(self) -> List[DecompositionNode]:
        if not self.result.nodes:
            return []
        leafs = self.result.leaf_nodes
        if not leafs:
            return [self.result.root] if self.result.root else []

        longest_path: List[DecompositionNode] = []
        for leaf in leafs:
            ancestors = self.result.get_ancestors(leaf.id)
            path = [leaf] + ancestors
            if len(path) > len(longest_path):
                longest_path = path

        return longest_path

    def get_status_summary(self) -> Dict[str, Any]:
        total = len(self.result.nodes)
        pending = sum(1 for n in self.result.nodes.values() if n.status == NodeStatus.PENDING)
        in_progress = sum(1 for n in self.result.nodes.values() if n.status == NodeStatus.IN_PROGRESS)
        completed = sum(1 for n in self.result.nodes.values() if n.status == NodeStatus.COMPLETED)
        failed = sum(1 for n in self.result.nodes.values() if n.status == NodeStatus.FAILED)
        blocked = sum(1 for n in self.result.nodes.values() if n.status == NodeStatus.BLOCKED)

        elapsed = (datetime.utcnow() - self._start_time).total_seconds()

        return {
            "total_tasks": total,
            "pending": pending,
            "in_progress": in_progress,
            "completed": completed,
            "failed": failed,
            "blocked": blocked,
            "progress": self.result.progress,
            "elapsed_seconds": elapsed,
            "critical_path_length": len(self.get_critical_path()),
            "has_blockers": blocked > 0,
        }
