# muLLM API Reference

## REST API Endpoints

### Completions

```http
POST /v1/completions
```

Creates a completion for the provided prompt and parameters.

**Request Body:**
```json
{
  "model": "string",
  "prompt": "string",
  "max_tokens": 100,
  "temperature": 0.7,
  "top_p": 0.9,
  "n": 1,
  "stream": false,
  "stop": ["\n"],
  "frequency_penalty": 0.0,
  "presence_penalty": 0.0
}
```

### Chat Completions

```http
POST /v1/chat/completions
```

**Request Body:**
```json
{
  "model": "string",
  "messages": [
    {"role": "system", "content": "You are helpful."},
    {"role": "user", "content": "Hello!"}
  ],
  "temperature": 0.7,
  "stream": false,
  "tools": []
}
```

### Embeddings

```http
POST /v1/embeddings
```

**Request Body:**
```json
{
  "model": "string",
  "input": "text to embed"
}
```

### Models

```http
GET /v1/models
```
Lists available models.

```http
GET /v1/models/{model_id}
```
Gets model details.

### Health

```http
GET /v1/health
```
Health check endpoint.

## Python SDK

```python
from mullm import muLLM

client = muLLM(api_key="your-key", base_url="http://localhost:8000")

# Text completion
response = client.completions.create(
    model="default",
    prompt="The meaning of life is",
    max_tokens=100,
)

# Chat completion
response = client.chat.completions.create(
    model="default",
    messages=[{"role": "user", "content": "Hello!"}],
)

# Streaming
for chunk in client.chat.completions.create(
    model="default",
    messages=[{"role": "user", "content": "Tell me a story"}],
    stream=True,
):
    print(chunk.choices[0].delta.content, end="")

# Embeddings
response = client.embeddings.create(
    model="default",
    input="Hello world",
)
```
