from __future__ import annotations

import math
from typing import Any, Callable, Dict, Iterator, List, Optional, Tuple, Union

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader, IterableDataset

from ..model.model import BaseCausalLM
from ..utils.logging_utils import get_logger

logger = get_logger(__name__)


class SupervisedDataset(Dataset):
    def __init__(
        self,
        texts: List[str],
        tokenizer: Callable,
        max_length: int = 2048,
        prompt_template: Optional[str] = None,
    ):
        self.tokenizer = tokenizer
        self.max_length = max_length
        self.prompt_template = prompt_template
        self.input_ids = []
        self.labels = []

        for text in texts:
            if prompt_template is not None:
                text = prompt_template.format(text=text)

            enc = tokenizer(
                text,
                truncation=True,
                max_length=max_length,
                return_tensors=None,
            )
            self.input_ids.append(enc["input_ids"])
            self.labels.append(enc["input_ids"].copy())

    def __len__(self) -> int:
        return len(self.input_ids)

    def __getitem__(self, idx: int) -> Dict[str, torch.Tensor]:
        return {
            "input_ids": torch.tensor(self.input_ids[idx], dtype=torch.long),
            "labels": torch.tensor(self.labels[idx], dtype=torch.long),
        }


class InstructionDataset(Dataset):
    def __init__(
        self,
        instructions: List[str],
        responses: List[str],
        tokenizer: Callable,
        max_length: int = 2048,
        response_template: Optional[str] = None,
    ):
        self.tokenizer = tokenizer
        self.max_length = max_length
        self.response_template = response_template or "\n### Response:\n"
        self.input_ids = []
        self.labels = []

        for instr, resp in zip(instructions, responses):
            prompt_text = instr + self.response_template
            full_text = prompt_text + resp

            prompt_enc = tokenizer(
                prompt_text,
                truncation=True,
                max_length=max_length,
                return_tensors=None,
            )
            full_enc = tokenizer(
                full_text,
                truncation=True,
                max_length=max_length,
                return_tensors=None,
            )

            full_ids = full_enc["input_ids"]
            prompt_len = len(prompt_enc["input_ids"])

            labels = full_ids.copy()
            for i in range(min(prompt_len, len(labels))):
                labels[i] = -100

            self.input_ids.append(full_ids)
            self.labels.append(labels)

    def __len__(self) -> int:
        return len(self.input_ids)

    def __getitem__(self, idx: int) -> Dict[str, torch.Tensor]:
        return {
            "input_ids": torch.tensor(self.input_ids[idx], dtype=torch.long),
            "labels": torch.tensor(self.labels[idx], dtype=torch.long),
        }


def sft_collate_fn(
    batch: List[Dict[str, torch.Tensor]],
    pad_token_id: int = 0,
) -> Dict[str, torch.Tensor]:
    input_ids = [item["input_ids"] for item in batch]
    labels = [item["labels"] for item in batch]

    max_len = max(t.size(0) for t in input_ids)

    padded_input_ids = []
    padded_labels = []
    attention_masks = []

    for ids, lbls in zip(input_ids, labels):
        pad_len = max_len - ids.size(0)
        padded_input_ids.append(
            F.pad(ids, (0, pad_len), value=pad_token_id)
        )
        padded_labels.append(
            F.pad(lbls, (0, pad_len), value=-100)
        )
        mask = torch.ones(ids.size(0), dtype=torch.long)
        attention_masks.append(
            F.pad(mask, (0, pad_len), value=0)
        )

    return {
        "input_ids": torch.stack(padded_input_ids),
        "labels": torch.stack(padded_labels),
        "attention_mask": torch.stack(attention_masks),
    }


def compute_sft_loss(
    logits: torch.Tensor,
    labels: torch.Tensor,
    label_smoothing: float = 0.0,
) -> torch.Tensor:
    shift_logits = logits[..., :-1, :].contiguous()
    shift_labels = labels[..., 1:].contiguous()
    vocab_size = shift_logits.size(-1)

    loss = F.cross_entropy(
        shift_logits.view(-1, vocab_size),
        shift_labels.view(-1),
        ignore_index=-100,
        label_smoothing=label_smoothing,
        reduction="mean",
    )
    return loss


class SFTTrainer:
    def __init__(
        self,
        model: BaseCausalLM,
        tokenizer: Callable,
        train_dataset: Dataset,
        eval_dataset: Optional[Dataset] = None,
        learning_rate: float = 5e-5,
        weight_decay: float = 0.01,
        warmup_steps: int = 0,
        max_grad_norm: float = 1.0,
        num_epochs: int = 3,
        batch_size: int = 8,
        gradient_accumulation_steps: int = 1,
        max_steps: int = -1,
        logging_steps: int = 10,
        save_steps: int = 500,
        eval_steps: int = 500,
        output_dir: str = "./sft_output",
        device: Optional[torch.device] = None,
        lora_rank: Optional[int] = None,
        lora_alpha: Optional[int] = None,
        lora_dropout: float = 0.05,
        pad_token_id: int = 0,
        label_smoothing: float = 0.0,
        use_lora: bool = False,
    ):
        self.model = model
        self.tokenizer = tokenizer
        self.train_dataset = train_dataset
        self.eval_dataset = eval_dataset
        self.learning_rate = learning_rate
        self.weight_decay = weight_decay
        self.warmup_steps = warmup_steps
        self.max_grad_norm = max_grad_norm
        self.num_epochs = num_epochs
        self.batch_size = batch_size
        self.gradient_accumulation_steps = gradient_accumulation_steps
        self.max_steps = max_steps
        self.logging_steps = logging_steps
        self.save_steps = save_steps
        self.eval_steps = eval_steps
        self.output_dir = output_dir
        self.pad_token_id = pad_token_id
        self.label_smoothing = label_smoothing

        self.device = device or (
            torch.device("cuda") if torch.cuda.is_available() else torch.device("cpu")
        )
        self.model.to(self.device)

        if use_lora:
            self._apply_lora(rank=lora_rank or 8, alpha=lora_alpha or 16, dropout=lora_dropout)
            lora_params = []
            for name, param in self.model.named_parameters():
                if "lora" in name.lower():
                    param.requires_grad = True
                    lora_params.append(param)
                else:
                    param.requires_grad = False
            self.optimizer = torch.optim.AdamW(
                lora_params,
                lr=self.learning_rate,
                weight_decay=self.weight_decay,
            )
        else:
            self.optimizer = torch.optim.AdamW(
                self.model.parameters(),
                lr=self.learning_rate,
                weight_decay=self.weight_decay,
            )

        total_steps = self._compute_total_steps()
        self.scheduler = self._create_scheduler(total_steps)

        self.global_step = 0
        self.epoch = 0
        self.best_eval_loss = float("inf")

    def _apply_lora(self, rank: int, alpha: int, dropout: float):
        for name, module in self.model.named_modules():
            if isinstance(module, nn.Linear):
                parent_name = ".".join(name.split(".")[:-1])
                child_name = name.split(".")[-1]
                parent = self.model
                if parent_name:
                    for part in parent_name.split("."):
                        parent = getattr(parent, part)
                lora_layer = LoRALayer(module, rank, alpha, dropout)
                setattr(parent, child_name, lora_layer)

    def _compute_total_steps(self) -> int:
        if self.max_steps > 0:
            return self.max_steps
        steps_per_epoch = max(1, len(self.train_dataset) // (self.batch_size * self.gradient_accumulation_steps))
        return steps_per_epoch * self.num_epochs

    def _create_scheduler(self, total_steps: int):
        def warmup_cosine(steps):
            if steps < self.warmup_steps:
                return float(steps) / float(max(1, self.warmup_steps))
            progress = float(steps - self.warmup_steps) / float(max(1, total_steps - self.warmup_steps))
            return 0.5 * (1.0 + math.cos(math.pi * progress))

        return torch.optim.lr_scheduler.LambdaLR(self.optimizer, warmup_cosine)

    def _create_dataloader(self, dataset: Dataset, shuffle: bool = True) -> DataLoader:
        return DataLoader(
            dataset,
            batch_size=self.batch_size,
            shuffle=shuffle,
            collate_fn=lambda b: sft_collate_fn(b, pad_token_id=self.pad_token_id),
            num_workers=0,
            pin_memory=True,
        )

    def train_step(self, batch: Dict[str, torch.Tensor]) -> Dict[str, torch.Tensor]:
        input_ids = batch["input_ids"].to(self.device)
        labels = batch["labels"].to(self.device)
        attention_mask = batch.get("attention_mask")

        outputs = self.model(input_ids=input_ids, labels=labels)
        loss = compute_sft_loss(outputs["logits"], labels, self.label_smoothing)

        loss = loss / self.gradient_accumulation_steps
        loss.backward()

        return {"loss": loss.detach() * self.gradient_accumulation_steps}

    def train(self) -> Dict[str, List[float]]:
        self.model.train()
        metrics = {"loss": [], "eval_loss": [], "lr": []}

        train_loader = self._create_dataloader(self.train_dataset, shuffle=True)
        total_steps = self._compute_total_steps()

        logger.info(f"Starting SFT training for up to {total_steps} steps")
        self.optimizer.zero_grad()

        step_in_epoch = 0
        for self.epoch in range(self.num_epochs):
            if self.max_steps > 0 and self.global_step >= self.max_steps:
                break

            for batch in train_loader:
                if self.max_steps > 0 and self.global_step >= self.max_steps:
                    break

                step_metrics = self.train_step(batch)

                if (self.global_step + 1) % self.gradient_accumulation_steps == 0:
                    torch.nn.utils.clip_grad_norm_(self.model.parameters(), self.max_grad_norm)
                    self.optimizer.step()
                    self.scheduler.step()
                    self.optimizer.zero_grad()

                if self.global_step % self.logging_steps == 0:
                    loss_val = step_metrics["loss"].item()
                    lr_val = self.scheduler.get_last_lr()[0]
                    metrics["loss"].append(loss_val)
                    metrics["lr"].append(lr_val)
                    logger.info(
                        f"Epoch {self.epoch}, Step {self.global_step}, Loss: {loss_val:.4f}, LR: {lr_val:.2e}"
                    )

                if self.eval_dataset is not None and self.global_step % self.eval_steps == 0 and self.global_step > 0:
                    eval_loss = self.evaluate()
                    metrics["eval_loss"].append(eval_loss)
                    if eval_loss < self.best_eval_loss:
                        self.best_eval_loss = eval_loss
                        self._save_checkpoint(f"{self.output_dir}/best")
                    logger.info(f"Eval loss at step {self.global_step}: {eval_loss:.4f}")

                if self.global_step % self.save_steps == 0 and self.global_step > 0:
                    self._save_checkpoint(f"{self.output_dir}/checkpoint-{self.global_step}")

                self.global_step += 1
                step_in_epoch += 1

        self._save_checkpoint(f"{self.output_dir}/final")
        logger.info("SFT training completed")
        return metrics

    @torch.no_grad()
    def evaluate(self) -> float:
        self.model.eval()
        loader = self._create_dataloader(self.eval_dataset, shuffle=False)
        total_loss = 0.0
        num_batches = 0

        for batch in loader:
            input_ids = batch["input_ids"].to(self.device)
            labels = batch["labels"].to(self.device)
            outputs = self.model(input_ids=input_ids, labels=labels)
            loss = compute_sft_loss(outputs["logits"], labels, self.label_smoothing)
            total_loss += loss.item()
            num_batches += 1

        self.model.train()
        return total_loss / max(1, num_batches)

    def _save_checkpoint(self, path: str):
        import os
        os.makedirs(path, exist_ok=True)
        torch.save(
            {
                "model_state_dict": self.model.state_dict(),
                "optimizer_state_dict": self.optimizer.state_dict(),
                "scheduler_state_dict": self.scheduler.state_dict(),
                "global_step": self.global_step,
                "epoch": self.epoch,
                "best_eval_loss": self.best_eval_loss,
            },
            f"{path}/checkpoint.pt",
        )
        logger.info(f"Checkpoint saved to {path}")

    @classmethod
    def from_checkpoint(cls, path: str, model: BaseCausalLM, **kwargs) -> SFTTrainer:
        checkpoint = torch.load(f"{path}/checkpoint.pt", map_location="cpu")
        trainer = cls(model=model, **kwargs)
        model.load_state_dict(checkpoint["model_state_dict"])
        trainer.optimizer.load_state_dict(checkpoint["optimizer_state_dict"])
        trainer.scheduler.load_state_dict(checkpoint["scheduler_state_dict"])
        trainer.global_step = checkpoint["global_step"]
        trainer.epoch = checkpoint["epoch"]
        trainer.best_eval_loss = checkpoint["best_eval_loss"]
        return trainer


class LoRALayer(nn.Module):
    def __init__(self, base_layer: nn.Linear, rank: int, alpha: int, dropout: float):
        super().__init__()
        self.base_layer = base_layer
        self.rank = rank
        self.alpha = alpha
        self.scaling = alpha / rank

        in_features = base_layer.in_features
        out_features = base_layer.out_features

        self.lora_A = nn.Parameter(torch.zeros(rank, in_features))
        self.lora_B = nn.Parameter(torch.zeros(out_features, rank))
        nn.init.kaiming_uniform_(self.lora_A, a=math.sqrt(5))
        nn.init.zeros_(self.lora_B)

        self.dropout = nn.Dropout(dropout) if dropout > 0 else nn.Identity()

        if base_layer.bias is not None:
            self.bias = nn.Parameter(base_layer.bias.clone())
            base_layer.bias = None
        else:
            self.bias = None

        self.base_layer.weight.requires_grad = False
        if hasattr(base_layer, "bias") and base_layer.bias is not None:
            base_layer.bias.requires_grad = False

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        base_out = self.base_layer(x)
        lora_out = (
            self.dropout(x) @ self.lora_A.t() @ self.lora_B.t() * self.scaling
        )
        out = base_out + lora_out
        if self.bias is not None:
            out = out + self.bias
        return out
