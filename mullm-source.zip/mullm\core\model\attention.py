import math
from typing import Optional, Tuple, List, Dict, Any, Callable

import torch
import torch.nn as nn
import torch.nn.functional as F


class KVCache:
    def __init__(self, max_batch_size: int = 1, max_seq_len: int = 2048, dtype: torch.dtype = torch.float32):
        self.max_batch_size = max_batch_size
        self.max_seq_len = max_seq_len
        self.dtype = dtype
        self.cache: Dict[str, Tuple[torch.Tensor, torch.Tensor]] = {}
        self.prefix_cache: Dict[str, Tuple[torch.Tensor, torch.Tensor, int]] = {}

    def update(
        self,
        layer_id: str,
        key: torch.Tensor,
        value: torch.Tensor,
        prefix_key: Optional[torch.Tensor] = None,
        prefix_value: Optional[torch.Tensor] = None,
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        if layer_id not in self.cache:
            batch_size, num_heads, seq_len, head_dim = key.shape
            k_cache = torch.zeros(
                batch_size, num_heads, self.max_seq_len, head_dim,
                dtype=key.dtype, device=key.device,
            )
            v_cache = torch.zeros_like(k_cache)
            self.cache[layer_id] = (k_cache, v_cache)

        k_cache, v_cache = self.cache[layer_id]
        if prefix_key is not None and prefix_value is not None:
            prefix_len = prefix_key.size(2)
            k_cache[:, :, :prefix_len] = prefix_key
            v_cache[:, :, :prefix_len] = prefix_value
            new_seq_len = prefix_len + key.size(2)
            k_cache[:, :, prefix_len:new_seq_len] = key
            v_cache[:, :, prefix_len:new_seq_len] = value
            return k_cache[:, :, :new_seq_len], v_cache[:, :, :new_seq_len]

        new_seq_len = k_cache.size(2) + key.size(2)
        if new_seq_len > self.max_seq_len:
            k_cache = k_cache[:, :, 1:]
            v_cache = v_cache[:, :, 1:]
            new_seq_len = k_cache.size(2) + key.size(2)
            k_cache = torch.cat([k_cache, key], dim=2)
            v_cache = torch.cat([v_cache, value], dim=2)
        else:
            k_cache[:, :, k_cache.size(2):new_seq_len] = key
            v_cache[:, :, v_cache.size(2):new_seq_len] = value
            k_cache = k_cache[:, :, :new_seq_len]
            v_cache = v_cache[:, :, :new_seq_len]

        return k_cache, v_cache

    def set_prefix_cache(self, layer_id: str, key: torch.Tensor, value: torch.Tensor, prefix_len: int) -> None:
        self.prefix_cache[layer_id] = (key, value, prefix_len)

    def get_prefix_cache(self, layer_id: str) -> Optional[Tuple[torch.Tensor, torch.Tensor, int]]:
        return self.prefix_cache.get(layer_id)

    def reset(self) -> None:
        self.cache.clear()
        self.prefix_cache.clear()

    def get_seq_len(self, layer_id: str) -> int:
        if layer_id not in self.cache:
            return 0
        k_cache, _ = self.cache[layer_id]
        return k_cache.size(2)


def _create_causal_mask(seq_len_q: int, seq_len_k: int, device: torch.device, dtype: torch.dtype) -> torch.Tensor:
    mask = torch.triu(
        torch.full((seq_len_q, seq_len_k), float("-inf"), dtype=dtype, device=device),
        diagonal=1,
    )
    return mask


class CausalAttentionMask:
    def __init__(self, sliding_window: Optional[int] = None):
        self.sliding_window = sliding_window

    def __call__(
        self,
        attention_scores: torch.Tensor,
        query_pos: Optional[torch.Tensor] = None,
        key_pos: Optional[torch.Tensor] = None,
    ) -> torch.Tensor:
        batch_size, num_heads, seq_len_q, seq_len_k = attention_scores.shape
        device = attention_scores.device
        dtype = attention_scores.dtype

        causal_mask = _create_causal_mask(seq_len_q, seq_len_k, device, dtype)

        if self.sliding_window is not None and self.sliding_window > 0:
            if query_pos is not None and key_pos is not None:
                distance = query_pos.unsqueeze(-1) - key_pos.unsqueeze(-2)
                sliding_mask = (distance > self.sliding_window) | (distance < 0)
                sliding_mask = sliding_mask.float() * float("-inf")
                causal_mask = causal_mask.unsqueeze(0).unsqueeze(0)
                causal_mask = torch.where(sliding_mask == float("-inf"), float("-inf"), causal_mask)
            else:
                window_mask = torch.triu(
                    torch.full((seq_len_q, seq_len_k), float("-inf"), dtype=dtype, device=device),
                    diagonal=self.sliding_window + 1,
                )
                causal_mask = torch.minimum(causal_mask, window_mask)

        return attention_scores + causal_mask


class MultiHeadAttention(nn.Module):
    def __init__(
        self,
        hidden_size: int,
        num_heads: int,
        dropout: float = 0.0,
        bias: bool = True,
        use_cache: bool = False,
        layer_id: Optional[str] = None,
        rotary_emb: Optional[nn.Module] = None,
    ):
        super().__init__()
        self.hidden_size = hidden_size
        self.num_heads = num_heads
        self.head_dim = hidden_size // num_heads
        self.dropout = dropout
        self.use_cache = use_cache
        self.layer_id = layer_id
        self.rotary_emb = rotary_emb

        self.q_proj = nn.Linear(hidden_size, hidden_size, bias=bias)
        self.k_proj = nn.Linear(hidden_size, hidden_size, bias=bias)
        self.v_proj = nn.Linear(hidden_size, hidden_size, bias=bias)
        self.o_proj = nn.Linear(hidden_size, hidden_size, bias=bias)

        self.attn_dropout = nn.Dropout(dropout)
        self.causal_mask = CausalAttentionMask()

    def _shape(self, x: torch.Tensor, seq_len: int, bsz: int) -> torch.Tensor:
        return x.view(bsz, seq_len, self.num_heads, self.head_dim).transpose(1, 2).contiguous()

    def forward(
        self,
        hidden_states: torch.Tensor,
        attention_mask: Optional[torch.Tensor] = None,
        past_key_value: Optional[KVCache] = None,
        position_ids: Optional[torch.Tensor] = None,
        use_cache: Optional[bool] = None,
        output_attentions: bool = False,
    ) -> Tuple[torch.Tensor, Optional[torch.Tensor], Optional[KVCache]]:
        bsz, seq_len, _ = hidden_states.shape
        use_cache = self.use_cache if use_cache is None else use_cache

        q = self._shape(self.q_proj(hidden_states), seq_len, bsz)
        k = self._shape(self.k_proj(hidden_states), seq_len, bsz)
        v = self._shape(self.v_proj(hidden_states), seq_len, bsz)

        if self.rotary_emb is not None:
            q, k = self.rotary_emb(q, k, position_ids=position_ids)

        if past_key_value is not None and self.layer_id is not None:
            k, v = past_key_value.update(self.layer_id, k, v)

        attn_weights = torch.einsum("bhid,bhjd->bhij", q, k) / math.sqrt(self.head_dim)

        if attention_mask is not None:
            attn_weights = attn_weights + attention_mask

        attn_weights = self.causal_mask(attn_weights)
        attn_weights = F.softmax(attn_weights, dim=-1, dtype=torch.float32).to(attn_weights.dtype)
        attn_weights = self.attn_dropout(attn_weights)

        attn_output = torch.einsum("bhij,bhjd->bhid", attn_weights, v)
        attn_output = attn_output.transpose(1, 2).contiguous().view(bsz, seq_len, self.hidden_size)
        attn_output = self.o_proj(attn_output)

        return attn_output, (attn_weights if output_attentions else None), past_key_value


class MultiQueryAttention(nn.Module):
    def __init__(
        self,
        hidden_size: int,
        num_heads: int,
        dropout: float = 0.0,
        bias: bool = True,
        use_cache: bool = False,
        layer_id: Optional[str] = None,
        rotary_emb: Optional[nn.Module] = None,
    ):
        super().__init__()
        self.hidden_size = hidden_size
        self.num_heads = num_heads
        self.num_kv_heads = 1
        self.head_dim = hidden_size // num_heads
        self.rotary_emb = rotary_emb

        self.q_proj = nn.Linear(hidden_size, hidden_size, bias=bias)
        self.k_proj = nn.Linear(hidden_size, self.num_kv_heads * self.head_dim, bias=bias)
        self.v_proj = nn.Linear(hidden_size, self.num_kv_heads * self.head_dim, bias=bias)
        self.o_proj = nn.Linear(hidden_size, hidden_size, bias=bias)

        self.attn_dropout = nn.Dropout(dropout)
        self.causal_mask = CausalAttentionMask()
        self.layer_id = layer_id
        self.use_cache = use_cache

    def forward(
        self,
        hidden_states: torch.Tensor,
        attention_mask: Optional[torch.Tensor] = None,
        past_key_value: Optional[KVCache] = None,
        position_ids: Optional[torch.Tensor] = None,
        use_cache: Optional[bool] = None,
        output_attentions: bool = False,
    ) -> Tuple[torch.Tensor, Optional[torch.Tensor], Optional[KVCache]]:
        bsz, seq_len, _ = hidden_states.shape
        use_cache = self.use_cache if use_cache is None else use_cache

        q = self.q_proj(hidden_states).view(bsz, seq_len, self.num_heads, self.head_dim).transpose(1, 2)
        k = self.k_proj(hidden_states).view(bsz, seq_len, self.num_kv_heads, self.head_dim).transpose(1, 2)
        v = self.v_proj(hidden_states).view(bsz, seq_len, self.num_kv_heads, self.head_dim).transpose(1, 2)

        if self.rotary_emb is not None:
            q, k = self.rotary_emb(q, k, position_ids=position_ids)

        if past_key_value is not None and self.layer_id is not None:
            k, v = past_key_value.update(self.layer_id, k, v)

        k = k.expand(-1, self.num_heads, -1, -1)
        v = v.expand(-1, self.num_heads, -1, -1)

        attn_weights = torch.einsum("bhid,bhjd->bhij", q, k) / math.sqrt(self.head_dim)

        if attention_mask is not None:
            attn_weights = attn_weights + attention_mask

        attn_weights = self.causal_mask(attn_weights)
        attn_weights = F.softmax(attn_weights, dim=-1, dtype=torch.float32).to(attn_weights.dtype)
        attn_weights = self.attn_dropout(attn_weights)

        attn_output = torch.einsum("bhij,bhjd->bhid", attn_weights, v)
        attn_output = attn_output.transpose(1, 2).contiguous().view(bsz, seq_len, self.hidden_size)
        attn_output = self.o_proj(attn_output)

        return attn_output, (attn_weights if output_attentions else None), past_key_value


class GroupedQueryAttention(nn.Module):
    def __init__(
        self,
        hidden_size: int,
        num_heads: int,
        num_kv_heads: int = 8,
        dropout: float = 0.0,
        bias: bool = False,
        use_cache: bool = False,
        layer_id: Optional[str] = None,
        rope_theta: float = 10000.0,
        max_position_embeddings: int = 2048,
        rotary_emb: Optional[nn.Module] = None,
    ):
        super().__init__()
        self.hidden_size = hidden_size
        self.num_heads = num_heads
        self.num_kv_heads = num_kv_heads
        self.head_dim = hidden_size // num_heads
        self.num_key_value_groups = num_heads // num_kv_heads
        self.rotary_emb = rotary_emb

        self.q_proj = nn.Linear(hidden_size, num_heads * self.head_dim, bias=bias)
        self.k_proj = nn.Linear(hidden_size, num_kv_heads * self.head_dim, bias=bias)
        self.v_proj = nn.Linear(hidden_size, num_kv_heads * self.head_dim, bias=bias)
        self.o_proj = nn.Linear(num_heads * self.head_dim, hidden_size, bias=bias)

        self.attn_dropout = nn.Dropout(dropout)
        self.causal_mask = CausalAttentionMask()
        self.layer_id = layer_id
        self.use_cache = use_cache

    def forward(
        self,
        hidden_states: torch.Tensor,
        attention_mask: Optional[torch.Tensor] = None,
        past_key_value: Optional[KVCache] = None,
        position_ids: Optional[torch.Tensor] = None,
        use_cache: Optional[bool] = None,
        output_attentions: bool = False,
    ) -> Tuple[torch.Tensor, Optional[torch.Tensor], Optional[KVCache]]:
        bsz, seq_len, _ = hidden_states.shape
        use_cache = self.use_cache if use_cache is None else use_cache

        q = self.q_proj(hidden_states).view(bsz, seq_len, self.num_heads, self.head_dim).transpose(1, 2)
        k = self.k_proj(hidden_states).view(bsz, seq_len, self.num_kv_heads, self.head_dim).transpose(1, 2)
        v = self.v_proj(hidden_states).view(bsz, seq_len, self.num_kv_heads, self.head_dim).transpose(1, 2)

        if self.rotary_emb is not None:
            q, k = self.rotary_emb(q, k, position_ids=position_ids)

        if past_key_value is not None and self.layer_id is not None:
            k, v = past_key_value.update(self.layer_id, k, v)

        k = k.repeat_interleave(self.num_key_value_groups, dim=1)
        v = v.repeat_interleave(self.num_key_value_groups, dim=1)

        attn_weights = torch.einsum("bhid,bhjd->bhij", q, k) / math.sqrt(self.head_dim)

        if attention_mask is not None:
            attn_weights = attn_weights + attention_mask

        attn_weights = self.causal_mask(attn_weights)
        attn_weights = F.softmax(attn_weights, dim=-1, dtype=torch.float32).to(attn_weights.dtype)
        attn_weights = self.attn_dropout(attn_weights)

        attn_output = torch.einsum("bhij,bhjd->bhid", attn_weights, v)
        attn_output = attn_output.transpose(1, 2).contiguous().view(bsz, seq_len, -1)
        attn_output = self.o_proj(attn_output)

        return attn_output, (attn_weights if output_attentions else None), past_key_value


class FlashAttentionWrapper(nn.Module):
    def __init__(
        self,
        hidden_size: int,
        num_heads: int,
        num_kv_heads: Optional[int] = None,
        dropout: float = 0.0,
        bias: bool = False,
        use_cache: bool = False,
        layer_id: Optional[str] = None,
        sliding_window: Optional[int] = None,
        causal: bool = True,
        rotary_emb: Optional[nn.Module] = None,
    ):
        super().__init__()
        self.hidden_size = hidden_size
        self.num_heads = num_heads
        self.num_kv_heads = num_kv_heads if num_kv_heads is not None else num_heads
        self.head_dim = hidden_size // num_heads
        self.dropout = dropout
        self.sliding_window = sliding_window
        self.causal = causal
        self.use_cache = use_cache
        self.layer_id = layer_id
        self.rotary_emb = rotary_emb

        self.q_proj = nn.Linear(hidden_size, num_heads * self.head_dim, bias=bias)
        self.k_proj = nn.Linear(hidden_size, self.num_kv_heads * self.head_dim, bias=bias)
        self.v_proj = nn.Linear(hidden_size, self.num_kv_heads * self.head_dim, bias=bias)
        self.o_proj = nn.Linear(num_heads * self.head_dim, hidden_size, bias=bias)

        self.causal_mask = CausalAttentionMask(sliding_window=sliding_window)

    def forward(
        self,
        hidden_states: torch.Tensor,
        attention_mask: Optional[torch.Tensor] = None,
        past_key_value: Optional[KVCache] = None,
        position_ids: Optional[torch.Tensor] = None,
        use_cache: Optional[bool] = None,
        output_attentions: bool = False,
    ) -> Tuple[torch.Tensor, Optional[torch.Tensor], Optional[KVCache]]:
        bsz, seq_len, _ = hidden_states.shape
        use_cache = self.use_cache if use_cache is None else use_cache

        q = self.q_proj(hidden_states).view(bsz, seq_len, self.num_heads, self.head_dim)
        k = self.k_proj(hidden_states).view(bsz, seq_len, self.num_kv_heads, self.head_dim)
        v = self.v_proj(hidden_states).view(bsz, seq_len, self.num_kv_heads, self.head_dim)

        if self.rotary_emb is not None:
            q_t = q.transpose(1, 2)
            k_t = k.transpose(1, 2)
            q_t, k_t = self.rotary_emb(q_t, k_t, position_ids=position_ids)
            q = q_t.transpose(1, 2)
            k = k_t.transpose(1, 2)

        if past_key_value is not None and self.layer_id is not None:
            k, v = past_key_value.update(self.layer_id, k.transpose(1, 2), v.transpose(1, 2))
            k = k.transpose(1, 2)
            v = v.transpose(1, 2)

        try:
            from flash_attn import flash_attn_func
            output = flash_attn_func(
                q.half(), k.half(), v.half(),
                dropout_p=self.dropout if self.training else 0.0,
                softmax_scale=1.0 / math.sqrt(self.head_dim),
                causal=self.causal,
                window_size=(self.sliding_window if self.sliding_window else -1, 0),
            )
            output = output.to(q.dtype)
        except ImportError:
            q_t = q.transpose(1, 2).contiguous()
            k_t = k.transpose(1, 2).contiguous()
            v_t = v.transpose(1, 2).contiguous()

            attn_weights = torch.einsum("bhid,bhjd->bhij", q_t, k_t) / math.sqrt(self.head_dim)

            if attention_mask is not None:
                attn_weights = attn_weights + attention_mask

            if self.causal:
                attn_weights = self.causal_mask(attn_weights)

            attn_weights = F.softmax(attn_weights, dim=-1, dtype=torch.float32).to(q.dtype)
            attn_weights = F.dropout(attn_weights, p=self.dropout, training=self.training)

            output = torch.einsum("bhij,bhjd->bhid", attn_weights, v_t)
            output = output.transpose(1, 2).contiguous().view(bsz, seq_len, -1)

        output = self.o_proj(output)

        return output, (None if output_attentions else None), past_key_value


class SlidingWindowAttention(nn.Module):
    def __init__(
        self,
        hidden_size: int,
        num_heads: int,
        num_kv_heads: Optional[int] = None,
        window_size: int = 4096,
        dropout: float = 0.0,
        bias: bool = False,
        use_cache: bool = False,
        layer_id: Optional[str] = None,
        rotary_emb: Optional[nn.Module] = None,
    ):
        super().__init__()
        self.hidden_size = hidden_size
        self.num_heads = num_heads
        self.num_kv_heads = num_kv_heads if num_kv_heads is not None else num_heads
        self.head_dim = hidden_size // num_heads
        self.window_size = window_size
        self.num_key_value_groups = num_heads // self.num_kv_heads
        self.rotary_emb = rotary_emb

        self.q_proj = nn.Linear(hidden_size, num_heads * self.head_dim, bias=bias)
        self.k_proj = nn.Linear(hidden_size, self.num_kv_heads * self.head_dim, bias=bias)
        self.v_proj = nn.Linear(hidden_size, self.num_kv_heads * self.head_dim, bias=bias)
        self.o_proj = nn.Linear(num_heads * self.head_dim, hidden_size, bias=bias)

        self.attn_dropout = nn.Dropout(dropout)
        self.causal_mask = CausalAttentionMask(sliding_window=window_size)
        self.layer_id = layer_id
        self.use_cache = use_cache

    def forward(
        self,
        hidden_states: torch.Tensor,
        attention_mask: Optional[torch.Tensor] = None,
        past_key_value: Optional[KVCache] = None,
        position_ids: Optional[torch.Tensor] = None,
        use_cache: Optional[bool] = None,
        output_attentions: bool = False,
    ) -> Tuple[torch.Tensor, Optional[torch.Tensor], Optional[KVCache]]:
        bsz, seq_len, _ = hidden_states.shape
        use_cache = self.use_cache if use_cache is None else use_cache

        q = self.q_proj(hidden_states).view(bsz, seq_len, self.num_heads, self.head_dim).transpose(1, 2)
        k = self.k_proj(hidden_states).view(bsz, seq_len, self.num_kv_heads, self.head_dim).transpose(1, 2)
        v = self.v_proj(hidden_states).view(bsz, seq_len, self.num_kv_heads, self.head_dim).transpose(1, 2)

        if self.rotary_emb is not None:
            q, k = self.rotary_emb(q, k, position_ids=position_ids)

        if past_key_value is not None and self.layer_id is not None:
            k, v = past_key_value.update(self.layer_id, k, v)
            seq_len_k = k.size(2)

            if self.window_size > 0 and seq_len_k > self.window_size:
                k = k[:, :, -self.window_size:]
                v = v[:, :, -self.window_size:]

        k = k.repeat_interleave(self.num_key_value_groups, dim=1)
        v = v.repeat_interleave(self.num_key_value_groups, dim=1)

        attn_weights = torch.einsum("bhid,bhjd->bhij", q, k) / math.sqrt(self.head_dim)

        if attention_mask is not None:
            attn_weights = attn_weights + attention_mask

        attn_weights = self.causal_mask(attn_weights)
        attn_weights = F.softmax(attn_weights, dim=-1, dtype=torch.float32).to(attn_weights.dtype)
        attn_weights = self.attn_dropout(attn_weights)

        attn_output = torch.einsum("bhij,bhjd->bhid", attn_weights, v)
        attn_output = attn_output.transpose(1, 2).contiguous().view(bsz, seq_len, -1)
        attn_output = self.o_proj(attn_output)

        return attn_output, (attn_weights if output_attentions else None), past_key_value


class SparseAttention(nn.Module):
    def __init__(
        self,
        hidden_size: int,
        num_heads: int,
        num_kv_heads: Optional[int] = None,
        block_size: int = 64,
        top_blocks: int = 4,
        dropout: float = 0.0,
        bias: bool = False,
        use_cache: bool = False,
        layer_id: Optional[str] = None,
        rotary_emb: Optional[nn.Module] = None,
    ):
        super().__init__()
        self.hidden_size = hidden_size
        self.num_heads = num_heads
        self.num_kv_heads = num_kv_heads if num_kv_heads is not None else num_heads
        self.head_dim = hidden_size // num_heads
        self.block_size = block_size
        self.top_blocks = top_blocks
        self.num_key_value_groups = num_heads // self.num_kv_heads
        self.rotary_emb = rotary_emb

        self.q_proj = nn.Linear(hidden_size, num_heads * self.head_dim, bias=bias)
        self.k_proj = nn.Linear(hidden_size, self.num_kv_heads * self.head_dim, bias=bias)
        self.v_proj = nn.Linear(hidden_size, self.num_kv_heads * self.head_dim, bias=bias)
        self.o_proj = nn.Linear(num_heads * self.head_dim, hidden_size, bias=bias)

        self.attn_dropout = nn.Dropout(dropout)
        self.causal_mask = CausalAttentionMask()
        self.layer_id = layer_id
        self.use_cache = use_cache

    def _block_sparse_mask(
        self,
        attn_weights: torch.Tensor,
        top_blocks: int,
        block_size: int,
    ) -> torch.Tensor:
        bsz, num_heads, seq_len_q, seq_len_k = attn_weights.shape
        num_blocks_q = (seq_len_q + block_size - 1) // block_size
        num_blocks_k = (seq_len_k + block_size - 1) // block_size

        block_scores = torch.zeros(bsz, num_heads, num_blocks_q, num_blocks_k, device=attn_weights.device, dtype=attn_weights.dtype)

        for i in range(num_blocks_q):
            q_start = i * block_size
            q_end = min(q_start + block_size, seq_len_q)
            for j in range(num_blocks_k):
                k_start = j * block_size
                k_end = min(k_start + block_size, seq_len_k)
                block_scores[:, :, i, j] = attn_weights[:, :, q_start:q_end, k_start:k_end].max(dim=-1).values.max(dim=-1).values

        topk_indices = block_scores.topk(min(top_blocks, num_blocks_k), dim=-1).indices

        sparse_mask = torch.full_like(attn_weights, float("-inf"))
        for i in range(num_blocks_q):
            q_start = i * block_size
            q_end = min(q_start + block_size, seq_len_q)
            topk_for_q = topk_indices[:, :, i, :]
            for b in range(bsz):
                for h in range(num_heads):
                    for t_idx in range(topk_indices.size(-1)):
                        j = topk_for_q[b, h, t_idx].item()
                        k_start = j * block_size
                        k_end = min(k_start + block_size, seq_len_k)
                        sparse_mask[b, h, q_start:q_end, k_start:k_end] = 0.0

        return sparse_mask

    def forward(
        self,
        hidden_states: torch.Tensor,
        attention_mask: Optional[torch.Tensor] = None,
        past_key_value: Optional[KVCache] = None,
        position_ids: Optional[torch.Tensor] = None,
        use_cache: Optional[bool] = None,
        output_attentions: bool = False,
    ) -> Tuple[torch.Tensor, Optional[torch.Tensor], Optional[KVCache]]:
        bsz, seq_len, _ = hidden_states.shape
        use_cache = self.use_cache if use_cache is None else use_cache

        q = self.q_proj(hidden_states).view(bsz, seq_len, self.num_heads, self.head_dim).transpose(1, 2)
        k = self.k_proj(hidden_states).view(bsz, seq_len, self.num_kv_heads, self.head_dim).transpose(1, 2)
        v = self.v_proj(hidden_states).view(bsz, seq_len, self.num_kv_heads, self.head_dim).transpose(1, 2)

        if self.rotary_emb is not None:
            q, k = self.rotary_emb(q, k, position_ids=position_ids)

        if past_key_value is not None and self.layer_id is not None:
            k, v = past_key_value.update(self.layer_id, k, v)

        k = k.repeat_interleave(self.num_key_value_groups, dim=1)
        v = v.repeat_interleave(self.num_key_value_groups, dim=1)

        attn_weights = torch.einsum("bhid,bhjd->bhij", q, k) / math.sqrt(self.head_dim)

        if attention_mask is not None:
            attn_weights = attn_weights + attention_mask

        attn_weights = self.causal_mask(attn_weights)

        sparse_mask = self._block_sparse_mask(attn_weights, self.top_blocks, self.block_size)
        attn_weights = attn_weights + sparse_mask

        attn_weights = F.softmax(attn_weights, dim=-1, dtype=torch.float32).to(attn_weights.dtype)
        attn_weights = self.attn_dropout(attn_weights)

        attn_output = torch.einsum("bhij,bhjd->bhid", attn_weights, v)
        attn_output = attn_output.transpose(1, 2).contiguous().view(bsz, seq_len, -1)
        attn_output = self.o_proj(attn_output)

        return attn_output, (attn_weights if output_attentions else None), past_key_value


ATTENTION_MAP = {
    "multi_head": MultiHeadAttention,
    "multi_query": MultiQueryAttention,
    "grouped_query": GroupedQueryAttention,
    "flash": FlashAttentionWrapper,
    "sliding_window": SlidingWindowAttention,
    "sparse": SparseAttention,
}


def get_attention(attention_type: str, **kwargs) -> nn.Module:
    if attention_type not in ATTENTION_MAP:
        raise ValueError(
            f"Unknown attention type: {attention_type}. "
            f"Available: {list(ATTENTION_MAP.keys())}"
        )
    return ATTENTION_MAP[attention_type](**kwargs)
