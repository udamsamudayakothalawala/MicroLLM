"""Multi-format document downloader with retry, progress tracking, and checksum verification."""

from __future__ import annotations

import asyncio
import hashlib
import logging
import os
import time
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any, Callable, Optional

import aiohttp

logger = logging.getLogger(__name__)


class FileFormat(Enum):
    PDF = "pdf"
    HTML = "html"
    TXT = "txt"
    JSON = "json"
    XML = "xml"
    CSV = "csv"
    PARQUET = "parquet"
    UNKNOWN = "unknown"


MIME_MAP: dict[str, FileFormat] = {
    "application/pdf": FileFormat.PDF,
    "text/html": FileFormat.HTML,
    "text/plain": FileFormat.TXT,
    "application/json": FileFormat.JSON,
    "application/xml": FileFormat.XML,
    "text/xml": FileFormat.XML,
    "text/csv": FileFormat.CSV,
    "application/octet-stream": FileFormat.UNKNOWN,
}

EXTENSION_MAP: dict[str, FileFormat] = {
    ".pdf": FileFormat.PDF,
    ".html": FileFormat.HTML,
    ".htm": FileFormat.HTML,
    ".txt": FileFormat.TXT,
    ".json": FileFormat.JSON,
    ".xml": FileFormat.XML,
    ".csv": FileFormat.CSV,
    ".parquet": FileFormat.PARQUET,
}


@dataclass
class DownloadConfig:
    """Configuration for document downloader."""

    max_concurrent: int = 20
    timeout: int = 60
    retry_count: int = 3
    retry_delay: float = 1.0
    max_retry_delay: float = 60.0
    chunk_size: int = 8192
    max_file_size: int = 500 * 1024 * 1024  # 500MB
    verify_checksum: bool = True
    stream_threshold: int = 10 * 1024 * 1024  # 10MB
    user_agent: str = "muLLM-Downloader/1.0"
    headers: dict[str, str] = field(default_factory=dict)
    output_dir: str = "./downloads"


@dataclass
class DownloadRequest:
    """A single download request."""

    url: str
    dest_path: Optional[str] = None
    filename: Optional[str] = None
    headers: dict[str, str] = field(default_factory=dict)
    expected_checksum: Optional[str] = None
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class DownloadResult:
    """Result of a download operation."""

    url: str
    success: bool
    file_path: Optional[str] = None
    file_format: FileFormat = FileFormat.UNKNOWN
    file_size: int = 0
    checksum: Optional[str] = None
    elapsed: float = 0.0
    error: Optional[str] = None
    retry_count: int = 0
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class ProgressInfo:
    """Download progress information."""

    url: str
    bytes_downloaded: int
    total_bytes: Optional[int]
    speed: float  # bytes per second
    elapsed: float
    eta: Optional[float]  # seconds


class ChecksumValidator:
    """Validates file checksums."""

    @staticmethod
    def compute(file_path: str, algorithm: str = "sha256") -> str:
        h = hashlib.new(algorithm)
        with open(file_path, "rb") as f:
            while True:
                chunk = f.read(8192)
                if not chunk:
                    break
                h.update(chunk)
        return h.hexdigest()

    @staticmethod
    def verify(file_path: str, expected: str, algorithm: str = "sha256") -> bool:
        actual = ChecksumValidator.compute(file_path, algorithm)
        return actual == expected.lower()


class DownloadManager:
    """Manages concurrent document downloads with retry and progress tracking."""

    def __init__(self, config: Optional[DownloadConfig] = None) -> None:
        self.config = config or DownloadConfig()
        self._semaphore = asyncio.Semaphore(self.config.max_concurrent)
        self._session: Optional[aiohttp.ClientSession] = None
        self._results: list[DownloadResult] = []
        self._on_progress: Optional[Callable[[ProgressInfo], None]] = None
        self._on_complete: Optional[Callable[[DownloadResult], None]] = None
        self._stats = {
            "total": 0,
            "success": 0,
            "failed": 0,
            "total_bytes": 0,
        }

    def on_progress(self, callback: Callable[[ProgressInfo], None]) -> None:
        self._on_progress = callback

    def on_complete(self, callback: Callable[[DownloadResult], None]) -> None:
        self._on_complete = callback

    @property
    def stats(self) -> dict[str, int]:
        return dict(self._stats)

    def _detect_format(self, url: str, content_type: str) -> FileFormat:
        ct = content_type.split(";")[0].strip().lower()
        if ct in MIME_MAP:
            return MIME_MAP[ct]
        from urllib.parse import urlparse

        ext = Path(urlparse(url).path).suffix.lower()
        if ext in EXTENSION_MAP:
            return EXTENSION_MAP[ext]
        return FileFormat.UNKNOWN

    def _default_filename(self, url: str, fmt: FileFormat) -> str:
        from urllib.parse import urlparse

        path = urlparse(url).path
        name = os.path.basename(path)
        if not name or name == "/":
            name = hashlib.md5(url.encode()).hexdigest()
        if fmt != FileFormat.UNKNOWN:
            ext = f".{fmt.value}"
            if not name.endswith(ext):
                name += ext
        return name

    async def _stream_download(
        self,
        url: str,
        file_path: str,
        headers: dict[str, str],
        timeout: aiohttp.ClientTimeout,
    ) -> tuple[int, str]:
        total_size = 0
        sha256 = hashlib.sha256()
        os.makedirs(os.path.dirname(file_path) or ".", exist_ok=True)
        start = time.monotonic()

        async with self._session.get(url, headers=headers, timeout=timeout) as resp:  # type: ignore
            total = resp.content_length
            with open(file_path, "wb") as f:
                async for chunk in resp.content.iter_chunked(self.config.chunk_size):
                    f.write(chunk)
                    sha256.update(chunk)
                    total_size += len(chunk)
                    elapsed = time.monotonic() - start
                    speed = total_size / max(elapsed, 0.001)
                    eta = None
                    if total and total > 0:
                        remaining = total - total_size
                        eta = remaining / max(speed, 1.0)

                    if self._on_progress:
                        self._on_progress(
                            ProgressInfo(
                                url=url,
                                bytes_downloaded=total_size,
                                total_bytes=total,
                                speed=speed,
                                elapsed=elapsed,
                                eta=eta,
                            )
                        )

        return total_size, sha256.hexdigest()

    async def _in_memory_download(
        self,
        url: str,
        headers: dict[str, str],
        timeout: aiohttp.ClientTimeout,
    ) -> tuple[bytes, str]:
        async with self._session.get(url, headers=headers, timeout=timeout) as resp:  # type: ignore
            data = await resp.read()
            checksum = hashlib.sha256(data).hexdigest()
            return data, checksum

    async def download_one(self, request: DownloadRequest) -> DownloadResult:
        start = time.monotonic()
        last_error: Optional[str] = None

        headers = {**self.config.headers, **request.headers}
        headers.setdefault("User-Agent", self.config.user_agent)

        async with self._semaphore:
            for attempt in range(self.config.retry_count):
                try:
                    timeout = aiohttp.ClientTimeout(total=self.config.timeout)
                    async with self._session.get(  # type: ignore
                        request.url, headers=headers, timeout=timeout
                    ) as resp:
                        if resp.status != 200:
                            last_error = f"HTTP {resp.status}"
                            delay = min(
                                self.config.retry_delay * (2 ** attempt),
                                self.config.max_retry_delay,
                            )
                            await asyncio.sleep(delay)
                            continue

                        content_type = resp.headers.get("Content-Type", "")
                        content_length = int(
                            resp.headers.get("Content-Length", "0")
                        )
                        fmt = self._detect_format(request.url, content_type)

                        filename = request.filename or self._default_filename(
                            request.url, fmt
                        )
                        dest_dir = request.dest_path or self.config.output_dir
                        file_path = os.path.join(dest_dir, filename)

                        if content_length > self.config.max_file_size:
                            return DownloadResult(
                                url=request.url,
                                success=False,
                                error=f"File too large: {content_length} bytes",
                                elapsed=time.monotonic() - start,
                                file_format=fmt,
                                retry_count=attempt,
                                metadata=request.metadata,
                            )

                        if content_length >= self.config.stream_threshold or content_length == 0:
                            file_size, checksum = await self._stream_download(
                                request.url,
                                file_path,
                                headers,
                                timeout,
                            )
                        else:
                            data, checksum = await self._in_memory_download(
                                request.url, headers, timeout
                            )
                            os.makedirs(os.path.dirname(file_path) or ".", exist_ok=True)
                            with open(file_path, "wb") as f:
                                f.write(data)
                            file_size = len(data)

                        if self.config.verify_checksum and request.expected_checksum:
                            if checksum != request.expected_checksum.lower():
                                return DownloadResult(
                                    url=request.url,
                                    success=False,
                                    file_path=file_path,
                                    file_format=fmt,
                                    file_size=file_size,
                                    checksum=checksum,
                                    elapsed=time.monotonic() - start,
                                    error="Checksum mismatch",
                                    retry_count=attempt,
                                    metadata=request.metadata,
                                )

                        result = DownloadResult(
                            url=request.url,
                            success=True,
                            file_path=file_path,
                            file_format=fmt,
                            file_size=file_size,
                            checksum=checksum,
                            elapsed=time.monotonic() - start,
                            retry_count=attempt,
                            metadata=request.metadata,
                        )
                        self._stats["success"] += 1
                        self._stats["total_bytes"] += file_size

                        if self._on_complete:
                            self._on_complete(result)
                        return result

                except asyncio.TimeoutError:
                    last_error = "Timeout"
                except aiohttp.ClientError as e:
                    last_error = f"Client error: {e}"
                except OSError as e:
                    last_error = f"OS error: {e}"
                except Exception as e:
                    last_error = f"Unexpected error: {e}"

                delay = min(
                    self.config.retry_delay * (2 ** attempt),
                    self.config.max_retry_delay,
                )
                logger.warning(
                    "Download failed (attempt %d/%d) for %s: %s. Retrying in %.1fs",
                    attempt + 1,
                    self.config.retry_count,
                    request.url,
                    last_error,
                    delay,
                )
                await asyncio.sleep(delay)

            self._stats["failed"] += 1
            result = DownloadResult(
                url=request.url,
                success=False,
                elapsed=time.monotonic() - start,
                error=f"Failed after {self.config.retry_count} retries: {last_error}",
                retry_count=self.config.retry_count,
                metadata=request.metadata,
            )
            if self._on_complete:
                self._on_complete(result)
            return result

    async def download_batch(
        self, requests: list[DownloadRequest]
    ) -> list[DownloadResult]:
        self._session = aiohttp.ClientSession()
        self._stats["total"] = len(requests)
        try:
            tasks = [self.download_one(req) for req in requests]
            results = await asyncio.gather(*tasks, return_exceptions=True)
            final: list[DownloadResult] = []
            for r in results:
                if isinstance(r, Exception):
                    final.append(
                        DownloadResult(
                            url="",
                            success=False,
                            error=str(r),
                        )
                    )
                else:
                    final.append(r)
            self._results.extend(final)
            return final
        finally:
            await self._session.close()  # type: ignore

    async def download(
        self,
        urls: list[str],
        output_dir: Optional[str] = None,
        on_progress: Optional[Callable[[ProgressInfo], None]] = None,
    ) -> list[DownloadResult]:
        if on_progress:
            self._on_progress = on_progress
        if output_dir:
            self.config.output_dir = output_dir
        requests = [DownloadRequest(url=url) for url in urls]
        return await self.download_batch(requests)
