from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, Dict, List, Optional, Set, Tuple, Union

import torch
import torch.distributed as dist
import torch.nn as nn

from mullm.core.trainer.training_config import FSDPConfig


class ShardingStrategy(str, Enum):
    FULL_SHARD = "full_shard"
    SHARD_GRAD_OP = "shard_grad_op"
    NO_SHARD = "no_shard"
    HYBRID_SHARD = "hybrid_shard"


class BackwardPrefetch(str, Enum):
    BACKWARD_PRE = "backward_pre"
    BACKWARD_POST = "backward_post"
    NO_PREFETCH = "no_prefetch"


class MixedPrecisionType(str, Enum):
    FP16 = "fp16"
    BF16 = "bf16"
    FP8 = "fp8"


@dataclass
class MixedPrecisionConfig:
    param_dtype: Optional[torch.dtype] = None
    reduce_dtype: Optional[torch.dtype] = None
    buffer_dtype: Optional[torch.dtype] = None
    cast_forward_inputs: bool = True
    cast_root_forward_inputs: bool = True

    @classmethod
    def bf16(cls) -> MixedPrecisionConfig:
        return cls(
            param_dtype=torch.bfloat16,
            reduce_dtype=torch.bfloat16,
            buffer_dtype=torch.bfloat16,
        )

    @classmethod
    def fp16(cls) -> MixedPrecisionConfig:
        return cls(
            param_dtype=torch.float16,
            reduce_dtype=torch.float16,
            buffer_dtype=torch.float16,
        )

    @classmethod
    def fp8(cls) -> MixedPrecisionConfig:
        return cls(
            param_dtype=torch.float8_e4m3fn,
            reduce_dtype=torch.float8_e4m3fn,
            buffer_dtype=torch.float8_e4m3fn,
        )

    @classmethod
    def no_mixed_precision(cls) -> MixedPrecisionConfig:
        return cls(
            param_dtype=torch.float32,
            reduce_dtype=torch.float32,
            buffer_dtype=torch.float32,
        )


class FSDPWrappingPolicy:
    def __init__(
        self,
        transformer_layer_cls: Optional[List[str]] = None,
        min_num_params: int = 100_000_000,
        auto_wrap_policy: Optional[Callable] = None,
    ) -> None:
        self.transformer_layer_cls = transformer_layer_cls or []
        self.min_num_params = min_num_params
        self._auto_wrap_policy = auto_wrap_policy

    @staticmethod
    def transformer_auto_wrap_policy(
        module: nn.Module,
        recurse: bool,
        unwrapped_params: int,
        transformer_layer_cls: Set[str],
    ) -> bool:
        if recurse:
            return True
        module_cls_name = module.__class__.__name__
        return module_cls_name in transformer_layer_cls

    @staticmethod
    def size_based_auto_wrap_policy(
        module: nn.Module,
        recurse: bool,
        unwrapped_params: int,
        min_num_params: int,
    ) -> bool:
        if recurse:
            return True
        return unwrapped_params >= min_num_params

    @staticmethod
    def no_wrap_policy(
        module: nn.Module,
        recurse: bool,
        unwrapped_params: int,
    ) -> bool:
        return False

    @staticmethod
    def lambda_auto_wrap_policy(
        module: nn.Module,
        recurse: bool,
        unwrapped_params: int,
        lambda_fn: Callable[[nn.Module], bool],
    ) -> bool:
        if recurse:
            return True
        return lambda_fn(module)

    def get_policy(self, name: str) -> Callable:
        if name == "transformer_auto_wrap_policy":
            return lambda module, recurse, unwrapped_params: self.transformer_auto_wrap_policy(
                module, recurse, unwrapped_params, set(self.transformer_layer_cls)
            )
        if name == "size_based_auto_wrap_policy":
            return lambda module, recurse, unwrapped_params: self.size_based_auto_wrap_policy(
                module, recurse, unwrapped_params, self.min_num_params
            )
        if name == "no_wrap_policy":
            return self.no_wrap_policy
        if self._auto_wrap_policy is not None:
            return self._auto_wrap_policy
        raise ValueError(f"Unknown auto wrap policy: {name}")


class FSDPConfigBuilder:
    def __init__(self, config: FSDPConfig) -> None:
        self.config = config

    def get_sharding_strategy(self) -> Any:
        try:
            from torch.distributed.fsdp import ShardingStrategy as FSDPShardingStrategy

            mapping = {
                ShardingStrategy.FULL_SHARD: FSDPShardingStrategy.FULL_SHARD,
                ShardingStrategy.SHARD_GRAD_OP: FSDPShardingStrategy.SHARD_GRAD_OP,
                ShardingStrategy.NO_SHARD: FSDPShardingStrategy.NO_SHARD,
                ShardingStrategy.HYBRID_SHARD: FSDPShardingStrategy.HYBRID_SHARD,
            }
            return mapping.get(self.config.sharding_strategy, FSDPShardingStrategy.FULL_SHARD)
        except ImportError:
            return 1

    def get_backward_prefetch(self) -> Any:
        try:
            from torch.distributed.fsdp import BackwardPrefetch as FSDPBackwardPrefetch

            mapping = {
                BackwardPrefetch.BACKWARD_PRE: FSDPBackwardPrefetch.BACKWARD_PRE,
                BackwardPrefetch.BACKWARD_POST: FSDPBackwardPrefetch.BACKWARD_POST,
                BackwardPrefetch.NO_PREFETCH: None,
            }
            return mapping.get(self.config.backward_prefetch, FSDPBackwardPrefetch.BACKWARD_PRE)
        except ImportError:
            return None

    def get_mixed_precision_policy(self) -> Optional[Any]:
        if not self.config.mixed_precision:
            return None
        try:
            from torch.distributed.fsdp import MixedPrecision

            bf16 = MixedPrecision(
                param_dtype=torch.bfloat16,
                reduce_dtype=torch.bfloat16,
                buffer_dtype=torch.bfloat16,
            )
            return bf16
        except ImportError:
            return None

    def get_auto_wrap_policy(self) -> Optional[Callable]:
        wrapping = FSDPWrappingPolicy(
            transformer_layer_cls=self.config.transformer_layer_cls,
            min_num_params=self.config.min_num_params,
        )
        return wrapping.get_policy(self.config.auto_wrap_policy)

    def get_cpu_offload(self) -> Optional[Any]:
        if not self.config.cpu_offload:
            return None
        try:
            from torch.distributed.fsdp import CPUOffload

            return CPUOffload(offload_params=True)
        except ImportError:
            return None

    def build_kwargs(self) -> Dict[str, Any]:
        kwargs: Dict[str, Any] = {
            "sharding_strategy": self.get_sharding_strategy(),
            "cpu_offload": self.get_cpu_offload(),
            "auto_wrap_policy": self.get_auto_wrap_policy(),
            "backward_prefetch": self.get_backward_prefetch(),
            "forward_prefetch": self.config.forward_prefetch,
            "limit_all_gathers": self.config.limit_all_gathers,
            "use_orig_params": self.config.use_orig_params,
            "sync_module_states": self.config.sync_module_states,
        }

        mixed_precision = self.get_mixed_precision_policy()
        if mixed_precision is not None:
            kwargs["mixed_precision"] = mixed_precision

        return kwargs

    @staticmethod
    def wrap_model_with_fsdp(
        model: nn.Module,
        config: FSDPConfig,
        device_id: Optional[Union[int, torch.device]] = None,
        param_init_fn: Optional[Callable[[nn.Module], None]] = None,
    ) -> nn.Module:
        try:
            from torch.distributed.fsdp import (
                FullyShardedDataParallel as FSDP,
                MixedPrecision,
                ShardingStrategy,
            )

            builder = FSDPConfigBuilder(config)
            kwargs = builder.build_kwargs()

            fsdp_kwargs: Dict[str, Any] = {}
            fsdp_kwargs["sharding_strategy"] = kwargs["sharding_strategy"]
            fsdp_kwargs["auto_wrap_policy"] = kwargs["auto_wrap_policy"]
            fsdp_kwargs["backward_prefetch"] = kwargs["backward_prefetch"]
            fsdp_kwargs["forward_prefetch"] = kwargs["forward_prefetch"]
            fsdp_kwargs["limit_all_gathers"] = kwargs["limit_all_gathers"]
            fsdp_kwargs["use_orig_params"] = kwargs["use_orig_params"]
            fsdp_kwargs["sync_module_states"] = kwargs["sync_module_states"]

            if kwargs.get("mixed_precision"):
                fsdp_kwargs["mixed_precision"] = kwargs["mixed_precision"]

            if kwargs.get("cpu_offload"):
                fsdp_kwargs["cpu_offload"] = kwargs["cpu_offload"]

            if device_id is not None:
                fsdp_kwargs["device_id"] = device_id

            if param_init_fn is not None:
                fsdp_kwargs["param_init_fn"] = param_init_fn

            return FSDP(model, **fsdp_kwargs)

        except ImportError:
            return model

    @staticmethod
    def get_param_groups_for_fsdp(
        model: nn.Module,
        weight_decay: float = 0.01,
        no_decay_params: Optional[List[str]] = None,
    ) -> List[Dict[str, Any]]:
        if no_decay_params is None:
            no_decay_params = ["bias", "layer_norm", "layernorm", "ln", "norm", "embed"]

        decay = []
        no_decay = []

        for name, param in model.named_parameters():
            if not param.requires_grad:
                continue
            if any(nd in name.lower() for nd in no_decay_params):
                no_decay.append(param)
            else:
                decay.append(param)

        return [
            {"params": decay, "weight_decay": weight_decay},
            {"params": no_decay, "weight_decay": 0.0},
        ]

    @staticmethod
    def supports_fsdp() -> bool:
        try:
            import torch.distributed.fsdp

            return hasattr(torch.distributed.fsdp, "FullyShardedDataParallel")
        except ImportError:
            return False
