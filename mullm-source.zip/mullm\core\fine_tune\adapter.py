from dataclasses import dataclass, field
from typing import Dict, List, Optional, Set, Union

import torch
import torch.nn as nn
import torch.nn.functional as F


@dataclass
class AdapterConfig:
    adapter_dim: int = 64
    adapter_dropout: float = 0.1
    activation_function: str = "gelu"
    use_parallel: bool = False
    use_scalar: bool = False
    scalar: float = 1.0
    target_modules: Optional[Set[str]] = None
    layernorm_before_adapter: bool = False
    adapter_length: Optional[int] = None
    fusion_mode: str = "mean"


class AdapterLayer(nn.Module):
    def __init__(
        self,
        hidden_size: int,
        adapter_dim: int = 64,
        dropout: float = 0.1,
        activation_function: str = "gelu",
        use_scalar: bool = False,
        scalar: float = 1.0,
    ):
        super().__init__()
        self.hidden_size = hidden_size
        self.adapter_dim = adapter_dim
        self.use_scalar = use_scalar

        self.down_proj = nn.Linear(hidden_size, adapter_dim, bias=False)
        self.activation = self._get_activation(activation_function)
        self.up_proj = nn.Linear(adapter_dim, hidden_size, bias=False)
        self.dropout = nn.Dropout(dropout)

        if use_scalar:
            self.scalar = nn.Parameter(torch.tensor(scalar))
        else:
            self.register_buffer("scalar", torch.tensor(1.0))

        self._init_weights()

    def _init_weights(self):
        nn.init.kaiming_uniform_(self.down_proj.weight, a=5**0.5)
        nn.init.zeros_(self.up_proj.weight)

    def _get_activation(self, name: str) -> nn.Module:
        activations = {
            "relu": nn.ReLU(),
            "gelu": nn.GELU(),
            "silu": nn.SiLU(),
            "tanh": nn.Tanh(),
            "sigmoid": nn.Sigmoid(),
        }
        return activations.get(name, nn.GELU())

    def forward(self, x: torch.Tensor, residual: Optional[torch.Tensor] = None) -> torch.Tensor:
        if residual is None:
            residual = x
        adapter_out = self.down_proj(x)
        adapter_out = self.activation(adapter_out)
        adapter_out = self.dropout(adapter_out)
        adapter_out = self.up_proj(adapter_out)
        adapter_out = adapter_out * self.scalar
        return residual + adapter_out


class ParallelAdapterLayer(nn.Module):
    def __init__(
        self,
        hidden_size: int,
        ffn_hidden_size: int,
        adapter_dim: int = 64,
        dropout: float = 0.1,
        activation_function: str = "gelu",
    ):
        super().__init__()
        self.hidden_size = hidden_size
        self.ffn_hidden_size = ffn_hidden_size
        self.adapter_dim = adapter_dim

        self.down_proj = nn.Linear(hidden_size, adapter_dim, bias=False)
        self.activation = self._get_activation(activation_function)
        self.up_proj = nn.Linear(adapter_dim, hidden_size, bias=False)
        self.dropout = nn.Dropout(dropout)

        self._init_weights()

    def _init_weights(self):
        nn.init.kaiming_uniform_(self.down_proj.weight, a=5**0.5)
        nn.init.zeros_(self.up_proj.weight)

    def _get_activation(self, name: str) -> nn.Module:
        activations = {
            "relu": nn.ReLU(),
            "gelu": nn.GELU(),
            "silu": nn.SiLU(),
            "tanh": nn.Tanh(),
            "sigmoid": nn.Sigmoid(),
        }
        return activations.get(name, nn.GELU())

    def forward(self, x: torch.Tensor, ffn_output: torch.Tensor) -> torch.Tensor:
        adapter_out = self.down_proj(x)
        adapter_out = self.activation(adapter_out)
        adapter_out = self.dropout(adapter_out)
        adapter_out = self.up_proj(adapter_out)
        return ffn_output + adapter_out


class AdapterFusion(nn.Module):
    def __init__(
        self,
        hidden_size: int,
        num_adapters: int,
        fusion_mode: str = "attention",
    ):
        super().__init__()
        self.hidden_size = hidden_size
        self.num_adapters = num_adapters
        self.fusion_mode = fusion_mode

        if fusion_mode == "attention":
            self.fusion_weights = nn.Linear(hidden_size, num_adapters)
        elif fusion_mode == "learned_avg":
            self.fusion_logits = nn.Parameter(torch.zeros(num_adapters))
        elif fusion_mode == "mean":
            self.fusion_logits = None
        else:
            raise ValueError(f"Unknown fusion mode: {fusion_mode}")

    def forward(
        self,
        x: torch.Tensor,
        adapter_outputs: List[torch.Tensor],
    ) -> torch.Tensor:
        if self.fusion_mode == "mean":
            stacked = torch.stack(adapter_outputs, dim=0)
            return stacked.mean(dim=0)

        if self.fusion_mode == "learned_avg":
            weights = F.softmax(self.fusion_logits, dim=-1)
            stacked = torch.stack(adapter_outputs, dim=-1)
            return (stacked * weights).sum(dim=-1)

        if self.fusion_mode == "attention":
            scores = self.fusion_weights(x)
            weights = F.softmax(scores, dim=-1)
            stacked = torch.stack(adapter_outputs, dim=-1)
            return (stacked * weights.unsqueeze(-2)).sum(dim=-1)

        raise ValueError(f"Unknown fusion mode: {self.fusion_mode}")


class ComposedAdapter(nn.Module):
    def __init__(
        self,
        hidden_size: int,
        configs: List[AdapterConfig],
    ):
        super().__init__()
        self.hidden_size = hidden_size
        self.adapters = nn.ModuleList([
            AdapterLayer(
                hidden_size=hidden_size,
                adapter_dim=config.adapter_dim,
                dropout=config.adapter_dropout,
                activation_function=config.activation_function,
            )
            for config in configs
        ])
        self.fusion = AdapterFusion(
            hidden_size=hidden_size,
            num_adapters=len(configs),
            fusion_mode=configs[0].fusion_mode if configs else "mean",
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        adapter_outputs = [adapter(x) for adapter in self.adapters]
        return self.fusion(x, adapter_outputs)


def inject_adapters(
    model: nn.Module,
    config: AdapterConfig,
) -> nn.Module:
    target_modules = config.target_modules
    if target_modules is None:
        target_modules = {"gate_proj", "up_proj", "down_proj"}

    for name, module in model.named_modules():
        if not any(t in name for t in target_modules):
            continue
        parent_name, child_name = name.rsplit(".", 1) if "." in name else ("", name)
        current = model
        if parent_name:
            for p in parent_name.split("."):
                current = getattr(current, p)
            parent = current
        else:
            parent = model

        if isinstance(module, nn.Linear):
            ffn_size = module.out_features if "down_proj" in name else module.in_features
            if config.use_parallel and "down_proj" not in name:
                adapter = ParallelAdapterLayer(
                    hidden_size=config.adapter_dim,
                    ffn_hidden_size=ffn_size,
                    adapter_dim=config.adapter_dim,
                    dropout=config.adapter_dropout,
                    activation_function=config.activation_function,
                )
            else:
                adapter = AdapterLayer(
                    hidden_size=module.in_features,
                    adapter_dim=config.adapter_dim,
                    dropout=config.adapter_dropout,
                    activation_function=config.activation_function,
                )
            setattr(parent, f"{child_name}_adapter", adapter)

    return model
